
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Activity,
  Zap,
  Database,
  Code,
  Network,
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Server,
  Box,
  Settings,
  Monitor,
  Globe,
  Fuel,
  Wand2 // New icon import
} from "lucide-react";

import NodeStatus from "../components/ethereum/NodeStatus";
import GasTracker from "../components/ethereum/GasTracker";
import ContractManager from "../components/ethereum/ContractManager";
import BridgeMonitor from "../components/ethereum/BridgeMonitor";
import DeployContractModal from '../components/ethereum/DeployContractModal';
import NodeSettingsModal from '../components/ethereum/NodeSettingsModal';
import NetworkConfigModal from '../components/ethereum/NetworkConfigModal';
import SecurityAuditModal from '../components/ethereum/SecurityAuditModal';
import SolidityContractWizard from '../components/ethereum/SolidityContractWizard'; // New import
import ContractSigningCard from '../components/ethereum/ContractSigningCard'; // New import

export default function EthereumConsole() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [nodeStatus, setNodeStatus] = useState({
    status: 'online',
    blockHeight: 18547293,
    peers: 47,
    syncProgress: 100,
    gasPrice: 23.5,
    networkHashrate: '892.3 TH/s'
  });
  const [networkStats, setNetworkStats] = useState({
    totalSupply: '120,389,847 ETH',
    marketCap: '$289.2B',
    transactions24h: '1,247,593',
    avgBlockTime: '12.1s',
    difficulty: '58.9T'
  });

  const [showDeployModal, setShowDeployModal] = useState(false);
  const [showNodeSettingsModal, setShowNodeSettingsModal] = useState(false);
  const [showNetworkConfigModal, setShowNetworkConfigModal] = useState(false);
  const [showSecurityAuditModal, setShowSecurityAuditModal] = useState(false);
  const [generatedContractForDeploy, setGeneratedContractForDeploy] = useState(null);
  const [contractAwaitingSignature, setContractAwaitingSignature] = useState(null); // New state

  // --- Style Definitions for Buttons ---
  const baseButtonStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '0.375rem',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
    cursor: 'pointer',
    border: '1px solid transparent',
    padding: '0.5rem 1rem'
  };
  
  const outlineStyle = { ...baseButtonStyle, backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' };
  const hoverOutlineStyle = { backgroundColor: 'rgba(255, 255, 255, 0.1)' };

  const tabsTriggerStyle = { ...baseButtonStyle, flex: 1, backgroundColor: 'transparent', color: '#a3a3a3' };
  const activeTabsTriggerStyle = { ...tabsTriggerStyle, backgroundColor: '#1e1e1e', color: '#60a5fa' };
  const hoverTabsTriggerStyle = { backgroundColor: 'rgba(255, 255, 255, 0.05)' };
  // --- End Style Definitions ---

  useEffect(() => {
    loadConsoleData();
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      updateRealTimeData();
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  const loadConsoleData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading console data:", error);
    }
  };

  const updateRealTimeData = () => {
    setNodeStatus(prev => ({
      ...prev,
      blockHeight: prev.blockHeight + Math.floor(Math.random() * 3),
      peers: prev.peers + Math.floor(Math.random() * 5) - 2,
      gasPrice: +(prev.gasPrice + (Math.random() - 0.5) * 2).toFixed(1)
    }));
  };

  const handleDeployFromWizard = (contract) => {
    setContractAwaitingSignature(contract);
  };
  
  const handleContractSigned = async (signedContract) => {
    // Process the signed contract
    setContractAwaitingSignature(null);
    
    // Show success message
    alert(`Contract "${signedContract.name}" deployment initiated!\nEstimated cost: ${signedContract.totalCost.toFixed(6)} ETH\nEstimated time: ${signedContract.estimatedTime}`);
  };

  const handleContractSigningCancelled = () => {
    setContractAwaitingSignature(null);
  };
  
  const closeAndResetDeployModal = () => {
    setShowDeployModal(false);
    setGeneratedContractForDeploy(null); // Reset on close
  }

  if (!user || (user.special_role !== 'admin' && user.special_role !== 'treasurer')) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8 text-center">
          <Shield className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-neutral-100 mb-2">Access Restricted</h3>
          <p className="text-neutral-400">Administrator access required for Ethereum Console</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-blue-700 rounded-xl flex items-center justify-center">
              <Box className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 mb-2">Ethereum Console</h1>
              <p className="text-neutral-400">
                Advanced Ethereum network management and monitoring
              </p>
              <div className="flex items-center gap-4 mt-2">
                <Badge className="bg-green-500/20 text-green-400">
                  <Activity className="w-3 h-3 mr-1" />
                  Network Online
                </Badge>
                <Badge className="bg-blue-500/20 text-blue-400">
                  Block #{nodeStatus.blockHeight.toLocaleString()}
                </Badge>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-neutral-400">Current Gas Price</div>
            <div className="text-2xl font-bold text-neutral-100">{nodeStatus.gasPrice} Gwei</div>
          </div>
        </div>
      </div>

      {/* Network Status Overview */}
      <div className="grid grid-cols-1 md::grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <p className="text-sm text-neutral-400">Node Status</p>
              <p className="text-lg font-bold text-green-400 capitalize">{nodeStatus.status}</p>
            </div>
          </div>
          <div className="text-xs text-neutral-500">
            Peers Connected: {nodeStatus.peers}
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Database className="w-5 h-5 text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-neutral-400">Total Supply</p>
              <p className="text-lg font-bold text-neutral-100">{networkStats.totalSupply}</p>
            </div>
          </div>
          <div className="text-xs text-neutral-500">
            Market Cap: {networkStats.marketCap}
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <p className="text-sm text-neutral-400">24h Transactions</p>
              <p className="text-lg font-bold text-neutral-100">{networkStats.transactions24h}</p>
            </div>
          </div>
          <div className="text-xs text-neutral-500">
            Avg Block Time: {networkStats.avgBlockTime}
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <Zap className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <p className="text-sm text-neutral-400">Network Hashrate</p>
              <p className="text-lg font-bold text-neutral-100">{nodeStatus.networkHashrate}</p>
            </div>
          </div>
          <div className="text-xs text-neutral-500">
            Difficulty: {networkStats.difficulty}
          </div>
        </div>
      </div>

      {/* Contract Signing Card - Shows when contract is awaiting signature */}
      {contractAwaitingSignature && (
        <ContractSigningCard
          contract={contractAwaitingSignature}
          onSign={handleContractSigned}
          onCancel={handleContractSigningCancelled}
          isVisible={!!contractAwaitingSignature}
        />
      )}

      {/* Main Console Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-effect">
          <TabsTrigger asChild value="overview">
            <button
              style={activeTab === 'overview' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'overview') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'overview') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Monitor className="w-4 h-4 mr-2" />
              Overview
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="node">
            <button
              style={activeTab === 'node' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'node') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'node') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Server className="w-4 h-4 mr-2" />
              Node Management
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="contracts">
            <button
              style={activeTab === 'contracts' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'contracts') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'contracts') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Code className="w-4 h-4 mr-2" />
              Smart Contracts
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="bridge">
            <button
              style={activeTab === 'bridge' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'bridge') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'bridge') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Network className="w-4 h-4 mr-2" />
              Bridge Monitor
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="wizard">
             <button
              style={activeTab === 'wizard' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'wizard') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'wizard') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Wand2 className="w-4 h-4 mr-2" />
              Contract Wizard
            </button>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Gas Tracker */}
          <GasTracker />

          {/* Quick Actions */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-lg font-bold text-neutral-100 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <button
                onClick={() => setShowDeployModal(true)}
                className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors cursor-pointer border-transparent px-4 py-2 text-white bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900"
              >
                <Fuel className="w-4 h-4 mr-2" />
                Deploy Contract
              </button>
              <button
                onClick={() => setShowNodeSettingsModal(true)}
                className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors cursor-pointer border-transparent px-4 py-2 text-white bg-gradient-to-r from-green-600 to-green-800 hover:from-green-700 hover:to-green-900"
              >
                <Settings className="w-4 h-4 mr-2" />
                Node Settings
              </button>
              <button
                onClick={() => setShowNetworkConfigModal(true)}
                className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors cursor-pointer border-transparent px-4 py-2 text-white bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900"
              >
                <Globe className="w-4 h-4 mr-2" />
                Network Config
              </button>
              <button
                onClick={() => setShowSecurityAuditModal(true)}
                className="inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors cursor-pointer border-transparent px-4 py-2 text-white bg-gradient-to-r from-red-600 to-red-800 hover:from-red-700 hover:to-red-900"
              >
                <Shield className="w-4 h-4 mr-2" />
                Security Audit
              </button>
            </div>
          </div>

          {/* Network Health */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-lg font-bold text-neutral-100 mb-4">Network Health</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Sync Status</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 bg-neutral-700 rounded-full h-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: `${nodeStatus.syncProgress}%` }}></div>
                  </div>
                  <span className="text-sm text-green-400">{nodeStatus.syncProgress}%</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Connection Quality</span>
                <Badge className="bg-green-500/20 text-green-400">Excellent</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Last Block</span>
                <span className="text-neutral-200">2 seconds ago</span>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="node" className="space-y-6">
          <NodeStatus />
        </TabsContent>

        <TabsContent value="contracts" className="space-y-6">
          <ContractManager />
        </TabsContent>

        <TabsContent value="bridge" className="space-y-6">
          <BridgeMonitor />
        </TabsContent>

        <TabsContent value="wizard" className="space-y-6">
          <SolidityContractWizard onDeploy={handleDeployFromWizard} />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <DeployContractModal 
        isOpen={showDeployModal} 
        onClose={closeAndResetDeployModal}
        initialContract={generatedContractForDeploy}
      />
      <NodeSettingsModal isOpen={showNodeSettingsModal} onClose={() => setShowNodeSettingsModal(false)} />
      <NetworkConfigModal isOpen={showNetworkConfigModal} onClose={() => setShowNetworkConfigModal(false)} />
      <SecurityAuditModal isOpen={showSecurityAuditModal} onClose={() => setShowSecurityAuditModal(false)} />
    </div>
  );
}
