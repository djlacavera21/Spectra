
import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Beaker, FileCode, Archive, Play } from 'lucide-react';

import ProjectConfiguration from '../components/incubator/ProjectConfiguration';
import CodeFileUpload from '../components/incubator/CodeFileUpload';
import LinuxShellEmulator from '../components/fabric/LinuxShellEmulator';

const coreFiles = [
  { name: 'main.cpp', desc: 'Main application entry point & node logic.', required: true },
  { name: 'wallet.cpp', desc: 'Core wallet functionality.', required: true },
  { name: 'db.cpp', desc: 'Blockchain database management.', required: true },
  { name: 'init.cpp', desc: 'Initialization and shutdown procedures.', required: true },
  { name: 'net.cpp', desc: 'P2P networking logic.', required: true },
  { name: 'util.cpp', desc: 'Utility functions and helpers.', required: true },
];

const headerFiles = [
  { name: 'headers.h', desc: 'Global header file.', required: true },
  { name: 'main.h', desc: 'Headers for main functions.', required: true },
  { name: 'wallet.h', desc: 'Headers for wallet functions.', required: true },
  { name: 'db.h', desc: 'Headers for database functions.', required: true },
  { name: 'net.h', desc: 'Headers for networking functions.', required: true },
];

const otherFiles = [
  { name: 'makefile.unix', desc: 'UNIX build instructions.', required: true },
  { name: 'license.txt', desc: 'Project license file.', required: false },
  { name: 'README.txt', desc: 'Project README file.', required: false },
  { name: 'bitcoin.ico', desc: 'Icon for desktop wallet.', required: false },
];

export default function CoinGenesisIncubator() {
  const [projectConfig, setProjectConfig] = useState({
    coinName: 'GenesisCoin',
    tickerSymbol: 'GEN',
    version: '0.1.0',
    amountToMint: 21000000
  });
  const [uploadedFiles, setUploadedFiles] = useState({});
  const [zipFile, setZipFile] = useState(null);
  const [buildState, setBuildState] = useState('idle'); // Kept for potential future use
  const shellRef = useRef(null);

  // Update shell configuration whenever project config changes
  useEffect(() => {
    if (shellRef.current && shellRef.current.setCoinConfig) {
      shellRef.current.setCoinConfig(projectConfig);
    }
  }, [projectConfig]);

  const handleFileChange = (fileName, file) => {
    setUploadedFiles(prev => ({ ...prev, [fileName]: file }));
  };

  const handleZipFileChange = (fileName, file) => {
    setZipFile(file);
  };
  
  const handleDeployFromZip = () => {
    if (zipFile && shellRef.current) {
      // Update shell with current configuration before deployment
      if (shellRef.current.setCoinConfig) {
        shellRef.current.setCoinConfig(projectConfig);
      }
      shellRef.current.runCommand('deploy-bitcoin-zip');
    } else {
      alert('Please upload bitcoin-master.zip first.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3">
          <Beaker className="w-8 h-8 text-red-400" />
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 gradient-text">Coin Genesis Incubator</h1>
            <p className="text-neutral-400">Admin-only console for creating and deploying new cryptocurrencies.</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Config & Deploy */}
        <div className="lg:col-span-1 space-y-6">
          <ProjectConfiguration config={projectConfig} setConfig={setProjectConfig} />
          
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-neutral-100">
                <Archive className="w-6 h-6 text-green-400" />
                <span>Deploy from Zip Archive</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <CodeFileUpload
                fileName="bitcoin-master.zip"
                description="Upload the complete source code archive."
                required={true}
                onFileChange={handleZipFileChange}
              />
              <Button 
                className="w-full bg-gradient-to-r from-green-500 to-green-700 text-white"
                disabled={!zipFile}
                onClick={handleDeployFromZip}
              >
                <Play className="w-5 h-5 mr-2" />
                Deploy {projectConfig.coinName} ({projectConfig.tickerSymbol})
              </Button>
              <Alert variant="default" className="bg-blue-500/10 border-blue-500/30">
                <AlertDescription className="text-blue-300 text-xs">
                  This will automatically replace Bitcoin references with your coin configuration, compile, and deploy {projectConfig.coinName}.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Codebase */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-neutral-100">
                <FileCode className="w-6 h-6 text-purple-400" />
                <span>Manual Codebase Upload</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 max-h-[600px] overflow-y-auto custom-scrollbar pr-2">
               <div className="space-y-2">
                <h4 className="font-medium text-neutral-300 text-sm">Deployment Script</h4>
                 <CodeFileUpload
                    fileName="deployment.sh"
                    description="All-in-one .sh script to create environment."
                    required={false}
                    onFileChange={handleFileChange}
                  />
              </div>
              <h3 className="font-semibold text-neutral-300 text-sm pt-4 -mb-2">Core Logic (.cpp)</h3>
              {coreFiles.map(f => <CodeFileUpload key={f.name} {...f} onFileChange={handleFileChange} />)}
              
              <h3 className="font-semibold text-neutral-300 text-sm pt-4 -mb-2">Headers (.h)</h3>
              {headerFiles.map(f => <CodeFileUpload key={f.name} {...f} onFileChange={handleFileChange} />)}
              
              <h3 className="font-semibold text-neutral-300 text-sm pt-4 -mb-2">Other Files</h3>
              {otherFiles.map(f => <CodeFileUpload key={f.name} {...f} onFileChange={handleFileChange} />)}
            </CardContent>
          </Card>
        </div>
      </div>
      
      <div>
        <LinuxShellEmulator ref={shellRef} />
      </div>
    </div>
  );
}
