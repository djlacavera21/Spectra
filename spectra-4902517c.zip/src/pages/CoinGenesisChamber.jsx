import React, { useState, useEffect } from "react";
import { User, Transaction, SystemSettings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Zap,
  Flame,
  Star,
  Crown,
  Sparkles,
  AlertTriangle,
  CheckCircle,
  Loader2,
  Lock,
  Unlock,
  Timer
} from "lucide-react";

const GENESIS_PHASES = [
  {
    id: 1,
    name: "Alpha Genesis",
    description: "Initial token creation phase",
    multiplier: 1.0,
    energyCost: 100,
    maxTokens: 1000,
    icon: Sparkles,
    color: "from-blue-500 to-purple-600"
  },
  {
    id: 2,
    name: "Beta Genesis",
    description: "Enhanced creation with 1.5x multiplier",
    multiplier: 1.5,
    energyCost: 200,
    maxTokens: 2500,
    icon: Star,
    color: "from-purple-500 to-pink-600"
  },
  {
    id: 3,
    name: "Gamma Genesis",
    description: "Advanced creation with 2x multiplier",
    multiplier: 2.0,
    energyCost: 500,
    maxTokens: 5000,
    icon: Flame,
    color: "from-orange-500 to-red-600"
  },
  {
    id: 4,
    name: "Omega Genesis",
    description: "Ultimate creation with 3x multiplier",
    multiplier: 3.0,
    energyCost: 1000,
    maxTokens: 10000,
    icon: Crown,
    color: "from-yellow-500 to-orange-600"
  }
];

export default function CoinGenesisChamber() {
  const [user, setUser] = useState(null);
  const [selectedPhase, setSelectedPhase] = useState(GENESIS_PHASES[0]);
  const [energyAmount, setEnergyAmount] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [creationProgress, setCreationProgress] = useState(0);
  const [recentCreations, setRecentCreations] = useState([]);
  const [totalEnergy, setTotalEnergy] = useState(0);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setTotalEnergy(currentUser.energy_balance || 1000); // Default energy

      // Load recent genesis transactions
      const creations = await Transaction.filter({
        from_address: currentUser.wallet_address,
        transaction_type: 'genesis_creation'
      }, '-created_date', 10);
      
      setRecentCreations(creations);
    } catch (error) {
      console.error("Error loading user data:", error);
    }
  };

  const calculateTokensGenerated = () => {
    const energy = parseFloat(energyAmount) || 0;
    if (energy < selectedPhase.energyCost) return 0;
    
    const baseTokens = Math.floor(energy / selectedPhase.energyCost) * 10;
    return Math.min(baseTokens * selectedPhase.multiplier, selectedPhase.maxTokens);
  };

  const handleGenesis = async () => {
    const energy = parseFloat(energyAmount);
    const tokensToGenerate = calculateTokensGenerated();
    
    if (!energy || energy < selectedPhase.energyCost) {
      alert(`Minimum energy required: ${selectedPhase.energyCost}`);
      return;
    }

    if (energy > totalEnergy) {
      alert(`Insufficient energy. You have ${totalEnergy} energy available.`);
      return;
    }

    if (!window.confirm(`Create ${tokensToGenerate} SPEC tokens using ${energy} energy in ${selectedPhase.name}?`)) {
      return;
    }

    setIsCreating(true);
    setCreationProgress(0);

    try {
      // Simulate genesis creation process
      for (let i = 0; i <= 100; i += 10) {
        setCreationProgress(i);
        await new Promise(resolve => setTimeout(resolve, 200));
      }

      // Deduct energy and add tokens
      const updates = {
        energy_balance: totalEnergy - energy,
        spec_balance: (user.spec_balance || 0) + tokensToGenerate,
        total_genesis_created: (user.total_genesis_created || 0) + tokensToGenerate
      };
      
      await User.updateMyUserData(updates);

      // Create transaction record
      const txHash = `0x${[...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      await Transaction.create({
        transaction_hash: txHash,
        from_address: user.wallet_address,
        to_address: user.wallet_address,
        amount: tokensToGenerate,
        transaction_type: 'genesis_creation',
        status: 'confirmed',
        gas_fee: 0,
        metadata: {
          genesis_phase: selectedPhase.name,
          energy_consumed: energy,
          multiplier: selectedPhase.multiplier,
          tokens_created: tokensToGenerate
        }
      });

      alert(`Successfully created ${tokensToGenerate} SPEC tokens!`);
      setEnergyAmount('');
      await loadUserData();
      
    } catch (error) {
      console.error("Genesis creation failed:", error);
      alert("Genesis creation failed. Please try again.");
    } finally {
      setIsCreating(false);
      setCreationProgress(0);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading Genesis Chamber...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 gradient-text">
                Coin Genesis Chamber
              </h1>
              <p className="text-neutral-400">
                Create SPEC tokens using pure energy
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-yellow-400">{totalEnergy.toLocaleString()}</div>
            <p className="text-sm text-neutral-400">Available Energy</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Genesis Phases */}
        <div className="lg:col-span-2 space-y-6">
          {/* Phase Selection */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100">Select Genesis Phase</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {GENESIS_PHASES.map((phase) => {
                  const IconComponent = phase.icon;
                  return (
                    <button
                      key={phase.id}
                      onClick={() => setSelectedPhase(phase)}
                      className={`p-4 rounded-xl border-2 transition-all ${
                        selectedPhase.id === phase.id 
                          ? 'border-purple-500 bg-purple-500/20' 
                          : 'border-white/20 bg-white/5 hover:border-white/30'
                      }`}
                    >
                      <div className={`w-8 h-8 bg-gradient-to-r ${phase.color} rounded-lg flex items-center justify-center mb-3`}>
                        <IconComponent className="w-5 h-5 text-white" />
                      </div>
                      <h3 className="text-neutral-100 font-semibold mb-1">{phase.name}</h3>
                      <p className="text-xs text-neutral-400 mb-2">{phase.description}</p>
                      <div className="flex justify-between text-xs">
                        <span className="text-green-400">{phase.multiplier}x multiplier</span>
                        <span className="text-blue-400">{phase.energyCost} energy/10 tokens</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Genesis Creation */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-400" />
                Create Tokens - {selectedPhase.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm text-neutral-400 mb-2">
                  Energy to Use
                </label>
                <div className="relative">
                  <Input
                    type="number"
                    placeholder="0"
                    value={energyAmount}
                    onChange={(e) => setEnergyAmount(e.target.value)}
                    className="text-xl font-medium bg-white/5 border-white/20 text-neutral-100 pr-20"
                    min={selectedPhase.energyCost}
                    step={selectedPhase.energyCost}
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                    ENERGY
                  </div>
                </div>
                <div className="flex gap-2 mt-2">
                  {[selectedPhase.energyCost, selectedPhase.energyCost * 2, selectedPhase.energyCost * 5].map(value => (
                    <Button
                      key={value}
                      variant="outline"
                      size="sm"
                      onClick={() => setEnergyAmount(value.toString())}
                      className="text-xs border-white/20 text-neutral-300 hover:bg-white/10"
                      disabled={value > totalEnergy}
                    >
                      {value}
                    </Button>
                  ))}
                </div>
              </div>

              {parseFloat(energyAmount) >= selectedPhase.energyCost && (
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="text-sm text-neutral-300 mb-3">Genesis Preview</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Energy Used</span>
                      <span className="text-neutral-200">{energyAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Phase Multiplier</span>
                      <span className="text-green-400">{selectedPhase.multiplier}x</span>
                    </div>
                    <div className="border-t border-white/10 pt-2 flex justify-between font-medium">
                      <span className="text-neutral-300">SPEC Tokens Created</span>
                      <span className="text-green-400">{calculateTokensGenerated()}</span>
                    </div>
                  </div>
                </div>
              )}

              {isCreating && (
                <div className="space-y-3">
                  <div className="flex items-center justify-center gap-2 text-purple-400">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    <span>Genesis in progress...</span>
                  </div>
                  <Progress value={creationProgress} className="h-2" />
                </div>
              )}

              <Button
                onClick={handleGenesis}
                disabled={isCreating || !energyAmount || parseFloat(energyAmount) < selectedPhase.energyCost}
                className={`w-full h-12 bg-gradient-to-r ${selectedPhase.color} text-white font-semibold`}
              >
                {isCreating ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Creating Tokens...
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <Zap className="w-5 h-5" />
                    Create {calculateTokensGenerated()} SPEC Tokens
                  </div>
                )}
              </Button>

              <Alert className="bg-purple-500/20 border-purple-500/30">
                <AlertTriangle className="w-4 h-4 text-purple-400" />
                <AlertDescription className="text-purple-400">
                  Genesis creation uses energy to create new SPEC tokens. Higher phases offer better multipliers but require more energy.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Stats */}
        <div className="space-y-6">
          {/* User Stats */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 text-sm">Genesis Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-neutral-100 mb-1">
                  {(user.spec_balance || 0).toLocaleString()}
                </div>
                <p className="text-xs text-neutral-400">Current SPEC Balance</p>
              </div>
              
              <div className="space-y-3 pt-4 border-t border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400 text-sm">Total Created</span>
                  <span className="text-green-400 font-medium">
                    {(user.total_genesis_created || 0).toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400 text-sm">Energy Balance</span>
                  <span className="text-yellow-400 font-medium">
                    {totalEnergy.toLocaleString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-neutral-400 text-sm">Genesis Sessions</span>
                  <span className="text-neutral-200 font-medium">
                    {recentCreations.length}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Genesis */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 text-sm">Recent Genesis</CardTitle>
            </CardHeader>
            <CardContent>
              {recentCreations.length > 0 ? (
                <div className="space-y-3">
                  {recentCreations.slice(0, 5).map((creation) => (
                    <div key={creation.id} className="glass-effect rounded-lg p-3">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-green-400">
                          +{creation.amount.toLocaleString()} SPEC
                        </span>
                        <Badge className="bg-purple-500/20 text-purple-400 text-xs">
                          {creation.metadata?.genesis_phase}
                        </Badge>
                      </div>
                      <div className="text-xs text-neutral-400">
                        {creation.metadata?.energy_consumed} energy • {new Date(creation.created_date).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-neutral-400">
                  <Zap className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No genesis sessions yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}