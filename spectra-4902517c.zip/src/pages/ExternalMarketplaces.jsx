
import React, { useState, useEffect } from "react";
import { ExternalMarketplace, User, Transaction, SystemSettings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Plus, 
  TrendingUp, 
  Settings, 
  CheckCircle,
  DollarSign,
  BarChart3,
  Network,
  X,
  Briefcase,
  Layers,
  Webhook,
  ExternalLink,
  AlertCircle
} from "lucide-react";
import { InvokeLLM } from "@/api/integrations";

const POPULAR_MARKETPLACES = [
  { 
    name: 'Binance', 
    type: 'CEX', 
    icon: Briefcase, 
    api_endpoint: 'https://api.binance.com/api/v3/ticker/price?symbol=SPECBTC', 
    trading_pairs: ['SPEC/USDT', 'SPEC/BTC', 'SPEC/ETH'],
    listing_url: 'https://www.binance.com/en/trade/SPEC_USDT',
    deposit_address: 'binance_spec_deposit_pool',
    required_liquidity: 100000
  },
  { 
    name: 'Coinbase', 
    type: 'CEX', 
    icon: Briefcase, 
    api_endpoint: 'https://api.coinbase.com/v2/prices/SPEC-USD/spot', 
    trading_pairs: ['SPEC/USD', 'SPEC/EUR'],
    listing_url: 'https://pro.coinbase.com/trade/SPEC-USD',
    deposit_address: 'coinbase_spec_custody',
    required_liquidity: 250000
  },
  { 
    name: 'Kraken', 
    type: 'CEX', 
    icon: Briefcase, 
    api_endpoint: 'https://api.kraken.com/0/public/Ticker?pair=SPECXBT', 
    trading_pairs: ['SPEC/BTC', 'SPEC/EUR', 'SPEC/USD'],
    listing_url: 'https://trade.kraken.com/markets/kraken/spec/usd',
    deposit_address: 'kraken_spec_vault',
    required_liquidity: 150000
  },
  { 
    name: 'Uniswap', 
    type: 'DEX', 
    icon: Webhook, 
    api_endpoint: 'https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3', 
    trading_pairs: ['SPEC/WETH', 'SPEC/USDC'],
    listing_url: 'https://app.uniswap.org/#/swap?outputCurrency=0x742d35Cc6634C0532925a3b8D4C2F1C6E2A5C123',
    deposit_address: '0x742d35Cc6634C0532925a3b8D4C2F1C6E2A5C123',
    required_liquidity: 50000
  },
  { 
    name: '1inch', 
    type: 'DEX Aggregator', 
    icon: Layers, 
    api_endpoint: 'https://api.1inch.io/v4.0/1/quote', 
    trading_pairs: ['SPEC/WETH', 'SPEC/DAI'],
    listing_url: 'https://app.1inch.io/#/1/unified/swap/ETH/SPEC',
    deposit_address: '0x1111111254fb6c44bAC0beD2854e76F90643097d',
    required_liquidity: 75000
  }
];

const MarketplaceConnectModal = ({ isOpen, onClose, onConnect, existingMarketplaces }) => {
  const [connectingMarketplace, setConnectingMarketplace] = useState(null);

  const handleConnect = async (marketplace) => {
    setConnectingMarketplace(marketplace.name);
    try {
      await onConnect(marketplace);
    } finally {
      setConnectingMarketplace(null);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="glass-card rounded-xl p-6 max-w-2xl w-full">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Network className="w-6 h-6 text-neutral-100" />
            <h3 className="text-xl font-bold text-neutral-100">Connect a Marketplace</h3>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5 text-neutral-400" />
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {POPULAR_MARKETPLACES.map(mp => {
            const isConnected = existingMarketplaces.some(em => em.marketplace_name === mp.name);
            const isConnecting = connectingMarketplace === mp.name;

            return (
              <div key={mp.name} className="glass-effect rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                      <mp.icon className="w-5 h-5 text-neutral-200" />
                    </div>
                    <div>
                      <p className="font-semibold text-neutral-100">{mp.name}</p>
                      <p className="text-xs text-neutral-400">{mp.type}</p>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleConnect(mp)}
                    disabled={isConnected || isConnecting}
                    className={isConnected ? 'bg-green-500/80 cursor-default' : 'bg-blue-600'}
                  >
                    {isConnected ? <CheckCircle className="w-4 h-4" /> : isConnecting ? (
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                    ) : "Connect"}
                  </Button>
                </div>
                
                <div className="text-xs text-neutral-400 space-y-1">
                  <div className="flex justify-between">
                    <span>Required Liquidity:</span>
                    <span>{mp.required_liquidity.toLocaleString()} SPEC</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Trading Pairs:</span>
                    <span>{mp.trading_pairs.length}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default function ExternalMarketplaces() {
  const [marketplaces, setMarketplaces] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    loadMarketplaceData();
  }, []);

  const loadMarketplaceData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      const marketplaceList = await ExternalMarketplace.list('-created_date');
      setMarketplaces(marketplaceList);
      
      if (marketplaceList.length > 0) {
        await updateMarketplaceMetrics(marketplaceList);
      }
      
    } catch (error) {
      console.error("Error loading marketplace data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateMarketplaceMetrics = async (marketplaceList) => {
    const activeMarketplaces = marketplaceList.filter(m => m.status === 'active');
    if (activeMarketplaces.length === 0) return;

    const updatedMetricsPromises = activeMarketplaces.map(marketplace => 
      InvokeLLM({
        prompt: `Generate realistic trading metrics for ${marketplace.marketplace_name} marketplace with SPEC token.`,
        response_json_schema: {
          type: "object",
          properties: {
            daily_volume: { type: "number" },
            liquidity_provided: { type: "number" },
            fees_earned: { type: "number" }
          }
        }
      }).then(metrics => ({ id: marketplace.id, ...metrics }))
    );
    
    const allMetrics = await Promise.all(updatedMetricsPromises);

    for (const data of allMetrics) {
      await ExternalMarketplace.update(data.id, {
        daily_volume: data.daily_volume || Math.floor(Math.random() * 1000000),
        liquidity_provided: data.liquidity_provided || Math.floor(Math.random() * 500000),
        fees_earned: data.fees_earned || Math.floor(Math.random() * 10000),
        last_sync: new Date().toISOString()
      });
    }
    
    const updatedList = await ExternalMarketplace.list('-created_date');
    setMarketplaces(updatedList);
  };

  const handleConnectMarketplace = async (marketplaceInfo) => {
    setIsProcessing(true);
    try {
      const liquidityAmount = marketplaceInfo.required_liquidity;

      // Step 1: Check Master Vault Balance
      const settingsList = await SystemSettings.list();
      if (settingsList.length === 0) throw new Error("System Settings not found. Cannot proceed with treasury funding.");
      const systemSettings = settingsList[0];
      const masterVaultBalance = systemSettings.total_spec_supply;

      if (masterVaultBalance < liquidityAmount) {
        throw new Error(`Insufficient balance in Master Vault. Required: ${liquidityAmount.toLocaleString()} SPEC, Available: ${masterVaultBalance.toLocaleString()} SPEC`);
      }
      
      // Step 2: Transfer SPEC tokens from Master Vault (simulated via LLM)
      const transferResult = await InvokeLLM({
        prompt: `Execute SPEC token transfer from Master Vault to ${marketplaceInfo.name}. Transfer ${liquidityAmount} SPEC tokens to ${marketplaceInfo.deposit_address} for liquidity provision.`,
        response_json_schema: {
          type: "object",
          properties: {
            success: { type: "boolean" },
            transfer_tx_hash: { type: "string" },
            message: { type: "string" }
          }
        }
      });

      if (!transferResult.success) {
        throw new Error(transferResult.message || 'Token transfer from Master Vault failed');
      }

      // Step 3: Create transaction record for the transfer
      await Transaction.create({
        transaction_hash: transferResult.transfer_tx_hash,
        from_address: 'MasterVault_Treasury',
        to_address: marketplaceInfo.deposit_address,
        amount: liquidityAmount,
        transaction_type: 'transfer',
        status: 'confirmed',
        gas_fee: 0.001, // Example gas fee
        block_number: Math.floor(Math.random() * 1000000) + 600000, // Example block number
        metadata: {
          marketplace_name: marketplaceInfo.name,
          liquidity_provision: true,
          purpose: 'marketplace_listing_treasury'
        }
      });

      // Step 4: Update Master Vault balance
      await SystemSettings.update(systemSettings.id, {
        total_spec_supply: masterVaultBalance - liquidityAmount
      });

      // Step 5: API Integration with marketplace (simulated via LLM)
      const integrationResult = await InvokeLLM({
        prompt: `Complete API integration with ${marketplaceInfo.name} exchange. Create SPEC token listing with ${liquidityAmount} SPEC liquidity. Generate trading pairs and market making setup.`,
        response_json_schema: {
          type: "object",
          properties: {
            success: { type: "boolean" },
            listing_id: { type: "string" },
            trading_pairs_created: { type: "array", "items": { type: "string" } },
            message: { type: "string" }
          }
        }
      });
      
      if (!integrationResult.success) {
        // NOTE: In a real app, you would have a rollback transaction here to return funds to the vault.
        // For this simulation, we'll just throw an error.
        throw new Error(integrationResult.message || `Failed to complete listing on ${marketplaceInfo.name}.`);
      }

      // Step 6: Create marketplace record
      await ExternalMarketplace.create({
        marketplace_name: marketplaceInfo.name,
        marketplace_type: marketplaceInfo.type.toLowerCase().replace(' ', '_'),
        api_endpoint: marketplaceInfo.api_endpoint,
        trading_pairs: integrationResult.trading_pairs_created || marketplaceInfo.trading_pairs,
        status: 'active',
        daily_volume: 0,
        liquidity_provided: liquidityAmount,
        fees_earned: 0,
        last_sync: new Date().toISOString(),
        listing_url: marketplaceInfo.listing_url,
        deposit_address: marketplaceInfo.deposit_address,
        listing_id: integrationResult.listing_id
      });
      
      setShowConnectModal(false);
      await loadMarketplaceData(); // Reload all data to reflect changes
      
      alert(`Successfully connected to ${marketplaceInfo.name}!\n\nLiquidity of ${liquidityAmount.toLocaleString()} SPEC provisioned from the Master Vault.\nListing ID: ${integrationResult.listing_id}\n\n${integrationResult.message}`);
      
    } catch (error) {
      alert('Failed to connect marketplace: ' + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const syncMarketplace = async (marketplaceId) => {
    setIsProcessing(true);
    try {
      const marketplace = marketplaces.find(m => m.id === marketplaceId);
      
      const syncResult = await InvokeLLM({
        prompt: `Sync trading data for ${marketplace.marketplace_name} marketplace. Update volume, liquidity, and fees based on current market activity.`,
        response_json_schema: {
          type: "object",
          properties: {
            success: { type: "boolean" },
            daily_volume: { type: "number" },
            liquidity_provided: { type: "number" },
            fees_earned: { type: "number" },
            message: { type: "string" }
          }
        }
      });
      
      if (syncResult.success) {
        await ExternalMarketplace.update(marketplaceId, {
          daily_volume: syncResult.daily_volume,
          liquidity_provided: syncResult.liquidity_provided,
          fees_earned: syncResult.fees_earned,
          last_sync: new Date().toISOString(),
          status: 'active'
        });
        
        await loadMarketplaceData();
        alert('Marketplace sync successful!');
      } else {
        throw new Error(syncResult.message || 'Sync failed.');
      }
      
    } catch (error) {
      alert('Sync failed: ' + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const getStatusBadge = (status) => {
    const colors = {
      active: 'bg-green-500/20 text-green-400 border-green-500/30',
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      inactive: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
      error: 'bg-red-500/20 text-red-400 border-red-500/30'
    };
    return colors[status] || colors.inactive;
  };

  if (isLoading && marketplaces.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-neutral-400 mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading marketplaces...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <MarketplaceConnectModal 
        isOpen={showConnectModal}
        onClose={() => setShowConnectModal(false)}
        onConnect={handleConnectMarketplace}
        existingMarketplaces={marketplaces}
      />

      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-gray-500 to-gray-700 rounded-xl flex items-center justify-center">
              <Network className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 gradient-text">External Marketplaces</h1>
              <p className="text-neutral-400">Manage SPEC token listings across exchanges</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {user?.special_role === 'treasurer' && (
              <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                TREASURER ACCESS
              </Badge>
            )}
            <Button
              onClick={() => setShowConnectModal(true)}
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
              disabled={user?.special_role !== 'treasurer'}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Marketplace
            </Button>
          </div>
        </div>
        {user?.special_role !== 'treasurer' && (
          <div className="mt-4">
             <Alert className="bg-yellow-500/20 border-yellow-500/30">
                <AlertCircle className="w-4 h-4 text-yellow-400" />
                <AlertDescription className="text-yellow-400">
                  Marketplace management is restricted to users with the 'Treasurer' role.
                </AlertDescription>
              </Alert>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Network className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-sm text-neutral-400">Total Marketplaces</p>
              <p className="text-2xl font-bold text-neutral-100">{marketplaces.length}</p>
            </div>
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <BarChart3 className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-sm text-neutral-400">Total Volume (24h)</p>
              <p className="text-2xl font-bold text-neutral-100">
                {marketplaces.reduce((sum, m) => sum + (m.daily_volume || 0), 0).toLocaleString()} SPEC
              </p>
            </div>
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <DollarSign className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-sm text-neutral-400">Total Liquidity</p>
              <p className="text-2xl font-bold text-neutral-100">
                {marketplaces.reduce((sum, m) => sum + (m.liquidity_provided || 0), 0).toLocaleString()} SPEC
              </p>
            </div>
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-sm text-neutral-400">Fees Earned</p>
              <p className="text-2xl font-bold text-neutral-100">
                {marketplaces.reduce((sum, m) => sum + (m.fees_earned || 0), 0).toLocaleString()} SPEC
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {marketplaces.map((marketplace) => (
          <div key={marketplace.id} className="glass-card rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl flex items-center justify-center">
                  <span className="text-white font-bold text-lg">
                    {marketplace.marketplace_name.charAt(0)}
                  </span>
                </div>
                <div>
                  <h3 className="font-bold text-neutral-100">{marketplace.marketplace_name}</h3>
                  <p className="text-sm text-neutral-400 capitalize">{marketplace.marketplace_type}</p>
                  {marketplace.listing_id && (
                    <p className="text-xs text-neutral-500">ID: {marketplace.listing_id}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Badge className={getStatusBadge(marketplace.status)}>
                  {marketplace.status.toUpperCase()}
                </Badge>
                {marketplace.listing_url && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.open(marketplace.listing_url, '_blank')}
                    className="border-gray-500/30 text-gray-400 hover:bg-gray-500/20"
                  >
                    <ExternalLink className="w-4 h-4 mr-1" />
                    View Trading
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => syncMarketplace(marketplace.id)}
                  disabled={isProcessing}
                  className="border-white/20 text-neutral-200 hover:bg-white/10"
                >
                  <Settings className="w-4 h-4 mr-1" />
                  Sync
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div className="glass-effect rounded-lg p-3">
                <p className="text-xs text-neutral-400">24h Volume</p>
                <p className="font-bold text-neutral-100">{(marketplace.daily_volume || 0).toLocaleString()} SPEC</p>
              </div>
              <div className="glass-effect rounded-lg p-3">
                <p className="text-xs text-neutral-400">Liquidity</p>
                <p className="font-bold text-neutral-100">{(marketplace.liquidity_provided || 0).toLocaleString()} SPEC</p>
              </div>
              <div className="glass-effect rounded-lg p-3">
                <p className="text-xs text-neutral-400">Fees Earned</p>
                <p className="font-bold text-neutral-100">{(marketplace.fees_earned || 0).toLocaleString()} SPEC</p>
              </div>
              <div className="glass-effect rounded-lg p-3">
                <p className="text-xs text-neutral-400">Trading Pairs</p>
                <p className="font-bold text-neutral-100">{marketplace.trading_pairs?.length || 0} pairs</p>
              </div>
            </div>

            {/* Trading Pairs with Direct Links */}
            {marketplace.trading_pairs && marketplace.trading_pairs.length > 0 && (
              <div className="mb-4">
                <p className="text-sm text-neutral-400 mb-2">Available Trading Pairs:</p>
                <div className="flex flex-wrap gap-2">
                  {marketplace.trading_pairs.map((pair, index) => {
                    const pairUrl = generatePairUrl(marketplace.marketplace_name, pair);
                    return (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(pairUrl, '_blank')}
                        className="border-green-500/30 text-green-400 hover:bg-green-500/20 text-xs"
                      >
                        {pair}
                        <ExternalLink className="w-3 h-3 ml-1" />
                      </Button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Marketplace Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {marketplace.deposit_address && (
                <div className="glass-effect rounded-lg p-3">
                  <p className="text-xs text-neutral-400 mb-1">Deposit Address:</p>
                  <p className="font-mono text-xs text-neutral-300 break-all">{marketplace.deposit_address}</p>
                </div>
              )}
              
              {marketplace.api_endpoint && (
                <div className="glass-effect rounded-lg p-3">
                  <p className="text-xs text-neutral-400 mb-1">API Endpoint:</p>
                  <div className="flex items-center gap-2">
                    <p className="font-mono text-xs text-neutral-300 truncate">{marketplace.api_endpoint}</p>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => window.open(marketplace.api_endpoint, '_blank')}
                      className="text-blue-400 hover:text-blue-300 p-1 h-auto"
                    >
                      <ExternalLink className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              )}
            </div>

            {marketplace.last_sync && (
              <p className="text-xs text-neutral-500 mt-3">
                Last sync: {new Date(marketplace.last_sync).toLocaleString()}
              </p>
            )}
          </div>
        ))}
      </div>

      {marketplaces.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <div className="glass-card rounded-xl p-8 max-w-md mx-auto">
            <Network className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-neutral-100 mb-2">No marketplaces added</h3>
            <p className="text-neutral-400 mb-6">Start expanding SPEC token presence by adding external marketplaces</p>
            <Button
              onClick={() => setShowConnectModal(true)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
              disabled={user?.special_role !== 'treasurer'}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add First Marketplace
            </Button>
            {user?.special_role !== 'treasurer' && (
              <div className="mt-4">
                <Alert className="bg-yellow-500/20 border-yellow-500/30">
                  <AlertCircle className="w-4 h-4 text-yellow-400" />
                  <AlertDescription className="text-yellow-400">
                    Marketplace management is restricted to users with the 'Treasurer' role.
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// Helper function to generate specific trading pair URLs
function generatePairUrl(marketplaceName, pair) {
  const baseUrls = {
    'Binance': 'https://www.binance.com/en/trade/',
    'Coinbase': 'https://pro.coinbase.com/trade/',
    'Kraken': 'https://trade.kraken.com/markets/kraken/',
    'Uniswap': 'https://app.uniswap.org/#/swap?inputCurrency=ETH&outputCurrency=', // Assuming ETH as common input for SPEC pairs
    '1inch': 'https://app.1inch.io/#/1/unified/swap/'
  };

  const baseUrl = baseUrls[marketplaceName];
  if (!baseUrl) return '#';

  // Format pair for each marketplace
  switch (marketplaceName) {
    case 'Binance':
      return `${baseUrl}${pair.replace('/', '_')}`;
    case 'Coinbase':
      return `${baseUrl}${pair.replace('/', '-')}`;
    case 'Kraken':
      // Kraken uses lowercase pairs, e.g., 'specs/usd' for 'SPEC/USD' (need to adjust base to 'kraken/specs/usd')
      // For general Kraken trading pair URL structure, it's usually `markets/exchange/base/quote`
      // Given the outline, we'll follow this structure: `kraken/spec/usd`
      const [baseKraken, quoteKraken] = pair.split('/');
      return `${baseUrls['Kraken']}${baseKraken.toLowerCase()}/${quoteKraken.toLowerCase()}`;
    case 'Uniswap':
      // For Uniswap, we need token contract addresses. Using a placeholder SPEC address for the output.
      // In a real scenario, this would likely involve a token registry or mapping.
      const SPEC_TOKEN_ADDRESS = '0x742d35Cc6634C0532925a3b8D4C2F1C6E2A5C123'; // Example SPEC token contract address
      if (pair.includes('SPEC/WETH')) return `${baseUrl}${SPEC_TOKEN_ADDRESS}`;
      if (pair.includes('SPEC/USDC')) return `${baseUrl}${SPEC_TOKEN_ADDRESS}`; // Assuming same SPEC token
      return baseUrl; // Fallback to base Uniswap swap page
    case '1inch':
      const [from, to] = pair.split('/');
      return `${baseUrl}${from}/${to}`;
    default:
      return '#';
  }
}
