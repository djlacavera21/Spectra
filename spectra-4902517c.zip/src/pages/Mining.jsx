import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Pickaxe, Server, Cpu, GitBranch } from 'lucide-react';
import PoolConfiguration from '../components/mining/PoolConfiguration';
import MiningStats from '../components/mining/MiningStats';
import MiningRewards from '../components/mining/MiningRewards';
import InfrastructureToolsuite from '../components/mining/InfrastructureToolsuite';
import FabricMiningConsole from '../components/mining/FabricMiningConsole'; // New Import

export default function MiningPage() {
  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Pickaxe className="w-8 h-8 text-yellow-400" />
            <div>
              <CardTitle className="text-2xl font-bold text-neutral-100">Mining Operations</CardTitle>
              <p className="text-neutral-400">Manage and monitor your mining activities on the Spectra network.</p>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs defaultValue="fabric-mining" className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass-effect">
          <TabsTrigger value="fabric-mining" className="text-neutral-300 data-[state=active]:text-white">
            <GitBranch className="w-4 h-4 mr-2" />
            Fabric Mining
          </TabsTrigger>
          <TabsTrigger value="pool-config" className="text-neutral-300 data-[state=active]:text-white">
            <Cpu className="w-4 h-4 mr-2" />
            Pool Configuration
          </TabsTrigger>
          <TabsTrigger value="infrastructure" className="text-neutral-300 data-[state=active]:text-white">
            <Server className="w-4 h-4 mr-2" />
            Infrastructure Suite
          </TabsTrigger>
        </TabsList>
        <TabsContent value="fabric-mining" className="mt-6">
          <FabricMiningConsole />
        </TabsContent>
        <TabsContent value="pool-config" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <PoolConfiguration />
            </div>
            <div className="space-y-6">
              <MiningStats />
              <MiningRewards />
            </div>
          </div>
        </TabsContent>
        <TabsContent value="infrastructure" className="mt-6">
          <InfrastructureToolsuite />
        </TabsContent>
      </Tabs>
    </div>
  );
}