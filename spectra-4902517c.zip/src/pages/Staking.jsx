
import React, { useState, useEffect, useCallback } from "react";
import { User, StakingPosition, StakingReward, SystemSettings } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Zap,
  TrendingUp,
  Lock,
  Unlock,
  Gift,
  Plus,
  Activity,
  Shield // Added Shield icon
} from "lucide-react";
import { format, addDays } from "date-fns";

const STAKING_POOLS = {
  SPEC: {
    name: "Spectra Coin",
    icon: Zap,
    options: [
      { period: 0, apy: 5.5, label: "Flexible" },
      { period: 30, apy: 7.2, label: "30 Days" },
      { period: 90, apy: 10.0, label: "90 Days" },
    ]
  },
  ETH: {
    name: "Ethereum",
    icon: () => (
      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
        <path d="M11.944 17.97L4.58 13.62 11.943 24l7.37-10.38-7.372 4.35h.003zM12.056 0L4.69 12.223l7.365 4.354 7.365-4.35L12.056 0z"/>
      </svg>
    ),
    options: [
      { period: 0, apy: 3.8, label: "Flexible" },
      { period: 60, apy: 4.5, label: "60 Days" },
    ]
  },
  BTC: {
    name: "Bitcoin",
    icon: () => (
      <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
         <path d="M12.83,3.06C13.21,3.2,14.5,4,14.5,4S13.43,4.64,13,4.5C11.5,4.1,8.32,4.36,6.6,5.65C4.05,7.45,4.5,10.65,4.5,10.65S4.17,9.6,4.5,9.25C5.17,8.55,6.6,8.1,7.8,8.5C8.8,8.8,9.5,9.44,9.5,9.44L9.83,9.05C8.5,8.05,7.17,7.8,5.85,8.5C3.9,9.6,3.17,12.15,3.17,12.15S3.5,13.25,3.83,13.5C4.5,14.1,5.83,14.3,6.83,14S8.17,13.5,8.17,13.5L8.5,12.83C8.5,12.83,7.5,12.45,7,12.17C6.17,11.72,5.5,10.83,5.5,10.83S6.83,11.5,8.17,11.17C10.17,10.67,10.5,8.5,10.5,8.5S11.17,9.17,11,9.5C10.83,9.83,10.17,10.17,10.17,10.17L9.83,10.5C11.17,11.5,13.17,11.83,14.5,11.17C16.5,10.17,17.17,7.5,17.17,7.5S16.83,6.5,16.5,6.17C15.83,5.5,14.5,5.17,13.5,5.5C12.5,5.83,11.83,6.5,11.83,6.5L11.5,6.83S12.5,7.17,13,7.5C13.83,7.83,14.5,8.83,14.5,8.83S13.17,8.17,11.83,8.5C9.83,9,9.5,11.17,9.5,11.17S8.83,10.5,9,10.17C9.17,9.83,9.83,9.5,9.83,9.5L10.17,9.17C8.83,8.17,6.83,7.83,5.5,8.5C3.5,9.5,2.83,12.17,2.83,12.17S2.5,13.17,2.17,13.5C1.5,14.17,0.17,14.5,0.17,14.5S2.17,16.17,4.17,17.17C6.83,18.5,10.17,18.5,12.17,18.5C14.17,18.5,16.5,17.83,18.17,16.5C19.5,15.17,19.83,13.17,19.83,13.17L19.5,13.5S19.17,14.17,17.83,14.83C15.83,15.83,13.17,15.83,11.17,15.17C9.17,14.5,8.5,12.5,8.5,12.5S8.83,11.83,9,11.5C9.17,11.17,9.83,10.83,9.83,10.83L10.5,11.17S11.5,11.55,12.17,11.83C12.83,12.17,14.17,12.5,14.17,12.5L13.83,12.83S13.5,13.17,13.17,13.33C12.83,13.5,12.17,13.83,12.17,13.83S11.5,14.17,11.83,14.5C12.5,15.17,13.83,15.5,14.83,15.17C16.17,14.83,17.17,13.83,17.17,13.83S18.5,15.17,19.5,15.83C20.83,16.83,22.5,16.83,23.83,15.83C25.5,14.5,25.83,12.5,25.83,12.5S20.17,4.83,12.83,3.06Z" />
      </svg>
    ),
    options: [
      { period: 90, apy: 1.5, label: "90 Days" },
      { period: 180, apy: 2.1, label: "180 Days" },
    ]
  }
};

export default function StakingPage() {
  const [user, setUser] = useState(null);
  const [balances, setBalances] = useState({});
  const [stakingPositions, setStakingPositions] = useState([]);
  const [stakeAmount, setStakeAmount] = useState('');
  const [selectedPool, setSelectedPool] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const loadStakingData = useCallback(async () => {
    try {
      const currentUser = await User.me();
      if (!currentUser) {
        setIsLoading(false);
        return; // User not logged in, stop execution to prevent errors
      }
      setUser(currentUser);
      
      const userBalances = {
        SPEC: currentUser.spec_balance || 0,
        ETH: currentUser.eth_balance || 0, // Updated to use actual user balance
        BTC: currentUser.btc_balance || 0  // Updated to use actual user balance
      };
      setBalances(userBalances);

      const positions = await StakingPosition.filter({ user_wallet: currentUser.wallet_address }, '-stake_date');
      
      // Update rewards for all positions before displaying
      const updatedPositions = await Promise.all(
        positions.map(async (pos) => {
          if (pos.status === 'active') {
            const now = new Date();
            const lastUpdate = new Date(pos.last_reward_update);
            const secondsDiff = (now.getTime() - lastUpdate.getTime()) / 1000;
            
            if (secondsDiff > 0) {
              const secondsInYear = 365 * 24 * 60 * 60;
              const rewardPerSecond = (pos.amount_staked * (pos.apy_rate / 100)) / secondsInYear;
              const newRewards = rewardPerSecond * secondsDiff;
              
              const updatedPosData = {
                rewards_accrued: (pos.rewards_accrued || 0) + newRewards,
                last_reward_update: now.toISOString(),
                status: new Date(pos.unlock_date) <= now ? 'unlocked' : 'active'
              };
              
              await StakingPosition.update(pos.id, updatedPosData);
              return { ...pos, ...updatedPosData };
            }
          }
          return pos;
        })
      );
      
      setStakingPositions(updatedPositions);
    } catch (error) {
      console.error("Error loading staking data:", error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStakingData();
    const interval = setInterval(loadStakingData, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [loadStakingData]);

  const handleStake = async () => {
    if (!stakeAmount || !selectedPool || parseFloat(stakeAmount) <= 0) return;
    
    const amount = parseFloat(stakeAmount);
    
    // For external wallets (non-SPEC tokens), mint new SPEC as rewards
    if (selectedPool.symbol !== 'SPEC') {
      // Simulate external wallet staking - mint new SPEC tokens
      const rewardAmount = amount * 0.1; // 10% bonus for external staking (example rate)
      
      setIsProcessing(true);
      try {
        const now = new Date();
        const unlockDate = addDays(now, selectedPool.period);
        
        await StakingPosition.create({
          user_wallet: user.wallet_address,
          token_symbol: selectedPool.symbol,
          amount_staked: amount,
          apy_rate: selectedPool.apy,
          stake_date: now.toISOString(),
          lockup_period_days: selectedPool.period,
          unlock_date: unlockDate.toISOString(),
          last_reward_update: now.toISOString(),
          rewards_accrued: 0,
          status: 'active'
        });
        
        // Mint new SPEC tokens as staking bonus
        await User.updateMyUserData({ 
          spec_balance: user.spec_balance + rewardAmount 
        });
        
        // Update total supply (simulate minting)
        const systemSettings = await SystemSettings.list();
        if (systemSettings.length > 0) {
          await SystemSettings.update(systemSettings[0].id, {
            total_spec_supply: (systemSettings[0].total_spec_supply || 0) + rewardAmount,
            minted_spec_supply: (systemSettings[0].minted_spec_supply || 0) + rewardAmount
          });
        } else {
            // If no SystemSettings record exists, create one with initial values
            await SystemSettings.create({
                total_spec_supply: rewardAmount,
                minted_spec_supply: rewardAmount,
                current_block_height: 0, // Placeholder, adjust as needed
                dao_treasury_balance: 0, // Placeholder, adjust as needed
            });
        }
        
        setStakeAmount('');
        setSelectedPool(null);
        loadStakingData();
        alert(`Stake successful! Minted ${rewardAmount.toFixed(2)} SPEC as staking bonus.`);
      } catch (error) {
        alert("Staking failed: " + error.message);
      } finally {
        setIsProcessing(false);
      }
    } else {
      // Regular SPEC staking
      if (amount > balances[selectedPool.symbol]) {
        alert(`Insufficient ${selectedPool.symbol} balance.`);
        return;
      }

      setIsProcessing(true);
      try {
        const now = new Date();
        const unlockDate = addDays(now, selectedPool.period);
        
        await StakingPosition.create({
          user_wallet: user.wallet_address,
          token_symbol: selectedPool.symbol,
          amount_staked: amount,
          apy_rate: selectedPool.apy,
          stake_date: now.toISOString(),
          lockup_period_days: selectedPool.period,
          unlock_date: unlockDate.toISOString(),
          last_reward_update: now.toISOString(),
          rewards_accrued: 0,
          status: 'active'
        });
        
        await User.updateMyUserData({ spec_balance: user.spec_balance - amount });
        
        setStakeAmount('');
        setSelectedPool(null);
        loadStakingData();
        alert('Stake successful!');
      } catch (error) {
        alert("Staking failed: " + error.message);
      } finally {
        setIsProcessing(false);
      }
    }
  };

  const handleClaimRewards = async (position) => {
    if (!position.rewards_accrued || position.rewards_accrued <= 0) return;

    setIsProcessing(true);
    try {
      await StakingReward.create({
        user_wallet: user.wallet_address,
        staking_position_id: position.id,
        token_symbol: position.token_symbol, // This would be the token that generated the rewards
        reward_amount: position.rewards_accrued,
        claim_date: new Date().toISOString(),
      });
      
      // All staking rewards are in SPEC
      await User.updateMyUserData({
        spec_balance: user.spec_balance + position.rewards_accrued
      });
      
      await StakingPosition.update(position.id, { rewards_accrued: 0 });
      
      loadStakingData();
      alert('Rewards claimed successfully!');
    } catch (error) {
      alert("Failed to claim rewards: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUnstake = async (position) => {
    if (position.status !== 'unlocked') {
      alert('This position is still locked.');
      return;
    }
    
    setIsProcessing(true);
    try {
      // First, claim any remaining rewards
      if (position.rewards_accrued > 0) {
        await handleClaimRewards(position);
      }
      
      await StakingPosition.update(position.id, { status: 'withdrawn' });

      // Return principal amount logic:
      if (position.token_symbol === 'SPEC') {
        const currentUser = await User.me(); // Fetch current user to ensure latest balance for update
        await User.updateMyUserData({ spec_balance: currentUser.spec_balance + position.amount_staked });
      } else {
        // For external tokens, the principal is not returned to an internal balance
        // as it was never transferred here in the first place.
        // It's a simulation that the user's external wallet is now "unlocked" from the stake.
        alert(`Your ${position.amount_staked} ${position.token_symbol} has been returned to your external wallet.`);
      }
      
      loadStakingData();
      alert('Unstaked successfully!');
    } catch (error) {
      alert("Unstaking failed: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };
  
  const StakingPoolCard = ({ symbol, pool }) => (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
          <pool.icon className="w-6 h-6 text-neutral-100" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-neutral-100">{pool.name}</h3>
          <p className="text-sm text-neutral-400">Stake {symbol}, Earn SPEC</p>
        </div>
      </div>
      <div className="space-y-3">
        {pool.options.map(option => (
          <div key={option.period} className="glass-effect p-3 rounded-lg flex justify-between items-center">
            <div>
              <p className="font-semibold text-neutral-200">{option.label}</p>
              <p className="text-sm text-green-400">{option.apy}% APY</p>
            </div>
            <Button size="sm" onClick={() => setSelectedPool({ ...option, symbol })}>
              Stake
            </Button>
          </div>
        ))}
      </div>
    </div>
  );

  const MyStakes = () => (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">My Staking Positions</h3>
      <div className="space-y-4">
        {stakingPositions.filter(p => p.status !== 'withdrawn').length > 0 ? (
          stakingPositions.filter(p => p.status !== 'withdrawn').map(pos => (
            <div key={pos.id} className="glass-effect rounded-lg p-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <p className="font-bold text-lg text-neutral-100">{pos.amount_staked.toLocaleString()} {pos.token_symbol}</p>
                  <p className="text-sm text-neutral-400">Staked on {format(new Date(pos.stake_date), 'MMM d, yyyy')}</p>
                </div>
                <div>
                  <p className="font-semibold text-green-400">{pos.apy_rate}% APY</p>
                  <p className="text-sm text-neutral-400">{pos.lockup_period_days > 0 ? `${pos.lockup_period_days} Day Lock` : 'Flexible'}</p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg text-blue-400">{pos.rewards_accrued.toFixed(6)} SPEC</p>
                  <p className="text-sm text-neutral-400">Rewards Accrued</p>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={() => handleClaimRewards(pos)} disabled={isProcessing || pos.rewards_accrued <= 0}>
                    <Gift className="w-4 h-4 mr-2" />
                    Claim
                  </Button>
                  <Button size="sm" onClick={() => handleUnstake(pos)} disabled={isProcessing || pos.status !== 'unlocked'}>
                    {pos.status === 'active' ? (
                      `Unlocks ${format(new Date(pos.unlock_date), 'MMM d')}`
                    ) : (
                      <>
                        <Unlock className="w-4 h-4 mr-2" />
                        Unstake
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-neutral-400">
             <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>You have no active stakes.</p>
          </div>
        )}
      </div>
    </div>
  );

  if (isLoading) {
    return <div className="text-center p-12">Loading Staking Platform...</div>;
  }

  // New authentication check
  if (!user) {
    return (
      <div className="glass-card rounded-xl p-8 text-center">
        <h2 className="text-xl font-bold text-neutral-100 mb-4">Authentication Required</h2>
        <p className="text-neutral-400 mb-6">Please log in to access the staking platform and manage your positions.</p>
        <Button onClick={() => User.login()} className="bg-gradient-to-r from-gray-500 to-gray-700 hover:from-gray-600 hover:to-gray-800 text-white border-none">
          Login
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-r from-gray-500 to-gray-700 rounded-xl flex items-center justify-center">
            <TrendingUp className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 gradient-text">Staking Platform</h1>
            <p className="text-neutral-400">Stake external assets to mint new SPEC tokens and earn passive income.</p>
          </div>
        </div>
      </div>
      
      {/* Enhanced Notice for External Staking */}
      <div className="glass-card rounded-xl p-6 bg-gradient-to-r from-purple-500/10 to-pink-500/10 border-purple-500/30">
        <div className="flex items-center gap-3 mb-2">
          <Shield className="w-5 h-5 text-purple-400" />
          <h3 className="font-bold text-purple-400">External Wallet Staking</h3>
        </div>
        <p className="text-sm text-neutral-300">
          Stake ETH or BTC from external wallets to mint new SPEC tokens! 
          External staking automatically mints new SPEC and increases the total supply.
        </p>
      </div>
      
      {/* Staking Pools */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(STAKING_POOLS).map(([symbol, pool]) => (
          <StakingPoolCard key={symbol} symbol={symbol} pool={pool} />
        ))}
      </div>

      {/* Stake Modal (simplified) */}
      {selectedPool && (
        <div className="glass-card rounded-xl p-6">
          <h3 className="text-xl font-bold text-neutral-100 mb-4">Stake {selectedPool.symbol}</h3>
          <div className="space-y-4">
            <p className="text-neutral-300">Staking for {selectedPool.label} at {selectedPool.apy}% APY.</p>
            {selectedPool.symbol !== 'SPEC' && (
              <div className="p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
                <p className="text-sm text-purple-400">
                  <strong>External Staking Bonus:</strong> Mint {stakeAmount ? (parseFloat(stakeAmount) * 0.1).toFixed(2) : '0.00'} SPEC tokens immediately!
                </p>
              </div>
            )}
            <p className="text-sm text-neutral-400">
              {selectedPool.symbol === 'SPEC' 
                ? `Available Balance: ${balances[selectedPool.symbol].toLocaleString()} ${selectedPool.symbol}`
                : `External ${selectedPool.symbol} Staking (No balance check required)`
              }
            </p>
            <Input 
              type="number"
              placeholder="Amount to stake"
              value={stakeAmount}
              onChange={(e) => setStakeAmount(e.target.value)}
              className="bg-white/5 border-white/20 text-neutral-100"
            />
            <div className="flex justify-end gap-3">
              <Button variant="outline" onClick={() => setSelectedPool(null)} className="border-white/20 text-neutral-200 hover:bg-white/10">Cancel</Button>
              <Button onClick={handleStake} disabled={isProcessing} className="bg-neutral-200 text-black hover:bg-neutral-300">
                {isProcessing ? "Staking..." : "Confirm Stake"}
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* User's Stakes */}
      <MyStakes />
    </div>
  );
}
