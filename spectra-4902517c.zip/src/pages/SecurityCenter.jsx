import React from 'react';
import AdvancedSecurityCenter from '../components/security/AdvancedSecurityCenter';

export default function SecurityCenterPage() {
  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
          Security Center
        </h1>
        <p className="text-neutral-400">
          Manage your account's security settings, API keys, and access controls.
        </p>
      </div>
      <AdvancedSecurityCenter />
    </div>
  );
}