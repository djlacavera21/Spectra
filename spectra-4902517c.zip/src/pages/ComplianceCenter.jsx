import React from 'react';
import ComplianceCenterComponent from '../components/security/ComplianceCenter';
import { User } from '@/api/entities';

export default function ComplianceCenterPage() {
    const [isAdmin, setIsAdmin] = React.useState(false);

    React.useEffect(() => {
        const checkAdmin = async () => {
            try {
                const user = await User.me();
                if (user && (user.special_role === 'admin' || user.special_role === 'treasurer')) {
                    setIsAdmin(true);
                }
            } catch (e) {
                // Not logged in or error
            }
        };
        checkAdmin();
    }, []);

    if (!isAdmin) {
        return (
            <div className="flex items-center justify-center h-full">
                <div className="text-center p-8 glass-card rounded-xl">
                    <h2 className="text-2xl font-bold text-red-400">Access Denied</h2>
                    <p className="text-neutral-300 mt-2">You do not have permission to view the Compliance Center.</p>
                </div>
            </div>
        );
    }

    return <ComplianceCenterComponent />;
}