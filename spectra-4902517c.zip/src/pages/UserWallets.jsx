import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, Search, Copy, Wallet } from "lucide-react";

export default function UserWallets() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadUsers();
  }, []);
  
  useEffect(() => {
    let filtered = users;
    if (searchTerm) {
        filtered = users.filter(user => 
            user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            user.wallet_address.toLowerCase().includes(searchTerm.toLowerCase())
        );
    }
    setFilteredUsers(filtered);
  }, [searchTerm, users]);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const userList = await User.list();
      setUsers(userList);
      setFilteredUsers(userList);
    } catch (error) {
      console.error("Failed to load users:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Address copied to clipboard!');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading user data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
              Platform Users
            </h1>
            <p className="text-neutral-400">
              Complete list of all registered wallet addresses on Spectra
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Users className="w-6 h-6 text-neutral-300" />
            <span className="text-xl font-bold text-neutral-100">{users.length} Total Users</span>
          </div>
        </div>
      </div>

      <div className="glass-card rounded-xl p-6">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
          <Input
            placeholder="Search by name, email, or wallet address..."
            className="pl-10 bg-white/10 border-white/20 text-neutral-200 placeholder:text-neutral-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>

        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-b-white/10 hover:bg-transparent">
                <TableHead className="text-neutral-300">User</TableHead>
                <TableHead className="text-neutral-300">Wallet Address</TableHead>
                <TableHead className="text-neutral-300 text-right">SPEC Balance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.map((user) => (
                <TableRow key={user.id} className="border-b-white/10 hover:bg-white/5">
                  <TableCell>
                    <div className="font-medium text-neutral-100">{user.full_name}</div>
                    <div className="text-sm text-neutral-400">{user.email}</div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Wallet className="w-4 h-4 text-neutral-500" />
                      <span className="font-mono text-sm text-neutral-300">{user.wallet_address}</span>
                      <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => copyToClipboard(user.wallet_address)}>
                        <Copy className="w-3 h-3 text-neutral-400" />
                      </Button>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium text-neutral-100">
                    {user.spec_balance?.toLocaleString()} SPEC
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {filteredUsers.length === 0 && !isLoading && (
            <div className="text-center py-12 text-neutral-400">
                <p>No users found matching your search.</p>
            </div>
        )}
      </div>
    </div>
  );
}