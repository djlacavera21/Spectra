import React from 'react';
import NotificationCenterComponent from '../components/notifications/NotificationCenter';

export default function NotificationCenterPage() {
  return (
    <div className="w-full max-w-4xl mx-auto">
      <NotificationCenterComponent />
    </div>
  );
}