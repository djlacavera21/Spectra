

import React, { useState, useEffect, createContext, useContext } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { User } from '@/api/entities';
import { createPageUrl } from '@/utils';
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  Bell,
  Home,
  LineChart,
  Package,
  ShoppingCart,
  Users,
  Menu,
  ChevronDown,
  LogOut,
  Wallet,
  PiggyBank,
  Shield,
  Briefcase,
  GitBranch,
  Settings,
  ShieldCheck,
  Gavel,
  Globe,
  Vault,
  Code,
  Box,
  Layers,
  Beaker,
  Pickaxe,
  ArrowUpDown
} from 'lucide-react';
import { Badge } from "@/components/ui/badge";
import { NotificationProvider, useNotifications } from './components/notifications/NotificationService';
import { SignatureProvider } from './components/common/SignatureContext';
import SignatureModal from './components/common/SignatureModal';

const navigationItems = [
  { name: 'Dashboard', href: 'Dashboard', icon: Home },
  { name: 'Trading', href: 'Trading', icon: LineChart },
  { name: 'Swap', href: 'Swap', icon: ArrowUpDown },
  { name: 'Marketplace', href: 'Marketplace', icon: ShoppingCart },
  { name: 'Staking', href: 'Staking', icon: PiggyBank },
  { name: 'Wallet', href: 'Wallet', icon: Wallet },
  { name: 'Explorer', href: 'Explorer', icon: Globe }, // Added Explorer to main navigation
  { name: 'Mining', href: 'Mining', icon: Pickaxe },
];

const developerNavigationItems = [
  { name: 'Fabric', href: 'Fabric', icon: GitBranch },
  { name: 'Security', href: 'SecurityCenter', icon: ShieldCheck },
  { name: 'Compliance', href: 'ComplianceCenter', icon: Gavel },
  { name: 'Gateway', href: 'BlockchainGateway', icon: Globe },
];

const treasurerNavigationItems = [
  { name: 'Master Vault', href: 'MasterVault', icon: Vault },
]

const LayoutContent = ({ children, currentPageName }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const { notifications } = useNotifications();
  const unreadCount = notifications.filter(n => n.status !== 'read').length;

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (e) {
        // Not logged in, user will be redirected by auth guard if necessary
      }
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    await User.logout();
    window.location.reload();
  };

  if (!currentUser) {
    return (
      <div className="flex items-center justify-center h-screen bg-neutral-950">
          <div className="text-center">
              <p className="text-neutral-300">Loading Spectra Platform...</p>
          </div>
      </div>
    );
  }

  const isTreasurer = currentUser?.special_role === 'treasurer' || currentUser?.special_role === 'admin';
  const isDeveloper = currentUser?.special_role === 'admin' || currentUser?.special_role === 'treasurer';
  const isAdmin = currentUser?.special_role === 'admin';
  
  const allNavigationItems = [
    ...navigationItems, 
    ...(isTreasurer ? treasurerNavigationItems : []),
    ...(isDeveloper ? developerNavigationItems : []),
  ];

  const pageTitle = currentPageName || 'Dashboard';

  return (
    <div className="grid min-h-screen w-full md:grid-cols-[220px_1fr] lg:grid-cols-[280px_1fr] bg-black text-white">
      <style>{`
        .glass-card {
          background-color: #0A0A0A !important;
          border: 1px solid #27272a;
        }
        .glass-effect {
          background-color: rgba(10, 10, 10, 0.8) !important;
          border: 1px solid #27272a;
        }
        
        /* Remove all white backgrounds */
        .bg-white, .bg-white\/5, .bg-white\/10, .bg-white\/20 {
          background-color: #0A0A0A !important;
        }
        
        /* Fix dropdown and modal backgrounds */
        [data-radix-popper-content-wrapper] > div,
        [role="dialog"],
        [role="menu"],
        [role="menuitem"],
        .dropdown-content,
        .dialog-content,
        .popover-content {
          background-color: #0A0A0A !important;
          border-color: #27272a !important;
          color: #e5e5e5 !important;
        }
        
        /* Fix input backgrounds */
        input, textarea, select {
          background-color: rgba(10, 10, 10, 0.8) !important;
          border-color: #27272a !important;
          color: #e5e5e5 !important;
        }
        
        /* Fix button backgrounds */
        button:not(.gradient-button) {
          background-color: rgba(10, 10, 10, 0.8) !important;
          border-color: #27272a !important;
        }
        
        /* Fix card backgrounds */
        .card, [data-slot="content"] {
          background-color: #0A0A0A !important;
          border-color: #27272a !important;
        }
        
        /* Fix table backgrounds */
        table, thead, tbody, tr, td, th {
          background-color: transparent !important;
          border-color: #27272a !important;
        }
        
        /* Fix scrollbar */
        ::-webkit-scrollbar {
          background-color: #0A0A0A !important;
        }
        ::-webkit-scrollbar-thumb {
          background-color: #27272a !important;
        }
        
        /* Fix text colors */
        .text-white {
          color: #e5e5e5 !important;
        }
        
        /* Override any remaining white elements */
        * {
          color: inherit; /* Allow some color inheritance, then apply specific override below */
        }
        
        *:not(.text-green-400):not(.text-red-400):not(.text-blue-400):not(.text-yellow-400):not(.text-purple-400):not(.text-cyan-400):not(.text-orange-400):not(.gradient-text) {
          color: #e5e5e5 !important;
        }
      `}</style>
      <div className="hidden border-r bg-black border-neutral-700 md:block">
        <div className="flex h-full max-h-screen flex-col gap-2">
          <div className="flex h-14 items-center border-b border-neutral-700 px-4 lg:h-[60px] lg:px-6">
            <Link to={createPageUrl("Dashboard")} className="flex items-center gap-2 font-semibold text-neutral-200">
              <Package className="h-6 w-6 text-yellow-400" />
              <span>Spectra</span>
            </Link>
          </div>
          <div className="flex-1">
            <nav className="grid items-start px-2 text-sm font-medium lg:px-4">
              {allNavigationItems.map(item => (
                <Link
                  key={item.name}
                  to={createPageUrl(item.href)}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all ${
                    currentPageName === item.href
                      ? 'text-yellow-400 bg-neutral-900'
                      : 'text-neutral-300 hover:text-neutral-100 hover:bg-neutral-900'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Link>
              ))}
            </nav>
          </div>
        </div>
      </div>
      <div className="flex flex-col">
        <header className="flex h-14 items-center gap-4 border-b bg-black border-neutral-700 px-4 lg:h-[60px] lg:px-6">
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="icon"
                className="shrink-0 md:hidden bg-neutral-900 border-neutral-700 text-neutral-200 hover:bg-neutral-800"
              >
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle navigation menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col bg-black border-r-neutral-700 text-neutral-200">
              <nav className="grid gap-2 text-lg font-medium">
                <Link
                  to={createPageUrl("Dashboard")}
                  className="flex items-center gap-2 text-lg font-semibold mb-4 text-neutral-200"
                >
                  <Package className="h-6 w-6 text-yellow-400" />
                  <span>Spectra</span>
                </Link>
                {allNavigationItems.map(item => (
                  <Link
                    key={item.name}
                    to={createPageUrl(item.href)}
                    className={`flex items-center gap-4 rounded-xl px-3 py-2 transition-all ${
                      currentPageName === item.href
                      ? 'text-yellow-400 bg-neutral-900'
                      : 'text-neutral-300 hover:text-neutral-100 hover:bg-neutral-900'
                    }`}
                  >
                    <item.icon className="h-5 w-5" />
                    {item.name}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
          <div className="w-full flex-1">
            <h1 className="text-xl font-semibold text-neutral-200">{pageTitle}</h1>
          </div>
           <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="secondary" className="rounded-full flex items-center gap-2 bg-neutral-900 hover:bg-neutral-800 border-neutral-700 text-neutral-200">
                <img src={`https://api.dicebear.com/7.x/pixel-art/svg?seed=${currentUser.email}`} alt="avatar" className="w-6 h-6 rounded-full" />
                <span className="hidden md:inline">{currentUser.full_name}</span>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56 bg-black border border-neutral-700 text-neutral-200" align="end">
                <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium leading-none text-neutral-200">{currentUser.full_name}</p>
                        {(isTreasurer || isAdmin) && (
                            <p className="text-xs leading-none text-purple-400 font-medium capitalize">
                                {currentUser.special_role}
                            </p>
                        )}
                        <p className="text-xs leading-none text-neutral-400">{currentUser.email}</p>
                    </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-neutral-700" />
                <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                    <Link to={createPageUrl("Portfolio")}>
                        <Briefcase className="mr-2 h-4 w-4" />
                        <span>Portfolio</span>
                    </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                  <Link to={createPageUrl("NotificationCenter")} className="flex justify-between w-full">
                    <div className="flex items-center">
                      <Bell className="mr-2 h-4 w-4" />
                      <span>Notifications</span>
                    </div>
                    {unreadCount > 0 && (
                      <Badge className="bg-red-600 text-neutral-200 px-2">{unreadCount}</Badge>
                    )}
                  </Link>
                </DropdownMenuItem>
                 <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                    <Link to={createPageUrl("SecurityCenter")}>
                        <ShieldCheck className="mr-2 h-4 w-4" />
                        <span>Security</span>
                    </Link>
                </DropdownMenuItem>
                
                {(isTreasurer || isAdmin) && <DropdownMenuSeparator className="bg-neutral-700" />}
                
                {(isTreasurer || isAdmin) && (
                    <>
                        <DropdownMenuLabel className="text-xs text-neutral-400">Admin Area</DropdownMenuLabel>
                        <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                            <Link to={createPageUrl("Admin")}>
                                <Shield className="mr-2 h-4 w-4" />
                                <span>Admin Panel</span>
                            </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                            <Link to={createPageUrl("MasterVault")}>
                                <Vault className="mr-2 h-4 w-4" />
                                <span>Master Vault</span>
                            </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                            <Link to={createPageUrl("IBMFabricConsole")}>
                                <Code className="mr-2 h-4 w-4" />
                                <span>IBM Fabric Console</span>
                            </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                            <Link to={createPageUrl("EthereumConsole")}>
                                <Box className="mr-2 h-4 w-4" />
                                <span>Ethereum Console</span>
                            </Link>
                        </DropdownMenuItem>
                        <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                            <Link to={createPageUrl("SolanaConsole")}>
                                <Layers className="mr-2 h-4 w-4" />
                                <span>Solana Console</span>
                            </Link>
                        </DropdownMenuItem>
                        {isAdmin && (
                          <DropdownMenuItem asChild className="cursor-pointer hover:!bg-neutral-800 text-neutral-200">
                              <Link to={createPageUrl("CoinGenesisIncubator")}>
                                  <Beaker className="mr-2 h-4 w-4" />
                                  <span>Incubator</span>
                              </Link>
                          </DropdownMenuItem>
                        )}
                    </>
                )}

                <DropdownMenuSeparator className="bg-neutral-700" />
                <DropdownMenuItem onSelect={handleLogout} className="cursor-pointer hover:!bg-red-900 !text-red-400 focus:text-red-400 focus:bg-red-900">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
           </DropdownMenu>
        </header>
        <main className="flex flex-1 flex-col gap-4 p-4 lg:gap-6 lg:p-6 overflow-auto bg-black">
            {children}
        </main>
      </div>
      <SignatureModal />
    </div>
  );
};

const Layout = ({ children, currentPageName }) => {
  return (
    <NotificationProvider>
      <SignatureProvider>
        <LayoutContent currentPageName={currentPageName}>
            {children}
        </LayoutContent>
      </SignatureProvider>
    </NotificationProvider>
  );
};

export default Layout;

