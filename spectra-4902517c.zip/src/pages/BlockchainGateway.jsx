import React from 'react';
import RealBlockchainGateway from '../components/blockchain/RealBlockchainGateway';

export default function BlockchainGatewayPage() {
  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
          Blockchain Gateway
        </h1>
        <p className="text-neutral-400">
          Real-time multi-blockchain connectivity and transaction broadcasting service
        </p>
      </div>
      <RealBlockchainGateway />
    </div>
  );
}