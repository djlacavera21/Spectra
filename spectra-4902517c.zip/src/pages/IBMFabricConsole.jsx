
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button"; // Keep Button import as it might be used elsewhere or for general purpose
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Code,
  Server,
  Database,
  Network,
  Settings,
  Play,
  StopCircle,
  Upload,
  Download,
  Terminal,
  FileText,
  Cpu,
  HardDrive,
  Activity,
  Zap,
  Shield
} from "lucide-react";

import SmartContractDeveloper from "../components/fabric/SmartContractDeveloper";
import NetworkManager from "../components/fabric/NetworkManager";
import FabricSDKInterface from "../components/fabric/FabricSDKInterface";
import KubernetesManager from "../components/fabric/KubernetesManager";
import APIConsole from "../components/fabric/APIConsole";
import NewSmartContractModal from "../components/fabric/NewSmartContractModal";
import DeployToNetworkModal from "../components/fabric/DeployToNetworkModal";
import IBMHandshakeVerification from "../components/fabric/IBMHandshakeVerification";
import LinuxShellEmulator from "../components/fabric/LinuxShellEmulator";
import IBMFabricBackend from "../components/fabric/IBMFabricBackend"; // New import

export default function IBMFabricConsole() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showNewContractModal, setShowNewContractModal] = useState(false);
  const [showDeployModal, setShowDeployModal] = useState(false);
  const [connectionProfile, setConnectionProfile] = useState(null);
  const [networkStatus, setNetworkStatus] = useState({
    peers: 2,
    orderers: 1,
    channels: 3,
    chaincodes: 5,
    transactions: 1247,
    blocks: 892
  });

  useEffect(() => {
    // Simulate network monitoring
    const interval = setInterval(() => {
      setNetworkStatus(prev => ({
        ...prev,
        transactions: prev.transactions + Math.floor(Math.random() * 3),
        blocks: prev.blocks + (Math.random() > 0.7 ? 1 : 0)
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleNewSmartContract = () => {
    setShowNewContractModal(true);
  };

  const handleDeployToNetwork = () => {
    setShowDeployModal(true);
  };

  const handleConnectionProfileUpload = (profile) => {
    setConnectionProfile(profile);
    alert('Connection Profile successfully loaded into the console.');
  };

  const handleOpenSDKConsole = () => {
    setActiveTab('sdk');
  };

  const handleManageKubernetes = () => {
    setActiveTab('kubernetes');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
            <Code className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 gradient-text">IBM Hyperledger Fabric Console</h1>
            <p className="text-neutral-400">Professional blockchain development and management platform</p>
          </div>
        </div>

        <Alert className="bg-blue-500/20 border-blue-500/30">
          <Shield className="w-4 h-4 text-blue-400" />
          <AlertDescription className="text-blue-400">
            <strong>Enterprise Development Environment:</strong> Full access to IBM Blockchain Platform tools,
            smart contract development, and Kubernetes orchestration for production-grade Hyperledger Fabric networks.
          </AlertDescription>
        </Alert>
      </div>

      {/* Network Overview Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Server className="w-5 h-5 text-blue-400" />
            <span className="text-sm text-neutral-400">Peers</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.peers}</p>
          <p className="text-xs text-green-400">Online</p>
        </div>

        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Database className="w-5 h-5 text-green-400" />
            <span className="text-sm text-neutral-400">Orderers</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.orderers}</p>
          <p className="text-xs text-green-400">Active</p>
        </div>

        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Network className="w-5 h-5 text-purple-400" />
            <span className="text-sm text-neutral-400">Channels</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.channels}</p>
          <p className="text-xs text-purple-400">Active</p>
        </div>

        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Code className="w-5 h-5 text-yellow-400" />
            <span className="text-sm text-neutral-400">Chaincodes</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.chaincodes}</p>
          <p className="text-xs text-yellow-400">Deployed</p>
        </div>

        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-5 h-5 text-orange-400" />
            <span className="text-sm text-neutral-400">Transactions</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.transactions.toLocaleString()}</p>
          <p className="text-xs text-orange-400">Total</p>
        </div>

        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <HardDrive className="w-5 h-5 text-red-400" />
            <span className="text-sm text-neutral-400">Blocks</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{networkStatus.blocks.toLocaleString()}</p>
          <p className="text-xs text-red-400">Height</p>
        </div>
      </div>

      {/* Main Console Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-8 glass-effect"> {/* Updated to 8 columns */}
          <TabsTrigger value="overview" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Activity className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="backend" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300"> {/* New tab */}
            <Database className="w-4 h-4 mr-2" />
            Backend
          </TabsTrigger>
          <TabsTrigger value="contracts" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Code className="w-4 h-4 mr-2" />
            Smart Contracts
          </TabsTrigger>
          <TabsTrigger value="network" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Network className="w-4 h-4 mr-2" />
            Network
          </TabsTrigger>
          <TabsTrigger value="sdk" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Terminal className="w-4 h-4 mr-2" />
            SDK Interface
          </TabsTrigger>
          <TabsTrigger value="kubernetes" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Server className="w-4 h-4 mr-2" />
            Kubernetes
          </TabsTrigger>
          <TabsTrigger value="api" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Zap className="w-4 h-4 mr-2" />
            APIs
          </TabsTrigger>
          <TabsTrigger value="shell" className="text-neutral-400 data-[state=active]:bg-neutral-700 data-[state=active]:text-purple-300">
            <Terminal className="w-4 h-4 mr-2" />
            Live Shell
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* IBM Blockchain Platform Status */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-xl font-bold text-neutral-100 mb-4">IBM Blockchain Platform Status</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-neutral-200">VS Code Extension</span>
                </div>
                <p className="text-xs text-green-400">Connected & Ready</p>
                <p className="text-xs text-neutral-500">v2.0.5</p>
              </div>

              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-neutral-200">Operations Console</span>
                </div>
                <p className="text-xs text-green-400">API Ready</p>
                <p className="text-xs text-neutral-500">REST v2.5.3</p>
              </div>

              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-neutral-200">Kubernetes Service</span>
                </div>
                <p className="text-xs text-green-400">Cluster Active</p>
                <p className="text-xs text-neutral-500">3 nodes</p>
              </div>
            </div>
          </div>

          {/* Enhanced Quick Actions */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-xl font-bold text-neutral-100 mb-4">Quick Development Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <button 
                onClick={handleNewSmartContract}
                className="h-12 px-4 rounded-md text-white font-medium transition-all flex items-center justify-center"
                style={{ background: 'linear-gradient(to right, #2563eb, #1d4ed8)' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #1d4ed8, #1e40af)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #2563eb, #1d4ed8)'; }}
              >
                <Code className="w-4 h-4 mr-2" />
                New Smart Contract
              </button>
              <button 
                onClick={handleDeployToNetwork}
                className="h-12 px-4 rounded-md text-white font-medium transition-all flex items-center justify-center"
                style={{ background: 'linear-gradient(to right, #059669, #047857)' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #047857, #065f46)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #059669, #047857)'; }}
              >
                <Play className="w-4 h-4 mr-2" />
                Deploy to Network
              </button>
              <button 
                onClick={handleOpenSDKConsole}
                className="h-12 px-4 rounded-md text-white font-medium transition-all flex items-center justify-center"
                style={{ background: 'linear-gradient(to right, #7c3aed, #6d28d9)' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #6d28d9, #5b21b6)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #7c3aed, #6d28d9)'; }}
              >
                <Terminal className="w-4 h-4 mr-2" />
                Open SDK Console
              </button>
              <button 
                onClick={handleManageKubernetes}
                className="h-12 px-4 rounded-md text-white font-medium transition-all flex items-center justify-center"
                style={{ background: 'linear-gradient(to right, #ea580c, #dc2626)' }}
                onMouseEnter={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #dc2626, #b91c1c)'; }}
                onMouseLeave={(e) => { e.currentTarget.style.background = 'linear-gradient(to right, #ea580c, #dc2626)'; }}
              >
                <Server className="w-4 h-4 mr-2" />
                Manage Kubernetes
              </button>
            </div>
          </div>

          {/* Development Workflow */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-xl font-bold text-neutral-100 mb-4">Development Workflow</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-medium text-neutral-200">Smart Contract Development</h4>
                <div className="space-y-3">
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">1. Create Contract Template</span>
                    <button 
                      onClick={() => setActiveTab('contracts')} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Start
                    </button>
                  </div>
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">2. Develop Business Logic</span>
                    <button 
                      onClick={() => setActiveTab('contracts')} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Code
                    </button>
                  </div>
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">3. Test Locally</span>
                    <button 
                      onClick={() => setActiveTab('contracts')} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Test
                    </button>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium text-neutral-200">Network Operations</h4>
                <div className="space-y-3">
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">1. Package Chaincode</span>
                    <button 
                      onClick={handleDeployToNetwork} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Package
                    </button>
                  </div>
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">2. Deploy to Channel</span>
                    <button 
                      onClick={() => setActiveTab('network')} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Deploy
                    </button>
                  </div>
                  <div className="glass-effect rounded-lg p-3 flex items-center justify-between">
                    <span className="text-sm text-neutral-300">3. Monitor Performance</span>
                    <button 
                      onClick={() => setActiveTab('kubernetes')} 
                      className="px-3 py-1 rounded text-sm font-medium transition-all"
                      style={{ backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' }}
                      onMouseEnter={(e) => { 
                        e.currentTarget.style.backgroundColor = 'rgba(255, 255, 255, 0.1)';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.3)';
                      }}
                      onMouseLeave={(e) => { 
                        e.currentTarget.style.backgroundColor = 'transparent';
                        e.currentTarget.style.borderColor = 'rgba(255, 255, 255, 0.2)';
                      }}
                    >
                      Monitor
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* IBM Handshake Verification */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-xl font-bold text-neutral-100 mb-4">IBM Blockchain Platform Integration</h3>
            <IBMHandshakeVerification 
              connectionProfile={connectionProfile}
              onProfileUpload={handleConnectionProfileUpload}
            />
          </div>
        </TabsContent>

        <TabsContent value="backend" className="space-y-6"> {/* New backend tab */}
          <IBMFabricBackend />
        </TabsContent>

        <TabsContent value="contracts" className="space-y-6">
          <SmartContractDeveloper />
        </TabsContent>

        <TabsContent value="network" className="space-y-6">
          <NetworkManager />
        </TabsContent>

        <TabsContent value="sdk" className="space-y-6">
          <FabricSDKInterface />
        </TabsContent>

        <TabsContent value="kubernetes" className="space-y-6">
          <KubernetesManager />
        </TabsContent>

        <TabsContent value="api" className="space-y-6">
          <APIConsole />
        </TabsContent>

        <TabsContent value="shell" className="space-y-6">
          <LinuxShellEmulator />
        </TabsContent>
      </Tabs>

      {/* New Smart Contract Modal */}
      <NewSmartContractModal 
        isOpen={showNewContractModal} 
        onClose={() => setShowNewContractModal(false)}
        onSuccess={() => {
          setShowNewContractModal(false);
          setActiveTab('contracts');
        }}
      />

      {/* Deploy to Network Modal */}
      <DeployToNetworkModal 
        isOpen={showDeployModal} 
        onClose={() => setShowDeployModal(false)}
        onSuccess={() => {
          setShowDeployModal(false);
          setActiveTab('network');
        }}
      />
    </div>
  );
}
