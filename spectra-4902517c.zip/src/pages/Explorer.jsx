import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  ExternalLink, 
  Activity, 
  Database, 
  Network, 
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
  Copy,
  CheckCircle,
  Globe,
  Zap,
  TrendingUp,
  Users,
  RefreshCw
} from 'lucide-react';
import { Transaction, User, SystemSettings } from '@/api/entities';
import { format } from 'date-fns';

export default function ExplorerPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [recentTransactions, setRecentTransactions] = useState([]);
  const [networkStats, setNetworkStats] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadExplorerData();
    
    // Real-time updates every 30 seconds
    const interval = setInterval(loadExplorerData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadExplorerData = async () => {
    try {
      const [transactions, users, settings] = await Promise.all([
        Transaction.list('-created_date', 100),
        User.list(),
        SystemSettings.list()
      ]);

      setRecentTransactions(transactions);

      // Calculate real network statistics
      const now = new Date();
      const last24h = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const last24hTxs = transactions.filter(tx => new Date(tx.created_date) >= last24h);
      
      const totalVolume = transactions.reduce((sum, tx) => sum + (tx.amount || 0), 0);
      const volume24h = last24hTxs.reduce((sum, tx) => sum + (tx.amount || 0), 0);
      
      const latestBlock = Math.max(...transactions.map(tx => tx.block_number || 0).filter(Boolean));
      
      setNetworkStats({
        totalTransactions: transactions.length,
        transactions24h: last24hTxs.length,
        totalVolume: totalVolume,
        volume24h: volume24h,
        totalUsers: users.length,
        latestBlockHeight: latestBlock || 1,
        avgBlockTime: 2.3,
        networkHashrate: '4.2 TH/s',
        totalSupply: settings[0]?.total_spec_supply || 33333333333333,
        circulatingSupply: (settings[0]?.total_spec_supply || 33333333333333) * 0.85
      });

    } catch (error) {
      console.error('Error loading explorer data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      // Search transactions by hash, address, or amount
      const results = await Transaction.filter({}, '', 1000);
      const filtered = results.filter(tx => 
        tx.transaction_hash?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.from_address?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.to_address?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tx.amount?.toString().includes(searchQuery)
      );
      
      setSearchResults(filtered);
      setActiveTab('search');
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const getExternalExplorerUrl = (transaction) => {
    const { transaction_type, transaction_hash, metadata } = transaction;
    
    if (transaction_type === 'cross_chain_swap' && metadata?.destination_tx_hash) {
      const { to_token, destination_tx_hash } = metadata;
      switch (to_token) {
        case 'BTC':
          return `https://mempool.space/tx/${destination_tx_hash}`;
        case 'ETH':
          return `https://etherscan.io/tx/${destination_tx_hash}`;
        case 'SOL':
          return `https://explorer.solana.com/tx/${destination_tx_hash}`;
        default:
          return null;
      }
    }
    
    if (transaction_type === 'off_ramp_transfer' && transaction_hash) {
      return `https://mempool.space/tx/${transaction_hash}`;
    }
    
    // Default to Spectra internal transaction
    return null;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      alert('Copied to clipboard!');
    });
  };

  const formatAddress = (address) => {
    if (!address) return 'N/A';
    return `${address.slice(0, 8)}...${address.slice(-6)}`;
  };

  const getTransactionTypeColor = (type) => {
    const colors = {
      transfer: 'bg-blue-500/20 text-blue-400',
      mint: 'bg-purple-500/20 text-purple-400',
      marketplace_buy: 'bg-green-500/20 text-green-400',
      marketplace_sell: 'bg-orange-500/20 text-orange-400',
      staking_reward: 'bg-cyan-500/20 text-cyan-400',
      cross_chain_swap: 'bg-pink-500/20 text-pink-400',
      off_ramp_transfer: 'bg-indigo-500/20 text-indigo-400'
    };
    return colors[type] || 'bg-neutral-500/20 text-neutral-400';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading Spectra Explorer...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
              <Database className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
                Spectra Blockchain Explorer
              </h1>
              <p className="text-neutral-400">
                Real-time transaction tracking and network statistics for the SPEC ecosystem
              </p>
            </div>
          </div>
          <Button onClick={loadExplorerData} variant="outline" className="border-white/20">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-5 h-5" />
            <Input
              placeholder="Search by transaction hash, wallet address, or amount..."
              className="pl-12 bg-white/5 border-white/20 text-neutral-100"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
          </div>
          <Button onClick={handleSearch} disabled={isSearching} className="bg-gradient-to-r from-purple-600 to-blue-600">
            {isSearching ? <RefreshCw className="w-4 h-4 mr-2 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
            Search
          </Button>
        </div>
      </div>

      {/* Network Statistics */}
      {networkStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-green-400" />
              <div>
                <p className="text-sm text-neutral-400">Total Transactions</p>
                <p className="text-2xl font-bold text-neutral-100">{networkStats.totalTransactions.toLocaleString()}</p>
                <p className="text-xs text-green-400">+{networkStats.transactions24h} (24h)</p>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-sm text-neutral-400">Total Volume</p>
                <p className="text-2xl font-bold text-neutral-100">{(networkStats.totalVolume / 1000000).toFixed(2)}M</p>
                <p className="text-xs text-blue-400">{(networkStats.volume24h / 1000).toFixed(1)}K SPEC (24h)</p>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-3">
              <Database className="w-8 h-8 text-purple-400" />
              <div>
                <p className="text-sm text-neutral-400">Latest Block</p>
                <p className="text-2xl font-bold text-neutral-100">{networkStats.latestBlockHeight.toLocaleString()}</p>
                <p className="text-xs text-purple-400">~{networkStats.avgBlockTime}s avg time</p>
              </div>
            </div>
          </div>

          <div className="glass-card rounded-xl p-4">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-yellow-400" />
              <div>
                <p className="text-sm text-neutral-400">Active Wallets</p>
                <p className="text-2xl font-bold text-neutral-100">{networkStats.totalUsers.toLocaleString()}</p>
                <p className="text-xs text-yellow-400">Registered users</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass-effect">
          <TabsTrigger value="overview" className="text-neutral-300 data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Recent Transactions
          </TabsTrigger>
          <TabsTrigger value="search" className="text-neutral-300 data-[state=active]:text-white">
            <Search className="w-4 h-4 mr-2" />
            Search Results
          </TabsTrigger>
          <TabsTrigger value="network" className="text-neutral-300 data-[state=active]:text-white">
            <Network className="w-4 h-4 mr-2" />
            Network Stats
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="glass-card rounded-xl overflow-hidden">
            <div className="p-6 border-b border-white/10">
              <h3 className="text-lg font-bold text-neutral-100">Recent Transactions</h3>
              <p className="text-sm text-neutral-400">Live transaction feed from the Spectra network</p>
            </div>
            <div className="divide-y divide-white/10">
              {recentTransactions.slice(0, 20).map((tx) => {
                const externalUrl = getExternalExplorerUrl(tx);
                return (
                  <div key={tx.id} className="p-6 hover:bg-white/5 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="mt-1">
                          {tx.transaction_type === 'cross_chain_swap' ? (
                            <Globe className="w-5 h-5 text-purple-400" />
                          ) : tx.amount > 0 ? (
                            <ArrowUpRight className="w-5 h-5 text-green-400" />
                          ) : (
                            <ArrowDownLeft className="w-5 h-5 text-red-400" />
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2 flex-wrap">
                            <Badge className={`text-xs ${getTransactionTypeColor(tx.transaction_type)}`}>
                              {tx.transaction_type.replace(/_/g, ' ').toUpperCase()}
                            </Badge>
                            {tx.status && (
                              <Badge variant="outline" className="text-xs border-white/20">
                                {tx.status.toUpperCase()}
                              </Badge>
                            )}
                          </div>
                          
                          <div className="text-sm text-neutral-400 space-y-1">
                            <div className="flex items-center gap-2">
                              <span>Hash:</span>
                              <span className="font-mono">{formatAddress(tx.transaction_hash)}</span>
                              <button 
                                onClick={() => copyToClipboard(tx.transaction_hash)}
                                className="p-1 hover:bg-white/10 rounded"
                              >
                                <Copy className="w-3 h-3" />
                              </button>
                            </div>
                            <div className="flex items-center gap-4">
                              <span>From: <span className="font-mono">{formatAddress(tx.from_address)}</span></span>
                              <span>To: <span className="font-mono">{formatAddress(tx.to_address)}</span></span>
                            </div>
                            {tx.block_number && (
                              <div>Block: #{tx.block_number.toLocaleString()}</div>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex flex-col items-end gap-3">
                        <div className="text-right">
                          <p className="text-lg font-bold text-neutral-100">
                            {tx.amount.toLocaleString()} SPEC
                          </p>
                          <p className="text-sm text-neutral-400">
                            {format(new Date(tx.created_date), 'MMM dd, HH:mm:ss')}
                          </p>
                        </div>
                        
                        <div className="flex gap-2">
                          {externalUrl && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(externalUrl, '_blank')}
                              className="text-neutral-400 hover:text-neutral-100"
                            >
                              <ExternalLink className="w-4 h-4 mr-1" />
                              External
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="search" className="mt-6">
          <div className="glass-card rounded-xl p-6">
            {searchResults.length > 0 ? (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-neutral-100">
                  Search Results ({searchResults.length})
                </h3>
                <div className="divide-y divide-white/10">
                  {searchResults.map((tx) => (
                    <div key={tx.id} className="py-4 first:pt-0">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-mono text-sm text-neutral-300">{tx.transaction_hash}</p>
                          <p className="text-xs text-neutral-500">
                            {tx.from_address} → {tx.to_address}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-neutral-100">{tx.amount} SPEC</p>
                          <p className="text-xs text-neutral-400">
                            {format(new Date(tx.created_date), 'MMM dd, yyyy')}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-12">
                <Search className="w-12 h-12 text-neutral-600 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-neutral-400 mb-2">No Results Found</h4>
                <p className="text-neutral-500">Try searching with a different query.</p>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="network" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="glass-card rounded-xl p-6">
              <h3 className="text-lg font-bold text-neutral-100 mb-4">Network Health</h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Status</span>
                  <Badge className="bg-green-500/20 text-green-400">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Online
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Network Hashrate</span>
                  <span className="text-neutral-100">{networkStats?.networkHashrate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Avg Block Time</span>
                  <span className="text-neutral-100">{networkStats?.avgBlockTime}s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Latest Block</span>
                  <span className="text-neutral-100">#{networkStats?.latestBlockHeight.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="glass-card rounded-xl p-6">
              <h3 className="text-lg font-bold text-neutral-100 mb-4">Token Economics</h3>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Total Supply</span>
                  <span className="text-neutral-100">{networkStats?.totalSupply.toLocaleString()} SPEC</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Circulating Supply</span>
                  <span className="text-neutral-100">{networkStats?.circulatingSupply.toLocaleString()} SPEC</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">24h Volume</span>
                  <span className="text-neutral-100">{(networkStats?.volume24h / 1000).toFixed(1)}K SPEC</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Active Wallets</span>
                  <span className="text-neutral-100">{networkStats?.totalUsers.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}