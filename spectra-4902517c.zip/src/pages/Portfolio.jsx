
import React, { useState, useEffect } from "react";
import { MarketplaceAsset, User, StakingPosition } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Wallet, 
  TrendingUp, 
  Image, 
  Star, 
  ExternalLink,
  ShoppingCart,
  PiggyBank,
  CheckCircle,
  Clock,
  Activity,
  DollarSign
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

import PortfolioChart from "../components/portfolio/PortfolioChart";
import AssetAllocation from "../components/portfolio/AssetAllocation";

export default function Portfolio() {
  const [user, setUser] = useState(null);
  const [ownedAssets, setOwnedAssets] = useState([]);
  const [listedAssets, setListedAssets] = useState([]);
  const [stakingPositions, setStakingPositions] = useState([]);
  const [portfolioStats, setPortfolioStats] = useState({
    totalValue: 0,
    liquidBalance: 0,
    stakedValue: 0,
    assetsValue: 0
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPortfolioData();
  }, []);

  const loadPortfolioData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Load owned assets (bought from marketplace)
      const userOwnedAssets = await MarketplaceAsset.filter({
        buyer_address: currentUser.wallet_address,
        status: "sold"
      });
      setOwnedAssets(userOwnedAssets);

      // Load assets user has listed
      const userListedAssets = await MarketplaceAsset.filter({
        seller_address: currentUser.wallet_address
      });
      setListedAssets(userListedAssets);

      // Load staking positions
      const userStakingPositions = await StakingPosition.filter({
        user_wallet: currentUser.wallet_address
      });
      setStakingPositions(userStakingPositions.filter(pos => pos.status !== 'withdrawn'));

      // Calculate portfolio stats
      const liquidBalance = currentUser.spec_balance || 0;
      const stakedValue = userStakingPositions
        .filter(pos => pos.status !== 'withdrawn')
        .reduce((sum, pos) => sum + pos.amount_staked, 0);
      const assetsValue = userOwnedAssets.reduce((sum, asset) => sum + asset.price_spec, 0);
      const totalValue = liquidBalance + stakedValue + assetsValue;

      setPortfolioStats({
        totalValue,
        liquidBalance,
        stakedValue,
        assetsValue
      });

    } catch (error) {
      console.error("Error loading portfolio:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getAllocationData = () => {
    const { liquidBalance, stakedValue, assetsValue } = portfolioStats;
    const data = [];
    
    if (liquidBalance > 0) {
      data.push({ name: 'Liquid SPEC', value: liquidBalance });
    }
    if (stakedValue > 0) {
      data.push({ name: 'Staked', value: stakedValue });
    }
    if (assetsValue > 0) {
      data.push({ name: 'Digital Assets', value: assetsValue });
    }
    
    return data;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading portfolio...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
              Portfolio Overview
            </h1>
            <p className="text-neutral-400">
              Track your complete Spectra ecosystem holdings
            </p>
          </div>
          <div className="text-right">
            <p className="text-3xl font-bold text-neutral-100">
              {portfolioStats.totalValue.toLocaleString()} SPEC
            </p>
            <p className="text-sm text-neutral-400">
              ≈ ${(portfolioStats.totalValue * 1.00).toLocaleString()} USD
            </p>
          </div>
        </div>
      </div>

      {/* Portfolio Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Wallet className="w-8 h-8 text-gray-400" />
            <div>
              <p className="text-sm text-neutral-400">Liquid Balance</p>
              <p className="text-2xl font-bold text-neutral-100">
                {portfolioStats.liquidBalance.toLocaleString()}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">Available SPEC</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-sm text-neutral-400">Staked Value</p>
              <p className="text-2xl font-bold text-neutral-100">
                {portfolioStats.stakedValue.toLocaleString()}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">Earning rewards</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Image className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-sm text-neutral-400">Digital Assets</p>
              <p className="text-2xl font-bold text-neutral-100">
                {portfolioStats.assetsValue.toLocaleString()}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">{ownedAssets.length} assets owned</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <ShoppingCart className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-sm text-neutral-400">Listed Assets</p>
              <p className="text-2xl font-bold text-neutral-100">
                {listedAssets.length}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">Active listings</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-bold text-neutral-100 mb-4">Portfolio Performance</h3>
          <PortfolioChart portfolioStats={portfolioStats} />
        </div>

        <div className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-bold text-neutral-100 mb-4">Asset Allocation</h3>
          <AssetAllocation data={getAllocationData()} />
        </div>
      </div>

      {/* Holdings Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Owned Assets */}
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-neutral-100">Owned Assets</h3>
            <Link to={createPageUrl("Marketplace")}>
              <Button variant="secondary" size="sm" className="bg-neutral-200 text-black hover:bg-neutral-300">
                <ShoppingCart className="w-4 h-4 mr-2" />
                Browse More
              </Button>
            </Link>
          </div>
          
          <div className="space-y-3">
            {ownedAssets.length > 0 ? (
              ownedAssets.slice(0, 5).map((asset) => (
                <div key={asset.id} className="glass-effect rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-gray-500 to-gray-700 rounded-lg flex items-center justify-center">
                        <Image className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-neutral-200">{asset.asset_name}</h4>
                        <p className="text-sm text-neutral-400 capitalize">{asset.asset_type}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-neutral-100">{asset.price_spec.toLocaleString()} SPEC</p>
                      <Badge className="bg-green-500/20 text-green-400 text-xs">Owned</Badge>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-neutral-400">
                <Image className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No assets owned yet</p>
                <p className="text-sm">Start collecting from the marketplace</p>
              </div>
            )}
          </div>
        </div>

        {/* Staking Positions */}
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-bold text-neutral-100">Active Stakes</h3>
            <Link to={createPageUrl("Staking")}>
              <Button variant="secondary" size="sm" className="bg-neutral-200 text-black hover:bg-neutral-300">
                <PiggyBank className="w-4 h-4 mr-2" />
                Stake More
              </Button>
            </Link>
          </div>
          
          <div className="space-y-3">
            {stakingPositions.length > 0 ? (
              stakingPositions.slice(0, 5).map((position) => (
                <div key={position.id} className="glass-effect rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-600 rounded-lg flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium text-neutral-200">
                          {position.amount_staked.toLocaleString()} {position.token_symbol}
                        </h4>
                        <p className="text-sm text-neutral-400">{position.apy_rate}% APY</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-green-400">
                        +{(position.rewards_accrued || 0).toFixed(4)} SPEC
                      </p>
                      <Badge className={`text-xs ${
                        position.status === 'active' ? 'bg-gray-500/20 text-gray-400' : 'bg-green-500/20 text-green-400'
                      }`}>
                        {position.status === 'active' ? 'Earning' : 'Unlocked'}
                      </Badge>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-neutral-400">
                <PiggyBank className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No active stakes</p>
                <p className="text-sm">Start earning rewards by staking</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
