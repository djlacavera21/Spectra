import React, { useState, useEffect } from "react";
import { User, VaultTransaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Vault, 
  TrendingUp, 
  DollarSign, 
  Shield, 
  Clock,
  ArrowUpRight,
  ArrowDownLeft,
  Calculator
} from "lucide-react";
import { format } from "date-fns";

export default function VaultPage() {
  const [user, setUser] = useState(null);
  const [depositAmount, setDepositAmount] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [vaultTransactions, setVaultTransactions] = useState([]);
  const [projectedEarnings, setProjectedEarnings] = useState({
    daily: 0,
    monthly: 0,
    yearly: 0
  });

  useEffect(() => {
    loadVaultData();
  }, []);

  useEffect(() => {
    if (user) {
      calculateProjectedEarnings();
    }
  }, [user]);

  const loadVaultData = async () => {
    try {
      const currentUser = await User.me();
      
      // Initialize vault data if not exists
      if (!currentUser.vault_balance) {
        await User.updateMyUserData({
          vault_balance: 0,
          vault_apy: 4.5,
          last_interest_calculation: new Date().toISOString(),
          special_role: "treasurer" // Set Treasurer role
        });
        currentUser.vault_balance = 0;
        currentUser.vault_apy = 4.5;
        currentUser.special_role = "treasurer";
      }
      
      setUser(currentUser);
      
      // Load vault transactions
      const transactions = await VaultTransaction.filter({
        user_wallet: currentUser.wallet_address
      }, '-created_date', 20);
      
      setVaultTransactions(transactions);
      
      // Calculate and apply interest if needed
      await calculateInterest(currentUser);
      
    } catch (error) {
      console.error("Error loading vault data:", error);
    }
  };

  const calculateInterest = async (userData) => {
    if (!userData.vault_balance || userData.vault_balance <= 0) return;
    
    const lastCalculation = new Date(userData.last_interest_calculation);
    const now = new Date();
    const hoursDiff = (now - lastCalculation) / (1000 * 60 * 60);
    
    // Calculate interest every hour (for demonstration)
    if (hoursDiff >= 1) {
      const hourlyRate = userData.vault_apy / 100 / 365 / 24;
      const interestEarned = userData.vault_balance * hourlyRate * hoursDiff;
      
      if (interestEarned > 0) {
        const newVaultBalance = userData.vault_balance + interestEarned;
        
        await User.updateMyUserData({
          vault_balance: newVaultBalance,
          last_interest_calculation: now.toISOString(),
          total_earned: (userData.total_earned || 0) + interestEarned
        });
        
        // Record interest payment
        await VaultTransaction.create({
          user_wallet: userData.wallet_address,
          transaction_type: "interest_payment",
          amount: interestEarned,
          balance_before: userData.vault_balance,
          balance_after: newVaultBalance,
          interest_rate: userData.vault_apy,
          status: "confirmed"
        });
        
        // Refresh user data
        const updatedUser = await User.me();
        setUser(updatedUser);
      }
    }
  };

  const calculateProjectedEarnings = () => {
    if (!user || !user.vault_balance) return;
    
    const principal = user.vault_balance;
    const apy = user.vault_apy / 100;
    
    const daily = principal * (apy / 365);
    const monthly = principal * (apy / 12);
    const yearly = principal * apy;
    
    setProjectedEarnings({ daily, monthly, yearly });
  };

  const handleDeposit = async () => {
    if (!depositAmount || parseFloat(depositAmount) <= 0) return;
    
    const amount = parseFloat(depositAmount);
    if (amount > user.spec_balance) {
      alert("Insufficient SPEC balance for deposit");
      return;
    }
    
    setIsProcessing(true);
    try {
      const newSpecBalance = user.spec_balance - amount;
      const newVaultBalance = (user.vault_balance || 0) + amount;
      
      await User.updateMyUserData({
        spec_balance: newSpecBalance,
        vault_balance: newVaultBalance,
        last_interest_calculation: new Date().toISOString()
      });
      
      await VaultTransaction.create({
        user_wallet: user.wallet_address,
        transaction_type: "deposit",
        amount: amount,
        balance_before: user.vault_balance || 0,
        balance_after: newVaultBalance,
        interest_rate: user.vault_apy,
        status: "confirmed"
      });
      
      setDepositAmount('');
      loadVaultData();
      
    } catch (error) {
      alert("Deposit failed: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleWithdraw = async () => {
    if (!withdrawAmount || parseFloat(withdrawAmount) <= 0) return;
    
    const amount = parseFloat(withdrawAmount);
    if (amount > user.vault_balance) {
      alert("Insufficient vault balance for withdrawal");
      return;
    }
    
    setIsProcessing(true);
    try {
      const newSpecBalance = user.spec_balance + amount;
      const newVaultBalance = user.vault_balance - amount;
      
      await User.updateMyUserData({
        spec_balance: newSpecBalance,
        vault_balance: newVaultBalance
      });
      
      await VaultTransaction.create({
        user_wallet: user.wallet_address,
        transaction_type: "withdrawal",
        amount: amount,
        balance_before: user.vault_balance,
        balance_after: newVaultBalance,
        interest_rate: user.vault_apy,
        status: "confirmed"
      });
      
      setWithdrawAmount('');
      loadVaultData();
      
    } catch (error) {
      alert("Withdrawal failed: " + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-neutral-400 mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading vault...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
              <Vault className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 gradient-text">SPEC Vault</h1>
              <p className="text-neutral-400">Earn {user.vault_apy}% APY on your SPEC tokens</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
              {user.special_role?.toUpperCase() || 'USER'}
            </Badge>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              {user.vault_apy}% APY
            </Badge>
          </div>
        </div>
      </div>

      {/* Vault Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Vault className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-sm text-neutral-400">Vault Balance</p>
              <p className="text-2xl font-bold text-neutral-100">
                {(user.vault_balance || 0).toLocaleString()} SPEC
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">≈ ${((user.vault_balance || 0) * 1.00).toLocaleString()} USD</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-sm text-neutral-400">Daily Earnings</p>
              <p className="text-2xl font-bold text-neutral-100">
                {projectedEarnings.daily.toFixed(2)} SPEC
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">≈ ${(projectedEarnings.daily * 1.00).toFixed(2)} USD</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <DollarSign className="w-8 h-8 text-yellow-400" />
            <div>
              <p className="text-sm text-neutral-400">Monthly Earnings</p>
              <p className="text-2xl font-bold text-neutral-100">
                {projectedEarnings.monthly.toFixed(2)} SPEC
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">≈ ${(projectedEarnings.monthly * 1.00).toFixed(2)} USD</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Calculator className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-sm text-neutral-400">Yearly Earnings</p>
              <p className="text-2xl font-bold text-neutral-100">
                {projectedEarnings.yearly.toFixed(2)} SPEC
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">≈ ${(projectedEarnings.yearly * 1.00).toFixed(2)} USD</p>
        </div>
      </div>

      {/* Deposit/Withdraw */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-bold text-neutral-100 mb-4">Deposit to Vault</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-neutral-400 mb-2">
                Available: {user.spec_balance.toLocaleString()} SPEC
              </p>
              <Input
                type="number"
                placeholder="Amount to deposit"
                value={depositAmount}
                onChange={(e) => setDepositAmount(e.target.value)}
                className="bg-white/5 border-white/20 text-neutral-100"
              />
            </div>
            <Button
              onClick={handleDeposit}
              disabled={isProcessing || !depositAmount}
              className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
            >
              {isProcessing ? 'Processing...' : 'Deposit to Vault'}
            </Button>
          </div>
        </div>

        <div className="glass-card rounded-xl p-6">
          <h3 className="text-lg font-bold text-neutral-100 mb-4">Withdraw from Vault</h3>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-neutral-400 mb-2">
                In Vault: {(user.vault_balance || 0).toLocaleString()} SPEC
              </p>
              <Input
                type="number"
                placeholder="Amount to withdraw"
                value={withdrawAmount}
                onChange={(e) => setWithdrawAmount(e.target.value)}
                className="bg-white/5 border-white/20 text-neutral-100"
              />
            </div>
            <Button
              onClick={handleWithdraw}
              disabled={isProcessing || !withdrawAmount}
              variant="outline"
              className="w-full border-white/20 text-neutral-200 hover:bg-white/10"
            >
              {isProcessing ? 'Processing...' : 'Withdraw from Vault'}
            </Button>
          </div>
        </div>
      </div>

      {/* Recent Vault Transactions */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-lg font-bold text-neutral-100 mb-6">Recent Vault Activity</h3>
        <div className="space-y-3">
          {vaultTransactions.length > 0 ? (
            vaultTransactions.map((tx) => (
              <div key={tx.id} className="glass-effect rounded-lg p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {tx.transaction_type === 'deposit' ? (
                      <ArrowDownLeft className="w-5 h-5 text-green-400" />
                    ) : tx.transaction_type === 'withdrawal' ? (
                      <ArrowUpRight className="w-5 h-5 text-red-400" />
                    ) : (
                      <TrendingUp className="w-5 h-5 text-blue-400" />
                    )}
                    <div>
                      <p className="font-medium text-neutral-200 capitalize">
                        {tx.transaction_type.replace('_', ' ')}
                      </p>
                      <p className="text-xs text-neutral-400">
                        {format(new Date(tx.created_date), 'MMM d, yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-bold ${
                      tx.transaction_type === 'deposit' || tx.transaction_type === 'interest_payment' 
                        ? 'text-green-400' 
                        : 'text-red-400'
                    }`}>
                      {tx.transaction_type === 'withdrawal' ? '-' : '+'}
                      {tx.amount.toFixed(6)} SPEC
                    </p>
                    <p className="text-xs text-neutral-400">
                      Balance: {tx.balance_after.toFixed(2)} SPEC
                    </p>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-neutral-400">
              <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No vault transactions yet</p>
              <p className="text-sm">Start earning by depositing SPEC tokens</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}