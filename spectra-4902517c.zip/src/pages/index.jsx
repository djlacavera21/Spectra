import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Marketplace from "./Marketplace";

import Admin from "./Admin";

import Portfolio from "./Portfolio";

import Transactions from "./Transactions";

import FabricIntegration from "./FabricIntegration";

import Swap from "./Swap";

import UserWallets from "./UserWallets";

import Vault from "./Vault";

import ExternalMarketplaces from "./ExternalMarketplaces";

import Staking from "./Staking";

import Wallet from "./Wallet";

import MasterVault from "./MasterVault";

import Trading from "./Trading";

import Fabric from "./Fabric";

import IBMFabricConsole from "./IBMFabricConsole";

import MultiBlockchainDeployment from "./MultiBlockchainDeployment";

import EthereumConsole from "./EthereumConsole";

import SolanaConsole from "./SolanaConsole";

import BuySpectra from "./BuySpectra";

import CoinGenesisChamber from "./CoinGenesisChamber";

import Mining from "./Mining";

import CoinGenesisIncubator from "./CoinGenesisIncubator";

import ComplianceCenter from "./ComplianceCenter";

import SecurityCenter from "./SecurityCenter";

import NotificationCenter from "./NotificationCenter";

import BlockchainGateway from "./BlockchainGateway";

import BitcoinBroadcast from "./BitcoinBroadcast";

import Explorer from "./Explorer";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Marketplace: Marketplace,
    
    Admin: Admin,
    
    Portfolio: Portfolio,
    
    Transactions: Transactions,
    
    FabricIntegration: FabricIntegration,
    
    Swap: Swap,
    
    UserWallets: UserWallets,
    
    Vault: Vault,
    
    ExternalMarketplaces: ExternalMarketplaces,
    
    Staking: Staking,
    
    Wallet: Wallet,
    
    MasterVault: MasterVault,
    
    Trading: Trading,
    
    Fabric: Fabric,
    
    IBMFabricConsole: IBMFabricConsole,
    
    MultiBlockchainDeployment: MultiBlockchainDeployment,
    
    EthereumConsole: EthereumConsole,
    
    SolanaConsole: SolanaConsole,
    
    BuySpectra: BuySpectra,
    
    CoinGenesisChamber: CoinGenesisChamber,
    
    Mining: Mining,
    
    CoinGenesisIncubator: CoinGenesisIncubator,
    
    ComplianceCenter: ComplianceCenter,
    
    SecurityCenter: SecurityCenter,
    
    NotificationCenter: NotificationCenter,
    
    BlockchainGateway: BlockchainGateway,
    
    BitcoinBroadcast: BitcoinBroadcast,
    
    Explorer: Explorer,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Marketplace" element={<Marketplace />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/Portfolio" element={<Portfolio />} />
                
                <Route path="/Transactions" element={<Transactions />} />
                
                <Route path="/FabricIntegration" element={<FabricIntegration />} />
                
                <Route path="/Swap" element={<Swap />} />
                
                <Route path="/UserWallets" element={<UserWallets />} />
                
                <Route path="/Vault" element={<Vault />} />
                
                <Route path="/ExternalMarketplaces" element={<ExternalMarketplaces />} />
                
                <Route path="/Staking" element={<Staking />} />
                
                <Route path="/Wallet" element={<Wallet />} />
                
                <Route path="/MasterVault" element={<MasterVault />} />
                
                <Route path="/Trading" element={<Trading />} />
                
                <Route path="/Fabric" element={<Fabric />} />
                
                <Route path="/IBMFabricConsole" element={<IBMFabricConsole />} />
                
                <Route path="/MultiBlockchainDeployment" element={<MultiBlockchainDeployment />} />
                
                <Route path="/EthereumConsole" element={<EthereumConsole />} />
                
                <Route path="/SolanaConsole" element={<SolanaConsole />} />
                
                <Route path="/BuySpectra" element={<BuySpectra />} />
                
                <Route path="/CoinGenesisChamber" element={<CoinGenesisChamber />} />
                
                <Route path="/Mining" element={<Mining />} />
                
                <Route path="/CoinGenesisIncubator" element={<CoinGenesisIncubator />} />
                
                <Route path="/ComplianceCenter" element={<ComplianceCenter />} />
                
                <Route path="/SecurityCenter" element={<SecurityCenter />} />
                
                <Route path="/NotificationCenter" element={<NotificationCenter />} />
                
                <Route path="/BlockchainGateway" element={<BlockchainGateway />} />
                
                <Route path="/BitcoinBroadcast" element={<BitcoinBroadcast />} />
                
                <Route path="/Explorer" element={<Explorer />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}