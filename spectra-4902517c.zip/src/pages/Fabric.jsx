
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Plus, 
  Network,
  CheckCircle,
  Timer,
  Unplug
} from "lucide-react";
import { User, FabricEntry, Transaction, SystemSettings } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

import FabricUploadModal from "../components/fabric/FabricUploadModal";
import FabricRewards from "../components/fabric/FabricRewards";
import FabricEntries from "../components/fabric/FabricEntries";
import TransparencyScore from "../components/fabric/TransparencyScore";

export default function Fabric() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [fabricEntries, setFabricEntries] = useState([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isConnecting, setIsConnecting] = useState(false);
  const [fabricConnected, setFabricConnected] = useState(false);
  const [transparencyScore, setTransparencyScore] = useState(0);
  const [rewardStats, setRewardStats] = useState({
    totalEarned: 0,
    thisMonth: 0,
    nextReward: 0,
    multiplier: 1.0
  });

  useEffect(() => {
    loadFabricData();
    checkFabricConnection();
  }, []);

  const checkFabricConnection = async () => {
    setIsConnecting(true);
    try {
      const settings = await SystemSettings.list();
      const fabricConfigured = settings.some(s => s.hyperledger_node_url);
      
      if (fabricConfigured) {
        // Simulate a handshake/status check with the configured node
        const response = await InvokeLLM({
          prompt: "Verify connectivity to a configured Hyperledger Fabric node. Return status.",
          response_json_schema: {
            type: "object",
            properties: {
              connected: { type: "boolean" },
              message: { type: "string" }
            }
          }
        });
        setFabricConnected(response.connected);
      } else {
        setFabricConnected(false);
      }
    } catch (error) {
      console.error("Failed to check Fabric connection:", error);
      setFabricConnected(false);
    } finally {
      setIsConnecting(false);
    }
  };

  const loadFabricData = async () => {
    setIsLoading(true); // Set loading true at the beginning
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      if (currentUser?.wallet_address) {
        const entries = await FabricEntry.filter(
          { user_wallet: currentUser.wallet_address },
          '-created_date',
          100
        );
        setFabricEntries(entries);
        calculateTransparencyScore(entries);
        calculateRewards(entries);
      }
    } catch (error) {
      console.error("Error loading fabric data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const calculateTransparencyScore = (entries) => {
    const categories = ['trade', 'swap', 'marketplace', 'whale_transaction', 'product_purchase', 'contract', 'data'];
    const uniqueCategories = new Set(entries.map(e => e.entry_type)).size;
    const totalEntries = entries.length;
    const verifiedEntries = entries.filter(e => e.verification_status === 'verified').length;
    
    let score = 0;
    score += (uniqueCategories / categories.length) * 30; // Diversity bonus
    score += Math.min(totalEntries * 2, 40); // Volume bonus (max 40)
    score += (verifiedEntries / Math.max(totalEntries, 1)) * 30; // Verification bonus

    setTransparencyScore(Math.min(100, Math.round(score)));
  };

  const calculateRewards = (entries) => {
    const totalEntries = entries.length;
    const verifiedEntries = entries.filter(e => e.verification_status === 'verified').length;
    const thisMonthEntries = entries.filter(e => 
      new Date(e.created_date) > new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    ).length;

    const baseReward = 10; // Base SPEC per entry
    const verificationBonus = 5; // Extra SPEC for verified entries
    const transparencyMultiplier = 1 + (transparencyScore / 100);

    const totalEarned = (totalEntries * baseReward + verifiedEntries * verificationBonus) * transparencyMultiplier;
    const thisMonth = (thisMonthEntries * baseReward) * transparencyMultiplier;
    const nextReward = baseReward * transparencyMultiplier;

    setRewardStats({
      totalEarned: Math.round(totalEarned),
      thisMonth: Math.round(thisMonth),
      nextReward: Math.round(nextReward),
      multiplier: transparencyMultiplier
    });
  };

  const calculateTransparencyContribution = (entryType) => {
    const weights = {
      'whale_transaction': 5,
      'contract': 4,
      'product_purchase': 3,
      'trade': 2,
      'swap': 2,
      'marketplace': 2,
      'data': 1
    };
    return (weights[entryType] || 1) * (1 + (transparencyScore / 200));
  };

  const handleUpload = async (entryData, files) => {
    try {
      const newEntry = await FabricEntry.create({
        ...entryData,
        user_wallet: user.wallet_address,
        verification_status: 'pending',
        reward_earned: Math.round(rewardStats.nextReward),
        transparency_contribution: calculateTransparencyContribution(entryData.entry_type)
      });

      // Award SPEC tokens for the upload
      const currentBalance = user.spec_balance || 0;
      await User.updateMyUserData({
        spec_balance: currentBalance + rewardStats.nextReward
      });

      // Create reward transaction
      await Transaction.create({
        from_address: "fabric_rewards",
        to_address: user.wallet_address,
        amount: rewardStats.nextReward,
        transaction_type: "fabric_reward",
        status: "confirmed",
        metadata: {
          entry_type: entryData.entry_type,
          transparency_bonus: transparencyScore > 75 ? "high" : transparencyScore > 50 ? "medium" : "low"
        }
      });

      setShowUploadModal(false);
      loadFabricData(); // Refresh data
      alert(`Upload successful! You earned ${rewardStats.nextReward} SPEC tokens.`);
    } catch (error) {
      console.error("Error uploading to fabric:", error);
      alert("Failed to upload to fabric. Please try again.");
    }
  };

  // The initial loading spinner block is now removed, as isLoading is passed to FabricEntries.

  return (
    <div className="space-y-6">
      <FabricUploadModal
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onUpload={handleUpload}
        isProcessing={isLoading}
      />

      <div className="glass-card rounded-xl p-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Network className="w-10 h-10 text-blue-400" />
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 gradient-text">Personal Fabric</h1>
              <p className="text-neutral-400">Contribute to the decentralized Master Fabric and earn transparency rewards.</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button onClick={checkFabricConnection} variant="outline" className="border-white/20 text-neutral-200" disabled={isConnecting}>
              {isConnecting ? (
                <Timer className="w-4 h-4 mr-2 animate-spin" />
              ) : fabricConnected ? (
                <CheckCircle className="w-4 h-4 mr-2 text-green-400" />
              ) : (
                <Unplug className="w-4 h-4 mr-2 text-red-400" />
              )}
              {isConnecting ? 'Checking...' : fabricConnected ? 'Connected' : 'Not Connected'}
            </Button>
            <Button 
              onClick={() => setShowUploadModal(true)} 
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              disabled={!fabricConnected || isConnecting}
            >
              <Plus className="w-4 h-4 mr-2" />
              Add to Fabric
            </Button>
          </div>
        </div>
        {!fabricConnected && !isConnecting && (
          <Alert variant="destructive" className="mt-4 bg-red-900/50 border-red-500/30 text-red-300">
            <Unplug className="h-4 w-4 !text-red-300" />
            <AlertDescription>
              Your personal fabric is not connected to the Hyperledger network. Please have an administrator configure the connection from the {" "}
              <a href={createPageUrl("FabricIntegration")} className="font-bold underline hover:text-red-200">
                Fabric Integration
              </a>
              {" "}page. You cannot add entries until a connection is established.
            </AlertDescription>
          </Alert>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <FabricEntries entries={fabricEntries} isLoading={isLoading} onRefresh={loadFabricData} />
        </div>
        <div className="space-y-6">
          <TransparencyScore 
            score={transparencyScore} 
            entriesCount={fabricEntries.length} // Keep these props for TransparencyScore
            verifiedCount={fabricEntries.filter(e => e.verification_status === 'verified').length}
          />
          <FabricRewards 
            stats={rewardStats}
            transparencyScore={transparencyScore} // Keep this prop for FabricRewards
          />
        </div>
      </div>
    </div>
  );
}
