
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Users, 
  Settings, 
  Activity,
  Network,
  Zap, // Existing import for Trading Engine icon
  Gavel, // Existing import for Compliance icon
  Package, // Added for new tab
  AlertTriangle // New import for Transaction Resolver icon
} from 'lucide-react';
import UserManagement from '../components/admin/UserManagement';
import SystemConfiguration from '../components/admin/SystemConfiguration';
import LiveBlockchainControls from '../components/admin/LiveBlockchainControls';
import SystemNotices from '../components/admin/SystemNotices';
import RealOrderMatchingEngine from '../components/trading/RealOrderMatchingEngine';
import ComplianceCenterComponent from '../components/admin/ComplianceCenterComponent'; 
import DesktopAppBuilder from '../components/admin/DesktopAppBuilder'; 
import TransactionResolver from '../components/admin/TransactionResolver'; // New import

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('transaction-resolver'); // Changed default tab

  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center gap-3">
            <Shield className="w-8 h-8 text-red-400" />
            <div>
              <CardTitle className="text-2xl font-bold text-neutral-100">Administrator Panel</CardTitle>
              <p className="text-neutral-400">Platform management and operational controls.</p>
            </div>
          </div>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        {/* Updated to 9 columns for new tab */}
        <TabsList className="grid w-full grid-cols-9 glass-effect">
          <TabsTrigger value="transaction-resolver" className="text-neutral-300 data-[state=active]:text-white">
            <AlertTriangle className="w-4 h-4 mr-2" />
            TX Resolver
          </TabsTrigger>
          <TabsTrigger value="overview" className="text-neutral-300 data-[state=active]:text-white">
            <Activity className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="users" className="text-neutral-300 data-[state=active]:text-white">
            <Users className="w-4 h-4 mr-2" />
            Users
          </TabsTrigger>
          <TabsTrigger value="trading-engine" className="text-neutral-300 data-[state=active]:text-white">
            <Zap className="w-4 h-4 mr-2" />
            Trading Engine
          </TabsTrigger>
          <TabsTrigger value="compliance" className="text-neutral-300 data-[state=active]:text-white">
            <Gavel className="w-4 h-4 mr-2" />
            Compliance
          </TabsTrigger>
          <TabsTrigger value="builds" className="text-neutral-300 data-[state=active]:text-white">
             <Package className="w-4 h-4 mr-2" />
             Builds
          </TabsTrigger>
          <TabsTrigger value="system" className="text-neutral-300 data-[state=active]:text-white">
            <Settings className="w-4 h-4 mr-2" />
            System
          </TabsTrigger>
          <TabsTrigger value="security" className="text-neutral-300 data-[state=active]:text-white">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="blockchain" className="text-neutral-300 data-[state=active]:text-white">
            <Network className="w-4 h-4 mr-2" />
            Blockchain
          </TabsTrigger>
        </TabsList>
        
        {/* New Transaction Resolver Tab Content */}
        <TabsContent value="transaction-resolver" className="mt-6">
          <TransactionResolver />
        </TabsContent>

        {/* Overview Tab Content */}
        <TabsContent value="overview" className="mt-6">
          <Card className="glass-card">
            <CardContent>
              <p className="text-neutral-400">Welcome to the Admin Dashboard. Select a tab to manage different aspects of the platform.</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Management Tab Content */}
        <TabsContent value="users" className="mt-6">
          <UserManagement />
        </TabsContent>

        {/* Trading Engine Tab Content */}
        <TabsContent value="trading-engine" className="mt-6">
          <RealOrderMatchingEngine />
        </TabsContent>

        {/* New Compliance Tab Content */}
        <TabsContent value="compliance" className="mt-6">
          <ComplianceCenterComponent />
        </TabsContent>

        {/* New Builds Tab Content */}
        <TabsContent value="builds" className="mt-6">
          <DesktopAppBuilder />
        </TabsContent>

        {/* System Configuration Tab Content */}
        <TabsContent value="system" className="mt-6">
          <SystemConfiguration />
        </TabsContent>

        {/* Security Tab Content */}
        <TabsContent value="security" className="mt-6">
          <SystemNotices />
        </TabsContent>

        {/* Live Blockchain Controls Tab Content */}
        <TabsContent value="blockchain" className="mt-6">
          <LiveBlockchainControls />
        </TabsContent>
      </Tabs>
    </div>
  );
}
