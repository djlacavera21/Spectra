
import React, { useState, useEffect } from "react";
import { User, SystemSettings, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { generateSpecAddress } from "@/components/common/WalletUtils"; // Corrected import path

import StatsGrid from "../components/dashboard/StatsGrid";
import RecentTransactions from "../components/dashboard/RecentTransactions";
import LiveMetrics from "../components/dashboard/LiveMetrics";
import SeedPhraseSetup from "../components/wallet/SeedPhraseSetup";
import CombinedSPECWallet from "../components/dashboard/CombinedSPECWallet";
import UnifiedMarketChart from "../components/dashboard/UnifiedMarketChart";

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showSeedPhraseSetup, setShowSeedPhraseSetup] = useState(false);
  const [systemMetrics, setSystemMetrics] = useState(null);

  useEffect(() => {
    loadDashboardData();
    loadSystemMetrics();
  }, []);

  const loadSystemMetrics = async () => {
    try {
      const [users, allTransactions, settings] = await Promise.all([
        User.list(),
        Transaction.list(),
        SystemSettings.list()
      ]);

      const totalUsers = users.length;
      const totalTransactions = allTransactions.length;
      const activeUsers24h = users.filter(u => {
        const lastActive = new Date(u.updated_date);
        const now = new Date();
        const hoursDiff = (now - lastActive) / (1000 * 60 * 60);
        return hoursDiff <= 24;
      }).length;

      const totalSupply = settings[0]?.total_spec_supply || 0;
      const circulatingSupply = totalSupply * 0.85;

      const now = new Date();
      const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
      const recent24hTransactions = allTransactions.filter(tx => 
        new Date(tx.created_date) >= yesterday
      );
      const volume24h = recent24hTransactions.reduce((sum, tx) => sum + tx.amount, 0);

      const tps = recent24hTransactions.length > 0 ? recent24hTransactions.length / (24 * 60 * 60) : 0;

      const latestTransaction = allTransactions
        .filter(tx => tx.block_number)
        .sort((a, b) => b.block_number - a.block_number)[0];
      const blockHeight = latestTransaction?.block_number || 0;

      setSystemMetrics({
        totalUsers: totalUsers,
        totalTransactions: totalTransactions,
        activeUsers24h: activeUsers24h,
        totalSupply: totalSupply,
        circulatingSupply: circulatingSupply,
        volume24h: volume24h,
        tps: parseFloat(tps.toFixed(3)),
        blockHeight: blockHeight,
        networkStatus: settings[0]?.network_status || 'online'
      });

    } catch (error) {
      console.error("Error loading system metrics:", error);
      setSystemMetrics({
        totalUsers: 0,
        totalTransactions: 0,
        activeUsers24h: 0,
        totalSupply: 0,
        circulatingSupply: 0,
        volume24h: 0,
        tps: 0,
        blockHeight: 0,
        networkStatus: 'offline'
      });
    }
  };

  const loadDashboardData = async () => {
    try {
      let currentUser = await User.me();
      
      if (!currentUser.seed_phrase_confirmed) {
        setShowSeedPhraseSetup(true);
      }
      
      const updates = {};

      if (!currentUser.wallet_address || !currentUser.wallet_address.startsWith('spec_')) {
        // Use the new, correct address generation standard
        updates.wallet_address = generateSpecAddress();
      }
      if (!currentUser.secondary_wallet_address || !currentUser.secondary_wallet_address.startsWith('spec_')) {
        // Use the new, correct address generation standard for the secondary wallet
        updates.secondary_wallet_address = generateSpecAddress();
      }

      if (Object.keys(updates).length > 0) {
        await User.updateMyUserData(updates);
        currentUser = { ...currentUser, ...updates };
      }
      
      setUser(currentUser);
      
      const userTransactions = await Transaction.filter({
        from_address: currentUser.wallet_address
      }, '-created_date', 10);
      
      const receivedTransactions = await Transaction.filter({
        to_address: currentUser.wallet_address
      }, '-created_date', 10);
      
      const allTransactions = [...userTransactions, ...receivedTransactions]
        .sort((a, b) => new Date(b.created_date).getTime() - new Date(a.created_date).getTime());
      
      setTransactions(allTransactions);
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSeedPhraseComplete = async (seedPhrase) => {
    try {
      await User.updateMyUserData({
        seed_phrase_confirmed: true,
        backup_completed: true
      });
      setShowSeedPhraseSetup(false);
      loadDashboardData();
    } catch (error) {
      console.error("Error saving seed phrase confirmation:", error);
      alert("Failed to confirm seed phrase. Please try again.");
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (showSeedPhraseSetup) {
    return (
      <div className="space-y-6">
        <SeedPhraseSetup onComplete={handleSeedPhraseComplete} user={user} />
      </div>
    );
  }

  const stats = {
    totalEarned: user?.total_earned || 0,
    totalSpent: user?.total_spent || 0,
    tradingLevel: user?.trading_level || "bronze"
  };

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
              Welcome back, {user?.full_name || 'Trader'}!
            </h1>
            <p className="text-neutral-400">
              Manage your SPEC tokens and explore the marketplace
            </p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => navigate(createPageUrl("Marketplace"))}
              className="bg-gradient-to-r from-gray-500 to-gray-700 hover:from-gray-600 hover:to-gray-800 text-white border-none"
            >
              <Plus className="w-4 h-4 mr-2" />
              Explore
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <StatsGrid stats={stats} />
      
      {/* Wallet and Recent Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        <div className="lg:col-span-3">
          <CombinedSPECWallet user={user} specToUsdRate={1.0} />
        </div>
        <div className="lg:col-span-2">
          <RecentTransactions
            transactions={transactions}
            currentUserAddress={user?.wallet_address}
            onViewAll={() => navigate(createPageUrl("Transactions"))}
          />
        </div>
      </div>

      {/* Live Metrics */}
      <div>
        <LiveMetrics systemMetrics={systemMetrics} />
      </div>
    </div>
  );
}
