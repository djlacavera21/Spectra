import React, { useState, useEffect } from "react";
import { User, TradingPair } from "@/api/entities";
import { useSignature } from "../components/common/SignatureContext";
import { MarketDataProvider, useMarketData } from "../components/trading/MarketDataFeed";

import PairSelector from "../components/trading/PairSelector";
import TradingChart from "../components/trading/TradingChart";
import TradingForm from "../components/trading/TradingForm";
import OrderHistory from "../components/trading/OrderHistory";
import MarketStats from "../components/trading/MarketStats";
import RealTimeOrderBook from "../components/trading/RealTimeOrderBook";
import RecentTrades from "../components/trading/RecentTrades";
import LivePriceTicker from "../components/trading/LivePriceTicker";

const TradingContent = () => {
  const { marketData, isLoading } = useMarketData();

  if (isLoading || !marketData.stats) {
     return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-12 gap-4">
      {/* Main Chart Area */}
      <div className="col-span-12 lg:col-span-9 space-y-4">
        <MarketStats pair={marketData.stats} />
        <TradingChart data={marketData.ohlcv} />
      </div>

      {/* Side Panel */}
      <div className="col-span-12 lg:col-span-3 space-y-4">
        <RealTimeOrderBook orderBook={marketData.orderBook} />
        <RecentTrades trades={marketData.recentTrades} />
      </div>

      {/* Bottom Area */}
      <div className="col-span-12 lg:col-span-7">
        <TradingForm pair={marketData.stats} />
      </div>
      <div className="col-span-12 lg:col-span-5">
        <OrderHistory pairSymbol={marketData.stats?.symbol} />
      </div>
    </div>
  );
};

export default function TradingPage() {
  const [user, setUser] = useState(null);
  const [tradingPairs, setTradingPairs] = useState([]);
  const [selectedPair, setSelectedPair] = useState(null);

  useEffect(() => {
    const loadInitialData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        const pairs = await TradingPair.filter({ is_active: true });
        setTradingPairs(pairs);
        if (pairs.length > 0) {
          setSelectedPair(pairs.find(p => p.symbol === 'SPEC/USDT') || pairs[0]);
        }
      } catch (error) {
        console.error("Error loading trading page data:", error);
      }
    };
    loadInitialData();
  }, []);

  if (!selectedPair) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <MarketDataProvider pairSymbol={selectedPair.symbol}>
      <div className="space-y-4">
        <LivePriceTicker />
        
        <div className="w-full">
          <PairSelector
            pairs={tradingPairs}
            selectedPair={selectedPair}
            onSelectPair={setSelectedPair}
          />
        </div>
        
        <TradingContent />
      </div>
    </MarketDataProvider>
  );
}