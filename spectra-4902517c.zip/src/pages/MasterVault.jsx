
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Vault,
  Shield,
  Key,
  Snowflake,
  Thermometer,
  Flame,
  Lock,
  Users,
  Server // Added Server icon
} from 'lucide-react';

import MasterVaultOverview from '../components/vault/MasterVaultOverview';
import WalletTierCard from '../components/vault/WalletTierCard';
import RecentVaultMovements from '../components/vault/RecentVaultMovements';
import VaultControls from '../components/vault/VaultControls';
import HSMIntegration from '../components/vault/HSMIntegration'; // Added HSMIntegration import

export default function MasterVaultPage() {
  const [activeTab, setActiveTab] = useState('overview');
  const [vaultStatus, setVaultStatus] = useState({
    coldWallet: { status: 'secure', balance: 75000000 },
    warmWallet: { status: 'operational', balance: 5000000 },
    hotWallet: { status: 'active', balance: 500000 },
    hsmStatus: 'connected',
    multiSigActive: true
  });

  useEffect(() => {
    // This would be replaced with real API calls to the HSM and blockchain nodes
    const fetchVaultStatus = async () => {
      // Real-world: await getHsmStatus(), await getWalletBalances(), etc.
      // For now, we use state to represent the real data we would fetch.
    };
    fetchVaultStatus();
  }, []);

  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Vault className="w-8 h-8 text-yellow-400" />
              <div>
                <CardTitle className="text-2xl font-bold text-neutral-100">Master Vault</CardTitle>
                <p className="text-neutral-400">Multi-tier wallet infrastructure with HSM security</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
               <div className="flex items-center gap-2">
                 <Shield className={`w-5 h-5 ${vaultStatus.hsmStatus === 'connected' ? 'text-green-400' : 'text-red-400'}`} />
                 <span className="text-sm text-neutral-300">HSM {vaultStatus.hsmStatus === 'connected' ? 'Connected' : 'Disconnected'}</span>
               </div>
               <div className="flex items-center gap-2">
                 <Users className={`w-5 h-5 ${vaultStatus.multiSigActive ? 'text-green-400' : 'text-red-400'}`} />
                 <span className="text-sm text-neutral-300">Multi-Sig {vaultStatus.multiSigActive ? 'Active' : 'Inactive'}</span>
               </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Vault Security Status */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Snowflake className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-sm text-neutral-400">Cold Storage</p>
                <p className="text-2xl font-bold text-neutral-100">{(vaultStatus.coldWallet.balance / 1000000).toFixed(1)}M SPEC</p>
                <Badge className="mt-1 bg-blue-500/20 text-blue-400">Offline Secure</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Thermometer className="w-8 h-8 text-yellow-400" />
              <div>
                <p className="text-sm text-neutral-400">Warm Storage</p>
                <p className="text-2xl font-bold text-neutral-100">{(vaultStatus.warmWallet.balance / 1000000).toFixed(1)}M SPEC</p>
                <Badge className="mt-1 bg-yellow-500/20 text-yellow-400">Delayed Access</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Flame className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-sm text-neutral-400">Hot Wallet</p>
                <p className="text-2xl font-bold text-neutral-100">{(vaultStatus.hotWallet.balance / 1000).toFixed(0)}K SPEC</p>
                <Badge className="mt-1 bg-red-500/20 text-red-400">Instant Access</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-effect">
          <TabsTrigger value="overview" className="text-neutral-300 data-[state=active]:text-white">
            <Vault className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="wallets" className="text-neutral-300 data-[state=active]:text-white">
            <Key className="w-4 h-4 mr-2" />
            Wallet Tiers
          </TabsTrigger>  
           <TabsTrigger value="movements" className="text-neutral-300 data-[state=active]:text-white">
            <Lock className="w-4 h-4 mr-2" />
            Movements
          </TabsTrigger>
          <TabsTrigger value="controls" className="text-neutral-300 data-[state=active]:text-white">
            <Shield className="w-4 h-4 mr-2" />
            Security Controls
          </TabsTrigger>
          <TabsTrigger value="hsm" className="text-neutral-300 data-[state=active]:text-white">
            <Server className="w-4 h-4 mr-2" />
            HSM Integration
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <MasterVaultOverview vaultStatus={vaultStatus}/>
        </TabsContent>
        
        <TabsContent value="wallets" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <WalletTierCard 
              tier="cold"
              name="Cold Storage"
              icon={Snowflake}
              balance={vaultStatus.coldWallet.balance}
              status={vaultStatus.coldWallet.status}
              description="Offline storage with hardware security modules"
            />
            <WalletTierCard 
              tier="warm"
              name="Warm Storage"
              icon={Thermometer}
              balance={vaultStatus.warmWallet.balance}
              status={vaultStatus.warmWallet.status}
              description="Delayed withdrawal buffer with multi-sig approval"
            />
            <WalletTierCard 
              tier="hot"
              name="Hot Wallet"
              icon={Flame}
              balance={vaultStatus.hotWallet.balance}
              status={vaultStatus.hotWallet.status}
              description="Instant access for user withdrawals and trading"
            />
          </div>
        </TabsContent>

        <TabsContent value="movements" className="mt-6">
          <RecentVaultMovements />
        </TabsContent>

        <TabsContent value="controls" className="mt-6">
          <VaultControls vaultStatus={vaultStatus} onStatusChange={setVaultStatus} />
        </TabsContent>

        <TabsContent value="hsm" className="mt-6">
          <HSMIntegration />
        </TabsContent>
      </Tabs>
    </div>
  );
}
