import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Activity,
  Zap,
  Database,
  Code,
  Network,
  Shield,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Server,
  Layers,
  Settings,
  Monitor,
  Globe,
  Coins,
  Wand2
} from "lucide-react";

import NetworkStats from "../components/solana/NetworkStats";
import SplTokenDashboard from "../components/solana/SplTokenDashboard";
import RpcEndpointManager from "../components/solana/RpcEndpointManager";
import TransactionMonitor from "../components/solana/TransactionMonitor";
import RustProgramWizard from '../components/solana/RustProgramWizard';
import ProgramSigningCard from '../components/solana/ProgramSigningCard';

export default function SolanaConsole() {
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [clusterInfo, setClusterInfo] = useState({
    status: 'healthy',
    currentSlot: 234567891,
    epochInfo: { epoch: 456, slotIndex: 12345, slotsInEpoch: 432000 },
    tps: 2847,
    validators: 1589,
    totalStake: '398,247,293 SOL'
  });
  const [networkMetrics, setNetworkMetrics] = useState({
    totalSupply: '450,123,456 SOL',
    inflationRate: '5.2%',
    transactions24h: '47,583,291',
    avgSlotTime: '400ms',
    stakeRatio: '73.4%'
  });

  const [programAwaitingSignature, setProgramAwaitingSignature] = useState(null);

  // --- Style Definitions for Buttons ---
  const baseButtonStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '0.375rem',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
    cursor: 'pointer',
    border: '1px solid transparent',
    padding: '0.5rem 1rem'
  };

  const gradientStyle = (from, to) => ({ ...baseButtonStyle, color: '#ffffff', background: `linear-gradient(to right, ${from}, ${to})` });
  const hoverGradientStyle = (from, to) => ({ background: `linear-gradient(to right, ${from}, ${to})` });
  
  const outlineStyle = { ...baseButtonStyle, backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' };
  const hoverOutlineStyle = { backgroundColor: 'rgba(255, 255, 255, 0.1)' };

  const tabsTriggerStyle = { ...baseButtonStyle, flex: 1, backgroundColor: 'transparent', color: '#a3a3a3' };
  const activeTabsTriggerStyle = { ...tabsTriggerStyle, backgroundColor: '#1e1e1e', color: '#a78bfa' };
  const hoverTabsTriggerStyle = { backgroundColor: 'rgba(255, 255, 255, 0.05)' };

  const solanaAccentColor = '#00FFA3';

  useEffect(() => {
    loadConsoleData();
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      updateRealTimeData();
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const loadConsoleData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error("Error loading console data:", error);
    }
  };

  const updateRealTimeData = () => {
    setClusterInfo(prev => ({
      ...prev,
      currentSlot: prev.currentSlot + Math.floor(Math.random() * 10) + 1,
      tps: Math.floor(prev.tps + (Math.random() - 0.5) * 200),
      epochInfo: {
        ...prev.epochInfo,
        slotIndex: prev.epochInfo.slotIndex + Math.floor(Math.random() * 10) + 1
      }
    }));
  };

  const handleDeployFromWizard = (program) => {
    setProgramAwaitingSignature(program);
  };
  
  const handleProgramSigned = async (signedProgram) => {
    // Process the signed program
    setProgramAwaitingSignature(null);
    
    // Show success message
    alert(`Program "${signedProgram.name}" deployment initiated!\nEstimated cost: ${signedProgram.totalCost.toFixed(6)} SOL\nEstimated time: ${signedProgram.estimatedTime}`);
  };

  const handleProgramSigningCancelled = () => {
    setProgramAwaitingSignature(null);
  };

  if (!user || (user.special_role !== 'admin' && user.special_role !== 'treasurer')) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8 text-center">
          <Shield className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-neutral-100 mb-2">Access Restricted</h3>
          <p className="text-neutral-400">Administrator access required for Solana Console</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-green-400 rounded-xl flex items-center justify-center">
              <Layers className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 mb-2">Solana Console</h1>
              <p className="text-neutral-400">
                High-performance blockchain management and monitoring
              </p>
              <div className="flex items-center gap-4 mt-2">
                <Badge className="bg-green-500/20 text-green-400">
                  <Activity className="w-3 h-3 mr-1" />
                  Cluster Healthy
                </Badge>
                <Badge className="bg-purple-500/20 text-purple-400">
                  Slot #{clusterInfo.currentSlot.toLocaleString()}
                </Badge>
                <Badge style={{ backgroundColor: `${solanaAccentColor}20`, color: solanaAccentColor }}>
                  {clusterInfo.tps.toLocaleString()} TPS
                </Badge>
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm text-neutral-400">Epoch Progress</div>
            <div className="text-2xl font-bold text-neutral-100">
              {Math.round((clusterInfo.epochInfo.slotIndex / clusterInfo.epochInfo.slotsInEpoch) * 100)}%
            </div>
          </div>
        </div>
      </div>

      {/* Program Signing Card - Shows when program is awaiting signature */}
      {programAwaitingSignature && (
        <ProgramSigningCard
          program={programAwaitingSignature}
          onSign={handleProgramSigned}
          onCancel={handleProgramSigningCancelled}
          isVisible={!!programAwaitingSignature}
        />
      )}

      {/* Main Console Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 glass-effect">
          <TabsTrigger asChild value="overview">
            <button
              style={activeTab === 'overview' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'overview') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'overview') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Monitor className="w-4 h-4 mr-2" />
              Overview
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="network">
            <button
              style={activeTab === 'network' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'network') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'network') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Network className="w-4 h-4 mr-2" />
              Network Stats
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="tokens">
            <button
              style={activeTab === 'tokens' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'tokens') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'tokens') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Coins className="w-4 h-4 mr-2" />
              SPL Tokens
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="rpc">
            <button
              style={activeTab === 'rpc' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'rpc') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'rpc') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Server className="w-4 h-4 mr-2" />
              RPC Endpoints
            </button>
          </TabsTrigger>
          <TabsTrigger asChild value="wizard">
             <button
              style={activeTab === 'wizard' ? activeTabsTriggerStyle : tabsTriggerStyle}
              onMouseEnter={(e) => { if (activeTab !== 'wizard') Object.assign(e.target.style, hoverTabsTriggerStyle); }}
              onMouseLeave={(e) => { if (activeTab !== 'wizard') Object.assign(e.target.style, tabsTriggerStyle); }}
            >
              <Wand2 className="w-4 h-4 mr-2" />
              Program Wizard
            </button>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Transaction Monitor */}
          <TransactionMonitor />

          {/* Quick Actions */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-lg font-bold text-neutral-100 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <button
                style={gradientStyle('#8b5cf6', solanaAccentColor)}
                onMouseEnter={(e) => Object.assign(e.target.style, hoverGradientStyle('#7c3aed', '#00e68a'))}
                onMouseLeave={(e) => Object.assign(e.target.style, gradientStyle('#8b5cf6', solanaAccentColor))}
              >
                <Code className="w-4 h-4 mr-2" />
                Deploy Program
              </button>
              <button
                style={gradientStyle('#059669', '#047857')}
                onMouseEnter={(e) => Object.assign(e.target.style, hoverGradientStyle('#047857', '#065f46'))}
                onMouseLeave={(e) => Object.assign(e.target.style, gradientStyle('#059669', '#047857'))}
              >
                <Coins className="w-4 h-4 mr-2" />
                Create SPL Token
              </button>
              <button
                style={gradientStyle('#3b82f6', '#1d4ed8')}
                onMouseEnter={(e) => Object.assign(e.target.style, hoverGradientStyle('#1d4ed8', '#1e40af'))}
                onMouseLeave={(e) => Object.assign(e.target.style, gradientStyle('#3b82f6', '#1d4ed8'))}
              >
                <Settings className="w-4 h-4 mr-2" />
                Validator Config
              </button>
              <button
                style={gradientStyle('#ea580c', '#dc2626')}
                onMouseEnter={(e) => Object.assign(e.target.style, hoverGradientStyle('#dc2626', '#b91c1c'))}
                onMouseLeave={(e) => Object.assign(e.target.style, gradientStyle('#ea580c', '#dc2626'))}
              >
                <Shield className="w-4 h-4 mr-2" />
                Program Audit
              </button>
            </div>
          </div>

          {/* Epoch Information */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-lg font-bold text-neutral-100 mb-4">Current Epoch Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-neutral-400">Current Epoch</p>
                <p className="text-2xl font-bold text-neutral-100">{clusterInfo.epochInfo.epoch}</p>
              </div>
              <div>
                <p className="text-sm text-neutral-400">Slot in Epoch</p>
                <p className="text-2xl font-bold text-neutral-100">{clusterInfo.epochInfo.slotIndex.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm text-neutral-400">Progress</p>
                <div className="flex items-center gap-3 mt-2">
                  <div className="flex-1 bg-neutral-700 rounded-full h-3">
                    <div 
                      className="h-3 rounded-full transition-all duration-500"
                      style={{ 
                        width: `${(clusterInfo.epochInfo.slotIndex / clusterInfo.epochInfo.slotsInEpoch) * 100}%`,
                        background: `linear-gradient(to right, #8b5cf6, ${solanaAccentColor})`
                      }}
                    ></div>
                  </div>
                  <span className="text-sm font-bold text-neutral-100">
                    {Math.round((clusterInfo.epochInfo.slotIndex / clusterInfo.epochInfo.slotsInEpoch) * 100)}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="glass-card rounded-xl p-6">
            <h3 className="text-lg font-bold text-neutral-100 mb-4">Performance Metrics</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Transactions Per Second</span>
                <div className="flex items-center gap-2">
                  <div className="text-xl font-bold" style={{ color: solanaAccentColor }}>
                    {clusterInfo.tps.toLocaleString()}
                  </div>
                  <Badge style={{ backgroundColor: `${solanaAccentColor}20`, color: solanaAccentColor }}>
                    Real-time
                  </Badge>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Network Capacity</span>
                <Badge className="bg-green-500/20 text-green-400">65,000 TPS Theoretical</Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-300">Confirmation Time</span>
                <span className="text-neutral-200">~13 seconds (finalized)</span>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="network" className="space-y-6">
          <NetworkStats />
        </TabsContent>

        <TabsContent value="tokens" className="space-y-6">
          <SplTokenDashboard />
        </TabsContent>

        <TabsContent value="rpc" className="space-y-6">
          <RpcEndpointManager />
        </TabsContent>

        <TabsContent value="wizard" className="space-y-6">
          <RustProgramWizard onDeploy={handleDeployFromWizard} />
        </TabsContent>
      </Tabs>
    </div>
  );
}