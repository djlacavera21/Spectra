import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, Transaction, VaultMovement, SecurityEvent } from '@/api/entities';
import { 
  Wallet as WalletIcon, 
  Shield, 
  Settings,
  Server,
  Activity,
  TrendingUp,
  History,
  CreditCard,
  Repeat
} from 'lucide-react';

import WalletOverview from '../components/wallet/WalletOverview';
import TransactionHistory from '../components/wallet/TransactionHistory';
import SecurityCenter from '../components/wallet/SecurityCenter';
import PaymentMethods from '../components/wallet/PaymentMethods';
import TradingInterface from '../components/wallet/TradingInterface';
import WalletSettings from '../components/wallet/WalletSettings';

export default function WalletPage() {
  const [user, setUser] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [vaultMovements, setVaultMovements] = useState([]);
  const [securityEvents, setSecurityEvents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  const loadWalletData = async () => {
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      const userTransactions = await Transaction.filter({
        $or: [
            { from_address: currentUser.wallet_address },
            { to_address: currentUser.wallet_address }
        ]
      }, '-created_date', 50);
      
      setTransactions(userTransactions);

      const movements = await VaultMovement.list('-created_date', 20);
      setVaultMovements(movements);

      const events = await SecurityEvent.filter({
        user_wallet: currentUser.wallet_address
      }, '-created_date', 30);
      setSecurityEvents(events);

    } catch (error) {
      console.error("Error loading wallet data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadWalletData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading Wallet Service...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="glass-card rounded-xl p-8 text-center">
        <h2 className="text-xl font-bold text-neutral-100 mb-4">Authentication Required</h2>
        <p className="text-neutral-400 mb-6">Please log in to access your wallet service.</p>
      </div>
    );
  }
  
  const TABS = [
    { value: 'overview', label: 'Overview', icon: WalletIcon, component: <WalletOverview user={user} onWalletUpdate={loadWalletData} /> },
    { value: 'history', label: 'History', icon: History, component: <TransactionHistory transactions={transactions} currentUserAddress={user?.wallet_address} /> },
    { value: 'security', label: 'Security', icon: Shield, component: <SecurityCenter user={user} securityEvents={securityEvents} /> },
    { value: 'trading', label: 'Trading', icon: Repeat, component: <TradingInterface user={user} /> },
    { value: 'payment', label: 'Payment', icon: CreditCard, component: <PaymentMethods /> },
    { value: 'settings', label: 'Settings', icon: Settings, component: <WalletSettings user={user} /> },
  ];

  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
            <WalletIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 gradient-text">
              Wallet Service
            </h1>
            <p className="text-neutral-400">
              Multi-tier custodial & non-custodial asset management
            </p>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 glass-effect">
          {TABS.map(tab => (
            <TabsTrigger key={tab.value} value={tab.value} className="text-neutral-300 data-[state=active]:text-white">
              <tab.icon className="w-4 h-4 mr-2" />
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        {TABS.map(tab => (
           <TabsContent key={tab.value} value={tab.value} className="mt-6">
             {tab.component}
           </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}