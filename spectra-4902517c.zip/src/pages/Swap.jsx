import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  ArrowUpDown, 
  ArrowRightLeft, 
  Zap, 
  TrendingUp,
  Clock,
  CheckCircle,
  AlertTriangle,
  Loader2,
  RefreshCw
} from 'lucide-react';
import { User, Transaction } from '@/api/entities';
import { useSignature } from '../components/common/SignatureContext';

export default function SwapPage() {
  const [user, setUser] = useState(null);
  const [fromAsset, setFromAsset] = useState('SPEC');
  const [toAsset, setToAsset] = useState('ETH');
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [exchangeRates, setExchangeRates] = useState({});
  const [slippage, setSlippage] = useState(0.5);
  const [recentSwaps, setRecentSwaps] = useState([]);
  const { requestSignature } = useSignature();

  const availableAssets = [
    { symbol: 'SPEC', name: 'Spectra', balance: 0, price: 1.00 },
    { symbol: 'ETH', name: 'Ethereum', balance: 0, price: 3500.00 },
    { symbol: 'BTC', name: 'Bitcoin', balance: 0, price: 65000.00 },
    { symbol: 'SOL', name: 'Solana', balance: 0, price: 150.00 },
    { symbol: 'USDC', name: 'USD Coin', balance: 0, price: 1.00 },
    { symbol: 'USDT', name: 'Tether', balance: 0, price: 1.00 }
  ];

  useEffect(() => {
    loadUserData();
    loadRecentSwaps();
    updateExchangeRates();
    
    // Update rates every 30 seconds
    const interval = setInterval(updateExchangeRates, 30000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    calculateToAmount();
  }, [fromAmount, fromAsset, toAsset, exchangeRates]);

  const loadUserData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      
      // Update asset balances
      availableAssets.forEach(asset => {
        const balanceField = asset.symbol === 'SPEC' ? 'spec_balance' : 
                           asset.symbol === 'ETH' ? 'eth_balance' :
                           asset.symbol === 'BTC' ? 'btc_balance' :
                           asset.symbol === 'SOL' ? 'sol_balance' :
                           asset.symbol === 'USDC' ? 'usdc_balance' :
                           asset.symbol === 'USDT' ? 'usdt_balance' : null;
        
        if (balanceField) {
          asset.balance = currentUser[balanceField] || 0;
        }
      });
    } catch (error) {
      console.error('Error loading user data:', error);
    }
  };

  const loadRecentSwaps = async () => {
    if (!user) return;
    
    try {
      const swapTransactions = await Transaction.filter({
        $or: [
          { from_address: user.wallet_address, transaction_type: 'cross_chain_swap' },
          { to_address: user.wallet_address, transaction_type: 'cross_chain_swap' }
        ]
      }, '-created_date', 10);
      
      setRecentSwaps(swapTransactions);
    } catch (error) {
      console.error('Error loading recent swaps:', error);
    }
  };

  const updateExchangeRates = () => {
    // Simulate real-time exchange rates
    const baseRates = {
      'SPEC/ETH': 0.0003,
      'SPEC/BTC': 0.000015,
      'SPEC/SOL': 0.007,
      'SPEC/USDC': 1.00,
      'SPEC/USDT': 1.00,
      'ETH/BTC': 0.054,
      'ETH/SOL': 23.33,
      'ETH/USDC': 3500,
      'ETH/USDT': 3500,
      'BTC/SOL': 433.33,
      'BTC/USDC': 65000,
      'BTC/USDT': 65000,
      'SOL/USDC': 150,
      'SOL/USDT': 150,
      'USDC/USDT': 1.00
    };

    // Add some market volatility
    const rates = {};
    Object.keys(baseRates).forEach(pair => {
      const variation = (Math.random() - 0.5) * 0.02; // ±1% variation
      rates[pair] = baseRates[pair] * (1 + variation);
    });

    setExchangeRates(rates);
  };

  const calculateToAmount = () => {
    if (!fromAmount || !exchangeRates) {
      setToAmount('');
      return;
    }

    const pair = `${fromAsset}/${toAsset}`;
    const reversePair = `${toAsset}/${fromAsset}`;
    
    let rate = exchangeRates[pair];
    if (!rate && exchangeRates[reversePair]) {
      rate = 1 / exchangeRates[reversePair];
    }

    if (rate) {
      const baseAmount = parseFloat(fromAmount) * rate;
      const slippageAmount = baseAmount * (slippage / 100);
      const finalAmount = baseAmount - slippageAmount;
      setToAmount(finalAmount.toFixed(8));
    }
  };

  const handleSwap = () => {
    const numericFromAmount = parseFloat(fromAmount);
    if (!numericFromAmount || numericFromAmount <= 0) {
      alert("Please enter a valid amount.");
      return;
    }

    const fromAssetData = availableAssets.find(a => a.symbol === fromAsset);
    if (numericFromAmount > fromAssetData.balance) {
      alert(`Insufficient balance. You have ${fromAssetData.balance} ${fromAsset}.`);
      return;
    }

    const swapFee = numericFromAmount * 0.003; // 0.3% swap fee
    const totalCost = numericFromAmount + swapFee;

    const transactionDetails = {
      from: user.wallet_address,
      to: "SpectraSwapContract",
      amount: numericFromAmount,
      fee: swapFee.toFixed(6),
      total: totalCost.toFixed(6),
      metadata: {
        action: "Cross-Chain Swap",
        from: `${numericFromAmount} ${fromAsset}`,
        to: `${toAmount} ${toAsset}`,
        slippage: `${slippage}%`,
        rate: exchangeRates[`${fromAsset}/${toAsset}`] || (1 / exchangeRates[`${toAsset}/${fromAsset}`])
      },
      data: `0x... (swap data)`
    };

    requestSignature(
      transactionDetails,
      // onConfirm
      async () => {
        setIsProcessing(true);
        try {
          // Create swap transaction record
          await Transaction.create({
            from_address: user.wallet_address,
            to_address: "SpectraSwapContract",
            amount: numericFromAmount,
            transaction_type: 'cross_chain_swap',
            status: 'processing_bridge',
            gas_fee: swapFee,
            metadata: {
              swap_type: 'cross_chain',
              from_token: fromAsset,
              to_token: toAsset,
              from_amount: numericFromAmount,
              to_amount: parseFloat(toAmount),
              exchange_rate: transactionDetails.metadata.rate,
              slippage_tolerance: slippage,
              estimated_confirmation: '2-5 minutes'
            }
          });

          alert(`Successfully initiated swap of ${fromAmount} ${fromAsset} for ${toAmount} ${toAsset}!`);
          
          // Reset form
          setFromAmount('');
          setToAmount('');
          
          // Reload data
          loadUserData();
          loadRecentSwaps();
          
        } catch (error) {
          console.error('Swap error:', error);
          alert('Swap failed. Please try again.');
        } finally {
          setIsProcessing(false);
        }
      },
      // onReject
      () => {
        alert("Swap cancelled.");
      }
    );
  };

  const setMaxAmount = () => {
    const fromAssetData = availableAssets.find(a => a.symbol === fromAsset);
    setFromAmount(fromAssetData.balance.toString());
  };

  const swapAssets = () => {
    setFromAsset(toAsset);
    setToAsset(fromAsset);
    setFromAmount('');
    setToAmount('');
  };

  const fromAssetData = availableAssets.find(a => a.symbol === fromAsset);
  const currentRate = exchangeRates[`${fromAsset}/${toAsset}`] || (1 / exchangeRates[`${toAsset}/${fromAsset}`]) || 0;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
            <ArrowUpDown className="w-8 h-8 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 mb-2">Asset Swap</h1>
            <p className="text-neutral-400">
              Cross-chain asset swapping with real-time rates
            </p>
            <div className="flex items-center gap-4 mt-2">
              <Badge className="bg-green-500/20 text-green-400">
                <CheckCircle className="w-3 h-3 mr-1" />
                Live Rates
              </Badge>
              <Badge className="bg-blue-500/20 text-blue-400">
                0.3% Fee
              </Badge>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Swap Interface */}
        <div className="lg:col-span-2">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-neutral-100">
                <Zap className="w-6 h-6 text-yellow-400" />
                Swap Assets
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* From Section */}
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <label className="text-sm text-neutral-400">You Sell</label>
                  <span className="text-sm text-neutral-400">
                    Balance: {fromAssetData?.balance.toFixed(4) || 0}
                  </span>
                </div>
                <div className="flex gap-3">
                  <Select value={fromAsset} onValueChange={setFromAsset}>
                    <SelectTrigger className="w-[140px] bg-white/5 border-white/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="glass-effect">
                      {availableAssets.map(asset => (
                        <SelectItem key={asset.symbol} value={asset.symbol}>
                          {asset.symbol}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="relative flex-grow">
                    <Input
                      type="number"
                      placeholder="0.0"
                      value={fromAmount}
                      onChange={(e) => setFromAmount(e.target.value)}
                      className="pr-16 bg-white/5 border-white/20"
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-7 text-xs"
                      onClick={setMaxAmount}
                    >
                      Max
                    </Button>
                  </div>
                </div>
              </div>

              {/* Swap Button */}
              <div className="flex justify-center">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-10 w-10 rounded-full bg-white/10 hover:bg-white/20" 
                  onClick={swapAssets}
                >
                  <ArrowRightLeft className="w-5 h-5" />
                </Button>
              </div>

              {/* To Section */}
              <div className="space-y-3">
                <label className="text-sm text-neutral-400">You Buy</label>
                <div className="flex gap-3">
                  <Select value={toAsset} onValueChange={setToAsset}>
                    <SelectTrigger className="w-[140px] bg-white/5 border-white/20">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="glass-effect">
                      {availableAssets.map(asset => (
                        <SelectItem key={asset.symbol} value={asset.symbol}>
                          {asset.symbol}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="number"
                    placeholder="0.0"
                    value={toAmount}
                    readOnly
                    className="bg-white/5 border-white/20"
                  />
                </div>
              </div>

              {/* Rate Info */}
              {currentRate > 0 && (
                <div className="glass-effect rounded-lg p-4">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-neutral-400">Exchange Rate</span>
                    <span className="text-neutral-200">
                      1 {fromAsset} = {currentRate.toFixed(6)} {toAsset}
                    </span>
                  </div>
                  <div className="flex justify-between items-center text-sm mt-2">
                    <span className="text-neutral-400">Slippage Tolerance</span>
                    <span className="text-neutral-200">{slippage}%</span>
                  </div>
                </div>
              )}

              {/* Swap Button */}
              <Button 
                onClick={handleSwap} 
                disabled={isProcessing || !fromAmount || !toAmount} 
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin"/>
                    Processing Swap...
                  </>
                ) : (
                  <>
                    <ArrowUpDown className="w-4 h-4 mr-2" />
                    Swap Assets
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          {/* Market Info */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100">Market Info</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Network Fee</span>
                  <span className="text-neutral-200">0.3%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Est. Time</span>
                  <span className="text-neutral-200">2-5 min</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Min. Received</span>
                  <span className="text-neutral-200">
                    {toAmount ? (parseFloat(toAmount) * 0.995).toFixed(6) : '0'} {toAsset}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Swaps */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100">Recent Swaps</CardTitle>
            </CardHeader>
            <CardContent>
              {recentSwaps.length > 0 ? (
                <div className="space-y-3">
                  {recentSwaps.slice(0, 5).map(swap => (
                    <div key={swap.id} className="glass-effect rounded-lg p-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-neutral-300">
                          {swap.metadata?.from_token} → {swap.metadata?.to_token}
                        </span>
                        <Badge className={
                          swap.status === 'confirmed' ? 'bg-green-500/20 text-green-400' :
                          swap.status === 'processing_bridge' ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }>
                          {swap.status}
                        </Badge>
                      </div>
                      <div className="text-xs text-neutral-500 mt-1">
                        {swap.metadata?.from_amount} → {swap.metadata?.to_amount}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-neutral-400 text-sm">No recent swaps</p>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}