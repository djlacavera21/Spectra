import React from 'react';
import BitcoinBroadcaster from '../components/blockchain/BitcoinBroadcaster';

export default function BitcoinBroadcastPage() {
  return (
    <div className="space-y-6">
      <div className="glass-card rounded-xl p-6">
        <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
          Bitcoin Transaction Broadcasting
        </h1>
        <p className="text-neutral-400">
          Broadcast raw Bitcoin transactions to the network and verify transaction status on the blockchain.
        </p>
      </div>
      <BitcoinBroadcaster />
    </div>
  );
}