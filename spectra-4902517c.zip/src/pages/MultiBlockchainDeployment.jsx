import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Code, 
  Zap, 
  Settings,
  Wallet,
  TrendingUp,
  Activity
} from "lucide-react";
import { User } from "@/api/entities";

import EthereumDeployment from "../components/blockchain/EthereumDeployment";
import SolanaDeployment from "../components/blockchain/SolanaDeployment";
import BitcoinIntegration from "../components/blockchain/BitcoinIntegration";
import IBMFabricBackend from "../components/fabric/IBMFabricBackend";

export default function MultiBlockchainDeployment() {
  const [activeTab, setActiveTab] = useState('fabric');
  const [user, setUser] = useState(null);
  const [deployedTokens, setDeployedTokens] = useState([]);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setDeployedTokens(currentUser.fabric_tokens || []);
    } catch (error) {
      console.error('Failed to load user data:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 gradient-text">
              Multi-Blockchain Deployment Center
            </h1>
            <p className="text-neutral-400">
              Deploy tokens and smart contracts across multiple blockchain networks
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30">
              {deployedTokens.length} Tokens Deployed
            </Badge>
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
              Multi-Chain Ready
            </Badge>
          </div>
        </div>
      </div>

      {/* Master Wallet Overview */}
      {user?.fabric_master_wallet && (
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-4">
            <Wallet className="w-6 h-6 text-purple-400" />
            <h3 className="text-lg font-bold text-neutral-100">Master Wallet Overview</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-sm text-neutral-300">Total Supply</span>
              </div>
              <p className="text-xl font-bold text-neutral-100">
                {(user.fabric_total_supply || 0).toLocaleString()}
              </p>
            </div>
            
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-300">Active Tokens</span>
              </div>
              <p className="text-xl font-bold text-neutral-100">
                {deployedTokens.length}
              </p>
            </div>
            
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Code className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-neutral-300">Blockchains</span>
              </div>
              <p className="text-xl font-bold text-neutral-100">
                {[...new Set(deployedTokens.map(t => t.blockchain))].length}
              </p>
            </div>
            
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-neutral-300">Master Address</span>
              </div>
              <p className="text-xs font-mono text-neutral-100">
                {user.fabric_master_wallet.substring(0, 12)}...
              </p>
            </div>
          </div>
          
          {/* Deployed Tokens List */}
          {deployedTokens.length > 0 && (
            <div className="mt-6">
              <h4 className="text-md font-semibold text-neutral-100 mb-3">Deployed Tokens</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {deployedTokens.map((token, index) => (
                  <div key={index} className="glass-effect rounded-lg p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-semibold text-neutral-100">{token.symbol}</p>
                        <p className="text-xs text-neutral-400">{token.name}</p>
                      </div>
                      <Badge className={`text-xs ${
                        token.blockchain === 'ethereum' ? 'bg-gray-500/20 text-gray-400' :
                        token.blockchain === 'solana' ? 'bg-purple-500/20 text-purple-400' :
                        token.blockchain === 'bitcoin' ? 'bg-orange-500/20 text-orange-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>
                        {token.blockchain}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Supply: {token.totalSupply?.toLocaleString()}</span>
                      <span>Balance: {token.balance?.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Deployment Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass-effect">
          <TabsTrigger value="fabric" className="text-neutral-400 data-[state=active]:text-blue-400">
            <Settings className="w-4 h-4 mr-2" />
            IBM Fabric
          </TabsTrigger>
          <TabsTrigger value="ethereum" className="text-neutral-400 data-[state=active]:text-gray-400">
            <Code className="w-4 h-4 mr-2" />
            Ethereum
          </TabsTrigger>
          <TabsTrigger value="solana" className="text-neutral-400 data-[state=active]:text-purple-400">
            <Zap className="w-4 h-4 mr-2" />
            Solana
          </TabsTrigger>
          <TabsTrigger value="bitcoin" className="text-neutral-400 data-[state=active]:text-orange-400">
            <TrendingUp className="w-4 h-4 mr-2" />
            Bitcoin
          </TabsTrigger>
        </TabsList>

        <TabsContent value="fabric" className="space-y-6">
          <IBMFabricBackend />
        </TabsContent>

        <TabsContent value="ethereum" className="space-y-6">
          <EthereumDeployment />
        </TabsContent>

        <TabsContent value="solana" className="space-y-6">
          <SolanaDeployment />
        </TabsContent>

        <TabsContent value="bitcoin" className="space-y-6">
          <BitcoinIntegration />
        </TabsContent>
      </Tabs>
    </div>
  );
}