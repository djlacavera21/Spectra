
import React, { useState, useEffect } from "react";
import { MarketplaceAsset, User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Plus, ShoppingCart, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { UploadFile } from "@/api/integrations";
import { InvokeLLM } from "@/api/integrations";

import AssetCard from "../components/marketplace/AssetCard";
import MarketplaceFilters from "../components/marketplace/MarketplaceFilters";
import NFTUploadModal from "../components/marketplace/NFTUploadModal";
import { useSignature } from "../components/common/SignatureContext";

const MINTING_FEE = 0.5; // Example minting fee in SPEC
const PLATFORM_FEE_PERCENTAGE = 2.5;

export default function Marketplace() {
  const navigate = useNavigate();
  const [assets, setAssets] = useState([]);
  const [filteredAssets, setFilteredAssets] = useState([]);
  const [assetCounts, setAssetCounts] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [showUploadModal, setShowUploadModal] = useState(false);
  const { requestSignature } = useSignature();

  useEffect(() => {
    loadMarketplaceData();
  }, []);

  useEffect(() => {
    filterAssets();
  }, [assets, searchTerm, selectedFilter]);

  const loadMarketplaceData = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
      
      const marketplaceAssets = await MarketplaceAsset.filter({
        status: "active"
      }, '-created_date');
      
      // Calculate counts for each asset type
      const counts = marketplaceAssets.reduce((acc, asset) => {
        acc[asset.asset_type] = (acc[asset.asset_type] || 0) + 1;
        return acc;
      }, {});
      setAssetCounts(counts);

      setAssets(marketplaceAssets);
    } catch (error) {
      console.error("Error loading marketplace:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const filterAssets = () => {
    let filtered = [...assets];

    if (searchTerm) {
      filtered = filtered.filter(asset =>
        asset.asset_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.collection_name?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedFilter !== "all") {
      filtered = filtered.filter(asset => asset.asset_type === selectedFilter);
    }

    setFilteredAssets(filtered);
  };
  
  const handleCreateAsset = async (assetData, imageFile) => {
    if (!currentUser) {
        alert("You must be logged in to create an asset.");
        return;
    }
    
    if (currentUser.spec_balance < MINTING_FEE) {
        alert(`Insufficient balance. You need at least ${MINTING_FEE} SPEC to mint an NFT.`);
        return;
    }

    setIsProcessing(true);

    try {
        // 1. Upload image to storage
        const { file_url } = await UploadFile({ file: imageFile });

        // 2. Simulate minting on Hyperledger Fabric via LLM
        const mintPrompt = `Simulate minting an NFT on a Hyperledger Fabric network for the Spectra platform. The asset is named "${assetData.asset_name}". Generate a unique, realistic sha256 token_id and a transaction_hash for this minting operation.`;
        const mintResponse = await InvokeLLM({
            prompt: mintPrompt,
            response_json_schema: {
                type: "object",
                properties: {
                    token_id: { type: "string" },
                    transaction_hash: { type: "string" },
                    success: { type: "boolean", "default": true }
                }
            }
        });

        if (!mintResponse.success || !mintResponse.token_id || !mintResponse.transaction_hash) {
            throw new Error("Blockchain minting simulation failed.");
        }
        
        // 3. Create transaction for the minting fee
        await Transaction.create({
            from_address: currentUser.wallet_address,
            to_address: "SpectraMintingContract",
            amount: MINTING_FEE,
            transaction_type: "mint",
            status: "confirmed",
            transaction_hash: mintResponse.transaction_hash,
            metadata: { asset_name: assetData.asset_name, token_id: mintResponse.token_id }
        });

        // 4. Deduct fee from user's balance
        await User.updateMyUserData({
            spec_balance: currentUser.spec_balance - MINTING_FEE
        });

        // 5. Create the marketplace asset record
        await MarketplaceAsset.create({
            ...assetData,
            price_spec: parseFloat(assetData.price_spec),
            image_url: file_url,
            token_id: mintResponse.token_id,
            seller_address: currentUser.wallet_address,
            asset_type: 'nft'
        });

        alert("NFT minted and listed successfully!");
        setShowUploadModal(false);
        loadMarketplaceData();

    } catch (error) {
        console.error("Error creating asset:", error);
        alert("Failed to create asset. " + error.message);
    } finally {
        setIsProcessing(false);
    }
  };

  const handleBuyAsset = async (asset) => {
    if (!currentUser) {
      alert("You must be logged in to purchase an asset.");
      return;
    }

    const platformFee = asset.price_spec * (PLATFORM_FEE_PERCENTAGE / 100);
    const totalCost = asset.price_spec + platformFee;

    if (currentUser.spec_balance < totalCost) {
      alert(`Insufficient balance. You need ${totalCost.toFixed(2)} SPEC to complete this purchase.`);
      return;
    }

    const transactionDetails = {
      from: currentUser.wallet_address,
      to: asset.seller_address,
      amount: asset.price_spec,
      fee: platformFee.toFixed(2),
      total: totalCost.toFixed(2),
      metadata: {
        asset_name: asset.asset_name,
        asset_id: asset.id,
        action: "NFT Purchase"
      },
      data: `0x... (NFT transfer data for token ${asset.token_id})` // Simulated data
    };

    requestSignature(
      transactionDetails,
      // onConfirm
      async () => {
        try {
          setIsProcessing(true); // Start processing after signature confirmation

          const seller = await User.filter({ wallet_address: asset.seller_address });
          if (!seller || seller.length === 0) {
            throw new Error("Seller not found");
          }

          // 1. Create transaction record
          await Transaction.create({
            from_address: currentUser.wallet_address,
            to_address: asset.seller_address,
            amount: asset.price_spec,
            gas_fee: platformFee,
            transaction_type: "marketplace_buy",
            status: "confirmed",
            metadata: { asset_id: asset.id, asset_name: asset.asset_name, token_id: asset.token_id }
          });

          // 2. Transfer funds: buyer -> seller
          await User.update(seller[0].id, {
            spec_balance: seller[0].spec_balance + asset.price_spec
          });
          await User.updateMyUserData({
            spec_balance: currentUser.spec_balance - totalCost
          });

          // 3. Update asset ownership
          await MarketplaceAsset.update(asset.id, {
            status: 'sold',
            buyer_address: currentUser.wallet_address
          });
          
          alert("Purchase successful! The NFT has been transferred to your wallet.");
          loadMarketplaceData(); // Refresh data

        } catch (error) {
          console.error("Purchase failed:", error);
          alert("An error occurred during the purchase. Please try again: " + error.message);
        } finally {
          setIsProcessing(false); // End processing
        }
      },
      // onReject
      () => {
        alert("Purchase cancelled.");
      }
    );
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 text-neutral-400 animate-spin" />
          <p className="text-neutral-400">Loading Marketplace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <NFTUploadModal 
        isOpen={showUploadModal}
        onClose={() => setShowUploadModal(false)}
        onUpload={handleCreateAsset}
        isProcessing={isProcessing}
      />
      
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-neutral-100 mb-2 gradient-text">
              Spectra NFT Marketplace
            </h1>
            <p className="text-neutral-400">
              Discover, create, and trade unique digital assets on-chain.
            </p>
          </div>
          <Button
            onClick={() => setShowUploadModal(true)}
            className="bg-gradient-to-r from-gray-500 to-gray-700 hover:from-gray-600 hover:to-gray-800 text-white border-none"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create NFT
          </Button>
        </div>
      </div>
      
      <MarketplaceFilters
        onFilterChange={setSelectedFilter}
        onSearchChange={setSearchTerm}
        onSortChange={(sort) => console.log("Sort:", sort)}
        assetCounts={assetCounts}
      />

      {/* Assets Grid */}
      {filteredAssets.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredAssets.map((asset) => (
            <AssetCard
              key={asset.id}
              asset={asset}
              onBuy={handleBuyAsset}
              onLike={(id) => console.log("Liked:", id)}
              onView={(id) => console.log("Viewed:", id)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <div className="glass-card rounded-xl p-8 max-w-md mx-auto">
            <ShoppingCart className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-neutral-100 mb-2">No Assets Found</h3>
            <p className="text-neutral-400 mb-6">
              {searchTerm ? "Try adjusting your search terms" : "Be the first to mint an NFT!"}
            </p>
            <Button
              onClick={() => setShowUploadModal(true)}
              className="bg-gradient-to-r from-gray-500 to-gray-700 hover:from-gray-600 hover:to-gray-800 text-white border-none"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Your First NFT
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
