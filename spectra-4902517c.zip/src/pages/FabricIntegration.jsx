
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Network, 
  Code, 
  Database, 
  Settings, 
  Download,
  Upload,
  Play,
  Book,
  Monitor,
  Zap
} from "lucide-react";

import FabricStatus from "../components/fabric/FabricStatus";
import RealTimeTransactions from "../components/fabric/RealTimeTransactions";
import HybridControls from "../components/fabric/HybridControls";
import BlockchainResources from "../components/fabric/BlockchainResources";

export default function FabricIntegration() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-r from-gray-500 to-gray-700 rounded-xl flex items-center justify-center">
            <Network className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Hyperledger Fabric Integration</h1>
            <p className="text-white/60">Complete blockchain infrastructure for Spectra platform</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 glass-effect">
          <TabsTrigger value="overview" className="text-white/60 data-[state=active]:text-white">
            <Monitor className="w-4 h-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="deployment" className="text-white/60 data-[state=active]:text-white">
            <Download className="w-4 h-4 mr-2" />
            Deployment
          </TabsTrigger>
          <TabsTrigger value="monitoring" className="text-white/60 data-[state=active]:text-white">
            <Zap className="w-4 h-4 mr-2" />
            Monitoring
          </TabsTrigger>
          <TabsTrigger value="hybrid" className="text-white/60 data-[state=active]:text-white">
            <Settings className="w-4 h-4 mr-2" />
            Hybrid Mode
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Network Status */}
          <FabricStatus />

          {/* Quick Start Instructions */}
          <div className="glass-card rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Play className="w-6 h-6 text-green-400" />
              <h3 className="text-xl font-bold text-white">Quick Start Guide</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">1. Prerequisites</h4>
                  <ul className="text-sm text-white/60 space-y-1">
                    <li>• Docker and Docker Compose</li>
                    <li>• Node.js 14+ and npm</li>
                    <li>• Hyperledger Fabric binaries</li>
                    <li>• Git for version control</li>
                  </ul>
                </div>
                
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">2. Network Setup</h4>
                  <ul className="text-sm text-white/60 space-y-1">
                    <li>• Download deployment resources</li>
                    <li>• Run setup script</li>
                    <li>• Deploy smart contracts</li>
                    <li>• Configure backend integration</li>
                  </ul>
                </div>
              </div>

              <div className="space-y-4">
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">3. Smart Contracts</h4>
                  <ul className="text-sm text-white/60 space-y-1">
                    <li>• SPEC Token Contract (ERC-20 like)</li>
                    <li>• Marketplace Contract</li>
                    <li>• Admin functions included</li>
                    <li>• Event logging enabled</li>
                  </ul>
                </div>
                
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="font-medium text-white mb-2">4. Integration</h4>
                  <ul className="text-sm text-white/60 space-y-1">
                    <li>• Enable backend functions</li>
                    <li>• Configure connection profiles</li>
                    <li>• Setup identity management</li>
                    <li>• Test network connectivity</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="deployment" className="space-y-6">
          <BlockchainResources />
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <RealTimeTransactions />
          
          {/* Network Health */}
          <div className="glass-card rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Monitor className="w-6 h-6 text-blue-400" />
              <h3 className="text-xl font-bold text-white">Network Health</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-white">Orderer</span>
                </div>
                <p className="text-xs text-white/60">localhost:7050</p>
                <p className="text-xs text-green-400">Online</p>
              </div>
              
              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-white">Peer0</span>
                </div>
                <p className="text-xs text-white/60">localhost:7051</p>
                <p className="text-xs text-green-400">Online</p>
              </div>
              
              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-white">Peer1</span>
                </div>
                <p className="text-xs text-white/60">localhost:8051</p>
                <p className="text-xs text-green-400">Online</p>
              </div>
              
              <div className="glass-effect rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-white">CouchDB</span>
                </div>
                <p className="text-xs text-white/60">localhost:5984</p>
                <p className="text-xs text-green-400">Online</p>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="hybrid" className="space-y-6">
          <HybridControls />
          
          {/* Migration Guide */}
          <div className="glass-card rounded-xl p-6">
            <div className="flex items-center gap-3 mb-6">
              <Settings className="w-6 h-6 text-purple-400" />
              <h3 className="text-xl font-bold text-white">Migration Guide</h3>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass-effect rounded-lg p-4">
                <h4 className="font-medium text-white mb-3">Simulation to Fabric</h4>
                <div className="space-y-2 text-sm text-white/60">
                  <p>• Export current data from simulation</p>
                  <p>• Setup Hyperledger Fabric network</p>
                  <p>• Deploy smart contracts</p>
                  <p>• Import data to blockchain</p>
                  <p>• Switch to Fabric mode</p>
                </div>
              </div>
              
              <div className="glass-effect rounded-lg p-4">
                <h4 className="font-medium text-white mb-3">Fabric to Simulation</h4>
                <div className="space-y-2 text-sm text-white/60">
                  <p>• Export blockchain state</p>
                  <p>• Convert to simulation format</p>
                  <p>• Import to local database</p>
                  <p>• Switch to simulation mode</p>
                  <p>• Verify data integrity</p>
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
