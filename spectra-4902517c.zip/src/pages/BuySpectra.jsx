import React, { useState, useEffect } from "react";
import { User, Transaction } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  ShoppingCart,
  CreditCard,
  Wallet,
  ArrowRight,
  CheckCircle,
  AlertTriangle,
  Loader2,
  DollarSign,
  TrendingUp
} from "lucide-react";

export default function BuySpectra() {
  const [user, setUser] = useState(null);
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentPrice] = useState(1.00); // SPEC price in USD
  const [purchaseHistory, setPurchaseHistory] = useState([]);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);

      // Load purchase history
      const purchases = await Transaction.filter({
        from_address: 'fiat_gateway',
        to_address: currentUser.wallet_address,
        transaction_type: 'fiat_purchase'
      }, '-created_date', 10);
      
      setPurchaseHistory(purchases);
    } catch (error) {
      console.error("Error loading user data:", error);
    }
  };

  const calculateTotal = () => {
    const specAmount = parseFloat(amount) || 0;
    const subtotal = specAmount * currentPrice;
    const processingFee = subtotal * 0.029; // 2.9% processing fee
    const total = subtotal + processingFee;
    
    return {
      specAmount,
      subtotal: subtotal.toFixed(2),
      processingFee: processingFee.toFixed(2),
      total: total.toFixed(2)
    };
  };

  const handlePurchase = async () => {
    const { specAmount, total } = calculateTotal();
    
    if (!specAmount || specAmount <= 0) {
      alert('Please enter a valid amount of SPEC to purchase.');
      return;
    }

    if (specAmount < 1) {
      alert('Minimum purchase amount is 1 SPEC.');
      return;
    }

    if (!window.confirm(`Purchase ${specAmount} SPEC for $${total}?`)) {
      return;
    }

    setIsProcessing(true);

    try {
      // Simulate payment processing delay
      await new Promise(resolve => setTimeout(resolve, 3000));

      // Add SPEC to user's balance
      const updates = {
        spec_balance: (user.spec_balance || 0) + specAmount,
        total_spent: (user.total_spent || 0) + parseFloat(total)
      };
      
      await User.updateMyUserData(updates);

      // Create transaction record
      const txHash = `0x${[...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join('')}`;
      await Transaction.create({
        transaction_hash: txHash,
        from_address: 'fiat_gateway',
        to_address: user.wallet_address,
        amount: specAmount,
        transaction_type: 'fiat_purchase',
        status: 'confirmed',
        gas_fee: 0,
        metadata: {
          fiat_amount_usd: parseFloat(total),
          payment_method: paymentMethod,
          processing_fee: parseFloat(calculateTotal().processingFee),
          exchange_rate: currentPrice
        }
      });

      alert(`Successfully purchased ${specAmount} SPEC! Your balance has been updated.`);
      setAmount('');
      await loadUserData();
      
    } catch (error) {
      console.error("Purchase failed:", error);
      alert("Purchase failed. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const { specAmount, subtotal, processingFee, total } = calculateTotal();

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="glass-card rounded-xl p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-neutral-400">Loading purchase interface...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-neutral-100 gradient-text">
                Buy SPEC Tokens
              </h1>
              <p className="text-neutral-400">
                Purchase SPEC tokens directly with fiat currency
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-400">${currentPrice.toFixed(2)}</div>
            <p className="text-sm text-neutral-400">Current SPEC Price</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Purchase Form */}
        <div className="lg:col-span-2">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-blue-400" />
                Purchase SPEC
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Amount Input */}
              <div>
                <label className="block text-sm text-neutral-400 mb-2">
                  Amount of SPEC to Purchase
                </label>
                <div className="relative">
                  <Input
                    type="number"
                    placeholder="0.00"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    className="text-xl font-medium bg-white/5 border-white/20 text-neutral-100 pr-16"
                    min="1"
                    step="0.01"
                  />
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-neutral-400">
                    SPEC
                  </div>
                </div>
                <div className="flex gap-2 mt-2">
                  {[10, 50, 100, 500].map(value => (
                    <Button
                      key={value}
                      variant="outline"
                      size="sm"
                      onClick={() => setAmount(value.toString())}
                      className="text-xs border-white/20 text-neutral-300 hover:bg-white/10"
                    >
                      {value} SPEC
                    </Button>
                  ))}
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <label className="block text-sm text-neutral-400 mb-2">
                  Payment Method
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setPaymentMethod('card')}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      paymentMethod === 'card' ? 'border-blue-500 bg-blue-500/20' : 'border-white/20 bg-white/5'
                    }`}
                  >
                    <CreditCard className="w-6 h-6 mx-auto mb-2 text-blue-400" />
                    <p className="text-sm text-neutral-200">Credit/Debit Card</p>
                    <p className="text-xs text-neutral-400">2.9% fee</p>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('bank')}
                    className={`p-4 rounded-lg border-2 transition-colors ${
                      paymentMethod === 'bank' ? 'border-green-500 bg-green-500/20' : 'border-white/20 bg-white/5'
                    }`}
                  >
                    <Wallet className="w-6 h-6 mx-auto mb-2 text-green-400" />
                    <p className="text-sm text-neutral-200">Bank Transfer</p>
                    <p className="text-xs text-neutral-400">1.5% fee</p>
                  </button>
                </div>
              </div>

              {/* Purchase Summary */}
              {specAmount > 0 && (
                <div className="glass-effect rounded-lg p-4">
                  <h4 className="text-sm text-neutral-300 mb-3">Purchase Summary</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-neutral-400">{specAmount} SPEC</span>
                      <span className="text-neutral-200">${subtotal}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-neutral-400">Processing Fee</span>
                      <span className="text-neutral-200">${processingFee}</span>
                    </div>
                    <div className="border-t border-white/10 pt-2 flex justify-between font-medium">
                      <span className="text-neutral-300">Total</span>
                      <span className="text-neutral-100">${total}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Purchase Button */}
              <Button
                onClick={handlePurchase}
                disabled={isProcessing || !specAmount || specAmount < 1}
                className="w-full h-12 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold"
              >
                {isProcessing ? (
                  <div className="flex items-center justify-center gap-2">
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processing Purchase...
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2">
                    <ShoppingCart className="w-5 h-5" />
                    Purchase {specAmount || 0} SPEC for ${total}
                  </div>
                )}
              </Button>

              <Alert className="bg-blue-500/20 border-blue-500/30">
                <AlertTriangle className="w-4 h-4 text-blue-400" />
                <AlertDescription className="text-blue-400">
                  SPEC tokens will be added to your wallet immediately after purchase confirmation.
                  Minimum purchase: 1 SPEC. All transactions are secure and encrypted.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-6">
          {/* Current Balance */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 text-sm">Your SPEC Balance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <div className="text-3xl font-bold text-neutral-100 mb-2">
                  {(user.spec_balance || 0).toLocaleString()}
                </div>
                <p className="text-sm text-neutral-400">SPEC Tokens</p>
                <p className="text-lg font-semibold text-green-400 mt-2">
                  ≈ ${((user.spec_balance || 0) * currentPrice).toFixed(2)} USD
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Purchase Stats */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 text-sm">Purchase Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-neutral-400 text-sm">Total Purchased</span>
                <span className="text-neutral-200 font-medium">
                  {purchaseHistory.reduce((sum, tx) => sum + tx.amount, 0).toLocaleString()} SPEC
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400 text-sm">Total Spent</span>
                <span className="text-neutral-200 font-medium">
                  ${(user.total_spent || 0).toFixed(2)}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-neutral-400 text-sm">Average Price</span>
                <span className="text-neutral-200 font-medium">
                  ${(purchaseHistory.length > 0 ? 
                    (user.total_spent || 0) / purchaseHistory.reduce((sum, tx) => sum + tx.amount, 0) : 
                    currentPrice
                  ).toFixed(2)}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Recent Purchases */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100 text-sm">Recent Purchases</CardTitle>
            </CardHeader>
            <CardContent>
              {purchaseHistory.length > 0 ? (
                <div className="space-y-3">
                  {purchaseHistory.slice(0, 5).map((purchase) => (
                    <div key={purchase.id} className="glass-effect rounded-lg p-3">
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm font-medium text-neutral-200">
                          {purchase.amount.toLocaleString()} SPEC
                        </span>
                        <Badge className="bg-green-500/20 text-green-400 text-xs">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Completed
                        </Badge>
                      </div>
                      <div className="text-xs text-neutral-400">
                        ${purchase.metadata?.fiat_amount_usd?.toFixed(2)} • {new Date(purchase.created_date).toLocaleDateString()}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-neutral-400">
                  <ShoppingCart className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No purchases yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}