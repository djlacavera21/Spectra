import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Globe, Loader2 } from 'lucide-react';

export default function NetworkConfigModal({ isOpen, onClose }) {
  const [config, setConfig] = useState({
    networkName: 'Mainnet',
    networkId: 1,
    rpcUrl: 'https://mainnet.infura.io/v3/YOUR_PROJECT_ID',
    chainId: 1
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSaving(false);
    onClose();
    alert('Network configuration saved.');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card text-neutral-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Globe className="w-6 h-6 text-purple-400" />
            Network Configuration
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Manage connection settings for the Ethereum network.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="networkName" className="text-neutral-300">Network Name</Label>
            <Input id="networkName" value={config.networkName} readOnly className="bg-black/20 border-white/20" />
          </div>
          <div>
            <Label htmlFor="rpcUrl" className="text-neutral-300">RPC URL</Label>
            <Input id="rpcUrl" value={config.rpcUrl} onChange={(e) => setConfig(c => ({...c, rpcUrl: e.target.value}))} className="bg-white/5 border-white/20" />
          </div>
          <div>
            <Label htmlFor="chainId" className="text-neutral-300">Chain ID</Label>
            <Input id="chainId" type="number" value={config.chainId} onChange={(e) => setConfig(c => ({...c, chainId: parseInt(e.target.value)}))} className="bg-white/5 border-white/20" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-white/20 hover:bg-white/10">Cancel</Button>
          <Button onClick={handleSave} className="bg-gradient-to-r from-purple-500 to-purple-700 text-white" disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Configuration'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}