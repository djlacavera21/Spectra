import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Shield, Loader2, CheckCircle, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const auditSteps = [
  "Initializing audit environment...",
  "Scanning for reentrancy vulnerabilities...",
  "Checking for integer overflow/underflow...",
  "Analyzing access control mechanisms...",
  "Verifying function visibility...",
  "Simulating known attack vectors...",
  "Finalizing report...",
];

export default function SecurityAuditModal({ isOpen, onClose }) {
  const [auditState, setAuditState] = useState('idle'); // idle, running, complete
  const [progress, setProgress] = useState(0);
  const [currentStep, setCurrentStep] = useState('');
  const [results, setResults] = useState(null);

  useEffect(() => {
    let interval;
    if (auditState === 'running') {
      let stepIndex = 0;
      setCurrentStep(auditSteps[stepIndex]);
      interval = setInterval(() => {
        setProgress(prev => {
          const newProgress = prev + (100 / (auditSteps.length * 2));
          if (newProgress >= (stepIndex + 1) * (100 / auditSteps.length)) {
            stepIndex++;
            if (stepIndex < auditSteps.length) {
              setCurrentStep(auditSteps[stepIndex]);
            }
          }
          return newProgress;
        });
      }, 500);
    }
    return () => clearInterval(interval);
  }, [auditState]);

  useEffect(() => {
    if (progress >= 100) {
      setAuditState('complete');
      setCurrentStep('Audit Complete.');
      setResults({
        critical: 0,
        medium: 2,
        low: 5,
        recommendations: [
          "Explicitly mark `payable` functions.",
          "Use `SafeMath` library for arithmetic operations."
        ]
      });
    }
  }, [progress]);

  const startAudit = () => {
    setAuditState('running');
    setProgress(0);
    setResults(null);
  };

  const handleClose = () => {
    setAuditState('idle');
    setProgress(0);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="glass-card text-neutral-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Shield className="w-6 h-6 text-red-400" />
            Security Audit
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Run an automated security analysis on the node and contracts.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          {auditState === 'idle' && (
            <div className="text-center p-4">
              <p className="text-neutral-300">Click below to begin the automated security audit. This may take a few minutes.</p>
            </div>
          )}
          {auditState === 'running' && (
            <div className="space-y-3">
              <Progress value={progress} className="w-full" />
              <div className="flex items-center justify-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <p className="text-sm text-neutral-300">{currentStep}</p>
              </div>
            </div>
          )}
          {auditState === 'complete' && results && (
            <div className="space-y-3">
              <h4 className="font-bold text-lg text-center">Audit Results</h4>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="glass-effect p-2 rounded-lg">
                  <p className="text-2xl font-bold text-red-500">{results.critical}</p>
                  <p className="text-xs text-red-400">Critical</p>
                </div>
                <div className="glass-effect p-2 rounded-lg">
                  <p className="text-2xl font-bold text-yellow-500">{results.medium}</p>
                  <p className="text-xs text-yellow-400">Medium</p>
                </div>
                <div className="glass-effect p-2 rounded-lg">
                  <p className="text-2xl font-bold text-green-500">{results.low}</p>
                  <p className="text-xs text-green-400">Low</p>
                </div>
              </div>
              <div>
                <h5 className="font-semibold mb-1">Recommendations:</h5>
                <ul className="list-disc list-inside text-sm text-neutral-300">
                  {results.recommendations.map((rec, i) => <li key={i}>{rec}</li>)}
                </ul>
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          {auditState === 'idle' && <Button onClick={startAudit} className="w-full bg-gradient-to-r from-red-500 to-red-700 text-white">Start Security Audit</Button>}
          {auditState === 'running' && <Button variant="outline" disabled>Audit in Progress...</Button>}
          {auditState === 'complete' && <Button onClick={handleClose} className="w-full">Close</Button>}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}