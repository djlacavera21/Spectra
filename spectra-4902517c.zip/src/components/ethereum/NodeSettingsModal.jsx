import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Settings, Loader2 } from 'lucide-react';

export default function NodeSettingsModal({ isOpen, onClose }) {
  const [settings, setSettings] = useState({
    syncMode: 'full',
    maxPeers: 50,
    apiFlags: { eth: true, net: true, web3: false }
  });
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = async () => {
    setIsSaving(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setIsSaving(false);
    onClose();
    alert('Node settings have been updated.');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card text-neutral-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Settings className="w-6 h-6 text-green-400" />
            Node Settings
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Configure the behavior of your Ethereum node client.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div>
            <Label htmlFor="syncMode" className="text-neutral-300">Sync Mode</Label>
            <Select value={settings.syncMode} onValueChange={(value) => setSettings(s => ({...s, syncMode: value}))}>
              <SelectTrigger className="bg-white/5 border-white/20">
                <SelectValue placeholder="Select sync mode" />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/20 text-neutral-200">
                <SelectItem value="full">Full Sync</SelectItem>
                <SelectItem value="fast">Fast Sync</SelectItem>
                <SelectItem value="light">Light Client</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="maxPeers" className="text-neutral-300">Maximum Peers</Label>
            <Input id="maxPeers" type="number" value={settings.maxPeers} onChange={(e) => setSettings(s => ({...s, maxPeers: parseInt(e.target.value)}))} className="bg-white/5 border-white/20" />
          </div>
          <div>
            <Label className="text-neutral-300">Enabled RPC APIs</Label>
            <div className="flex items-center space-x-4 mt-2">
              {Object.keys(settings.apiFlags).map(flag => (
                <div key={flag} className="flex items-center space-x-2">
                  <Switch id={flag} checked={settings.apiFlags[flag]} onCheckedChange={(checked) => setSettings(s => ({...s, apiFlags: {...s.apiFlags, [flag]: checked}}))} />
                  <Label htmlFor={flag} className="font-mono text-sm">{flag}</Label>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="border-white/20 hover:bg-white/10">Cancel</Button>
          <Button onClick={handleSave} className="bg-gradient-to-r from-green-500 to-green-700 text-white" disabled={isSaving}>
            {isSaving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              'Save Settings'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}