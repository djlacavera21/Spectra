import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import {
  Fuel,
  TrendingUp,
  TrendingDown,
  Clock,
  DollarSign,
  Zap,
  AlertCircle
} from "lucide-react";

export default function GasTracker() {
  const [gasData, setGasData] = useState({
    current: { slow: 15, standard: 23, fast: 35, instant: 48 },
    trend: 'increasing',
    recommendation: 'standard',
    networkCongestion: 'moderate'
  });
  
  const [gasHistory, setGasHistory] = useState([]);
  const [selectedTimeframe, setSelectedTimeframe] = useState('1h');

  // --- Style Definitions for Buttons ---
  const baseButtonStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '0.375rem',
    fontSize: '0.75rem',
    fontWeight: '500',
    transition: 'all 0.2s',
    cursor: 'pointer',
    border: '1px solid transparent',
    padding: '0.25rem 0.75rem'
  };

  const outlineStyle = { ...baseButtonStyle, backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' };
  const hoverOutlineStyle = { backgroundColor: 'rgba(255, 255, 255, 0.1)' };
  const activeOutlineStyle = { ...outlineStyle, backgroundColor: 'rgba(59, 130, 246, 0.2)', color: '#60a5fa', borderColor: '#3b82f6' };
  // --- End Style Definitions ---

  useEffect(() => {
    // Generate initial gas history data
    const generateHistoryData = () => {
      const data = [];
      const now = new Date();
      
      for (let i = 23; i >= 0; i--) {
        const time = new Date(now.getTime() - i * 60 * 60 * 1000);
        data.push({
          time: time.getHours() + ':00',
          slow: Math.floor(12 + Math.random() * 8),
          standard: Math.floor(18 + Math.random() * 12),
          fast: Math.floor(28 + Math.random() * 15),
          instant: Math.floor(40 + Math.random() * 20)
        });
      }
      
      setGasHistory(data);
    };

    generateHistoryData();

    // Update gas prices every 30 seconds
    const interval = setInterval(() => {
      setGasData(prev => ({
        ...prev,
        current: {
          slow: Math.max(8, prev.current.slow + (Math.random() - 0.5) * 4),
          standard: Math.max(12, prev.current.standard + (Math.random() - 0.5) * 6),
          fast: Math.max(20, prev.current.fast + (Math.random() - 0.5) * 8),
          instant: Math.max(30, prev.current.instant + (Math.random() - 0.5) * 10)
        }
      }));
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const getTrendIcon = () => {
    return gasData.trend === 'increasing' ? 
      <TrendingUp className="w-4 h-4 text-red-400" /> : 
      <TrendingDown className="w-4 h-4 text-green-400" />;
  };

  const getCongestionColor = (level) => {
    switch (level) {
      case 'low': return 'bg-green-500/20 text-green-400';
      case 'moderate': return 'bg-yellow-500/20 text-yellow-400';
      case 'high': return 'bg-red-500/20 text-red-400';
      default: return 'bg-neutral-500/20 text-neutral-400';
    }
  };

  const getRecommendedGas = () => {
    const { recommendation } = gasData;
    return gasData.current[recommendation];
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-orange-500/20 rounded-xl flex items-center justify-center">
            <Fuel className="w-6 h-6 text-orange-400" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-neutral-100">Gas Tracker</h3>
            <p className="text-neutral-400">Real-time Ethereum network fees</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            {getTrendIcon()}
            <span className="text-sm text-neutral-300 capitalize">{gasData.trend}</span>
          </div>
          <Badge className={getCongestionColor(gasData.networkCongestion)}>
            <AlertCircle className="w-3 h-3 mr-1" />
            {gasData.networkCongestion} congestion
          </Badge>
        </div>
      </div>

      {/* Current Gas Prices */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <div className={`glass-effect rounded-lg p-4 ${gasData.recommendation === 'slow' ? 'ring-2 ring-blue-500/50' : ''}`}>
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-blue-400" />
            <span className="text-sm text-neutral-300">Slow</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{Math.round(gasData.current.slow)}</p>
          <p className="text-xs text-neutral-500">~5 min</p>
        </div>

        <div className={`glass-effect rounded-lg p-4 ${gasData.recommendation === 'standard' ? 'ring-2 ring-blue-500/50' : ''}`}>
          <div className="flex items-center gap-2 mb-2">
            <Zap className="w-4 h-4 text-green-400" />
            <span className="text-sm text-neutral-300">Standard</span>
            {gasData.recommendation === 'standard' && (
              <Badge className="bg-blue-500/20 text-blue-400 text-xs">Recommended</Badge>
            )}
          </div>
          <p className="text-2xl font-bold text-neutral-100">{Math.round(gasData.current.standard)}</p>
          <p className="text-xs text-neutral-500">~2 min</p>
        </div>

        <div className={`glass-effect rounded-lg p-4 ${gasData.recommendation === 'fast' ? 'ring-2 ring-blue-500/50' : ''}`}>
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-4 h-4 text-orange-400" />
            <span className="text-sm text-neutral-300">Fast</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{Math.round(gasData.current.fast)}</p>
          <p className="text-xs text-neutral-500">~30 sec</p>
        </div>

        <div className={`glass-effect rounded-lg p-4 ${gasData.recommendation === 'instant' ? 'ring-2 ring-blue-500/50' : ''}`}>
          <div className="flex items-center gap-2 mb-2">
            <Fuel className="w-4 h-4 text-red-400" />
            <span className="text-sm text-neutral-300">Instant</span>
          </div>
          <p className="text-2xl font-bold text-neutral-100">{Math.round(gasData.current.instant)}</p>
          <p className="text-xs text-neutral-500">~15 sec</p>
        </div>
      </div>

      {/* Gas Price Chart */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h4 className="text-lg font-semibold text-neutral-100">Gas Price History</h4>
          <div className="flex gap-2">
            {['1h', '6h', '24h'].map(timeframe => (
              <button
                key={timeframe}
                onClick={() => setSelectedTimeframe(timeframe)}
                style={selectedTimeframe === timeframe ? activeOutlineStyle : outlineStyle}
                onMouseEnter={(e) => { if (selectedTimeframe !== timeframe) Object.assign(e.target.style, hoverOutlineStyle); }}
                onMouseLeave={(e) => { if (selectedTimeframe !== timeframe) Object.assign(e.target.style, outlineStyle); }}
              >
                {timeframe}
              </button>
            ))}
          </div>
        </div>
        
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={gasHistory}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis 
                dataKey="time" 
                stroke="#9ca3af"
                fontSize={12}
              />
              <YAxis 
                stroke="#9ca3af"
                fontSize={12}
                label={{ value: 'Gwei', angle: -90, position: 'insideLeft' }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'rgba(30, 30, 33, 0.9)',
                  border: '1px solid rgba(255, 255, 255, 0.1)',
                  borderRadius: '8px',
                  color: '#f5f5f5'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="slow" 
                stroke="#60a5fa" 
                strokeWidth={2}
                name="Slow"
              />
              <Line 
                type="monotone" 
                dataKey="standard" 
                stroke="#34d399" 
                strokeWidth={2}
                name="Standard"
              />
              <Line 
                type="monotone" 
                dataKey="fast" 
                stroke="#fbbf24" 
                strokeWidth={2}
                name="Fast"
              />
              <Line 
                type="monotone" 
                dataKey="instant" 
                stroke="#f87171" 
                strokeWidth={2}
                name="Instant"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Gas Optimization Tips */}
      <div className="glass-effect rounded-lg p-4">
        <h4 className="font-semibold text-neutral-100 mb-3">💡 Gas Optimization Tips</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-neutral-300 mb-1">• Use standard gas for non-urgent transactions</p>
            <p className="text-neutral-300 mb-1">• Batch multiple operations together</p>
            <p className="text-neutral-300">• Avoid peak hours (US evening)</p>
          </div>
          <div>
            <p className="text-neutral-300 mb-1">• Monitor network congestion</p>
            <p className="text-neutral-300 mb-1">• Use Layer 2 solutions when possible</p>
            <p className="text-neutral-300">• Set gas limits appropriately</p>
          </div>
        </div>
      </div>
    </div>
  );
}