import React from 'react';
import { Code, FileText, ExternalLink, Settings } from 'lucide-react';

export default function ContractManager() {
  const contracts = [
    { name: 'SPECToken (ERC20)', address: '0x123...abc', version: '1.2.0', status: 'Active' },
    { name: 'MarketplaceLogic', address: '0x456...def', version: '2.0.1', status: 'Active' },
    { name: 'StakingRewards', address: '0x789...ghi', version: '1.0.5', status: 'Active' },
    { name: 'CrossChainBridge', address: '0xabc...123', version: '3.1.0', status: 'Active' },
  ];

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">Deployed Ethereum Contracts</h3>
      <div className="space-y-4">
        {contracts.map((contract, index) => (
          <div key={index} className="glass-effect rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Code className="w-6 h-6 text-purple-400" />
              <div>
                <p className="font-semibold text-neutral-200">{contract.name}</p>
                <p className="text-sm text-neutral-400 font-mono">{contract.address}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-neutral-500">v{contract.version}</span>
              <span className="text-sm text-green-400 font-semibold">{contract.status}</span>
              <div className="flex items-center gap-2">
                 <button className="p-2 rounded-md hover:bg-neutral-600 transition-colors"><ExternalLink className="w-4 h-4 text-neutral-400" /></button>
                 <button className="p-2 rounded-md hover:bg-neutral-600 transition-colors"><FileText className="w-4 h-4 text-neutral-400" /></button>
                 <button className="p-2 rounded-md hover:bg-neutral-600 transition-colors"><Settings className="w-4 h-4 text-neutral-400" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}