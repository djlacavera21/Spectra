import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileText, 
  Fuel, 
  Clock, 
  Zap, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Copy,
  ExternalLink,
  Calculator
} from 'lucide-react';

export default function ContractSigningCard({ contract, onSign, onCancel, isVisible }) {
  const [gasSettings, setGasSettings] = useState({
    gasLimit: 21000,
    baseFee: 20,
    priorityFee: 2,
    maxFee: 25
  });
  const [selectedSpeed, setSelectedSpeed] = useState('standard');
  const [estimatedTime, setEstimatedTime] = useState('~2 min');
  const [totalCost, setTotalCost] = useState(0);
  const [isSigningMode, setIsSigningMode] = useState(false);
  const [activeTab, setActiveTab] = useState('details');

  const speedPresets = {
    slow: { priorityFee: 1, maxFee: 22, time: '~5 min', color: 'bg-blue-500/20 text-blue-400' },
    standard: { priorityFee: 2, maxFee: 25, time: '~2 min', color: 'bg-green-500/20 text-green-400' },
    fast: { priorityFee: 5, maxFee: 30, time: '~30 sec', color: 'bg-orange-500/20 text-orange-400' },
    priority: { priorityFee: 10, maxFee: 40, time: '~15 sec', color: 'bg-red-500/20 text-red-400' }
  };

  useEffect(() => {
    if (contract) {
      // Estimate gas limit based on contract complexity
      const codeLength = contract.code?.length || 1000;
      const estimatedGasLimit = Math.min(300000, Math.max(21000, Math.floor(codeLength / 10)));
      
      setGasSettings(prev => ({ ...prev, gasLimit: estimatedGasLimit }));
    }
  }, [contract]);

  useEffect(() => {
    // Calculate total cost whenever gas settings change
    const cost = ((gasSettings.baseFee + gasSettings.priorityFee) * gasSettings.gasLimit) / 1e9;
    setTotalCost(cost);
    
    const preset = speedPresets[selectedSpeed];
    if (preset) {
      setEstimatedTime(preset.time);
    }
  }, [gasSettings, selectedSpeed]);

  const handleSpeedChange = (speed) => {
    setSelectedSpeed(speed);
    const preset = speedPresets[speed];
    setGasSettings(prev => ({
      ...prev,
      priorityFee: preset.priorityFee,
      maxFee: preset.maxFee
    }));
  };

  const handleCustomGasChange = (field, value) => {
    setGasSettings(prev => ({ ...prev, [field]: parseFloat(value) || 0 }));
    setSelectedSpeed('custom');
  };

  const handleSign = () => {
    const signedContract = {
      ...contract,
      gasSettings,
      totalCost,
      estimatedTime,
      signedAt: new Date().toISOString()
    };
    onSign(signedContract);
  };

  const copyContractAddress = () => {
    if (contract?.estimatedAddress) {
      navigator.clipboard.writeText(contract.estimatedAddress);
    }
  };

  if (!isVisible || !contract) {
    return null;
  }

  return (
    <Card className="glass-card border border-yellow-500/30 shadow-lg">
      <CardHeader className="border-b border-white/10">
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <FileText className="w-6 h-6 text-yellow-400" />
          <span>Contract Signature Required</span>
          <Badge className="bg-yellow-500/20 text-yellow-400">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Pending Signature
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 glass-effect mb-4">
            <TabsTrigger value="details">Contract Details</TabsTrigger>
            <TabsTrigger value="gas">Gas Settings</TabsTrigger>
            <TabsTrigger value="review">Review & Sign</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-neutral-300 text-sm">Contract Name</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100 font-medium">{contract.name}</p>
                </div>
              </div>
              <div>
                <Label className="text-neutral-300 text-sm">Type</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100">ERC20 Token</p>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-neutral-300 text-sm">Estimated Contract Address</Label>
              <div className="glass-effect rounded-lg p-3 mt-1 flex items-center justify-between">
                <p className="text-neutral-100 font-mono text-sm flex-1">
                  {contract.estimatedAddress || `0x${Array.from(crypto.getRandomValues(new Uint8Array(20))).map(b => b.toString(16).padStart(2, '0')).join('')}`}
                </p>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={copyContractAddress}>
                    <Copy className="w-3 h-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <ExternalLink className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-neutral-300 text-sm">Contract Bytecode Preview</Label>
              <div className="glass-effect rounded-lg p-3 mt-1 max-h-32 overflow-y-auto">
                <p className="text-neutral-400 font-mono text-xs break-all">
                  {contract.code?.substring(0, 500)}...
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="gas" className="space-y-4">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.entries(speedPresets).map(([speed, preset]) => (
                <button
                  key={speed}
                  onClick={() => handleSpeedChange(speed)}
                  className={`p-3 rounded-lg border transition-all ${
                    selectedSpeed === speed 
                      ? 'border-blue-500/50 bg-blue-500/10' 
                      : 'border-white/20 hover:border-white/30 bg-white/5'
                  }`}
                >
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-2">
                      {speed === 'slow' && <Clock className="w-4 h-4 text-blue-400" />}
                      {speed === 'standard' && <CheckCircle className="w-4 h-4 text-green-400" />}
                      {speed === 'fast' && <Zap className="w-4 h-4 text-orange-400" />}
                      {speed === 'priority' && <TrendingUp className="w-4 h-4 text-red-400" />}
                    </div>
                    <p className="text-xs font-medium text-neutral-200 capitalize mb-1">{speed}</p>
                    <p className="text-xs text-neutral-400">{preset.time}</p>
                    <p className="text-xs text-neutral-300 mt-1">{preset.priorityFee} Gwei</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="border-t border-white/10 pt-4">
              <h4 className="text-sm font-medium text-neutral-200 mb-3 flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                Custom Gas Settings
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-neutral-300 text-sm">Gas Limit</Label>
                  <Input
                    type="number"
                    value={gasSettings.gasLimit}
                    onChange={(e) => handleCustomGasChange('gasLimit', e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                  />
                </div>
                <div>
                  <Label className="text-neutral-300 text-sm">Base Fee (Gwei)</Label>
                  <Input
                    type="number"
                    value={gasSettings.baseFee}
                    onChange={(e) => handleCustomGasChange('baseFee', e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                  />
                </div>
                <div>
                  <Label className="text-neutral-300 text-sm">Priority Fee (Gwei)</Label>
                  <Input
                    type="number"
                    value={gasSettings.priorityFee}
                    onChange={(e) => handleCustomGasChange('priorityFee', e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                  />
                </div>
                <div>
                  <Label className="text-neutral-300 text-sm">Max Fee (Gwei)</Label>
                  <Input
                    type="number"
                    value={gasSettings.maxFee}
                    onChange={(e) => handleCustomGasChange('maxFee', e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            <Alert className="bg-blue-500/10 border-blue-500/30">
              <CheckCircle className="w-4 h-4 text-blue-400" />
              <AlertDescription className="text-blue-300">
                Review all details carefully before signing the transaction.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Contract Name:</span>
                <span className="text-neutral-100 font-medium">{contract.name}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Gas Limit:</span>
                <span className="text-neutral-100">{gasSettings.gasLimit.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Gas Price:</span>
                <span className="text-neutral-100">{gasSettings.baseFee + gasSettings.priorityFee} Gwei</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Estimated Time:</span>
                <span className="text-neutral-100">{estimatedTime}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg border border-green-500/30">
                <span className="text-neutral-300">Total Cost:</span>
                <span className="text-green-400 font-bold">{totalCost.toFixed(6)} ETH</span>
              </div>
            </div>

            <Alert className="bg-yellow-500/10 border-yellow-500/30">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
              <AlertDescription className="text-yellow-300 text-sm">
                This transaction will deploy a smart contract to the Ethereum blockchain. 
                Gas fees are non-refundable even if the transaction fails.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 mt-6 pt-4 border-t border-white/10">
          <Button 
            variant="outline" 
            className="flex-1 border-white/20 hover:bg-white/10"
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 bg-gradient-to-r from-green-500 to-green-700 text-white hover:from-green-600 hover:to-green-800"
            onClick={handleSign}
          >
            <Fuel className="w-4 h-4 mr-2" />
            Sign & Deploy Contract
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}