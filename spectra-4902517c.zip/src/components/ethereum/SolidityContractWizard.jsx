
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Wand2, Copy, Fuel, AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

export default function SolidityContractWizard({ onDeploy }) {
  const [config, setConfig] = useState({
    contractName: 'MyToken',
    tokenName: 'My Awesome Token',
    tokenSymbol: 'MAT',
    totalSupply: 1000000,
    features: {
      mintable: true,
      burnable: true,
      pausable: false,
      ownable: true, // Ownable is implied by mintable
    },
  });
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  const handleConfigChange = (e) => {
    const { name, value, type } = e.target;
    setConfig(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) || 0 : value }));
  };

  const handleFeatureChange = (feature, value) => {
    setConfig(prev => {
      const newFeatures = { ...prev.features, [feature]: value };
      // If mintable is true, ownable must also be true
      if (feature === 'mintable' && value) {
        newFeatures.ownable = true;
      }
      return { ...prev, features: newFeatures };
    });
  };

  useEffect(() => {
    const generateCode = () => {
      const { contractName, tokenName, tokenSymbol, totalSupply, features } = config;
      
      let imports = ['import "@openzeppelin/contracts/token/ERC20/ERC20.sol";'];
      let inheritance = ['ERC20'];
      let constructorBody = `_mint(msg.sender, ${totalSupply} * 10 ** decimals());`;
      let functions = '';

      if (features.ownable || features.mintable) {
          imports.push('import "@openzeppelin/contracts/access/Ownable.sol";');
          inheritance.push('Ownable');
          if (!features.mintable) { // Add constructor call only if mintable isn't also adding it
            constructorBody += `\n        _transferOwnership(msg.sender);`;
          }
      }
      if (features.burnable) {
          imports.push('import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";');
          inheritance.push('ERC20Burnable');
      }
      if (features.pausable) {
          imports.push('import "@openzeppelin/contracts/security/Pausable.sol";');
          inheritance.push('Pausable');
          functions += `
    function pause() public onlyOwner {
        _pause();
    }

    function unpause() public onlyOwner {
        _unpause();
    }

    function _beforeTokenTransfer(address from, address to, uint256 amount)
        internal
        whenNotPaused
        override
    {
        super._beforeTokenTransfer(from, to, amount);
    }
`;
      }
      if (features.mintable) {
          functions += `
    function mint(address to, uint256 amount) public onlyOwner {
        _mint(to, amount);
    }
`;
      }

      const uniqueImports = [...new Set(imports)];

      const code = `// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

${uniqueImports.join('\n')}

contract ${contractName} is ${inheritance.join(', ')} {
    constructor() ERC20("${tokenName}", "${tokenSymbol}") ${features.ownable || features.mintable ? 'Ownable(msg.sender)' : ''} {
        ${constructorBody}
    }
${functions}
}`;
      setGeneratedCode(code);
    };

    generateCode();
  }, [config]);
  
  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDeployClick = () => {
    // Generate estimated contract address
    const estimatedAddress = `0x${Array.from(crypto.getRandomValues(new Uint8Array(20))).map(b => b.toString(16).padStart(2, '0')).join('')}`;
    
    onDeploy({
      name: config.contractName,
      code: generatedCode,
      estimatedAddress,
      tokenName: config.tokenName,
      tokenSymbol: config.tokenSymbol,
      totalSupply: config.totalSupply,
      features: config.features
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left side: Configuration */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-neutral-100">
            <Wand2 className="w-6 h-6 text-purple-400" />
            ERC20 Contract Wizard
          </CardTitle>
          <CardDescription className="text-neutral-400">
            Define your token's properties, and a deployable contract will be generated.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="contractName">Contract Name</Label>
            <Input id="contractName" name="contractName" value={config.contractName} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tokenName">Token Name</Label>
              <Input id="tokenName" name="tokenName" value={config.tokenName} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tokenSymbol">Token Symbol</Label>
              <Input id="tokenSymbol" name="tokenSymbol" value={config.tokenSymbol} onChange={handleConfigChange} className="bg-white/5 border-white/20" maxLength="5" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="totalSupply">Initial Total Supply</Label>
            <Input id="totalSupply" name="totalSupply" type="number" value={config.totalSupply} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
          </div>

          <div className="space-y-4 pt-4 border-t border-white/10">
            <h4 className="font-medium text-neutral-200">Contract Features</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch id="ownable" checked={config.features.ownable} onCheckedChange={(v) => handleFeatureChange('ownable', v)} disabled={config.features.mintable} />
                <Label htmlFor="ownable">Ownable (for admin functions)</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="mintable" checked={config.features.mintable} onCheckedChange={(v) => handleFeatureChange('mintable', v)} />
                <Label htmlFor="mintable">Mintable</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="burnable" checked={config.features.burnable} onCheckedChange={(v) => handleFeatureChange('burnable', v)} />
                <Label htmlFor="burnable">Burnable</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="pausable" checked={config.features.pausable} onCheckedChange={(v) => handleFeatureChange('pausable', v)} />
                <Label htmlFor="pausable">Pausable</Label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Right side: Generated Code */}
      <Card className="glass-card flex flex-col">
        <CardHeader>
          <CardTitle className="text-neutral-100">Generated Solidity Code</CardTitle>
          <CardDescription className="text-neutral-400">
            This code is generated based on your configuration.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col">
          <div className="relative flex-grow">
            <Textarea
              readOnly
              value={generatedCode}
              className="w-full h-full font-mono text-xs bg-black/50 border-white/20 custom-scrollbar resize-none"
            />
            <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-7" onClick={copyCode}>
              <Copy className="w-3 h-3 mr-1" />
              {copied ? 'Copied!' : 'Copy'}
            </Button>
          </div>
          <Alert className="mt-4 bg-blue-500/10 border-blue-500/30">
            <AlertCircle className="w-4 h-4 text-blue-400" />
            <AlertTitle className="text-blue-300">OpenZeppelin Contracts</AlertTitle>
            <AlertDescription className="text-blue-400/80">
              This contract uses industry-standard, secure OpenZeppelin contracts for core functionality.
            </AlertDescription>
          </Alert>
          <Button className="w-full mt-4 bg-gradient-to-r from-purple-600 to-purple-800 text-white" onClick={handleDeployClick}>
            <Fuel className="w-4 h-4 mr-2" />
            Deploy this Contract
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
