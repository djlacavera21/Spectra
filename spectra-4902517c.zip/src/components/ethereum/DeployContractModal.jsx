
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { FileCode, Loader2, CheckCircle, Terminal } from 'lucide-react';

export default function DeployContractModal({ isOpen, onClose, initialContract }) {
  const [contractName, setContractName] = useState('');
  const [sourceCode, setSourceCode] = useState('// SPDX-License-Identifier: MIT\npragma solidity ^0.8.0;\n\ncontract MyContract {\n    string public myString = "Hello, World!";\n}');
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentResult, setDeploymentResult] = useState(null);

  useEffect(() => {
    if (isOpen) {
      if (initialContract && initialContract.code) {
        setContractName(initialContract.name);
        setSourceCode(initialContract.code);
      } else {
        // Reset to default if no initial contract is provided or when opening without it
        setContractName('');
        setSourceCode('// SPDX-License-Identifier: MIT\npragma solidity ^0.8.0;\n\ncontract MyContract {\n    string public myString = "Hello, World!";\n}');
      }
      // Clear previous deployment results when opening the modal
      setDeploymentResult(null);
    }
  }, [initialContract, isOpen]);

  const handleDeploy = async () => {
    setIsDeploying(true);
    setDeploymentResult(null);
    // Simulate deployment
    await new Promise(resolve => setTimeout(resolve, 2500));
    setIsDeploying(false);
    setDeploymentResult({
      success: true,
      address: `0x${Array.from(crypto.getRandomValues(new Uint8Array(20))).map(b => b.toString(16).padStart(2, '0')).join('')}`,
      txHash: `0x${Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('')}`
    });
  };

  const handleClose = () => {
    if (isDeploying) return;
    setDeploymentResult(null);
    setContractName('');
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}> {/* Changed from handleClose to onClose per outline */}
      <DialogContent className="glass-card text-neutral-200">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <FileCode className="w-6 h-6 text-blue-400" />
            Deploy New Smart Contract
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Compile and deploy a new contract to the Ethereum network.
          </DialogDescription>
        </DialogHeader>
        
        {!deploymentResult ? (
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="contractName" className="text-neutral-300">Contract Name</Label>
              <Input id="contractName" placeholder="e.g., MyToken" value={contractName} onChange={(e) => setContractName(e.target.value)} className="bg-white/5 border-white/20" />
            </div>
            <div>
              <Label htmlFor="sourceCode" className="text-neutral-300">Solidity Source Code</Label>
              <Textarea id="sourceCode" value={sourceCode} onChange={(e) => setSourceCode(e.target.value)} className="bg-white/5 border-white/20 font-mono h-48 custom-scrollbar" />
            </div>
          </div>
        ) : (
          <div className="py-4">
            <Alert className="bg-green-500/10 border-green-500/30">
              <CheckCircle className="h-4 w-4 text-green-400" />
              <AlertTitle className="text-green-300">Deployment Successful!</AlertTitle>
              <AlertDescription className="text-green-400/80 space-y-2 mt-2">
                <p><strong>Contract Address:</strong><br/><span className="font-mono text-xs">{deploymentResult.address}</span></p>
                <p><strong>Transaction Hash:</strong><br/><span className="font-mono text-xs">{deploymentResult.txHash}</span></p>
              </AlertDescription>
            </Alert>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} className="border-white/20 hover:bg-white/10" disabled={isDeploying}>Cancel</Button>
          {!deploymentResult && (
            <Button onClick={handleDeploy} className="bg-gradient-to-r from-blue-500 to-blue-700 text-white" disabled={isDeploying || !contractName || !sourceCode}>
              {isDeploying ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deploying...
                </>
              ) : (
                <>
                  <Terminal className="mr-2 h-4 w-4" />
                  Deploy
                </>
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
