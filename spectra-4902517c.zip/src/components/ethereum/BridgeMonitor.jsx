import React from 'react';
import { Link as LinkIcon, Clock, Check, TrendingUp, AlertCircle } from 'lucide-react';

export default function BridgeMonitor() {
  const stats = {
    totalVolume: 125400000,
    totalTransactions: 4321,
    pending: 5,
    avgDuration: '3.5 min',
    errorRate: '0.12%',
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">Fabric-ETH Bridge Monitor</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
        <StatCard icon={TrendingUp} label="Total Volume" value={`${(stats.totalVolume / 1e6).toFixed(2)}M SPEC`} />
        <StatCard icon={Check} label="Total Txns" value={stats.totalTransactions.toLocaleString()} />
        <StatCard icon={Clock} label="Pending Txns" value={stats.pending} highlight="text-yellow-400" />
        <StatCard icon={LinkIcon} label="Avg Duration" value={stats.avgDuration} />
        <StatCard icon={AlertCircle} label="Error Rate" value={stats.errorRate} highlight="text-red-400" />
      </div>
    </div>
  );
}

const StatCard = ({ icon: Icon, label, value, highlight = 'text-neutral-100' }) => (
  <div className="glass-effect rounded-lg p-4">
    <div className="flex items-center gap-3 mb-2">
      <Icon className="w-5 h-5 text-neutral-400" />
      <p className="text-sm text-neutral-400">{label}</p>
    </div>
    <p className={`text-2xl font-bold ${highlight}`}>{value}</p>
  </div>
);