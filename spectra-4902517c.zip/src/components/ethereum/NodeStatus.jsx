import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Server,
  Activity,
  Wifi,
  HardDrive,
  Cpu,
  Monitor,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  Settings
} from "lucide-react";

export default function NodeStatus() {
  const [nodeData, setNodeData] = useState({
    status: 'synced',
    version: 'Geth/v1.13.5',
    network: 'mainnet',
    syncProgress: 100,
    blockHeight: 18547293,
    peers: 47,
    diskSpace: { used: 856, total: 2000 },
    memory: { used: 12.4, total: 32 },
    cpu: 23,
    uptime: '12d 8h 42m'
  });

  // --- Style Definitions for Buttons ---
  const baseButtonStyle = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '0.375rem',
    fontSize: '0.875rem',
    fontWeight: '500',
    transition: 'all 0.2s',
    cursor: 'pointer',
    border: '1px solid transparent',
    padding: '0.5rem 1rem'
  };

  const gradientStyle = (from, to) => ({ ...baseButtonStyle, color: '#ffffff', background: `linear-gradient(to right, ${from}, ${to})` });
  const hoverGradientStyle = (from, to) => ({ background: `linear-gradient(to right, ${from}, ${to})` });
  
  const outlineStyle = { ...baseButtonStyle, backgroundColor: 'transparent', color: '#d4d4d4', border: '1px solid rgba(255, 255, 255, 0.2)' };
  const hoverOutlineStyle = { backgroundColor: 'rgba(255, 255, 255, 0.1)' };
  // --- End Style Definitions ---

  useEffect(() => {
    const interval = setInterval(() => {
      setNodeData(prev => ({
        ...prev,
        blockHeight: prev.blockHeight + Math.floor(Math.random() * 3),
        peers: Math.max(25, prev.peers + Math.floor(Math.random() * 5) - 2),
        cpu: Math.max(5, Math.min(80, prev.cpu + Math.floor(Math.random() * 10) - 5)),
        memory: {
          ...prev.memory,
          used: Math.max(8, Math.min(28, prev.memory.used + (Math.random() - 0.5) * 2))
        }
      }));
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  const getStatusColor = (status) => {
    switch (status) {
      case 'synced': return 'text-green-400';
      case 'syncing': return 'text-yellow-400';
      case 'offline': return 'text-red-400';
      default: return 'text-neutral-400';
    }
  };

  const restartNode = async () => {
    if (window.confirm('Are you sure you want to restart the Ethereum node? This will cause temporary downtime.')) {
      alert('Node restart initiated. This may take 2-3 minutes.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Node Overview */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
              <Server className="w-6 h-6 text-blue-400" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-neutral-100">Ethereum Node Status</h3>
              <p className="text-neutral-400">Real-time node monitoring and management</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge className={`bg-green-500/20 ${getStatusColor(nodeData.status)}`}>
              <CheckCircle className="w-3 h-3 mr-1" />
              {nodeData.status.charAt(0).toUpperCase() + nodeData.status.slice(1)}
            </Badge>
            <button
              onClick={restartNode}
              style={outlineStyle}
              onMouseEnter={(e) => Object.assign(e.target.style, hoverOutlineStyle)}
              onMouseLeave={(e) => Object.assign(e.target.style, outlineStyle)}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Restart Node
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-4 h-4 text-blue-400" />
              <span className="text-sm text-neutral-300">Block Height</span>
            </div>
            <p className="text-xl font-bold text-neutral-100">#{nodeData.blockHeight.toLocaleString()}</p>
            <p className="text-xs text-neutral-500">Mainnet</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Wifi className="w-4 h-4 text-green-400" />
              <span className="text-sm text-neutral-300">Connected Peers</span>
            </div>
            <p className="text-xl font-bold text-neutral-100">{nodeData.peers}</p>
            <p className="text-xs text-neutral-500">Active connections</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Monitor className="w-4 h-4 text-purple-400" />
              <span className="text-sm text-neutral-300">Sync Progress</span>
            </div>
            <p className="text-xl font-bold text-neutral-100">{nodeData.syncProgress}%</p>
            <div className="w-full bg-neutral-700 rounded-full h-1 mt-2">
              <div 
                className="bg-purple-500 h-1 rounded-full transition-all"
                style={{ width: `${nodeData.syncProgress}%` }}
              ></div>
            </div>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Server className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-neutral-300">Uptime</span>
            </div>
            <p className="text-xl font-bold text-neutral-100">{nodeData.uptime}</p>
            <p className="text-xs text-neutral-500">{nodeData.version}</p>
          </div>
        </div>
      </div>

      {/* System Resources */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-lg font-bold text-neutral-100 mb-4">System Resources</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-300">Disk Usage</span>
              </div>
              <span className="text-sm text-neutral-200">
                {nodeData.diskSpace.used}GB / {nodeData.diskSpace.total}GB
              </span>
            </div>
            <div className="w-full bg-neutral-700 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all"
                style={{ width: `${(nodeData.diskSpace.used / nodeData.diskSpace.total) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              {Math.round((nodeData.diskSpace.used / nodeData.diskSpace.total) * 100)}% used
            </p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Monitor className="w-4 h-4 text-green-400" />
                <span className="text-sm text-neutral-300">Memory Usage</span>
              </div>
              <span className="text-sm text-neutral-200">
                {nodeData.memory.used.toFixed(1)}GB / {nodeData.memory.total}GB
              </span>
            </div>
            <div className="w-full bg-neutral-700 rounded-full h-2">
              <div 
                className="bg-green-500 h-2 rounded-full transition-all"
                style={{ width: `${(nodeData.memory.used / nodeData.memory.total) * 100}%` }}
              ></div>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              {Math.round((nodeData.memory.used / nodeData.memory.total) * 100)}% used
            </p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-neutral-300">CPU Usage</span>
              </div>
              <span className="text-sm text-neutral-200">{nodeData.cpu}%</span>
            </div>
            <div className="w-full bg-neutral-700 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all ${
                  nodeData.cpu > 70 ? 'bg-red-500' : 
                  nodeData.cpu > 40 ? 'bg-yellow-500' : 'bg-orange-500'
                }`}
                style={{ width: `${nodeData.cpu}%` }}
              ></div>
            </div>
            <p className="text-xs text-neutral-500 mt-1">
              {nodeData.cpu > 70 ? 'High load' : 'Normal operation'}
            </p>
          </div>
        </div>
      </div>

      {/* Node Configuration */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-neutral-100">Node Configuration</h3>
          <button
            onClick={() => alert('Node configuration panel opening...')}
            style={gradientStyle('#3b82f6', '#1d4ed8')}
            onMouseEnter={(e) => Object.assign(e.target.style, hoverGradientStyle('#1d4ed8', '#1e40af'))}
            onMouseLeave={(e) => Object.assign(e.target.style, gradientStyle('#3b82f6', '#1d4ed8'))}
          >
            <Settings className="w-4 h-4 mr-2" />
            Configure
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-neutral-400">Client Version:</span>
              <span className="text-neutral-200">{nodeData.version}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Network:</span>
              <Badge className="bg-blue-500/20 text-blue-400">{nodeData.network}</Badge>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Consensus Client:</span>
              <span className="text-neutral-200">Prysm v4.1.1</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Execution Engine:</span>
              <span className="text-neutral-200">Enabled</span>
            </div>
          </div>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-neutral-400">JSON-RPC Port:</span>
              <span className="text-neutral-200">8545</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">WebSocket Port:</span>
              <span className="text-neutral-200">8546</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">P2P Port:</span>
              <span className="text-neutral-200">30303</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Archive Mode:</span>
              <Badge className="bg-green-500/20 text-green-400">Enabled</Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Alerts */}
      {nodeData.cpu > 70 && (
        <Alert className="bg-yellow-500/20 border-yellow-500/30">
          <AlertTriangle className="w-4 h-4 text-yellow-400" />
          <AlertDescription className="text-yellow-400">
            High CPU usage detected. Consider optimizing node configuration or upgrading hardware.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}