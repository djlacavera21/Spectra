
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Upload, FileText, CheckCircle, XCircle } from 'lucide-react';

export default function CodeFileUpload({ fileName, description, required, onFileChange }) {
  const [fileInfo, setFileInfo] = useState(null);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFileInfo({ name: file.name, size: file.size });
      onFileChange(fileName, file);
    }
  };

  const handleRemoveFile = () => {
    setFileInfo(null);
    onFileChange(fileName, null);
  };

  return (
    <div className="glass-effect rounded-lg p-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-neutral-700 rounded-lg flex items-center justify-center">
          {fileInfo ? (
            <CheckCircle className="w-6 h-6 text-green-400" />
          ) : (
            <FileText className="w-5 h-5 text-neutral-400" />
          )}
        </div>
        <div>
          <h4 className="font-medium text-neutral-200">
            {fileName} {required && <span className="text-red-400">*</span>}
          </h4>
          <p className="text-xs text-neutral-400">{description}</p>
          {fileInfo && (
            <p className="text-xs text-blue-400 mt-1">{fileInfo.name} ({(fileInfo.size / 1024).toFixed(2)} KB)</p>
          )}
        </div>
      </div>
      <div>
        {fileInfo ? (
          <Button variant="ghost" size="icon" onClick={handleRemoveFile} className="text-red-400 hover:bg-red-500/10">
            <XCircle className="w-5 h-5" />
          </Button>
        ) : (
          <Button asChild variant="outline" size="icon" className="border-white/20 hover:bg-white/10">
            <label className="cursor-pointer">
              <Upload className="w-4 h-4" />
              <input type="file" className="hidden" onChange={handleFileChange} />
            </label>
          </Button>
        )}
      </div>
    </div>
  );
}
