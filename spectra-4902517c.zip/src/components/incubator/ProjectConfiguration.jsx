
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings } from 'lucide-react';

export default function ProjectConfiguration({ config, setConfig }) {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setConfig(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Settings className="w-6 h-6 text-blue-400" />
          <span>New Coin Configuration</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="coinName" className="text-neutral-400 mb-2 block">Coin Name</Label>
          <Input
            id="coinName"
            name="coinName"
            placeholder="e.g., NovaCoin"
            value={config.coinName}
            onChange={handleChange}
            className="bg-white/5 border-white/20 text-neutral-100"
          />
        </div>
        <div>
          <Label htmlFor="tickerSymbol" className="text-neutral-400 mb-2 block">Ticker Symbol</Label>
          <Input
            id="tickerSymbol"
            name="tickerSymbol"
            placeholder="e.g., NVC"
            value={config.tickerSymbol}
            onChange={handleChange}
            className="bg-white/5 border-white/20 text-neutral-100"
            maxLength="5"
          />
        </div>
        <div>
          <Label htmlFor="version" className="text-neutral-400 mb-2 block">Initial Version</Label>
          <Input
            id="version"
            name="version"
            placeholder="e.g., 0.1.0"
            value={config.version}
            onChange={handleChange}
            className="bg-white/5 border-white/20 text-neutral-100"
          />
        </div>
        <div>
          <Label htmlFor="amountToMint" className="text-neutral-400 mb-2 block">Total Supply (Amount to Mint)</Label>
          <Input
            id="amountToMint"
            name="amountToMint"
            type="number"
            placeholder="e.g., 21000000"
            value={config.amountToMint}
            onChange={handleChange}
            className="bg-white/5 border-white/20 text-neutral-100"
          />
        </div>
      </CardContent>
    </Card>
  );
}
