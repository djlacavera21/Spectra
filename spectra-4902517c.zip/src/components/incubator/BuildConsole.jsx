import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Terminal, Bot } from 'lucide-react';

export default function BuildConsole({ log, buildState }) {
  const consoleEndRef = useRef(null);

  useEffect(() => {
    consoleEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [log]);

  const getStatusColor = () => {
    switch (buildState) {
      case 'building': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'failed': return 'text-red-400';
      default: return 'text-neutral-400';
    }
  };

  return (
    <Card className="glass-card h-full flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Terminal className="w-6 h-6 text-purple-400" />
          <span>Live Build & Deployment Console</span>
          <span className={`ml-auto text-sm font-medium capitalize ${getStatusColor()}`}>{buildState}</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-grow bg-black/50 rounded-b-xl font-mono text-sm text-neutral-300 p-4 overflow-y-auto custom-scrollbar">
        {log.map((line, index) => (
          <div key={index} className="flex gap-2">
            <span className="text-neutral-500">{`[${new Date().toLocaleTimeString()}] >`}</span>
            <span className={line.startsWith('Error:') ? 'text-red-400' : line.startsWith('Success:') ? 'text-green-400' : ''}>
              {line}
            </span>
          </div>
        ))}
        {buildState === 'building' && (
          <div className="flex items-center gap-2 animate-pulse">
            <span className="text-neutral-500">{`[${new Date().toLocaleTimeString()}] >`}</span>
            <Bot className="w-4 h-4 text-yellow-400 animate-spin" />
            <span>Processing...</span>
          </div>
        )}
        <div ref={consoleEndRef} />
      </CardContent>
    </Card>
  );
}