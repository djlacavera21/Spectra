import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Wallet,
  Zap,
  Shield,
  CheckCircle,
  AlertTriangle,
  Copy,
  ExternalLink,
  Unlink,
  Network,
  Globe
} from "lucide-react";

// Simulated wallet connection hook (since we can't import external libraries)
const useWallet = () => {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [address, setAddress] = useState("");
  const [chainId, setChainId] = useState(null);
  const [connected, setConnected] = useState(false);
  const [walletType, setWalletType] = useState("");

  const connectMetaMask = async () => {
    // Simulate MetaMask connection
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const mockAddress = "0x742d35Cc6bF4532C65a7A7A7A7A7A7A7A7A7A7A7";
    const mockChainId = 1; // Ethereum Mainnet
    
    setAddress(mockAddress);
    setChainId(mockChainId);
    setConnected(true);
    setWalletType("MetaMask");
    
    alert("MetaMask connected successfully!");
  };

  const connectWalletConnect = async () => {
    // Simulate WalletConnect connection
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockAddress = "0x8ba1f109551bD432803012645Hac136c22C0B98E";
    const mockChainId = 137; // Polygon
    
    setAddress(mockAddress);
    setChainId(mockChainId);
    setConnected(true);
    setWalletType("WalletConnect");
    
    alert("WalletConnect connected successfully!");
  };

  const connectCoinbaseWallet = async () => {
    // Simulate Coinbase Wallet connection
    await new Promise(resolve => setTimeout(resolve, 1800));
    
    const mockAddress = "0x1f9840a85d5aF5bf1D1762F925BDADdC4201F984";
    const mockChainId = 1; // Ethereum Mainnet
    
    setAddress(mockAddress);
    setChainId(mockChainId);
    setConnected(true);
    setWalletType("Coinbase Wallet");
    
    alert("Coinbase Wallet connected successfully!");
  };

  const disconnect = async () => {
    setProvider(null);
    setSigner(null);
    setAddress("");
    setChainId(null);
    setConnected(false);
    setWalletType("");
  };

  return {
    provider,
    signer,
    address,
    chainId,
    connected,
    walletType,
    connectMetaMask,
    connectWalletConnect,
    connectCoinbaseWallet,
    disconnect
  };
};

export default function WalletConnector({ onWalletConnected, onWalletDisconnected }) {
  const [showModal, setShowModal] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectingWallet, setConnectingWallet] = useState("");
  
  const {
    address,
    chainId,
    connected,
    walletType,
    connectMetaMask,
    connectWalletConnect,
    connectCoinbaseWallet,
    disconnect
  } = useWallet();

  useEffect(() => {
    if (connected && address) {
      onWalletConnected({
        address,
        chainId,
        walletType,
        provider: `${walletType} Provider`
      });
    }
  }, [connected, address, chainId, walletType, onWalletConnected]);

  const handleConnect = async (walletName, connectFunction) => {
    setIsConnecting(true);
    setConnectingWallet(walletName);
    
    try {
      await connectFunction();
      setShowModal(false);
    } catch (error) {
      console.error(`Error connecting to ${walletName}:`, error);
      alert(`Failed to connect to ${walletName}. Please try again.`);
    } finally {
      setIsConnecting(false);
      setConnectingWallet("");
    }
  };

  const handleDisconnect = async () => {
    await disconnect();
    onWalletDisconnected();
  };

  const getChainName = (chainId) => {
    const chains = {
      1: "Ethereum Mainnet",
      137: "Polygon",
      56: "BSC",
      43114: "Avalanche",
      250: "Fantom",
      42161: "Arbitrum"
    };
    return chains[chainId] || `Chain ${chainId}`;
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    alert("Address copied to clipboard!");
  };

  if (connected) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <CheckCircle className="w-5 h-5 text-green-400" />
            Wallet Connected
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-blue-400" />
                <span className="text-sm font-medium text-neutral-200">{walletType}</span>
              </div>
              <Badge className="bg-green-500/20 text-green-400">Connected</Badge>
            </div>
            
            <div className="space-y-2">
              <div>
                <p className="text-xs text-neutral-400">Wallet Address</p>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono text-neutral-200">
                    {address.slice(0, 6)}...{address.slice(-4)}
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={copyAddress}
                    className="h-6 w-6 p-0 text-neutral-400 hover:text-neutral-200"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div>
                <p className="text-xs text-neutral-400">Network</p>
                <div className="flex items-center gap-2">
                  <Network className="w-3 h-3 text-purple-400" />
                  <span className="text-sm text-neutral-200">{getChainName(chainId)}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            <Button
              onClick={handleDisconnect}
              variant="outline"
              size="sm"
              className="flex-1 border-white/20 text-neutral-200 hover:bg-white/10"
            >
              <Unlink className="w-4 h-4 mr-2" />
              Disconnect
            </Button>
            <Button
              onClick={() => window.open(`https://etherscan.io/address/${address}`, '_blank')}
              variant="outline"
              size="sm"
              className="border-white/20 text-neutral-200 hover:bg-white/10"
            >
              <ExternalLink className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Wallet className="w-5 h-5 text-blue-400" />
            Connect External Wallet
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <Globe className="w-12 h-12 text-neutral-600 mx-auto mb-4" />
            <h4 className="font-medium text-neutral-200 mb-2">No Wallet Connected</h4>
            <p className="text-sm text-neutral-400 mb-6">
              Connect your external wallet to access cross-chain swaps and DeFi features
            </p>
            <Button
              onClick={() => setShowModal(true)}
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
            >
              <Zap className="w-4 h-4 mr-2" />
              Connect Wallet
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Wallet Selection Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="glass-card max-w-md">
          <DialogHeader>
            <DialogTitle className="text-neutral-100 flex items-center gap-2">
              <Wallet className="w-5 h-5 text-blue-400" />
              Connect Your Wallet
            </DialogTitle>
            <DialogDescription className="text-neutral-400">
              Choose your preferred wallet to connect and start swapping
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-3">
            <Button
              onClick={() => handleConnect("MetaMask", connectMetaMask)}
              disabled={isConnecting}
              className="w-full bg-white text-black hover:bg-neutral-200 justify-start h-12"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                  <Wallet className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-medium">MetaMask</p>
                  <p className="text-xs text-neutral-600">Browser extension wallet</p>
                </div>
              </div>
              {isConnecting && connectingWallet === "MetaMask" && (
                <div className="ml-auto animate-spin rounded-full h-4 w-4 border-b-2 border-orange-500"></div>
              )}
            </Button>

            <Button
              onClick={() => handleConnect("WalletConnect", connectWalletConnect)}
              disabled={isConnecting}
              className="w-full bg-white text-black hover:bg-neutral-200 justify-start h-12"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
                  <Network className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-medium">WalletConnect</p>
                  <p className="text-xs text-neutral-600">Mobile wallet connection</p>
                </div>
              </div>
              {isConnecting && connectingWallet === "WalletConnect" && (
                <div className="ml-auto animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
              )}
            </Button>

            <Button
              onClick={() => handleConnect("Coinbase Wallet", connectCoinbaseWallet)}
              disabled={isConnecting}
              className="w-full bg-white text-black hover:bg-neutral-200 justify-start h-12"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <Shield className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <p className="font-medium">Coinbase Wallet</p>
                  <p className="text-xs text-neutral-600">Self-custody wallet</p>
                </div>
              </div>
              {isConnecting && connectingWallet === "Coinbase Wallet" && (
                <div className="ml-auto animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
              )}
            </Button>
          </div>

          <Alert className="bg-yellow-500/20 border-yellow-500/30 mt-4">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <AlertDescription className="text-yellow-400 text-sm">
              <strong>Security Notice:</strong> Only connect wallets you trust. Never share your seed phrase or private keys.
            </AlertDescription>
          </Alert>
        </DialogContent>
      </Dialog>
    </>
  );
}