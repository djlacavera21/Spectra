import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  Clock,
  Eye,
  Calculator,
  Lock
} from "lucide-react";
import { User, SecurityEvent } from "@/api/entities";

export default function TransactionValidator({ 
  transaction, 
  onApprove, 
  onReject, 
  isVisible = false 
}) {
  const [verificationCode, setVerificationCode] = useState("");
  const [riskScore, setRiskScore] = useState(0);
  const [riskFactors, setRiskFactors] = useState([]);
  const [timeRemaining, setTimeRemaining] = useState(300); // 5 minutes
  const [isValidating, setIsValidating] = useState(false);

  useEffect(() => {
    if (isVisible && transaction) {
      calculateRiskScore();
      startCountdown();
    }
  }, [isVisible, transaction]);

  const calculateRiskScore = () => {
    let score = 0;
    const factors = [];

    // Amount-based risk
    if (transaction.amount > 10000) {
      score += 30;
      factors.push("High transaction amount");
    } else if (transaction.amount > 5000) {
      score += 15;
      factors.push("Medium transaction amount");
    }

    // Destination analysis
    if (transaction.to_address && !transaction.to_address.startsWith('bc1')) {
      score += 10;
      factors.push("Non-native segwit address");
    }

    // Time-based risk
    const hour = new Date().getHours();
    if (hour < 6 || hour > 22) {
      score += 10;
      factors.push("Unusual transaction time");
    }

    // Cross-chain risk
    if (transaction.transaction_type === 'cross_chain_swap') {
      score += 20;
      factors.push("Cross-chain transaction");
    }

    // First-time recipient
    if (transaction.metadata?.first_time_recipient) {
      score += 25;
      factors.push("New recipient address");
    }

    setRiskScore(Math.min(100, score));
    setRiskFactors(factors);
  };

  const startCountdown = () => {
    const interval = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          onReject("Transaction expired");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  };

  const handleValidation = async () => {
    if (!verificationCode || verificationCode.length < 6) {
      alert("Please enter a valid verification code");
      return;
    }

    setIsValidating(true);
    
    try {
      // Simulate validation delay
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Log security event
      await SecurityEvent.create({
        user_wallet: transaction.from_address,
        event_type: "transaction_approved",
        ip_address: "current_session",
        risk_score: riskScore,
        details: {
          transaction_hash: transaction.transaction_hash,
          amount: transaction.amount,
          verification_method: "2fa_code",
          risk_factors: riskFactors
        }
      });

      onApprove(verificationCode);
    } catch (error) {
      console.error("Validation failed:", error);
      alert("Validation failed. Please try again.");
    } finally {
      setIsValidating(false);
    }
  };

  const getRiskColor = () => {
    if (riskScore >= 70) return "text-red-400 bg-red-500/20 border-red-500/30";
    if (riskScore >= 40) return "text-yellow-400 bg-yellow-500/20 border-yellow-500/30";
    return "text-green-400 bg-green-500/20 border-green-500/30";
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="glass-card rounded-xl p-6 max-w-md w-full">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-8 h-8 text-blue-400" />
          <div>
            <h3 className="text-xl font-bold text-neutral-100">Transaction Security Check</h3>
            <p className="text-neutral-400">Verify this transaction before proceeding</p>
          </div>
        </div>

        {/* Transaction Details */}
        <div className="glass-effect rounded-lg p-4 mb-4">
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-neutral-400">Amount:</span>
              <span className="text-neutral-100 font-bold">
                {transaction.amount?.toLocaleString()} SPEC
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">To:</span>
              <span className="text-neutral-100 font-mono text-xs">
                {transaction.to_address?.substring(0, 20)}...
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-400">Type:</span>
              <span className="text-neutral-100 capitalize">
                {transaction.transaction_type?.replace('_', ' ')}
              </span>
            </div>
          </div>
        </div>

        {/* Risk Assessment */}
        <div className={`rounded-lg p-4 mb-4 border ${getRiskColor()}`}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5" />
              <span className="font-medium">Risk Assessment</span>
            </div>
            <Badge className={getRiskColor()}>
              {riskScore >= 70 ? 'High Risk' : riskScore >= 40 ? 'Medium Risk' : 'Low Risk'}
            </Badge>
          </div>
          
          {riskFactors.length > 0 && (
            <div className="space-y-1">
              {riskFactors.map((factor, index) => (
                <div key={index} className="flex items-center gap-2 text-xs">
                  <div className="w-1 h-1 rounded-full bg-current"></div>
                  <span>{factor}</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Countdown Timer */}
        <div className="flex items-center justify-center gap-2 mb-4">
          <Clock className="w-4 h-4 text-yellow-400" />
          <span className="text-yellow-400 font-mono">
            Expires in {formatTime(timeRemaining)}
          </span>
        </div>

        {/* 2FA Code Input */}
        <div className="mb-6">
          <label className="block text-sm text-neutral-300 mb-2">
            Enter your 2FA verification code:
          </label>
          <Input
            type="text"
            placeholder="123456"
            value={verificationCode}
            onChange={(e) => setVerificationCode(e.target.value)}
            className="bg-white/5 border-white/20 text-neutral-100 text-center font-mono text-lg"
            maxLength={6}
            autoFocus
          />
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <Button
            onClick={() => onReject("User cancelled")}
            variant="outline"
            className="flex-1 border-white/20 text-neutral-200 hover:bg-white/10"
            disabled={isValidating}
          >
            Cancel
          </Button>
          <Button
            onClick={handleValidation}
            disabled={!verificationCode || verificationCode.length < 6 || isValidating}
            className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
          >
            {isValidating ? (
              <div className="flex items-center justify-center">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Validating...
              </div>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Approve Transaction
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}