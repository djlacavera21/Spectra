import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { 
  ShieldCheck, 
  Users, 
  FileText, 
  Search,
  UserCheck,
  UserX,
  Gavel,
  Loader2,
  AlertTriangle,
  ClipboardList
} from 'lucide-react';
import { User, ComplianceRecord, AuditLog } from '@/api/entities';
import { format } from 'date-fns';

const KycStatusBadge = ({ status }) => {
  const styles = {
    approved: 'bg-green-500/20 text-green-400',
    pending: 'bg-yellow-500/20 text-yellow-400',
    under_review: 'bg-blue-500/20 text-blue-400',
    rejected: 'bg-red-500/20 text-red-400',
  };
  return <Badge className={styles[status] || 'bg-neutral-500/20 text-neutral-400'}>{status.replace('_', ' ')}</Badge>;
};

const RiskScoreBar = ({ score }) => {
  let color;
  if (score < 40) color = 'bg-green-500';
  else if (score < 70) color = 'bg-yellow-500';
  else color = 'bg-red-500';

  return (
    <div className="w-full bg-neutral-700 rounded-full h-2.5">
      <div className={`${color} h-2.5 rounded-full`} style={{ width: `${score}%` }}></div>
    </div>
  );
};

const UserComplianceDashboard = () => {
    const [users, setUsers] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedUser, setSelectedUser] = useState(null);
    const [complianceRecord, setComplianceRecord] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [notes, setNotes] = useState('');

    useEffect(() => {
        const fetchUsers = async () => {
            const allUsers = await User.list();
            setUsers(allUsers);
        };
        fetchUsers();
    }, []);

    const handleUserSelect = async (user) => {
        setIsLoading(true);
        setSelectedUser(user);
        try {
            const record = await ComplianceRecord.filter({ user_wallet: user.wallet_address });
            if (record.length > 0) {
                setComplianceRecord(record[0]);
                setNotes(record[0].compliance_notes || '');
            } else {
                // If no record, create a default one for the admin to fill
                const newRecord = {
                    user_wallet: user.wallet_address,
                    kyc_level: 'none',
                    kyc_status: 'pending',
                    aml_risk_score: 10,
                    jurisdiction: 'Unknown',
                };
                const created = await ComplianceRecord.create(newRecord);
                setComplianceRecord(created);
                setNotes('');
            }
        } catch (e) {
            console.error("Error fetching/creating compliance record", e);
        } finally {
            setIsLoading(false);
        }
    };

    const handleUpdateRecord = async () => {
        if (!complianceRecord) return;
        setIsLoading(true);
        try {
            const updates = {
                kyc_status: complianceRecord.kyc_status,
                kyc_level: complianceRecord.kyc_level,
                aml_risk_score: complianceRecord.aml_risk_score,
                compliance_notes: notes,
            };
            await ComplianceRecord.update(complianceRecord.id, updates);
            alert("Record updated successfully.");
        } catch(e) {
            alert("Failed to update record.");
        } finally {
            setIsLoading(false);
        }
    }

    const filteredUsers = users.filter(u => 
        u.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        u.wallet_address.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* User List */}
            <div className="md:col-span-1">
                <Card className="glass-card h-full">
                    <CardHeader>
                        <CardTitle>Users</CardTitle>
                        <div className="relative mt-2">
                           <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 w-4 h-4" />
                           <Input placeholder="Search user..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-10" />
                        </div>
                    </CardHeader>
                    <CardContent className="overflow-y-auto max-h-[600px]">
                        {filteredUsers.map(user => (
                            <div key={user.id} onClick={() => handleUserSelect(user)} className={`p-3 rounded-lg cursor-pointer hover:bg-neutral-800 ${selectedUser?.id === user.id ? 'bg-blue-900/50' : ''}`}>
                                <p className="font-semibold">{user.full_name}</p>
                                <p className="text-sm text-neutral-400">{user.email}</p>
                                <p className="text-xs text-neutral-500 font-mono">{user.wallet_address}</p>
                            </div>
                        ))}
                    </CardContent>
                </Card>
            </div>
            {/* Compliance Details */}
            <div className="md:col-span-2">
                <Card className="glass-card">
                     <CardHeader>
                        <CardTitle>Compliance Details</CardTitle>
                         {selectedUser && <p className="text-neutral-300">Viewing record for <span className="font-bold">{selectedUser.full_name}</span></p>}
                    </CardHeader>
                    <CardContent>
                        {isLoading && <Loader2 className="animate-spin" />}
                        {!selectedUser && <p className="text-center text-neutral-400 py-12">Select a user to view their compliance record.</p>}
                        {selectedUser && !isLoading && complianceRecord && (
                            <div className="space-y-6">
                               <div className="grid grid-cols-2 gap-4">
                                   <div>
                                       <label className="text-sm text-neutral-400">KYC Status</label>
                                       <Select value={complianceRecord.kyc_status} onValueChange={val => setComplianceRecord(p => ({...p, kyc_status: val}))}>
                                           <SelectTrigger><SelectValue /></SelectTrigger>
                                           <SelectContent>
                                               <SelectItem value="pending">Pending</SelectItem>
                                               <SelectItem value="under_review">Under Review</SelectItem>
                                               <SelectItem value="approved">Approved</SelectItem>
                                               <SelectItem value="rejected">Rejected</SelectItem>
                                           </SelectContent>
                                       </Select>
                                   </div>
                                    <div>
                                       <label className="text-sm text-neutral-400">KYC Level</label>
                                       <Select value={complianceRecord.kyc_level} onValueChange={val => setComplianceRecord(p => ({...p, kyc_level: val}))}>
                                           <SelectTrigger><SelectValue /></SelectTrigger>
                                           <SelectContent>
                                                <SelectItem value="none">None</SelectItem>
                                               <SelectItem value="basic">Basic</SelectItem>
                                               <SelectItem value="advanced">Advanced</SelectItem>
                                               <SelectItem value="institutional">Institutional</SelectItem>
                                           </SelectContent>
                                       </Select>
                                   </div>
                               </div>

                               <div>
                                   <label className="text-sm text-neutral-400">AML Risk Score ({complianceRecord.aml_risk_score})</label>
                                   <div className="flex items-center gap-2">
                                     <RiskScoreBar score={complianceRecord.aml_risk_score} />
                                     <Input type="number" min="0" max="100" value={complianceRecord.aml_risk_score} onChange={e => setComplianceRecord(p => ({...p, aml_risk_score: parseInt(e.target.value)}))} className="w-20" />
                                   </div>
                               </div>

                                <div>
                                   <label className="text-sm text-neutral-400">Compliance Notes</label>
                                   <Textarea value={notes} onChange={e => setNotes(e.target.value)} placeholder="Add internal notes..." rows={4} />
                               </div>
                               
                               <div className="flex justify-end">
                                   <Button onClick={handleUpdateRecord}>
                                       <Gavel className="w-4 h-4 mr-2" />
                                       Update Record
                                   </Button>
                               </div>

                            </div>
                        )}
                    </CardContent>
                </Card>
            </div>
        </div>
    )
};

const AuditTrail = () => {
    const [logs, setLogs] = useState([]);
    const [filter, setFilter] = useState('all');

    useEffect(() => {
        const fetchLogs = async () => {
            const allLogs = await AuditLog.list('-created_date', 100);
            setLogs(allLogs);
        };
        fetchLogs();
    }, []);

    const filteredLogs = logs.filter(log => filter === 'all' || log.event_type === filter);

    return (
        <Card className="glass-card">
            <CardHeader>
                <CardTitle>Audit Trail</CardTitle>
                <p className="text-neutral-400">Live feed of all significant system events.</p>
                 <Select value={filter} onValueChange={setFilter}>
                    <SelectTrigger className="w-48 mt-2"><SelectValue /></SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">All Events</SelectItem>
                        <SelectItem value="login_success">Login Success</SelectItem>
                        <SelectItem value="login_failure">Login Failure</SelectItem>
                        <SelectItem value="withdrawal_request">Withdrawal Request</SelectItem>
                        <SelectItem value="trade_executed">Trade Executed</SelectItem>
                        <SelectItem value="admin_action">Admin Action</SelectItem>
                         <SelectItem value="compliance_flag">Compliance Flag</SelectItem>
                    </SelectContent>
                </Select>
            </CardHeader>
            <CardContent className="max-h-[600px] overflow-y-auto">
                <div className="space-y-3">
                    {filteredLogs.map(log => (
                        <div key={log.id} className="glass-effect p-3 rounded-lg">
                           <div className="flex justify-between items-center">
                               <div>
                                  <p className="font-semibold">{log.event_description}</p>
                                  <p className="text-sm text-neutral-400 font-mono">
                                      {log.user_wallet || 'SYSTEM'} @ {log.ip_address}
                                  </p>
                               </div>
                               <div className="text-right">
                                    <Badge variant="outline" className="capitalize">{log.event_type.replace('_', ' ')}</Badge>
                                    <p className="text-xs text-neutral-500">{format(new Date(log.created_date), 'PPpp')}</p>
                               </div>
                           </div>
                        </div>
                    ))}
                </div>
            </CardContent>
        </Card>
    )
};


export default function ComplianceCenterComponent() {
  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-8 h-8 text-green-400" />
            <div>
              <CardTitle className="text-2xl font-bold text-neutral-100">Compliance Center</CardTitle>
              <p className="text-neutral-400">KYC/AML Management, Risk Analysis, and Audit Trails</p>
            </div>
          </div>
        </CardHeader>
      </Card>
      
      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-2 glass-effect">
          <TabsTrigger value="dashboard"><Users className="w-4 h-4 mr-2" />User Compliance</TabsTrigger>
          <TabsTrigger value="audit"><FileText className="w-4 h-4 mr-2" />Audit Trail</TabsTrigger>
        </TabsList>
        <TabsContent value="dashboard" className="mt-6">
            <UserComplianceDashboard />
        </TabsContent>
        <TabsContent value="audit" className="mt-6">
            <AuditTrail />
        </TabsContent>
      </Tabs>
    </div>
  );
}