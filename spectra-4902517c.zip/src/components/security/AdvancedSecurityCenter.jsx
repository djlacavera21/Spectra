import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Shield, 
  Key, 
  Lock,
  Plus,
  Trash2,
  Fingerprint,
  Smartphone,
  Laptop,
  QrCode,
  Copy,
  CheckCircle,
  Eye, EyeOff
} from 'lucide-react';
import { User, SecurityEvent, ApiKey } from '@/api/entities';

const SectionCard = ({ title, icon, children }) => (
  <Card className="glass-card">
    <CardHeader>
      <CardTitle className="flex items-center gap-2">
        {icon}
        {title}
      </CardTitle>
    </CardHeader>
    <CardContent>{children}</CardContent>
  </Card>
);

const APIKeyManagement = ({ user }) => {
  const [apiKeys, setApiKeys] = useState([]);
  const [newKeyLabel, setNewKeyLabel] = useState('');
  const [newKeyData, setNewKeyData] = useState(null);

  useEffect(() => {
    const fetchApiKeys = async () => {
      if (!user) return;
      const keys = await ApiKey.filter({ user_wallet: user.wallet_address });
      setApiKeys(keys);
    };
    fetchApiKeys();
  }, [user]);

  const generateNewKey = async () => {
    // In a REAL system, this is done backend. We are creating the real data structure here.
    const publicKey = `spec_pk_${Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b => b.toString(16).padStart(2, '0')).join('')}`;
    const secretKey = `spec_sk_${Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('')}`;
    
    // We only ever store a hash of the secret.
    const secretHash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(secretKey))
      .then(buf => Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join(''));

    await ApiKey.create({
      user_wallet: user.wallet_address,
      label: newKeyLabel,
      api_key_public: publicKey,
      api_secret_hash: secretHash,
      permissions: ['read_only'],
      status: 'active'
    });
    
    setNewKeyData({ publicKey, secretKey });
    setNewKeyLabel('');
    const keys = await ApiKey.filter({ user_wallet: user.wallet_address });
    setApiKeys(keys);
  };
  
  const revokeKey = async (keyId) => {
      await ApiKey.update(keyId, { status: 'revoked' });
      const keys = await ApiKey.filter({ user_wallet: user.wallet_address });
      setApiKeys(keys);
  };

  return (
    <SectionCard title="API Key Management" icon={<Key className="w-5 h-5 text-yellow-400" />}>
      <div className="space-y-4">
        {newKeyData && (
          <div className="p-4 bg-green-900/50 border border-green-400 rounded-lg space-y-3">
            <h4 className="font-bold text-green-300">New API Key Generated - Save Your Secret Key!</h4>
            <p className="text-sm text-neutral-300">This is the **only** time your secret key will be shown.</p>
            <div>
              <label className="text-xs text-neutral-400">API Key (Public)</label>
              <div className="flex items-center gap-2 font-mono p-2 bg-black rounded">
                <span>{newKeyData.publicKey}</span>
                <Copy className="w-4 h-4 cursor-pointer" onClick={() => navigator.clipboard.writeText(newKeyData.publicKey)} />
              </div>
            </div>
            <div>
              <label className="text-xs text-neutral-400">API Secret</label>
              <div className="flex items-center gap-2 font-mono p-2 bg-black rounded">
                <span>********************</span>
                <Copy className="w-4 h-4 cursor-pointer" onClick={() => navigator.clipboard.writeText(newKeyData.secretKey)} />
              </div>
            </div>
            <Button size="sm" onClick={() => setNewKeyData(null)}>I have saved my secret key</Button>
          </div>
        )}

        <div className="flex gap-2">
          <Input placeholder="New API Key Label" value={newKeyLabel} onChange={e => setNewKeyLabel(e.target.value)} className="bg-neutral-900" />
          <Button onClick={generateNewKey}><Plus className="w-4 h-4 mr-2" />Generate Key</Button>
        </div>
        <div className="space-y-2">
          {apiKeys.map(key => (
            <div key={key.id} className="glass-effect p-3 rounded-lg flex justify-between items-center">
              <div>
                <p className="font-semibold">{key.label}</p>
                <p className="font-mono text-xs text-neutral-400">{key.api_key_public}</p>
                <div className="flex gap-1 mt-1">
                  {key.permissions.map(p => <Badge key={p} variant="outline" className="text-xs">{p}</Badge>)}
                </div>
              </div>
              <div className="flex items-center gap-2">
                  <Badge className={key.status === 'active' ? `bg-green-500/20 text-green-400` : `bg-red-500/20 text-red-400`}>{key.status}</Badge>
                  {key.status === 'active' && 
                    <Button variant="destructive" size="sm" onClick={() => revokeKey(key.id)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  }
              </div>
            </div>
          ))}
        </div>
      </div>
    </SectionCard>
  );
};


const WhitelistManagement = ({ user }) => {
  const [ipWhitelist, setIpWhitelist] = useState([]);
  const [newIp, setNewIp] = useState('');
  const [withdrawalWhitelist, setWithdrawalWhitelist] = useState([]);
  const [newWAddress, setNewWAddress] = useState({ address: '', asset: 'BTC', label: '' });

  useEffect(() => {
    setIpWhitelist(user?.ip_whitelist || []);
    setWithdrawalWhitelist(user?.withdrawal_whitelist || []);
  }, [user]);

  const addIp = async () => {
    if (!newIp) return;
    const updated = [...ipWhitelist, newIp];
    await User.updateMyUserData({ ip_whitelist: updated });
    setIpWhitelist(updated);
    setNewIp('');
  };

  const removeIp = async (ipToRemove) => {
    const updated = ipWhitelist.filter(ip => ip !== ipToRemove);
    await User.updateMyUserData({ ip_whitelist: updated });
    setIpWhitelist(updated);
  };
  
  const addWithdrawalAddress = async () => {
    if (!newWAddress.address || !newWAddress.label) return;
    const updated = [...withdrawalWhitelist, newWAddress];
    await User.updateMyUserData({ withdrawal_whitelist: updated });
    setWithdrawalWhitelist(updated);
    setNewWAddress({ address: '', asset: 'BTC', label: '' });
  };
  
  const removeWithdrawalAddress = async (addrToRemove) => {
    const updated = withdrawalWhitelist.filter(w => w.address !== addrToRemove);
    await User.updateMyUserData({ withdrawal_whitelist: updated });
    setWithdrawalWhitelist(updated);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <SectionCard title="IP Address Whitelist (Login)" icon={<Lock className="w-5 h-5 text-blue-400" />}>
        <div className="flex gap-2 mb-4">
          <Input placeholder="Enter IP address" value={newIp} onChange={e => setNewIp(e.target.value)} className="bg-neutral-900" />
          <Button onClick={addIp}><Plus className="w-4 h-4" /></Button>
        </div>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {ipWhitelist.map(ip => (
            <div key={ip} className="glass-effect flex justify-between items-center p-2 rounded">
              <span className="font-mono text-sm">{ip}</span>
              <Button variant="ghost" size="icon" onClick={() => removeIp(ip)}>
                <Trash2 className="w-4 h-4 text-red-500" />
              </Button>
            </div>
          ))}
        </div>
      </SectionCard>
      
      <SectionCard title="Withdrawal Address Whitelist" icon={<Shield className="w-5 h-5 text-green-400" />}>
         <div className="space-y-2 mb-4">
             <Input placeholder="Address Label" value={newWAddress.label} onChange={e => setNewWAddress(prev => ({...prev, label: e.target.value}))} className="bg-neutral-900" />
             <Input placeholder="Withdrawal Address" value={newWAddress.address} onChange={e => setNewWAddress(prev => ({...prev, address: e.target.value}))} className="bg-neutral-900" />
             {/* Simple select for now */}
             <select value={newWAddress.asset} onChange={e => setNewWAddress(prev => ({...prev, asset: e.target.value}))} className="w-full p-2 rounded bg-neutral-900 border border-neutral-700">
                 <option>BTC</option>
                 <option>ETH</option>
                 <option>SPEC</option>
                 <option>USDT</option>
             </select>
          <Button onClick={addWithdrawalAddress} className="w-full"><Plus className="w-4 h-4 mr-2" />Add Address</Button>
        </div>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {withdrawalWhitelist.map(w => (
            <div key={w.address} className="glass-effect p-2 rounded">
                <div className="flex justify-between items-start">
                    <div>
                      <p className="font-semibold text-sm">{w.label} ({w.asset})</p>
                      <p className="font-mono text-xs text-neutral-400">{w.address}</p>
                    </div>
                    <Button variant="ghost" size="icon" onClick={() => removeWithdrawalAddress(w.address)}>
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </Button>
                </div>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
};


const AuthenticationSettings = ({ user }) => {
    const [twoFactorEnabled, setTwoFactorEnabled] = useState(user?.two_factor_enabled || false);

    const handle2FAChange = async (enabled) => {
        // Here you would trigger a real 2FA setup flow (e.g., show QR code for TOTP)
        // For now, we just update the state and the user record
        await User.updateMyUserData({ two_factor_enabled: enabled });
        setTwoFactorEnabled(enabled);
        alert(`2FA has been ${enabled ? 'enabled' : 'disabled'}.`);
    };

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <SectionCard title="Password" icon={<Lock className="w-5 h-5 text-neutral-400" />}>
                <p className="text-neutral-400 mb-4">It's recommended to use a strong, unique password.</p>
                <Button>Change Password</Button>
            </SectionCard>
            <SectionCard title="Two-Factor Authentication (2FA)" icon={<Smartphone className="w-5 h-5 text-green-400" />}>
                <div className="flex items-center justify-between">
                    <p className="text-neutral-300">Enable 2FA for enhanced security.</p>
                    <Switch
                        checked={twoFactorEnabled}
                        onCheckedChange={handle2FAChange}
                    />
                </div>
                {twoFactorEnabled && 
                    <div className="mt-4 p-3 bg-green-900/50 rounded-lg flex items-center gap-2">
                        <CheckCircle className="w-5 h-5 text-green-400" />
                        <p className="text-sm text-green-300">2FA is active on your account.</p>
                    </div>
                }
                <div className="mt-4 flex gap-2">
                    <Button variant="outline" disabled={!twoFactorEnabled}>Manage TOTP</Button>
                    <Button variant="outline">Add FIDO2/YubiKey</Button>
                </div>
            </SectionCard>
        </div>
    );
};

const ActiveSessions = () => {
  const [activeSessions, setActiveSessions] = useState([]);
  
  useEffect(() => {
    const fetchSessions = async () => {
      // Fetching real successful login events
      const sessions = await SecurityEvent.filter({ event_type: 'login_success' }, '-created_date', 5);
      setActiveSessions(sessions);
    };
    fetchSessions();
  }, []);

  return (
    <SectionCard title="Active Sessions" icon={<Fingerprint className="w-5 h-5 text-purple-400" />}>
      <div className="space-y-3">
        {activeSessions.map(session => (
          <div key={session.id} className="flex justify-between items-center p-3 glass-effect rounded-lg">
            <div className="flex items-center gap-3">
              {session.user_agent.includes('Mobile') ? <Smartphone /> : <Laptop />}
              <div>
                <p className="text-sm text-neutral-200">{session.user_agent.slice(0, 40)}...</p>
                <p className="text-xs text-neutral-400 font-mono">{session.ip_address}</p>
              </div>
            </div>
            <Button variant="outline" size="sm">Revoke</Button>
          </div>
        ))}
      </div>
    </SectionCard>
  );
};

export default function AdvancedSecurityCenter() {
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    const fetchData = async () => {
      const currentUser = await User.me();
      setUser(currentUser);
    };
    fetchData();
  }, []);
  
  if (!user) {
    return <p>Loading security settings...</p>;
  }

  return (
    <Tabs defaultValue="authentication" className="w-full">
      <TabsList className="grid w-full grid-cols-4 glass-effect">
        <TabsTrigger value="authentication">Authentication</TabsTrigger>
        <TabsTrigger value="access">Access Control</TabsTrigger>
        <TabsTrigger value="api">API Keys</TabsTrigger>
        <TabsTrigger value="sessions">Active Sessions</TabsTrigger>
      </TabsList>

      <TabsContent value="authentication" className="mt-6">
        <AuthenticationSettings user={user} />
      </TabsContent>
      
      <TabsContent value="access" className="mt-6">
        <WhitelistManagement user={user} />
      </TabsContent>

      <TabsContent value="api" className="mt-6">
        <APIKeyManagement user={user} />
      </TabsContent>
      
      <TabsContent value="sessions" className="mt-6">
        <ActiveSessions />
      </TabsContent>
    </Tabs>
  );
}