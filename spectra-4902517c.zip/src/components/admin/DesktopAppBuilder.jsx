import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { 
  Laptop, 
  Terminal, 
  Package, 
  Play, 
  Download, 
  Loader2, 
  CheckCircle,
  XCircle,
  HardDrive,
  GitCommit,
  Clock,
  RefreshCw,
  Info
} from 'lucide-react';
import { BuildArtifact } from '@/api/entities';
import { User } from '@/api/entities';
import { format } from 'date-fns';

const buildSteps = {
  deb: [
    { status: "Cloning", log: "git clone https://github.com/spectraco/spectra-desktop.git && cd spectra-desktop" },
    { status: "Compiling", log: "cmake . -B build && cmake --build build -j$(nproc)" },
    { status: "Packaging", log: "cpack -G DEB -C build" },
    { status: "Uploading", log: "mv build/spectra-desktop-1.0.0-Linux.deb ./spectra-desktop_1.0.0_amd64.deb && echo 'Uploading artifact...'" },
  ],
  exe: [
    { status: "Cloning", log: "git clone https://github.com/spectraco/spectra-desktop.git && cd spectra-desktop" },
    { status: "Compiling", log: "vcpkg install && cmake . -B build -DCMAKE_TOOLCHAIN_FILE=[vcpkg_root]/scripts/buildsystems/vcpkg.cmake && cmake --build build --config Release" },
    { status: "Packaging", log: "cpack -G NSIS -C Release" },
    { status: "Uploading", log: "echo 'Uploading artifact...'" },
  ],
  dmg: [
    { status: "Cloning", log: "git clone https://github.com/spectraco/spectra-desktop.git && cd spectra-desktop" },
    { status: "Compiling", log: "cmake . -B build && cmake --build build" },
    { status: "Packaging", log: "cpack -G DragNDrop -C build" },
    { status: "Uploading", log: "echo 'Uploading artifact...'" },
  ]
};

export default function DesktopAppBuilder() {
  const [builds, setBuilds] = useState([]);
  const [selectedBuild, setSelectedBuild] = useState(null);
  const [isBuilding, setIsBuilding] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [config, setConfig] = useState({
    build_target: 'deb',
    version: '1.0.0',
    build_type: 'Release',
    commit_hash: ''
  });
  const buildIntervalRef = useRef(null);

  useEffect(() => {
    fetchBuilds();
    const fetchUser = async () => {
      const user = await User.me();
      setCurrentUser(user);
    };
    fetchUser();

    // Check for any builds that were interrupted
    const runningBuild = builds.find(b => ["Queued", "Cloning", "Compiling", "Packaging", "Uploading"].includes(b.status));
    if(runningBuild && !isBuilding) {
      // resume the build process visualization
    }
    
    return () => {
      if(buildIntervalRef.current) clearInterval(buildIntervalRef.current);
    }
  }, []);
  
  const fetchBuilds = async () => {
    const allBuilds = await BuildArtifact.list('-created_date', 50);
    setBuilds(allBuilds);
    if (!selectedBuild && allBuilds.length > 0) {
      setSelectedBuild(allBuilds[0]);
    } else if (selectedBuild) {
        // refresh selected build data
        const refreshedBuild = allBuilds.find(b => b.id === selectedBuild.id);
        setSelectedBuild(refreshedBuild || allBuilds[0]);
    }
  };

  const handleTriggerBuild = async () => {
    if (!currentUser) return;
    setIsBuilding(true);

    const newBuildData = {
      ...config,
      status: 'Queued',
      triggered_by: currentUser.email,
      build_log: `[${new Date().toISOString()}] Build triggered by ${currentUser.email}\n`
    };

    const newBuild = await BuildArtifact.create(newBuildData);
    setSelectedBuild(newBuild);
    await fetchBuilds();
    
    // --- Build Process Simulation ---
    const steps = buildSteps[config.build_target];
    let currentLog = newBuild.build_log;
    let buildSuccess = true;

    for (const step of steps) {
      currentLog += `[${new Date().toISOString()}] Starting step: ${step.status}\n$ ${step.log}\n`;
      await BuildArtifact.update(newBuild.id, { status: step.status, build_log: currentLog });
      await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 1500)); // simulate time for step
      currentLog += `[${new Date().toISOString()}] Step ${step.status} finished.\n`;
      await fetchBuilds();
    }

    // Finalize build
    if(buildSuccess) {
        const artifactName = `spectra-desktop-${config.version}-${config.build_target}.sh`;
        const artifactContent = `#!/bin/bash\necho "Spectra Desktop v${config.version} Installer"\n# Build Target: ${config.build_target}\n# Commit: ${config.commit_hash || 'latest'}\n# This script represents the successful build artifact.\nexit 0`;
        const blob = new Blob([artifactContent], { type: 'application/x-shellscript' });
        const url = URL.createObjectURL(blob);
        const sizeKB = Math.round(blob.size / 1024);
        
        // "calculate" checksum
        const hashBuffer = await crypto.subtle.digest('SHA-256', await blob.arrayBuffer());
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const checksum_sha256 = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

        currentLog += `[${new Date().toISOString()}] Artifact created: ${artifactName}\n[${new Date().toISOString()}] SHA256: ${checksum_sha256}\n`;
        await BuildArtifact.update(newBuild.id, {
            status: 'Success',
            artifact_url: url,
            artifact_name: artifactName,
            artifact_size_kb: sizeKB,
            checksum_sha256,
            build_log: currentLog
        });
    } else {
        currentLog += `[${new Date().toISOString()}] Build failed during ${steps[steps.length-1].status} step.\n`;
        await BuildArtifact.update(newBuild.id, { status: 'Failed', build_log: currentLog });
    }
    
    setIsBuilding(false);
    await fetchBuilds();
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case 'Success': return <Badge className="bg-green-500/20 text-green-400"><CheckCircle className="w-3 h-3 mr-1"/>Success</Badge>;
      case 'Failed': return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1"/>Failed</Badge>;
      case 'Queued': return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1"/>Queued</Badge>;
      default: return <Badge className="bg-blue-500/20 text-blue-400"><Loader2 className="w-3 h-3 mr-1 animate-spin"/>{status}</Badge>;
    }
  };
  
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left Column: Configuration & Trigger */}
      <div className="lg:col-span-1 space-y-6">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-3"><Package className="w-6 h-6 text-blue-400" /> New Build</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Build Target</Label>
              <Select value={config.build_target} onValueChange={(v) => setConfig(p => ({...p, build_target: v}))} disabled={isBuilding}>
                <SelectTrigger><SelectValue/></SelectTrigger>
                <SelectContent>
                  <SelectItem value="deb">Linux (Debian .deb)</SelectItem>
                  <SelectItem value="exe">Windows (Installer .exe)</SelectItem>
                  <SelectItem value="dmg">macOS (Disk Image .dmg)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Version</Label>
              <Input value={config.version} onChange={(e) => setConfig(p => ({...p, version: e.target.value}))} placeholder="e.g., 1.0.1" disabled={isBuilding} />
            </div>
             <div>
              <Label>Git Commit Hash (Optional)</Label>
              <Input value={config.commit_hash} onChange={(e) => setConfig(p => ({...p, commit_hash: e.target.value}))} placeholder="e.g., a1b2c3d" disabled={isBuilding} />
            </div>
            <Button onClick={handleTriggerBuild} disabled={isBuilding} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600">
              {isBuilding ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Play className="w-4 h-4 mr-2"/>}
              Trigger Build
            </Button>
          </CardContent>
        </Card>
        
        <Card className="glass-card">
            <CardHeader>
                <CardTitle className="flex items-center gap-3"><Clock className="w-5 h-5 text-purple-400" /> Build History</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="max-h-96 overflow-y-auto">
                    <Table>
                        <TableHeader>
                            <TableRow>
                                <TableHead>Version</TableHead>
                                <TableHead>Target</TableHead>
                                <TableHead>Status</TableHead>
                            </TableRow>
                        </TableHeader>
                        <TableBody>
                            {builds.map(build => (
                                <TableRow key={build.id} onClick={() => setSelectedBuild(build)} className={`cursor-pointer ${selectedBuild?.id === build.id ? 'bg-white/10' : ''}`}>
                                    <TableCell>{build.version}</TableCell>
                                    <TableCell>{build.build_target}</TableCell>
                                    <TableCell>{getStatusBadge(build.status)}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </div>
            </CardContent>
        </Card>

      </div>

      {/* Right Column: Build Details & Logs */}
      <div className="lg:col-span-2">
        <Card className="glass-card">
          <CardHeader>
            <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-3"><Terminal className="w-6 h-6 text-green-400" /> Build Details</CardTitle>
                <Button variant="ghost" size="icon" onClick={fetchBuilds}><RefreshCw className="w-4 h-4"/></Button>
            </div>
          </CardHeader>
          <CardContent>
            {selectedBuild ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div><Label>Version</Label><p className="font-semibold text-neutral-200">{selectedBuild.version}</p></div>
                    <div><Label>Target</Label><p className="font-semibold text-neutral-200">{selectedBuild.build_target}</p></div>
                    <div><Label>Status</Label><div>{getStatusBadge(selectedBuild.status)}</div></div>
                    <div><Label>Triggered</Label><p className="font-semibold text-neutral-200">{format(new Date(selectedBuild.created_date), 'PP pp')}</p></div>
                    <div className="col-span-2"><Label>Commit</Label><p className="font-mono text-xs text-neutral-300">{selectedBuild.commit_hash || 'Not specified'}</p></div>
                    <div className="col-span-2"><Label>Triggered By</Label><p className="font-semibold text-neutral-200">{selectedBuild.triggered_by}</p></div>
                </div>

                {selectedBuild.status === 'Success' && (
                  <Alert className="bg-green-900/50 border-green-500/30">
                    <CheckCircle className="h-4 w-4 text-green-400" />
                    <AlertTitle className="text-green-300">Build Successful</AlertTitle>
                    <AlertDescription className="flex items-center justify-between">
                      <div>
                        <p className="text-green-400/80">Artifact is ready for download.</p>
                        <p className="text-xs text-neutral-400 font-mono mt-1">
                            {selectedBuild.artifact_name} ({selectedBuild.artifact_size_kb} KB)
                        </p>
                         <p className="text-xs text-neutral-400 font-mono mt-1">
                            SHA256: {selectedBuild.checksum_sha256?.substring(0, 32)}...
                        </p>
                      </div>
                      <a href={selectedBuild.artifact_url} download={selectedBuild.artifact_name}>
                        <Button><Download className="w-4 h-4 mr-2"/>Download Artifact</Button>
                      </a>
                    </AlertDescription>
                  </Alert>
                )}
                
                <div>
                  <Label>Build Log</Label>
                  <div className="bg-black rounded-lg p-4 h-80 overflow-y-auto font-mono text-xs text-green-400 whitespace-pre-wrap">
                    {selectedBuild.build_log || "No logs available."}
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-16 text-neutral-400">
                <Info className="w-8 h-8 mx-auto mb-2"/>
                <p>Select a build from the history or trigger a new one.</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}