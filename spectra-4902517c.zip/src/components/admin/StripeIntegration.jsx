import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, ExternalLink, Loader2, CheckCircle, WifiOff, Settings, Save, LogIn } from 'lucide-react';

export default function StripeIntegration() {
  const [isConfigured, setIsConfigured] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [keys, setKeys] = useState({ client_id: '', secret_key: '' });
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const savedKeys = localStorage.getItem('stripe_config');
    if (savedKeys) {
      setKeys(JSON.parse(savedKeys));
      setIsConfigured(true);
    }
    const connectionStatus = localStorage.getItem('stripe_connection_status');
    if (connectionStatus === 'connected') {
        setIsConnected(true);
    }
  }, []);

  const handleSaveConfig = () => {
    if (!keys.client_id || !keys.secret_key) {
      alert('Please provide both Client ID and Secret Key.');
      return;
    }
    localStorage.setItem('stripe_config', JSON.stringify(keys));
    setIsConfigured(true);
    alert('Stripe configuration saved!');
  };
  
  const handleStripeConnect = () => {
    const STRIPE_CONNECT_URL = 'https://connect.stripe.com/oauth/authorize';
    const REDIRECT_URI = `${window.location.origin}/admin/stripe-callback`;
    const params = new URLSearchParams({
      response_type: 'code',
      client_id: keys.client_id,
      scope: 'read_write',
      redirect_uri: REDIRECT_URI
    });
    
    window.location.href = `${STRIPE_CONNECT_URL}?${params.toString()}`;
  };

  const openStripeLogin = () => {
    window.open('https://dashboard.stripe.com/login', '_blank');
  };

  const openStripeDashboard = () => {
    window.open('https://dashboard.stripe.com', '_blank');
  };

  const renderConfigurationForm = () => (
    <div className="space-y-4">
       <Alert className="bg-yellow-500/10 border-yellow-500/20">
        <Settings className="h-4 w-4 text-yellow-400" />
        <AlertTitle className="text-yellow-300">Configuration Required</AlertTitle>
        <AlertDescription className="text-yellow-400/80">
          Get your API keys from your Stripe Dashboard to enable payment processing.
        </AlertDescription>
      </Alert>

      <div className="flex gap-2 mb-4">
        <Button 
          onClick={openStripeLogin}
          variant="outline" 
          className="flex-1 border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
        >
          <LogIn className="w-4 h-4 mr-2" />
          Login to Stripe
        </Button>
        <Button 
          onClick={openStripeDashboard}
          variant="outline" 
          className="flex-1 border-blue-500/30 text-blue-400 hover:bg-blue-500/10"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Stripe Dashboard
        </Button>
      </div>

      <div>
        <Label htmlFor="stripe-client-id" className="text-neutral-300">Stripe Client ID</Label>
        <Input 
          id="stripe-client-id"
          placeholder="ca_..."
          value={keys.client_id}
          onChange={(e) => setKeys({...keys, client_id: e.target.value})}
          className="bg-white/5 border-white/20"
        />
        <p className="text-xs text-neutral-500 mt-1">Found in Dashboard → Settings → Connect</p>
      </div>
      <div>
        <Label htmlFor="stripe-secret-key" className="text-neutral-300">Stripe Secret Key</Label>
        <Input 
          id="stripe-secret-key"
          type="password"
          placeholder="sk_live_... or sk_test_..."
          value={keys.secret_key}
          onChange={(e) => setKeys({...keys, secret_key: e.target.value})}
          className="bg-white/5 border-white/20"
        />
        <p className="text-xs text-neutral-500 mt-1">Found in Dashboard → Developers → API keys</p>
      </div>
      <Button onClick={handleSaveConfig} className="w-full">
        <Save className="w-4 h-4 mr-2" />
        Save Configuration
      </Button>
    </div>
  );

  const renderConnectionInterface = () => (
    <div className="text-center py-8">
        {isConnected ? (
             <Alert className="bg-green-500/10 border-green-500/20 mb-6">
                <CheckCircle className="h-4 w-4 text-green-400" />
                <AlertTitle className="text-green-300">Stripe Account Connected</AlertTitle>
                <AlertDescription className="text-green-400/80">
                    Payment processing is active for Spectra Platform.
                </AlertDescription>
            </Alert>
        ) : (
            <>
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CreditCard className="w-8 h-8 text-neutral-400" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-200 mb-2">Connect to Stripe</h3>
                <p className="text-neutral-400 mb-6 max-w-md mx-auto">
                Authorize Spectra to process payments using your configured Stripe account.
                </p>
                <div className="flex gap-2 justify-center mb-4">
                  <Button 
                      onClick={handleStripeConnect} 
                      className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                  >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Connect with Stripe
                  </Button>
                  <Button 
                    onClick={openStripeDashboard}
                    variant="outline" 
                    className="border-white/20 hover:bg-white/10"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Dashboard
                  </Button>
                </div>
            </>
        )}

        {isConnected && (
          <div className="flex gap-2 justify-center mt-4">
            <Button 
              onClick={openStripeDashboard}
              variant="outline" 
              className="border-white/20 hover:bg-white/10"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              Open Stripe Dashboard
            </Button>
            <Button 
              onClick={() => setIsConfigured(false)}
              variant="outline" 
              className="border-white/20 hover:bg-white/10"
            >
              <Settings className="w-4 h-4 mr-2" />
              Update Keys
            </Button>
          </div>
        )}
    </div>
  );

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-3 text-neutral-100">
            <CreditCard className="w-6 h-6 text-blue-400" />
            Stripe Payment Gateway
          </CardTitle>
          <div className="flex items-center gap-2">
            {isConfigured ? (
              <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                <CheckCircle className="w-3 h-3 mr-1" />
                Configured
              </Badge>
            ) : (
              <Badge variant="destructive" className="bg-red-500/20 text-red-400 border-red-500/30">
                <WifiOff className="w-3 h-3 mr-1" />
                Not Configured
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isConfigured ? renderConnectionInterface() : renderConfigurationForm()}
      </CardContent>
    </Card>
  );
}