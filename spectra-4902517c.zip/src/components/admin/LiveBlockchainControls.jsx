import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Network, Activity, Pause, Play, AlertCircle } from 'lucide-react';

export default function LiveBlockchainControls() {
  const [gatewayStatus, setGatewayStatus] = useState('online');
  const [engineStatus, setEngineStatus] = useState('running');

  // This would be replaced with real-time data from a WebSocket or polling
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate status fluctuations
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const toggleGateway = () => {
    setGatewayStatus(prev => prev === 'online' ? 'paused' : 'online');
  };

  const toggleEngine = () => {
    setEngineStatus(prev => prev === 'running' ? 'paused' : 'running');
  };

  const getStatusBadge = (status) => {
    const isOnline = status === 'online' || status === 'running';
    return (
      <Badge className={isOnline ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
        {isOnline ? 'Active' : 'Paused'}
      </Badge>
    );
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-green-400" />
          <CardTitle>Live Blockchain Controls</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="glass-effect rounded-lg p-4 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-neutral-100 flex items-center gap-2">
              <Network className="w-5 h-5" />
              Blockchain Gateway
            </h3>
            <p className="text-sm text-neutral-400">Controls connections to all blockchains.</p>
          </div>
          <div className="flex items-center gap-4">
            {getStatusBadge(gatewayStatus)}
            <Button onClick={toggleGateway} variant="outline" className="border-white/20">
              {gatewayStatus === 'online' ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {gatewayStatus === 'online' ? 'Pause' : 'Resume'}
            </Button>
          </div>
        </div>

        <div className="glass-effect rounded-lg p-4 flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-neutral-100 flex items-center gap-2">
              <Activity className="w-5 h-5" />
              Order Matching Engine
            </h3>
            <p className="text-sm text-neutral-400">Handles all order matching and trade execution.</p>
          </div>
          <div className="flex items-center gap-4">
            {getStatusBadge(engineStatus)}
            <Button onClick={toggleEngine} variant="outline" className="border-white/20">
              {engineStatus === 'running' ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {engineStatus === 'running' ? 'Pause' : 'Resume'}
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2 p-3 bg-red-500/10 text-red-400 rounded-lg">
          <AlertCircle className="w-5 h-5" />
          <p className="text-sm font-medium">
            Warning: Pausing live systems will halt all trading and blockchain operations. Use with extreme caution.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}