import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Coins, 
  Zap, 
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Activity,
  Database
} from "lucide-react";
import { User, SystemSettings, Transaction } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";

export default function TokenMinter() {
  const [mintAmount, setMintAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [isMinting, setIsMinting] = useState(false);
  const [mintResult, setMintResult] = useState(null);
  const [systemStats, setSystemStats] = useState({
    totalSupply: 0,
    mintedToday: 0,
    circulatingSupply: 0
  });

  useEffect(() => {
    loadSystemStats();
  }, []);

  const loadSystemStats = async () => {
    try {
      const settings = await SystemSettings.list();
      const totalSupply = settings[0]?.total_spec_supply || 33333333333333;
      const mintedSupply = settings[0]?.minted_spec_supply || totalSupply;
      
      // Calculate minted today from transactions
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const transactions = await Transaction.filter({
        transaction_type: 'mint'
      });
      
      const mintedToday = transactions
        .filter(tx => new Date(tx.created_date) >= today)
        .reduce((sum, tx) => sum + tx.amount, 0);

      setSystemStats({
        totalSupply,
        mintedToday,
        circulatingSupply: totalSupply * 0.85 // 85% circulating
      });
    } catch (error) {
      console.error('Failed to load system stats:', error);
    }
  };

  const executeMint = async () => {
    if (!mintAmount || !recipient || parseFloat(mintAmount) <= 0) {
      alert('Please enter valid mint amount and recipient');
      return;
    }

    setIsMinting(true);
    setMintResult(null);

    try {
      const amount = parseFloat(mintAmount);
      
      // Simulate Hyperledger Fabric mint transaction
      const fabricMintResponse = await InvokeLLM({
        prompt: `Execute SPEC token mint operation on Hyperledger Fabric. Mint ${amount} SPEC tokens to recipient: ${recipient}. Generate realistic blockchain transaction details including transaction hash, block number, and confirmation.`,
        response_json_schema: {
          type: "object",
          properties: {
            success: { type: "boolean" },
            txHash: { type: "string" },
            blockNumber: { type: "number" },
            gasUsed: { type: "number" },
            mintedAmount: { type: "number" },
            newTotalSupply: { type: "number" },
            timestamp: { type: "string" },
            message: { type: "string" }
          }
        }
      });

      if (!fabricMintResponse.success) {
        throw new Error(fabricMintResponse.message || 'Blockchain mint operation failed');
      }

      // Create transaction record
      const transaction = await Transaction.create({
        transaction_hash: fabricMintResponse.txHash,
        from_address: 'SpectraFoundation',
        to_address: recipient,
        amount: amount,
        transaction_type: 'mint',
        status: 'confirmed',
        gas_fee: fabricMintResponse.gasUsed || 0.001,
        block_number: fabricMintResponse.blockNumber,
        metadata: {
          mint_operation: true,
          new_total_supply: fabricMintResponse.newTotalSupply,
          minted_by: 'admin',
          fabric_transaction: true
        }
      });

      // Update recipient balance if it's a platform user
      try {
        const users = await User.filter({ wallet_address: recipient });
        if (users.length > 0) {
          const user = users[0];
          await User.update(user.id, {
            spec_balance: (user.spec_balance || 0) + amount
          });
        }
      } catch (error) {
        console.log('Recipient not a platform user, external wallet mint');
      }

      // Update system settings
      const settings = await SystemSettings.list();
      if (settings.length > 0) {
        await SystemSettings.update(settings[0].id, {
          total_spec_supply: fabricMintResponse.newTotalSupply,
          minted_spec_supply: (settings[0].minted_spec_supply || 0) + amount
        });
      } else {
        await SystemSettings.create({
          total_spec_supply: fabricMintResponse.newTotalSupply,
          minted_spec_supply: amount
        });
      }

      setMintResult({
        success: true,
        message: `Successfully minted ${amount.toLocaleString()} SPEC tokens`,
        txHash: fabricMintResponse.txHash,
        blockNumber: fabricMintResponse.blockNumber,
        newSupply: fabricMintResponse.newTotalSupply
      });

      setMintAmount('');
      setRecipient('');
      loadSystemStats();

    } catch (error) {
      setMintResult({
        success: false,
        error: error.message || 'Minting operation failed'
      });
    } finally {
      setIsMinting(false);
    }
  };

  const formatNumber = (num) => {
    if (num >= 1e12) return (num / 1e12).toFixed(2) + 'T';
    if (num >= 1e9) return (num / 1e9).toFixed(2) + 'B';
    if (num >= 1e6) return (num / 1e6).toFixed(2) + 'M';
    if (num >= 1e3) return (num / 1e3).toFixed(2) + 'K';
    return num.toLocaleString();
  };

  return (
    <div className="space-y-6">
      {/* System Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Database className="w-8 h-8 text-blue-400" />
            <div>
              <p className="text-sm text-neutral-400">Total Supply</p>
              <p className="text-2xl font-bold text-neutral-100">
                {formatNumber(systemStats.totalSupply)}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">SPEC tokens on Hyperledger Fabric</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <Activity className="w-8 h-8 text-green-400" />
            <div>
              <p className="text-sm text-neutral-400">Circulating Supply</p>
              <p className="text-2xl font-bold text-neutral-100">
                {formatNumber(systemStats.circulatingSupply)}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">Available for trading</p>
        </div>

        <div className="glass-card rounded-xl p-6">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-8 h-8 text-purple-400" />
            <div>
              <p className="text-sm text-neutral-400">Minted Today</p>
              <p className="text-2xl font-bold text-neutral-100">
                {formatNumber(systemStats.mintedToday)}
              </p>
            </div>
          </div>
          <p className="text-xs text-neutral-500">New tokens issued</p>
        </div>
      </div>

      {/* Token Minting Interface */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-6">
          <Coins className="w-8 h-8 text-yellow-400" />
          <div>
            <h3 className="text-xl font-bold text-neutral-100">SPEC Token Minter</h3>
            <p className="text-neutral-400">Mint new SPEC tokens on Hyperledger Fabric blockchain</p>
          </div>
        </div>

        <Alert className="mb-6 bg-yellow-500/20 border-yellow-500/30">
          <AlertCircle className="w-4 h-4 text-yellow-400" />
          <AlertDescription className="text-yellow-400">
            <strong>Blockchain Operation:</strong> This will create real SPEC tokens on the Hyperledger Fabric network.
            Ensure the recipient address is valid and the amount is correct.
          </AlertDescription>
        </Alert>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label className="block text-sm text-neutral-400 mb-2">Recipient Address</label>
            <Input
              placeholder="Enter wallet address or user identifier"
              value={recipient}
              onChange={(e) => setRecipient(e.target.value)}
              className="bg-white/5 border-white/20 text-neutral-100"
            />
          </div>
          <div>
            <label className="block text-sm text-neutral-400 mb-2">Amount to Mint</label>
            <Input
              type="number"
              placeholder="Enter amount of SPEC tokens"
              value={mintAmount}
              onChange={(e) => setMintAmount(e.target.value)}
              className="bg-white/5 border-white/20 text-neutral-100"
            />
          </div>
        </div>

        <Button
          onClick={executeMint}
          disabled={isMinting || !mintAmount || !recipient}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white h-12"
        >
          {isMinting ? (
            <div className="flex items-center justify-center">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3"></div>
              Minting on Hyperledger Fabric...
            </div>
          ) : (
            <>
              <Zap className="w-5 h-5 mr-2" />
              Execute Mint Operation
            </>
          )}
        </Button>
      </div>

      {/* Mint Result */}
      {mintResult && (
        <div className="glass-card rounded-xl p-6">
          {mintResult.success ? (
            <Alert className="bg-green-500/20 border-green-500/30">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <AlertDescription className="text-green-400">
                <div className="space-y-2">
                  <div>
                    <strong>Mint Successful!</strong>
                    <p>{mintResult.message}</p>
                  </div>
                  
                  <div className="bg-green-900/20 p-3 rounded-lg mt-3">
                    <p className="text-xs font-mono mb-1">
                      <strong>Transaction Hash:</strong> {mintResult.txHash}
                    </p>
                    <p className="text-xs">
                      <strong>Block Number:</strong> {mintResult.blockNumber}
                    </p>
                    <p className="text-xs">
                      <strong>New Total Supply:</strong> {mintResult.newSupply?.toLocaleString()} SPEC
                    </p>
                  </div>
                </div>
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="bg-red-500/20 border-red-500/30">
              <AlertCircle className="w-4 h-4 text-red-400" />
              <AlertDescription className="text-red-400">
                <strong>Mint Failed:</strong> {mintResult.error}
              </AlertDescription>
            </Alert>
          )}
        </div>
      )}

      {/* Recent Mint Operations */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">Recent Mint Operations</h4>
        <div className="text-center py-8 text-neutral-400">
          <Coins className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>Recent mint operations will appear here</p>
          <p className="text-sm">All operations are recorded on the blockchain</p>
        </div>
      </div>
    </div>
  );
}