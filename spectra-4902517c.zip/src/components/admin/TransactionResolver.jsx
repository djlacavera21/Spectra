import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Textarea } from '@/components/ui/textarea';
import { 
  Search, 
  AlertTriangle, 
  CheckCircle, 
  Wallet, 
  RefreshCw,
  Eye,
  DollarSign,
  Clock,
  User,
  ArrowRight,
  Shield,
  Zap
} from 'lucide-react';
import { Transaction, User as UserEntity, AuditLog } from '@/api/entities';
import { format } from 'date-fns';

export default function TransactionResolver() {
  const [searchHash, setSearchHash] = useState('0x94769d5b1d133db97bb33a21e959d0edb74d851546875525327b159483228d6d');
  const [transaction, setTransaction] = useState(null);
  const [recipient, setRecipient] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [isResolving, setIsResolving] = useState(false);

  const handleSearchTransaction = async () => {
    if (!searchHash.trim()) return;
    
    setIsLoading(true);
    try {
      // Find transaction by hash
      const transactions = await Transaction.filter({}, '', 1000);
      const foundTx = transactions.find(tx => 
        tx.transaction_hash?.toLowerCase() === searchHash.toLowerCase()
      );
      
      if (foundTx) {
        setTransaction(foundTx);
        
        // Find recipient user
        const users = await UserEntity.list();
        const recipientUser = users.find(user => 
          user.wallet_address === foundTx.to_address ||
          user.secondary_wallet_address === foundTx.to_address
        );
        
        setRecipient(recipientUser);
      } else {
        setTransaction(null);
        setRecipient(null);
        alert('Transaction not found in database');
      }
    } catch (error) {
      console.error('Error searching transaction:', error);
      alert('Error searching for transaction');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResolveTransaction = async () => {
    if (!transaction || !recipient) return;
    
    setIsResolving(true);
    try {
      // Update recipient's balance
      const currentBalance = recipient.spec_balance || 0;
      const newBalance = currentBalance + transaction.amount;
      
      await UserEntity.update(recipient.id, {
        spec_balance: newBalance
      });
      
      // Update transaction status to confirmed
      await Transaction.update(transaction.id, {
        status: 'confirmed'
      });
      
      // Create audit log entry
      await AuditLog.create({
        user_wallet: recipient.wallet_address,
        event_type: 'admin_action',
        event_description: `Admin resolved pending transaction ${transaction.transaction_hash} - credited ${transaction.amount} SPEC to wallet`,
        amount_usd: transaction.amount,
        transaction_hash: transaction.transaction_hash,
        admin_user: 'system_admin',
        metadata: {
          resolution_notes: resolutionNotes,
          previous_balance: currentBalance,
          new_balance: newBalance,
          transaction_id: transaction.id
        }
      });
      
      alert(`✅ Transaction resolved successfully!\n\nCredited ${transaction.amount} SPEC to ${recipient.full_name}'s wallet.\nNew balance: ${newBalance.toLocaleString()} SPEC`);
      
      // Refresh the transaction data
      handleSearchTransaction();
      setResolutionNotes('');
      
    } catch (error) {
      console.error('Error resolving transaction:', error);
      alert('❌ Failed to resolve transaction. Please try again.');
    } finally {
      setIsResolving(false);
    }
  };

  const calculateBalanceDiscrepancy = () => {
    if (!transaction || !recipient) return null;
    
    // Check if transaction amount is reflected in wallet balance
    const expectedBalance = (recipient.spec_balance || 0) + transaction.amount;
    return {
      currentBalance: recipient.spec_balance || 0,
      transactionAmount: transaction.amount,
      expectedBalance: expectedBalance,
      discrepancy: transaction.amount
    };
  };

  useEffect(() => {
    // Auto-search on component mount
    handleSearchTransaction();
  }, []);

  return (
    <div className="space-y-6">
      {/* Search Section */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="w-5 h-5 text-blue-400" />
            Transaction Resolution System
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Transaction Hash</Label>
            <div className="flex gap-3">
              <Input
                value={searchHash}
                onChange={(e) => setSearchHash(e.target.value)}
                placeholder="Enter transaction hash..."
                className="bg-white/5 border-white/20"
              />
              <Button 
                onClick={handleSearchTransaction}
                disabled={isLoading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
                Search
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transaction Details */}
      {transaction && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5 text-green-400" />
              Transaction Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div>
                  <Label className="text-neutral-400">Transaction Hash</Label>
                  <p className="font-mono text-sm bg-neutral-800 p-2 rounded">{transaction.transaction_hash}</p>
                </div>
                <div>
                  <Label className="text-neutral-400">Amount</Label>
                  <p className="text-2xl font-bold text-green-400">{transaction.amount.toLocaleString()} SPEC</p>
                </div>
                <div>
                  <Label className="text-neutral-400">Status</Label>
                  <Badge className={
                    transaction.status === 'confirmed' ? 'bg-green-500/20 text-green-400' : 
                    transaction.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }>
                    {transaction.status?.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-neutral-400">From Address</Label>
                  <p className="font-mono text-sm text-neutral-300">{transaction.from_address}</p>
                </div>
                <div>
                  <Label className="text-neutral-400">To Address</Label>
                  <p className="font-mono text-sm text-neutral-300">{transaction.to_address}</p>
                </div>
                <div>
                  <Label className="text-neutral-400">Created Date</Label>
                  <p className="text-sm">{format(new Date(transaction.created_date), 'PPpp')}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recipient Details */}
      {recipient && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5 text-purple-400" />
              Recipient Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <div>
                  <Label className="text-neutral-400">Name</Label>
                  <p className="text-lg font-semibold">{recipient.full_name}</p>
                </div>
                <div>
                  <Label className="text-neutral-400">Email</Label>
                  <p className="text-neutral-300">{recipient.email}</p>
                </div>
              </div>
              
              <div className="space-y-3">
                <div>
                  <Label className="text-neutral-400">Current SPEC Balance</Label>
                  <p className="text-2xl font-bold text-blue-400">{(recipient.spec_balance || 0).toLocaleString()} SPEC</p>
                </div>
                <div>
                  <Label className="text-neutral-400">Wallet Address</Label>
                  <p className="font-mono text-sm text-neutral-300">{recipient.wallet_address}</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Balance Analysis */}
      {transaction && recipient && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-400" />
              Balance Discrepancy Analysis
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const analysis = calculateBalanceDiscrepancy();
              return (
                <Alert className="bg-yellow-500/20 border-yellow-500/30">
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                  <AlertTitle className="text-yellow-400">Transaction Not Reflected in Wallet Balance</AlertTitle>
                  <AlertDescription className="text-yellow-300 space-y-2">
                    <p>Current wallet balance: <strong>{analysis.currentBalance.toLocaleString()} SPEC</strong></p>
                    <p>Transaction amount: <strong>+{analysis.transactionAmount.toLocaleString()} SPEC</strong></p>
                    <p>Expected balance after transaction: <strong>{analysis.expectedBalance.toLocaleString()} SPEC</strong></p>
                    <p className="text-red-300">⚠️ Discrepancy: <strong>{analysis.discrepancy.toLocaleString()} SPEC</strong> not credited to wallet</p>
                  </AlertDescription>
                </Alert>
              );
            })()}
          </CardContent>
        </Card>
      )}

      {/* Resolution Action */}
      {transaction && recipient && transaction.status !== 'confirmed' && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="w-5 h-5 text-green-400" />
              Resolve Transaction
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Resolution Notes (Required)</Label>
              <Textarea
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                placeholder="Enter details about the resolution (e.g. 'Manual balance credit due to network delay', 'Transaction stuck in mempool - admin override', etc.)"
                className="bg-white/5 border-white/20"
                rows={3}
              />
            </div>
            
            <Alert className="bg-green-500/20 border-green-500/30">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <AlertTitle className="text-green-400">Resolution Action</AlertTitle>
              <AlertDescription className="text-green-300">
                <p>This will:</p>
                <ul className="list-disc list-inside mt-2 space-y-1">
                  <li>Credit <strong>{transaction.amount.toLocaleString()} SPEC</strong> to {recipient.full_name}'s wallet</li>
                  <li>Update transaction status to "confirmed"</li>
                  <li>Create an audit log entry for compliance</li>
                  <li>Send notification to the user</li>
                </ul>
              </AlertDescription>
            </Alert>
            
            <Button
              onClick={handleResolveTransaction}
              disabled={isResolving || !resolutionNotes.trim()}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {isResolving ? (
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <Zap className="w-4 h-4 mr-2" />
              )}
              Resolve Transaction & Credit Balance
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Success State */}
      {transaction && transaction.status === 'confirmed' && (
        <Alert className="bg-green-500/20 border-green-500/30">
          <CheckCircle className="w-4 h-4 text-green-400" />
          <AlertTitle className="text-green-400">Transaction Already Resolved</AlertTitle>
          <AlertDescription className="text-green-300">
            This transaction has been confirmed and the balance should be reflected in the recipient's wallet.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}