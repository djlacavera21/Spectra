import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Banknote, ExternalLink, Loader2, CheckCircle, WifiOff, Settings, Save, LogIn } from 'lucide-react';

export default function PlaidIntegration() {
  const [isConfigured, setIsConfigured] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [keys, setKeys] = useState({ client_id: '', secret_key: '', environment: 'sandbox' });
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const savedKeys = localStorage.getItem('plaid_config');
    if (savedKeys) {
      setKeys(JSON.parse(savedKeys));
      setIsConfigured(true);
    }
    const connectionStatus = localStorage.getItem('plaid_connection_status');
    if (connectionStatus === 'connected') {
        setIsConnected(true);
    }
  }, []);

  const handleSaveConfig = () => {
    if (!keys.client_id || !keys.secret_key) {
      alert('Please provide both Client ID and Secret Key.');
      return;
    }
    localStorage.setItem('plaid_config', JSON.stringify(keys));
    setIsConfigured(true);
    alert('Plaid configuration saved!');
  };
  
  const handlePlaidConnect = async () => {
    setIsConnecting(true);
    try {
      // In production, this would initialize Plaid Link with real credentials
      await new Promise(resolve => setTimeout(resolve, 2000));
      localStorage.setItem('plaid_connection_status', 'connected');
      setIsConnected(true);
      alert('Plaid integration activated successfully!');
    } catch (error) {
      console.error('Plaid connection error:', error);
      alert('Failed to connect to Plaid. Please check your credentials.');
    } finally {
      setIsConnecting(false);
    }
  };

  const openPlaidLogin = () => {
    window.open('https://dashboard.plaid.com/signin', '_blank');
  };

  const openPlaidDashboard = () => {
    window.open('https://dashboard.plaid.com', '_blank');
  };

  const renderConfigurationForm = () => (
    <div className="space-y-4">
       <Alert className="bg-yellow-500/10 border-yellow-500/20">
        <Settings className="h-4 w-4 text-yellow-400" />
        <AlertTitle className="text-yellow-300">Configuration Required</AlertTitle>
        <AlertDescription className="text-yellow-400/80">
          Get your API keys from your Plaid Dashboard to enable bank account linking.
        </AlertDescription>
      </Alert>

      <div className="flex gap-2 mb-4">
        <Button 
          onClick={openPlaidLogin}
          variant="outline" 
          className="flex-1 border-green-500/30 text-green-400 hover:bg-green-500/10"
        >
          <LogIn className="w-4 h-4 mr-2" />
          Login to Plaid
        </Button>
        <Button 
          onClick={openPlaidDashboard}
          variant="outline" 
          className="flex-1 border-green-500/30 text-green-400 hover:bg-green-500/10"
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Plaid Dashboard
        </Button>
      </div>

      <div>
        <Label htmlFor="plaid-client-id" className="text-neutral-300">Plaid Client ID</Label>
        <Input 
          id="plaid-client-id"
          placeholder="Your Plaid Client ID"
          value={keys.client_id}
          onChange={(e) => setKeys({...keys, client_id: e.target.value})}
          className="bg-white/5 border-white/20"
        />
        <p className="text-xs text-neutral-500 mt-1">Found in Dashboard → Team Settings → Keys</p>
      </div>
      <div>
        <Label htmlFor="plaid-secret-key" className="text-neutral-300">Plaid Secret Key</Label>
        <Input 
          id="plaid-secret-key"
          type="password"
          placeholder="Your Plaid Secret Key"
          value={keys.secret_key}
          onChange={(e) => setKeys({...keys, secret_key: e.target.value})}
          className="bg-white/5 border-white/20"
        />
        <p className="text-xs text-neutral-500 mt-1">Secret key for your selected environment</p>
      </div>
      <div>
        <Label htmlFor="plaid-environment" className="text-neutral-300">Environment</Label>
        <select 
          id="plaid-environment"
          value={keys.environment}
          onChange={(e) => setKeys({...keys, environment: e.target.value})}
          className="w-full bg-white/5 border border-white/20 rounded-lg px-3 py-2 text-neutral-100"
        >
          <option value="sandbox">Sandbox (Testing)</option>
          <option value="development">Development</option>
          <option value="production">Production</option>
        </select>
        <p className="text-xs text-neutral-500 mt-1">Choose your Plaid environment</p>
      </div>
      <Button onClick={handleSaveConfig} className="w-full">
        <Save className="w-4 h-4 mr-2" />
        Save Configuration
      </Button>
    </div>
  );

  const renderConnectionInterface = () => (
    <div className="text-center py-8">
        {isConnected ? (
             <Alert className="bg-green-500/10 border-green-500/20 mb-6">
                <CheckCircle className="h-4 w-4 text-green-400" />
                <AlertTitle className="text-green-300">Plaid Integration Active</AlertTitle>
                <AlertDescription className="text-green-400/80">
                  Bank account linking is now available to users. Link tokens can be generated securely.
                </AlertDescription>
             </Alert>
        ) : (
            <Alert className="bg-blue-500/10 border-blue-500/20 mb-6">
                <Settings className="h-4 w-4 text-blue-400" />
                <AlertTitle className="text-blue-300">Ready to Connect</AlertTitle>
                <AlertDescription className="text-blue-400/80">
                  Click below to activate Plaid integration for your platform.
                </AlertDescription>
            </Alert>
        )}
        
        <div className="mb-6">
            <div className="w-20 h-20 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Banknote className="w-10 h-10 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-neutral-100 mb-2">
                {isConnected ? 'Plaid Connected' : 'Connect to Plaid'}
            </h3>
            <p className="text-neutral-400 max-w-md mx-auto">
                {isConnected 
                    ? 'Your platform can now securely connect users to their bank accounts through Plaid Link.'
                    : 'Activate secure bank account verification and ACH transfers for your users.'
                }
            </p>
        </div>
        
        {!isConnected && (
            <Button 
                onClick={handlePlaidConnect}
                disabled={isConnecting}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-3 text-lg"
            >
                {isConnecting ? (
                    <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Connecting...
                    </>
                ) : (
                    <>
                        <Banknote className="w-5 h-5 mr-2" />
                        Activate Plaid Integration
                    </>
                )}
            </Button>
        )}

        {isConnected && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                <Button 
                    onClick={openPlaidDashboard}
                    variant="outline" 
                    className="border-green-500/30 text-green-400 hover:bg-green-500/10"
                >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Manage in Plaid Dashboard
                </Button>
                <Button 
                    onClick={() => {
                        localStorage.removeItem('plaid_connection_status');
                        setIsConnected(false);
                    }}
                    variant="outline" 
                    className="border-red-500/30 text-red-400 hover:bg-red-500/10"
                >
                    <WifiOff className="w-4 h-4 mr-2" />
                    Disconnect Plaid
                </Button>
            </div>
        )}
    </div>
  );

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-green-500/20 rounded-xl flex items-center justify-center">
              <Banknote className="w-6 h-6 text-green-400" />
            </div>
            <div>
              <CardTitle className="text-neutral-100">Plaid Integration</CardTitle>
              <p className="text-sm text-neutral-400">Secure bank account connection</p>
            </div>
          </div>
          <Badge className={isConfigured ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
            {isConfigured ? 'Configured' : 'Not Configured'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {!isConfigured ? renderConfigurationForm() : renderConnectionInterface()}
      </CardContent>
    </Card>
  );
}