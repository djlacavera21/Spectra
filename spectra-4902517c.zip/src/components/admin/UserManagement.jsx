
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Users, 
  Search, 
  Lock, 
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Edit,
  Copy,
  CheckCircle,
  RefreshCw, // Added for regeneration button
  Loader2 // Added for loading spinner
} from 'lucide-react';
import { User } from '@/api/entities';
import { generateSpecAddress } from '@/components/common/WalletUtils'; // Corrected import path
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [copiedAddress, setCopiedAddress] = useState('');
  const [isMigrating, setIsMigrating] = useState(false); // New state for migration process

  useEffect(() => {
    loadUsers();
  }, []);

  useEffect(() => {
    const filtered = users.filter(user =>
      user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.wallet_address && user.wallet_address.toLowerCase().includes(searchTerm.toLowerCase()))
    );
    setFilteredUsers(filtered);
  }, [searchTerm, users]);

  const loadUsers = async () => {
    setIsLoading(true);
    try {
      const allUsers = await User.list('-created_date');
      setUsers(allUsers);
    } catch (error) {
      console.error("Error loading users:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegenerateAllWallets = async () => {
    if (!window.confirm("This will regenerate SPEC wallets for ALL users to the new standard. This action cannot be undone. Are you sure you want to proceed?")) {
      return;
    }
    
    setIsMigrating(true);
    try {
      const allUsers = await User.list();
      const updatePromises = allUsers.map(user => {
        const newPrimaryAddress = generateSpecAddress();
        const newSecondaryAddress = generateSpecAddress(); // Assuming a secondary address is also generated based on the new standard
        return User.update(user.id, {
          wallet_address: newPrimaryAddress,
          secondary_wallet_address: newSecondaryAddress // Update this field as well if applicable
        });
      });
      
      await Promise.all(updatePromises);
      
      alert(`Successfully migrated ${allUsers.length} users to the new SPEC address standard.`);
      await loadUsers(); // Refresh the user list to show new addresses
    } catch (error) {
      console.error("Error regenerating all user wallets:", error);
      alert("An error occurred during the wallet migration.");
    } finally {
      setIsMigrating(false);
    }
  };

  const copyWalletAddress = (address, userName) => {
    if (!address) {
      alert('No wallet address available for this user');
      return;
    }
    
    navigator.clipboard.writeText(address).then(() => {
      setCopiedAddress(address);
      // Show success feedback
      setTimeout(() => setCopiedAddress(''), 2000);
    }).catch(err => {
      console.error('Failed to copy address:', err);
      alert('Failed to copy wallet address');
    });
  };

  const toggleUserLock = async (user) => {
    try {
      await User.update(user.id, { account_locked: !user.account_locked });
      alert(`User account ${user.account_locked ? 'unlocked' : 'locked'}.`);
      loadUsers();
    } catch (error) {
      console.error("Error toggling user lock:", error);
      alert('Failed to update user lock status.');
    }
  };

  const changeUserRole = async (userId, newRole) => {
    try {
      await User.update(userId, { special_role: newRole });
      alert(`User role updated to ${newRole}.`);
      loadUsers();
    } catch (error) {
      console.error("Error changing user role:", error);
      alert('Failed to change user role.');
    }
  };
  
  const getKycBadge = (user) => {
    if (user.kyc_verified) {
      return <Badge className="bg-green-500/20 text-green-400">Verified</Badge>;
    }
    return <Badge className="bg-yellow-500/20 text-yellow-400">Pending</Badge>;
  };

  const formatAddress = (address) => {
    if (!address) return 'Not Generated';
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Users className="w-6 h-6 text-blue-400" />
            <CardTitle>User Management</CardTitle>
          </div>
          <div className="flex items-center gap-4">
            <Button
              onClick={handleRegenerateAllWallets}
              disabled={isMigrating}
              variant="destructive"
              className="bg-red-800 hover:bg-red-700"
            >
              {isMigrating ? (
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4 mr-2" />
              )}
              Regenerate All SPEC Wallets
            </Button>
            <div className="w-64 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
              <Input 
                placeholder="Search users..."
                className="pl-10 bg-white/5 border-white/20"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-b-white/10">
                <TableHead className="text-white">User</TableHead>
                <TableHead className="text-white">Wallet Address</TableHead>
                <TableHead className="text-white">Multi-Chain Wallets</TableHead>
                <TableHead className="text-white">Role</TableHead>
                <TableHead className="text-white">KYC</TableHead>
                <TableHead className="text-white">Status</TableHead>
                <TableHead className="text-white text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">Loading users...</TableCell>
                </TableRow>
              ) : (
                filteredUsers.map(user => (
                  <TableRow key={user.id} className="border-b-white/10">
                    <TableCell>
                      <div className="font-medium text-neutral-200">{user.full_name}</div>
                      <div className="text-sm text-neutral-400">{user.email}</div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm text-neutral-300">
                          {formatAddress(user.wallet_address)}
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => copyWalletAddress(user.wallet_address, user.full_name)}
                          className="h-6 w-6 text-neutral-400 hover:text-neutral-100 hover:bg-white/10"
                          title="Copy wallet address"
                        >
                          {copiedAddress === user.wallet_address ? (
                            <CheckCircle className="w-3 h-3 text-green-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        {user.eth_wallet_address && (
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-neutral-400">ETH:</span>
                            <span className="font-mono text-neutral-300">{formatAddress(user.eth_wallet_address)}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => copyWalletAddress(user.eth_wallet_address, `${user.full_name} (ETH)`)}
                              className="h-4 w-4 text-neutral-400 hover:text-neutral-100"
                            >
                              {copiedAddress === user.eth_wallet_address ? (
                                <CheckCircle className="w-2 h-2 text-green-400" />
                              ) : (
                                <Copy className="w-2 h-2" />
                              )}
                            </Button>
                          </div>
                        )}
                        {user.btc_wallet_address && (
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-neutral-400">BTC:</span>
                            <span className="font-mono text-neutral-300">{formatAddress(user.btc_wallet_address)}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => copyWalletAddress(user.btc_wallet_address, `${user.full_name} (BTC)`)}
                              className="h-4 w-4 text-neutral-400 hover:text-neutral-100"
                            >
                              {copiedAddress === user.btc_wallet_address ? (
                                <CheckCircle className="w-2 h-2 text-green-400" />
                              ) : (
                                <Copy className="w-2 h-2" />
                              )}
                            </Button>
                          </div>
                        )}
                        {user.sol_wallet_address && (
                          <div className="flex items-center gap-2 text-xs">
                            <span className="text-neutral-400">SOL:</span>
                            <span className="font-mono text-neutral-300">{formatAddress(user.sol_wallet_address)}</span>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => copyWalletAddress(user.sol_wallet_address, `${user.full_name} (SOL)`)}
                              className="h-4 w-4 text-neutral-400 hover:text-neutral-100"
                            >
                              {copiedAddress === user.sol_wallet_address ? (
                                <CheckCircle className="w-2 h-2 text-green-400" />
                              ) : (
                                <Copy className="w-2 h-2" />
                              )}
                            </Button>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize border-white/20 text-neutral-300">
                        {user.special_role}
                      </Badge>
                    </TableCell>
                    <TableCell>{getKycBadge(user)}</TableCell>
                    <TableCell>
                      {user.account_locked ? 
                        <Badge className="bg-red-500/20 text-red-400">Locked</Badge> : 
                        <Badge className="bg-green-500/20 text-green-400">Active</Badge>
                      }
                    </TableCell>
                    <TableCell className="text-right">
                       <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent className="glass-effect border-white/10 text-neutral-200">
                          <DropdownMenuItem onSelect={() => toggleUserLock(user)}>
                            {user.account_locked ? <Unlock className="w-4 h-4 mr-2" /> : <Lock className="w-4 h-4 mr-2" />}
                            {user.account_locked ? 'Unlock Account' : 'Lock Account'}
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => changeUserRole(user.id, 'admin')}>
                            <ShieldCheck className="w-4 h-4 mr-2" />
                            Make Admin
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => changeUserRole(user.id, 'treasurer')}>
                             <ShieldCheck className="w-4 h-4 mr-2" />
                            Make Treasurer
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => changeUserRole(user.id, 'user')}>
                            <Users className="w-4 h-4 mr-2" />
                            Make User
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
        
        {copiedAddress && (
          <div className="mt-4 p-3 bg-green-500/20 border border-green-500/30 rounded-lg">
            <div className="flex items-center gap-2 text-green-400 text-sm">
              <CheckCircle className="w-4 h-4" />
              Wallet address copied to clipboard!
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
