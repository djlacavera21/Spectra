import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Bell, Plus, Trash2 } from 'lucide-react';
// Assuming a "Notice" entity exists for storing platform-wide notices
// For now, we'll manage this in local state
// import { Notice } from '@/api/entities/Notice';

export default function SystemNotices() {
  const [notices, setNotices] = useState([]);
  const [newNotice, setNewNotice] = useState({ title: '', content: '' });

  // In a real app, this would load from the Notice entity
  useEffect(() => {
    // setNotices(await Notice.list());
  }, []);

  const handleCreateNotice = () => {
    if (!newNotice.title || !newNotice.content) {
      alert("Title and content are required.");
      return;
    }
    const notice = { ...newNotice, id: Date.now(), createdAt: new Date() };
    setNotices(prev => [notice, ...prev]);
    // await Notice.create(notice);
    setNewNotice({ title: '', content: '' });
    alert("Notice published successfully.");
  };

  const handleDeleteNotice = (id) => {
    setNotices(prev => prev.filter(n => n.id !== id));
    // await Notice.delete(id);
    alert("Notice deleted.");
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center gap-3">
          <Bell className="w-6 h-6 text-yellow-400" />
          <CardTitle>System Notices</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="glass-effect rounded-lg p-4 space-y-4">
          <h3 className="font-semibold text-neutral-100">Create New Notice</h3>
          <Input 
            placeholder="Notice Title"
            value={newNotice.title}
            onChange={(e) => setNewNotice(prev => ({...prev, title: e.target.value}))}
            className="bg-white/5 border-white/20"
          />
          <Textarea 
            placeholder="Notice Content..."
            value={newNotice.content}
            onChange={(e) => setNewNotice(prev => ({...prev, content: e.target.value}))}
            className="bg-white/5 border-white/20 h-24"
          />
          <Button onClick={handleCreateNotice}>
            <Plus className="w-4 h-4 mr-2" />
            Publish Notice
          </Button>
        </div>

        <div className="space-y-4">
          <h3 className="font-semibold text-neutral-100">Published Notices</h3>
          {notices.length > 0 ? (
            notices.map(notice => (
              <div key={notice.id} className="glass-effect rounded-lg p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-bold text-neutral-100">{notice.title}</h4>
                    <p className="text-sm text-neutral-300 mt-2">{notice.content}</p>
                    <p className="text-xs text-neutral-500 mt-3">
                      Published on {new Date(notice.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <Button onClick={() => handleDeleteNotice(notice.id)} variant="destructive" size="icon">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-neutral-400 py-4">No active system notices.</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}