import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Gavel, 
  Shield, 
  AlertTriangle,
  CheckCircle,
  Search,
  FileText,
  Users,
  Activity
} from 'lucide-react';
import { User, ComplianceRecord, AuditLog } from '@/api/entities';

const ComplianceCenterComponent = () => {
  const [users, setUsers] = useState([]);
  const [complianceRecords, setComplianceRecords] = useState([]);
  const [auditLogs, setAuditLogs] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadComplianceData();
  }, []);

  const loadComplianceData = async () => {
    try {
      const [allUsers, allRecords, allLogs] = await Promise.all([
        User.list('-created_date', 100),
        ComplianceRecord.list('-created_date', 50),
        AuditLog.list('-created_date', 100)
      ]);

      setUsers(allUsers);
      setComplianceRecords(allRecords);
      setAuditLogs(allLogs);
    } catch (error) {
      console.error('Error loading compliance data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getComplianceStats = () => {
    const totalUsers = users.length;
    const kycVerified = users.filter(u => u.kyc_verified).length;
    const flaggedUsers = complianceRecords.filter(r => r.aml_risk_score > 75).length;
    const recentAlerts = auditLogs.filter(log => 
      log.compliance_flag && 
      new Date(log.created_date) > new Date(Date.now() - 24 * 60 * 60 * 1000)
    ).length;

    return { totalUsers, kycVerified, flaggedUsers, recentAlerts };
  };

  const stats = getComplianceStats();

  const getKycStatusBadge = (user) => {
    if (user.kyc_verified) {
      return <Badge className="bg-green-500/20 text-green-400">Verified</Badge>;
    }
    return <Badge className="bg-yellow-500/20 text-yellow-400">Pending</Badge>;
  };

  const getRiskBadge = (score) => {
    if (score < 25) return <Badge className="bg-green-500/20 text-green-400">Low Risk</Badge>;
    if (score < 75) return <Badge className="bg-yellow-500/20 text-yellow-400">Medium Risk</Badge>;
    return <Badge className="bg-red-500/20 text-red-400">High Risk</Badge>;
  };

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardContent className="pt-6 text-center">Loading compliance data...</CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-neutral-100">
            <Gavel className="w-6 h-6 text-purple-400" />
            Compliance & Risk Management
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Compliance Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-sm text-neutral-400">Total Users</p>
                <p className="text-2xl font-bold text-neutral-100">{stats.totalUsers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-400" />
              <div>
                <p className="text-sm text-neutral-400">KYC Verified</p>
                <p className="text-2xl font-bold text-neutral-100">{stats.kycVerified}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-sm text-neutral-400">Flagged Users</p>
                <p className="text-2xl font-bold text-neutral-100">{stats.flaggedUsers}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Activity className="w-8 h-8 text-yellow-400" />
              <div>
                <p className="text-sm text-neutral-400">Alerts (24h)</p>
                <p className="text-2xl font-bold text-neutral-100">{stats.recentAlerts}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Compliance Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass-effect">
          <TabsTrigger value="overview" className="text-neutral-300 data-[state=active]:text-white">
            Overview
          </TabsTrigger>
          <TabsTrigger value="users" className="text-neutral-300 data-[state=active]:text-white">
            User Compliance
          </TabsTrigger>
          <TabsTrigger value="audit" className="text-neutral-300 data-[state=active]:text-white">
            Audit Logs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100">Compliance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center p-4 glass-effect rounded-lg">
                  <div>
                    <h4 className="font-semibold text-neutral-100">KYC Verification Rate</h4>
                    <p className="text-sm text-neutral-400">Percentage of verified users</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-green-400">
                      {stats.totalUsers > 0 ? Math.round((stats.kycVerified / stats.totalUsers) * 100) : 0}%
                    </p>
                  </div>
                </div>

                <div className="flex justify-between items-center p-4 glass-effect rounded-lg">
                  <div>
                    <h4 className="font-semibold text-neutral-100">Risk Assessment</h4>
                    <p className="text-sm text-neutral-400">High-risk users requiring review</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-red-400">{stats.flaggedUsers}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="mt-6">
          <Card className="glass-card">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-neutral-100">User Compliance Status</CardTitle>
                <div className="flex gap-3">
                  <Input
                    placeholder="Search users..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-white/5 border-white/20 w-64"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {users
                  .filter(user => 
                    user.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    user.email.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                  .slice(0, 20)
                  .map(user => (
                    <div key={user.id} className="flex items-center justify-between p-4 glass-effect rounded-lg">
                      <div>
                        <h4 className="font-medium text-neutral-200">{user.full_name}</h4>
                        <p className="text-sm text-neutral-400">{user.email}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        {getKycStatusBadge(user)}
                        <Badge variant="outline" className="border-white/20 text-neutral-300">
                          {user.special_role || 'User'}
                        </Badge>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audit" className="mt-6">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="text-neutral-100">Recent Audit Events</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {auditLogs.slice(0, 15).map(log => (
                  <div key={log.id} className="flex items-center justify-between p-4 glass-effect rounded-lg">
                    <div>
                      <h4 className="font-medium text-neutral-200 capitalize">
                        {log.event_type.replace(/_/g, ' ')}
                      </h4>
                      <p className="text-sm text-neutral-400">{log.event_description}</p>
                      <p className="text-xs text-neutral-500">
                        {new Date(log.created_date).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {log.compliance_flag && (
                        <Badge className="bg-red-500/20 text-red-400">Flagged</Badge>
                      )}
                      {log.risk_score > 0 && (
                        getRiskBadge(log.risk_score)
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComplianceCenterComponent;