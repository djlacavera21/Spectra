import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Settings, Save, Percent, Zap, TrendingUp, AlertTriangle } from 'lucide-react';
import { SystemSettings } from '@/api/entities';

export default function SystemConfiguration() {
  const [settings, setSettings] = useState(null);
  const [initialSettings, setInitialSettings] = useState(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const systemSettings = await SystemSettings.list();
      if (systemSettings.length > 0) {
        setSettings(systemSettings[0]);
        setInitialSettings(systemSettings[0]);
      } else {
        // Create default settings if none exist
        const defaultSettings = await SystemSettings.create({});
        setSettings(defaultSettings);
        setInitialSettings(defaultSettings);
      }
    } catch (error) {
      console.error("Error loading system settings:", error);
    }
  };

  const handleSettingChange = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  const handleSaveSettings = async () => {
    setIsSaving(true);
    try {
      if (!settings.id) throw new Error("Settings not initialized.");
      
      const updates = {};
      for (const key in settings) {
        if (settings[key] !== initialSettings[key]) {
          updates[key] = settings[key];
        }
      }

      if (Object.keys(updates).length > 0) {
        await SystemSettings.update(settings.id, updates);
        alert("System settings updated successfully!");
        setInitialSettings(settings); // Update baseline
      } else {
        alert("No changes to save.");
      }
    } catch (error) {
      console.error("Error saving system settings:", error);
      alert("Failed to save settings.");
    } finally {
      setIsSaving(false);
    }
  };

  if (!settings) {
    return (
      <Card className="glass-card">
        <CardContent className="pt-6 text-center">Loading settings...</CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Settings className="w-6 h-6 text-purple-400" />
            <CardTitle>System Configuration</CardTitle>
          </div>
          <Button onClick={handleSaveSettings} disabled={isSaving}>
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? 'Saving...' : 'Save Changes'}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-neutral-100">Fees & Rates</h3>
              <div className="glass-effect p-4 rounded-lg space-y-4">
                <div>
                  <Label htmlFor="platformFee" className="flex items-center gap-2 mb-2 text-neutral-300">
                    <Percent className="w-4 h-4" /> Platform Fee (%)
                  </Label>
                  <Input 
                    id="platformFee"
                    type="number"
                    value={settings.platform_fee_percentage}
                    onChange={(e) => handleSettingChange('platform_fee_percentage', parseFloat(e.target.value))}
                    className="bg-white/5 border-white/20"
                  />
                </div>
                <div>
                  <Label htmlFor="gasPrice" className="flex items-center gap-2 mb-2 text-neutral-300">
                    <Zap className="w-4 h-4" /> Gas Price (SPEC)
                  </Label>
                  <Input 
                    id="gasPrice"
                    type="number"
                    value={settings.gas_price_spec}
                    onChange={(e) => handleSettingChange('gas_price_spec', parseFloat(e.target.value))}
                    className="bg-white/5 border-white/20"
                  />
                </div>
                <div>
                  <Label htmlFor="stakingRate" className="flex items-center gap-2 mb-2 text-neutral-300">
                    <TrendingUp className="w-4 h-4" /> Staking APY (%)
                  </Label>
                  <Input 
                    id="stakingRate"
                    type="number"
                    value={settings.staking_reward_rate}
                    onChange={(e) => handleSettingChange('staking_reward_rate', parseFloat(e.target.value))}
                    className="bg-white/5 border-white/20"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-neutral-100">Platform Status</h3>
              <div className="glass-effect p-4 rounded-lg space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="maintenanceMode" className="text-neutral-300">
                    Maintenance Mode
                  </Label>
                  <Switch 
                    id="maintenanceMode"
                    checked={settings.maintenance_mode}
                    onCheckedChange={(checked) => handleSettingChange('maintenance_mode', checked)}
                  />
                </div>
                {settings.maintenance_mode && (
                  <Alert className="bg-orange-500/20 border-orange-500/30">
                    <AlertTriangle className="w-4 h-4 text-orange-400" />
                    <AlertTitle className="text-orange-400">Maintenance Mode Active</AlertTitle>
                    <AlertDescription className="text-orange-400/80">
                      The platform is currently offline for public users. Only admins can access the system.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}