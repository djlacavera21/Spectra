import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Lock, Unlock, Send } from 'lucide-react';
import { VaultMovement } from '@/api/entities';
import { useSignature } from '../common/SignatureContext';

const VaultControls = ({ vaultStatus, onStatusChange }) => {
  const { requestSignature } = useSignature();
  const [amount, setAmount] = useState('');
  const [movementType, setMovementType] = useState('');

  const handleInitiateMovement = () => {
    if (!amount || !movementType || parseFloat(amount) <= 0) {
      alert('Please select a movement type and enter a valid amount.');
      return;
    }
    
    const details = {
      action: 'Initiate Vault Movement',
      from: movementType.split('_to_')[0],
      to: movementType.split('_to_')[1],
      amount: parseFloat(amount),
      asset: 'SPEC',
    };
    
    requestSignature(details, async () => {
      await VaultMovement.create({
        movement_type: movementType,
        asset: 'SPEC',
        amount: parseFloat(amount),
        initiated_by: 'treasurer@spectra.io',
        status: 'pending_approval'
      });
      alert('Movement initiated and is now pending multi-sig approval.');
      setAmount('');
      setMovementType('');
    }, () => {
      alert('Signature rejected. Movement cancelled.');
    });
  };

  const toggleVaultLock = () => {
    const isLocking = vaultStatus.multiSigActive;
    const action = isLocking ? 'Lock Master Vault' : 'Unlock Master Vault';

    requestSignature({ action }, () => {
      onStatusChange(prev => ({...prev, multiSigActive: !isLocking}));
      alert(`Vault has been ${isLocking ? 'locked' : 'unlocked'}.`);
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" /> Initiate Fund Movement
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Select onValueChange={setMovementType} value={movementType}>
            <SelectTrigger><SelectValue placeholder="Select movement type" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="cold_to_warm">Cold → Warm</SelectItem>
              <SelectItem value="warm_to_hot">Warm → Hot</SelectItem>
            </SelectContent>
          </Select>
          <Input 
            type="number" 
            placeholder="Amount in SPEC"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
          <Button className="w-full" onClick={handleInitiateMovement}>
            Request Multi-Sig Approval
          </Button>
        </CardContent>
      </Card>
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" /> Global Security Controls
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-neutral-400 mb-4">
            Activate or deactivate the master vault lock. This requires multi-signature approval and will halt all major fund movements.
          </p>
          <Button 
            className="w-full" 
            variant="destructive"
            onClick={toggleVaultLock}
          >
            {vaultStatus.multiSigActive ? <Lock className="w-4 h-4 mr-2"/> : <Unlock className="w-4 h-4 mr-2" />}
            {vaultStatus.multiSigActive ? 'Activate Master Lock' : 'Deactivate Master Lock'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default VaultControls;