import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, CheckCircle, Clock } from 'lucide-react';
import { VaultMovement } from '@/api/entities';

const RecentVaultMovements = () => {
  const [movements, setMovements] = useState([]);
  
  useEffect(() => {
    const fetchMovements = async () => {
      const data = await VaultMovement.list('-created_date', 10);
      setMovements(data);
    };
    fetchMovements();
  }, []);

  const getStatusColor = (status) => {
    switch(status) {
      case 'completed': return 'bg-green-500/20 text-green-400';
      case 'pending_approval': return 'bg-yellow-500/20 text-yellow-400';
      default: return 'bg-neutral-500/20 text-neutral-400';
    }
  };

  const getMovementPath = (type) => {
    return type.replace(/_/g, ' ').replace('to', '→').toUpperCase();
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle>Recent Vault Movements</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {movements.length > 0 ? movements.map(move => (
            <div key={move.id} className="p-3 glass-effect rounded-lg flex justify-between items-center">
              <div>
                <p className="font-semibold">{getMovementPath(move.movement_type)}</p>
                <p className="text-lg font-bold text-neutral-200">{move.amount.toLocaleString()} {move.asset}</p>
                <p className="text-xs text-neutral-400">Initiated by: {move.initiated_by}</p>
              </div>
              <div className="text-right">
                <Badge className={getStatusColor(move.status)}>
                  {move.status === 'completed' ? <CheckCircle className="w-3 h-3 mr-1"/> : <Clock className="w-3 h-3 mr-1"/>}
                  {move.status.replace('_', ' ')}
                </Badge>
                <p className="text-xs text-neutral-500 mt-1">{new Date(move.created_date).toLocaleString()}</p>
              </div>
            </div>
          )) : <p className="text-center text-neutral-500 py-4">No recent movements.</p>}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentVaultMovements;