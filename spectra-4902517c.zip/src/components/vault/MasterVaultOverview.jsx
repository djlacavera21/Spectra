import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Vault, TrendingUp, Shield, Database } from 'lucide-react';

const MasterVaultOverview = ({ vaultStatus }) => {
  const chartData = [
    { name: 'Cold', balance: vaultStatus.coldWallet.balance, fill: '#3b82f6' },
    { name: 'Warm', balance: vaultStatus.warmWallet.balance, fill: '#f59e0b' },
    { name: 'Hot', balance: vaultStatus.hotWallet.balance, fill: '#ef4444' }
  ];

  const totalBalance = vaultStatus.coldWallet.balance + vaultStatus.warmWallet.balance + vaultStatus.hotWallet.balance;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2">
        <Card className="glass-card h-full">
          <CardHeader>
            <CardTitle>Asset Distribution Across Tiers</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <XAxis dataKey="name" stroke="#888888" fontSize={12} />
                <YAxis stroke="#888888" fontSize={12} tickFormatter={(value) => `${value / 1000000}M`} />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1f2937', border: 'none', borderRadius: '0.5rem' }} 
                  labelStyle={{ color: '#d1d5db' }}
                />
                <Bar dataKey="balance" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
      <div className="space-y-6">
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2"><Vault className="w-5 h-5" />Total Assets</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-yellow-400">{(totalBalance / 1000000).toFixed(2)}M SPEC</p>
          </CardContent>
        </Card>
        <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2"><TrendingUp className="w-5 h-5" />Daily Movements</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-bold">1.2M SPEC</p>
          </CardContent>
        </Card>
         <Card className="glass-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2"><Shield className="w-5 h-5" />Security Status</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xl font-bold text-green-400">Fully Secured</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MasterVaultOverview;