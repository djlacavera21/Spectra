import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

const tierColors = {
  cold: { icon: 'text-blue-400', border: 'border-blue-500/30', bg: 'bg-blue-500/10' },
  warm: { icon: 'text-yellow-400', border: 'border-yellow-500/30', bg: 'bg-yellow-500/10' },
  hot: { icon: 'text-red-400', border: 'border-red-500/30', bg: 'bg-red-500/10' }
};

const WalletTierCard = ({ tier, name, icon: Icon, balance, status, description }) => {
  const colors = tierColors[tier];
  
  return (
    <Card className={`glass-card ${colors.border} ${colors.bg}`}>
      <CardHeader>
        <div className="flex items-center gap-3">
          <Icon className={`w-8 h-8 ${colors.icon}`} />
          <div>
            <CardTitle>{name}</CardTitle>
            <Badge className="mt-1 capitalize">{status}</Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <p className="text-3xl font-bold mb-2">{(balance / 1000000).toFixed(2)}M SPEC</p>
        <p className="text-sm text-neutral-400 h-10">{description}</p>
        <Button variant="outline" className="w-full mt-4">
          Manage Funds <ArrowRight className="w-4 h-4 ml-2" />
        </Button>
      </CardContent>
    </Card>
  );
};

export default WalletTierCard;