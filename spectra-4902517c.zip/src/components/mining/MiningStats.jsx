import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Zap, Activity, Cpu, Database, CheckCircle, AlertCircle } from 'lucide-react';
import { SystemSettings } from '@/api/entities';

export default function MiningStats({ isMining }) {
  const [stats, setStats] = useState({
    blockHeight: 0,
    tps: 0,
    activePeers: 4, // In Fabric, peers are the validators
    blockReward: 50, // Pre-defined block reward
    networkStatus: 'online'
  });
  
  useEffect(() => {
    const fetchSystemData = async () => {
      try {
        const settings = await SystemSettings.list();
        if (settings.length > 0) {
            setStats(prev => ({
                ...prev,
                networkStatus: settings[0].network_status || 'online'
            }));
        }
      } catch (error) {
          console.error("Failed to fetch system settings:", error);
      }
    };
    
    fetchSystemData();

    const interval = setInterval(() => {
        setStats(prev => ({
            ...prev,
            blockHeight: prev.blockHeight + 1,
            tps: (Math.random() * 15 + 5).toFixed(2),
        }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-3 text-neutral-100">
            <Activity className="w-6 h-6 text-orange-400" />
            <span>Real-Time Network Status</span>
          </div>
          {isMining ? (
            <Badge className="bg-green-500/20 text-green-400">
              <CheckCircle className="w-3 h-3 mr-1" />
              Mining Active
            </Badge>
          ) : (
             <Badge className="bg-red-500/20 text-red-400">
              <AlertCircle className="w-3 h-3 mr-1" />
              Mining Inactive
            </Badge>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="glass-effect rounded-lg p-4">
          <p className="text-sm text-neutral-400 flex items-center gap-2"><Database className="w-4 h-4"/> Block Height</p>
          <p className="text-2xl font-bold text-neutral-100">{stats.blockHeight.toLocaleString()}</p>
        </div>
        <div className="glass-effect rounded-lg p-4">
          <p className="text-sm text-neutral-400 flex items-center gap-2"><Zap className="w-4 h-4"/> Transactions/Sec</p>
          <p className="text-2xl font-bold text-neutral-100">{stats.tps}</p>
        </div>
        <div className="glass-effect rounded-lg p-4">
          <p className="text-sm text-neutral-400 flex items-center gap-2"><Cpu className="w-4 h-4"/> Active Peers</p>
          <p className="text-2xl font-bold text-neutral-100">{stats.activePeers}</p>
        </div>
        <div className="glass-effect rounded-lg p-4">
          <p className="text-sm text-neutral-400 flex items-center gap-2">Block Reward</p>
          <p className="text-2xl font-bold text-neutral-100">{stats.blockReward} SPEC</p>
        </div>
      </CardContent>
    </Card>
  );
}