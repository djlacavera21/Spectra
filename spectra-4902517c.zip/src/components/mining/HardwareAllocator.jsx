
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Cpu, HardDrive, MemoryStick } from 'lucide-react';
import { Progress } from "@/components/ui/progress";
import { Label } from "@/components/ui/label"; // Added this import

export default function HardwareAllocator({ isMining }) {
  const getUsage = (base, variance) => {
    if (!isMining) return 0;
    return Math.max(0, Math.min(100, base + Math.random() * variance - variance / 2));
  };

  const [usage, setUsage] = React.useState({
    cpu: getUsage(40, 10),
    memory: getUsage(60, 15),
    storage: 75, // Storage is less volatile
  });

  React.useEffect(() => {
    if (isMining) {
      const interval = setInterval(() => {
        setUsage({
          cpu: getUsage(40, 10),
          memory: getUsage(60, 15),
          storage: 75
        });
      }, 2000);
      return () => clearInterval(interval);
    } else {
        setUsage({ cpu: 0, memory: 0, storage: 75 });
    }
  }, [isMining]);

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Cpu className="w-6 h-6 text-purple-400" />
          <span>Hardware Allocation</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-neutral-400">
          Resources allocated from the Spectra cloud to network validation.
        </p>
        <div className="space-y-3">
          <div>
            <div className="flex justify-between items-center mb-1">
              <Label className="text-sm text-neutral-300">CPU Usage</Label>
              <Badge variant="outline">{usage.cpu.toFixed(0)}%</Badge>
            </div>
            <Progress value={usage.cpu} className="h-2" />
          </div>
          <div>
            <div className="flex justify-between items-center mb-1">
              <Label className="text-sm text-neutral-300">Memory Usage</Label>
              <Badge variant="outline">{usage.memory.toFixed(0)}%</Badge>
            </div>
            <Progress value={usage.memory} className="h-2" />
          </div>
          <div>
            <div className="flex justify-between items-center mb-1">
              <Label className="text-sm text-neutral-300">Ledger Storage</Label>
              <Badge variant="outline">{usage.storage.toFixed(0)}%</Badge>
            </div>
            <Progress value={usage.storage} className="h-2" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
