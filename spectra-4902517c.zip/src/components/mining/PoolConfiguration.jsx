
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Play, StopCircle, Wallet, Server, CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';
import { User } from '@/api/entities';
import { isValidSpecAddress } from '@/components/common/WalletUtils';

export default function PoolConfiguration({ user, onStatusChange, initialIsMining }) {
  const [poolUrl, setPoolUrl] = useState('stratum+tcp://fabric-pool.spectra.io:3333');
  const [walletAddress, setWalletAddress] = useState('');
  const [workerName, setWorkerName] = useState('');
  const [isMining, setIsMining] = useState(initialIsMining);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (user?.mining_pool_config) {
      setPoolUrl(user.mining_pool_config.poolUrl || 'stratum+tcp://fabric-pool.spectra.io:3333');
      setWalletAddress(user.mining_pool_config.walletAddress || '');
      setWorkerName(user.mining_pool_config.workerName || `${user.full_name}_worker` || 'default_worker');
    } else if (user) {
      setWorkerName(`${user.full_name}_worker` || 'default_worker');
    }
  }, [user]);

  const handleStartMining = async () => {
    setError('');
    if (!walletAddress) {
      setError('A valid Spectra wallet address is required to receive rewards.');
      return;
    }
    if (!isValidSpecAddress(walletAddress)) {
      setError('The provided Spectra wallet address is invalid. Please check the format.');
      return;
    }

    setIsLoading(true);
    try {
      const config = { poolUrl, walletAddress, workerName };
      await User.updateMyUserData({ mining_pool_config: config });
      setIsMining(true);
      onStatusChange(true, config);
    } catch (e) {
      setError('Failed to save mining configuration. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleStopMining = async () => {
    setIsLoading(true);
    try {
      const config = { poolUrl: '', walletAddress: '', workerName: '' };
      await User.updateMyUserData({ mining_pool_config: config });
      setIsMining(false);
      onStatusChange(false, config);
    } catch (e) {
      setError('Failed to stop mining. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Server className="w-6 h-6 text-green-400" />
          <span>Pool Configuration</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="poolUrl" className="text-neutral-400">Pool URL</Label>
          <Input 
            id="poolUrl" 
            value={poolUrl}
            onChange={(e) => setPoolUrl(e.target.value)}
            className="bg-white/5 border-white/20"
            readOnly 
          />
        </div>
        <div>
          <Label htmlFor="walletAddress" className="text-neutral-400">Spectra Wallet Address (for Rewards)</Label>
          <Input 
            id="walletAddress" 
            placeholder="Enter your spec_ address"
            value={walletAddress}
            onChange={(e) => setWalletAddress(e.target.value)}
            className="bg-white/5 border-white/20"
          />
        </div>
        <div>
          <Label htmlFor="workerName" className="text-neutral-400">Worker Name</Label>
          <Input 
            id="workerName"
            value={workerName}
            onChange={(e) => setWorkerName(e.target.value)}
            className="bg-white/5 border-white/20"
          />
        </div>
        
        {error && (
          <Alert variant="destructive" className="bg-red-500/10 border-red-500/30">
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {isMining ? (
          <Button onClick={handleStopMining} disabled={isLoading} className="w-full bg-gradient-to-r from-red-500 to-red-700 text-white">
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <StopCircle className="mr-2 h-4 w-4" />}
            Stop Mining
          </Button>
        ) : (
          <Button onClick={handleStartMining} disabled={isLoading} className="w-full bg-gradient-to-r from-green-500 to-green-700 text-white">
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Play className="mr-2 h-4 w-4" />}
            Start Mining
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
