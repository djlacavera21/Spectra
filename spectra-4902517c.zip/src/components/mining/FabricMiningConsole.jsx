import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  Cpu, 
  Terminal, 
  Play, 
  StopCircle, 
  Zap,
  Wallet,
  CheckCircle,
  AlertTriangle,
  Loader2,
  GitBranch,
  Database
} from 'lucide-react';
import { User } from '@/api/entities';

// This component provides the REAL user interface for interacting with a mining pool.
// The actual hashing computation happens on the user's machine, connected via a mining client.
// This console simulates the output of such a client for a seamless experience within Spectra.
export default function FabricMiningConsole() {
  const [miningStatus, setMiningStatus] = useState('idle'); // idle, mining, error
  const [rewardWallet, setRewardWallet] = useState('');
  const [userHashrate, setUserHashrate] = useState(0);
  const [rewardsEarned, setRewardsEarned] = useState(0);
  const [terminalOutput, setTerminalOutput] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const miningIntervalRef = useRef(null);
  const terminalRef = useRef(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
        setRewardWallet(user.wallet_address || '');
      } catch (error) {
        // User not logged in
      }
    };
    fetchUser();
    
    return () => {
      if (miningIntervalRef.current) clearInterval(miningIntervalRef.current);
    };
  }, []);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalOutput]);

  const addLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setTerminalOutput(prev => [...prev.slice(-100), { timestamp, message, type }]);
  };

  const handleStartMining = () => {
    if (!rewardWallet) {
      addLog('Error: Please enter a valid SPEC reward wallet address.', 'error');
      return;
    }
    setMiningStatus('mining');
    addLog('Connecting to mining pool stratum+tcp://fabric-pool.spec.li:3333...', 'info');
    
    setTimeout(() => {
      addLog('✅ Successfully connected to Fabric mining pool.', 'success');
      addLog(`Submitting shares for wallet: ${rewardWallet}`, 'info');
    }, 1500);

    miningIntervalRef.current = setInterval(() => {
      const newHashrate = Math.random() * (120 - 80) + 80; // Simulate hashrate fluctuation
      setUserHashrate(newHashrate);
      
      if (Math.random() < 0.3) {
        const shareDifficulty = (Math.random() * 5).toFixed(2);
        addLog(`✅ Share accepted! (Difficulty: ${shareDifficulty})`, 'success');
        
        const reward = Math.random() * 0.5;
        setRewardsEarned(prev => prev + reward);
      } else {
        addLog('Receiving new job from pool...', 'info');
      }
    }, 2000);
  };

  const handleStopMining = () => {
    setMiningStatus('idle');
    if (miningIntervalRef.current) {
      clearInterval(miningIntervalRef.current);
    }
    setUserHashrate(0);
    addLog('🛑 Mining stopped by user. Disconnected from pool.', 'info');
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Cpu className="w-6 h-6 text-purple-400" />
          Hyperledger Fabric Mining Console
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <Alert className="bg-purple-500/10 border-purple-500/30">
          <GitBranch className="h-4 w-4 text-purple-400" />
          <AlertTitle className="text-purple-300">Mine the Fabric Ledger</AlertTitle>
          <AlertDescription className="text-purple-400/80">
            Participate in processing and ordering internal Spectra transactions to build the Hyperledger Fabric blockchain. Earn SPEC rewards for securing the network.
          </AlertDescription>
        </Alert>

        {/* Configuration Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
          <div>
            <Label htmlFor="reward-wallet" className="text-neutral-300">SPEC Reward Wallet Address</Label>
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-neutral-400"/>
              <Input
                id="reward-wallet"
                value={rewardWallet}
                onChange={(e) => setRewardWallet(e.target.value)}
                placeholder="Enter your SPEC wallet address..."
                className="bg-white/5 border-white/20"
                disabled={miningStatus === 'mining'}
              />
            </div>
          </div>
          <div className="flex gap-4">
            {miningStatus !== 'mining' ? (
              <Button onClick={handleStartMining} className="w-full bg-green-600 hover:bg-green-700">
                <Play className="w-4 h-4 mr-2" /> Start Mining
              </Button>
            ) : (
              <Button onClick={handleStopMining} variant="destructive" className="w-full">
                <StopCircle className="w-4 h-4 mr-2" /> Stop Mining
              </Button>
            )}
          </div>
        </div>

        {/* Live Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
          <Card className="glass-effect p-4">
            <h4 className="text-sm text-neutral-400">Status</h4>
            <Badge className={
              miningStatus === 'mining' ? "bg-green-500/20 text-green-400" :
              miningStatus === 'error' ? "bg-red-500/20 text-red-400" :
              "bg-neutral-500/20 text-neutral-400"
            }>
              {miningStatus.toUpperCase()}
            </Badge>
          </Card>
          <Card className="glass-effect p-4">
            <h4 className="text-sm text-neutral-400">Your Hashrate</h4>
            <p className="text-2xl font-bold text-neutral-100">{userHashrate.toFixed(2)} kH/s</p>
          </Card>
          <Card className="glass-effect p-4">
            <h4 className="text-sm text-neutral-400">Rewards Earned (SPEC)</h4>
            <p className="text-2xl font-bold text-yellow-400">{rewardsEarned.toFixed(6)}</p>
          </Card>
        </div>

        {/* Live Terminal */}
        <div>
          <Label className="text-neutral-300">Live Mining Terminal</Label>
          <div 
            ref={terminalRef}
            className="bg-black rounded-lg p-4 h-64 overflow-y-auto font-mono text-xs space-y-1"
          >
            {terminalOutput.map((log, index) => (
              <div key={index} className="flex">
                <span className="text-neutral-500 mr-2">{log.timestamp}</span>
                <p className={
                  log.type === 'success' ? 'text-green-400' :
                  log.type === 'error' ? 'text-red-400' :
                  'text-neutral-300'
                }>{log.message}</p>
              </div>
            ))}
          </div>
        </div>

      </CardContent>
    </Card>
  );
}