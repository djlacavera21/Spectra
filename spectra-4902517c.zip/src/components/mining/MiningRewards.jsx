import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Gift, Clock } from 'lucide-react';
import { Transaction } from '@/api/entities';
import { format } from 'date-fns';

export default function MiningRewards({ userWallet, isMining }) {
  const [rewards, setRewards] = useState([]);

  useEffect(() => {
    const fetchRewards = async () => {
      if (userWallet) {
        try {
          const rewardTxs = await Transaction.filter({
            to_address: userWallet,
            transaction_type: 'staking_reward' // Re-purposing this type for mining rewards
          }, '-created_date', 20);
          setRewards(rewardTxs);
        } catch (error) {
          console.error("Failed to fetch mining rewards:", error);
        }
      }
    };
    
    fetchRewards();
    // Fetch new rewards periodically if mining is active
    const interval = setInterval(() => {
        if(isMining) fetchRewards();
    }, 30000);

    return () => clearInterval(interval);

  }, [userWallet, isMining]);

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Gift className="w-6 h-6 text-yellow-400" />
          <span>Recent Mining Rewards</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {rewards.length > 0 ? (
          <div className="space-y-3 max-h-60 overflow-y-auto pr-2">
            {rewards.map(reward => (
              <div key={reward.id} className="glass-effect rounded-lg p-3 flex justify-between items-center">
                <div>
                  <p className="text-sm font-medium text-green-400">
                    + {reward.amount} SPEC
                  </p>
                  <p className="text-xs text-neutral-400">
                    Block Reward
                  </p>
                </div>
                <div className="text-right">
                    <Badge className="bg-green-500/20 text-green-400">Confirmed</Badge>
                    <p className="text-xs text-neutral-500 mt-1 flex items-center gap-1">
                        <Clock className="w-3 h-3"/>
                        {format(new Date(reward.created_date), 'MMM dd, HH:mm:ss')}
                    </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-neutral-400 text-sm text-center py-8">
            {isMining ? "Waiting for next block reward..." : "Start mining to see rewards here."}
          </p>
        )}
      </CardContent>
    </Card>
  );
}