
import React from "react";
import { TrendingUp, Activity, Award, Zap } from "lucide-react";

const StatCard = ({ icon: Icon, title, value, subtitle, gradient }) => (
  <div className="glass-card rounded-xl p-6 relative overflow-hidden">
    <div className={`absolute top-0 right-0 w-20 h-20 ${gradient} rounded-full blur-2xl opacity-20 -translate-y-4 translate-x-4`}></div>
    <div className="relative z-10">
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-10 h-10 ${gradient} rounded-lg flex items-center justify-center`}>
          <Icon className="w-5 h-5 text-white" />
        </div>
        <span className="text-sm text-neutral-400">{title}</span>
      </div>
      <div className="text-2xl font-bold text-neutral-100 mb-1">{value}</div>
      <div className="text-xs text-neutral-500">{subtitle}</div>
    </div>
  </div>
);

export default function StatsGrid({ stats }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      <StatCard
        icon={TrendingUp}
        title="Total Earned"
        value={`${stats.totalEarned?.toLocaleString() || 0} SPEC`}
        subtitle="All-time earnings"
        gradient="bg-gradient-to-r from-green-400 to-emerald-500"
      />
      <StatCard
        icon={Activity}
        title="Total Spent"
        value={`${stats.totalSpent?.toLocaleString() || 0} SPEC`}
        subtitle="Total purchases"
        gradient="bg-gradient-to-r from-purple-400 to-pink-400"
      />
      <StatCard
        icon={Award}
        title="Trading Level"
        value={stats.tradingLevel || "Bronze"}
        subtitle="Current tier"
        gradient="bg-gradient-to-r from-yellow-400 to-orange-500"
      />
      <StatCard
        icon={Zap}
        title="Network Fee"
        value="0.001 SPEC"
        subtitle="Current gas price"
        gradient="bg-gradient-to-r from-gray-400 to-gray-600"
      />
    </div>
  );
}
