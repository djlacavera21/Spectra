import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  TrendingUp, 
  Users, 
  Zap,
  Server,
  Database,
  Network,
  Cpu
} from "lucide-react";

export default function LiveMetrics({ systemMetrics }) {
  const [isLive, setIsLive] = useState(true);

  useEffect(() => {
    // Update live status based on system metrics
    if (systemMetrics) {
      setIsLive(systemMetrics.networkStatus === 'online');
    }
  }, [systemMetrics]);

  if (!systemMetrics) {
    return (
      <div className="glass-card rounded-2xl p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mr-3"></div>
          <span className="text-neutral-400">Loading system metrics...</span>
        </div>
      </div>
    );
  }

  const getHealthColor = (status) => {
    if (status === 'online') return 'text-green-400';
    if (status === 'maintenance') return 'text-yellow-400';
    return 'text-red-400';
  };

  const getHealthPercentage = (status) => {
    if (status === 'online') return 100;
    if (status === 'maintenance') return 75;
    return 0;
  };

  return (
    <div className="glass-card rounded-2xl p-6 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-full blur-3xl -translate-y-4 translate-x-4"></div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Activity className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-100">System Metrics</h3>
              <p className="text-xs text-neutral-400">Real-time Network Stats</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${isLive ? 'bg-green-400' : 'bg-red-400'} animate-pulse`}></div>
            <Badge className={`text-xs ${isLive ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
              {isLive ? 'Live' : 'Offline'}
            </Badge>
          </div>
        </div>

        <div className="space-y-4">
          {/* Network Health */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Server className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-300">Network Status</span>
              </div>
              <span className={`text-sm font-bold ${getHealthColor(systemMetrics.networkStatus)}`}>
                {systemMetrics.networkStatus.toUpperCase()}
              </span>
            </div>
            <div className="w-full bg-neutral-700 rounded-full h-1.5">
              <div 
                className="bg-gradient-to-r from-green-400 to-blue-400 h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${getHealthPercentage(systemMetrics.networkStatus)}%` }}
              ></div>
            </div>
          </div>

          {/* Active Users */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-neutral-300">Total Users</span>
              </div>
              <span className="text-sm font-bold text-purple-400">
                {systemMetrics.totalUsers.toLocaleString()}
              </span>
            </div>
          </div>

          {/* Transactions Per Second */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-neutral-300">TPS</span>
              </div>
              <span className="text-sm font-bold text-yellow-400">
                {systemMetrics.tps}
              </span>
            </div>
          </div>

          {/* Block Height */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-green-400" />
                <span className="text-sm text-neutral-300">Block Height</span>
              </div>
              <span className="text-sm font-bold text-green-400">
                {systemMetrics.blockHeight.toLocaleString()}
              </span>
            </div>
          </div>

          {/* 24h Volume */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-neutral-300">24h Volume</span>
              </div>
              <span className="text-sm font-bold text-orange-400">
                {systemMetrics.volume24h.toLocaleString()} SPEC
              </span>
            </div>
          </div>

          {/* Active Users (24h) */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span className="text-sm text-neutral-300">Active (24h)</span>
              </div>
              <span className="text-sm font-bold text-cyan-400">
                {systemMetrics.activeUsers24h.toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}