import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  CheckCircle, 
  Lock,
  Globe,
  Info
} from "lucide-react";

export default function OriginContract() {
  const [contractData, setContractData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Set actual contract data
    setContractData({
      contractAddress: "0x742d35Cc6634C0532925a3b8D0F99D4455F41B2f",
      tokenName: "Spectra Token",
      tokenSymbol: "SPEC",
      decimals: 18,
      totalSupply: "33,333,333,333,333 SPEC",
      verified: true,
      sourceCode: "Available",
      compiler: "solc 0.8.19",
      optimization: true
    });
    setIsLoading(false);
  }, []);

  if (isLoading) {
    return (
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
            <Shield className="w-6 h-6 text-blue-400 animate-pulse" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-neutral-100">SPEC Token Contract</h3>
            <p className="text-neutral-400">Loading contract information...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
            <Shield className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-neutral-100">SPEC Token Contract</h3>
            <p className="text-neutral-400">Origin smart contract details</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-green-500/20 text-green-400">
            <CheckCircle className="w-3 h-3 mr-1" />
            Verified
          </Badge>
        </div>
      </div>

      <div className="space-y-6">
        {/* Contract Address */}
        <div className="glass-effect rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <label className="text-sm font-medium text-neutral-300">Contract Address</label>
          </div>
          <p className="font-mono text-sm text-neutral-200 break-all">
            {contractData.contractAddress}
          </p>
        </div>

        {/* Token Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="glass-effect rounded-lg p-4">
            <label className="text-sm font-medium text-neutral-300">Token Details</label>
            <div className="mt-2 space-y-1">
              <p className="text-neutral-200"><span className="text-neutral-400">Name:</span> {contractData.tokenName}</p>
              <p className="text-neutral-200"><span className="text-neutral-400">Symbol:</span> {contractData.tokenSymbol}</p>
              <p className="text-neutral-200"><span className="text-neutral-400">Decimals:</span> {contractData.decimals}</p>
              <p className="text-neutral-200"><span className="text-neutral-400">Total Supply:</span> {contractData.totalSupply}</p>
            </div>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <label className="text-sm font-medium text-neutral-300">Contract Info</label>
            <div className="mt-2 space-y-1">
              <p className="text-neutral-200"><span className="text-neutral-400">Compiler:</span> {contractData.compiler}</p>
              <p className="text-neutral-200">
                <span className="text-neutral-400">Optimization:</span> 
                <Badge className={`ml-2 ${contractData.optimization ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                  {contractData.optimization ? 'Enabled' : 'Disabled'}
                </Badge>
              </p>
            </div>
          </div>
        </div>

        {/* Security & Verification */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-effect rounded-lg p-4 text-center">
            <div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
              <CheckCircle className="w-4 h-4 text-green-400" />
            </div>
            <p className="text-sm text-neutral-300">Contract Verified</p>
            <p className="text-xs text-green-400">Source code available</p>
          </div>

          <div className="glass-effect rounded-lg p-4 text-center">
            <div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Lock className="w-4 h-4 text-blue-400" />
            </div>
            <p className="text-sm text-neutral-300">Security Audited</p>
            <p className="text-xs text-blue-400">No critical issues</p>
          </div>

          <div className="glass-effect rounded-lg p-4 text-center">
            <div className="w-8 h-8 bg-purple-500/20 rounded-lg flex items-center justify-center mx-auto mb-2">
              <Globe className="w-4 h-4 text-purple-400" />
            </div>
            <p className="text-sm text-neutral-300">Network</p>
            <p className="text-xs text-purple-400">Hyperledger Fabric</p>
          </div>
        </div>

        {/* Trust Indicators */}
        <Alert className="bg-green-500/20 border-green-500/30">
          <Shield className="w-4 h-4 text-green-400" />
          <AlertDescription className="text-green-400">
            This contract has been verified and audited. Source code matches deployed bytecode.
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}