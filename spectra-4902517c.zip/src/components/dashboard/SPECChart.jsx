import React from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";

export default function SPECChart() {
  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-neutral-100">SPEC/USDC</h3>
          <p className="text-neutral-400">Price: $1.00</p>
        </div>
      </div>

      <Alert className="bg-blue-500/20 border-blue-500/30">
        <Info className="w-4 h-4 text-blue-400" />
        <AlertDescription className="text-blue-400">
          <strong>Price Chart:</strong> Live trading charts will be available once the platform connects to market data feeds and begins actual trading operations.
        </AlertDescription>
      </Alert>
    </div>
  );
}