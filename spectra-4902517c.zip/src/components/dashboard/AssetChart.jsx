import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, RefreshCw } from "lucide-react";
import { InvokeLLM } from "@/api/integrations";

const CustomTooltip = ({ active, payload, label, assetSymbol }) => {
  if (active && payload && payload.length) {
    return (
      <div className="glass-card p-3 rounded-lg">
        <p className="text-neutral-200 text-sm">{label}</p>
        <p className="text-green-400 font-semibold">
          {assetSymbol === 'DXY' ? '' : '$'}{payload[0].value.toLocaleString()}
        </p>
      </div>
    );
  }
  return null;
};

export default function AssetChart({ assetName, assetSymbol, chartColor }) {
  const [chartData, setChartData] = useState([]);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [priceChange, setPriceChange] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const response = await InvokeLLM({
        prompt: `Fetch the daily price history for ${assetName} (${assetSymbol}) in USD for the last 30 days. Provide an array of 30 objects with 'time' (date as 'MMM d') and 'price' keys. Also provide the current price and the percentage change over the 30-day period.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            current_price: { type: "number" },
            price_change_percent: { type: "number" },
            history: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  time: { type: "string" },
                  price: { type: "number" }
                },
                required: ["time", "price"]
              }
            }
          },
          required: ["current_price", "price_change_percent", "history"]
        }
      });
      setChartData(response.history);
      setCurrentPrice(response.current_price);
      setPriceChange(response.price_change_percent);
    } catch (error) {
      console.error(`Error fetching ${assetName} data:`, error);
      // Fallback data
      setChartData([{time: 'N/A', price: 0}]);
      setCurrentPrice(0);
      setPriceChange(0);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [assetName]);

  return (
    <div className="glass-card rounded-xl p-6 h-full">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-xl font-bold text-neutral-100">{assetName} ({assetSymbol}/USD)</h3>
          <div className="flex items-center gap-4 mt-2">
            <span className="text-2xl font-bold text-neutral-100">
              {assetSymbol === 'DXY' ? '' : '$'}{currentPrice.toLocaleString()}
            </span>
            <div className={`flex items-center gap-1 text-sm ${priceChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {priceChange >= 0 ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              {priceChange.toFixed(2)}%
            </div>
          </div>
        </div>
        <button onClick={fetchData} className="text-neutral-400 hover:text-white">
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
        </button>
      </div>
      <div className="h-64">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white"></div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="time" stroke="#888888" fontSize={10} tickLine={false} />
              <YAxis stroke="#888888" fontSize={10} tickLine={false} domain={['dataMin * 0.98', 'dataMax * 1.02']} tickFormatter={(value) => value.toLocaleString()} />
              <Tooltip content={<CustomTooltip assetSymbol={assetSymbol} />} />
              <Line type="monotone" dataKey="price" stroke={chartColor} strokeWidth={2} dot={false} activeDot={{ r: 4, fill: chartColor }} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}