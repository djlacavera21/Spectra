import React from "react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";

export default function UnifiedMarketChart() {
  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-2xl font-bold text-neutral-100 mb-2">Market Overview</h3>
          <p className="text-neutral-400 text-sm">
            Market data will be available after platform launch
          </p>
        </div>
      </div>

      <Alert className="bg-blue-500/20 border-blue-500/30">
        <Info className="w-4 h-4 text-blue-400" />
        <AlertDescription className="text-blue-400">
          <strong>Market Data:</strong> Real-time market charts and trading data will be displayed here once the platform is fully operational and connected to external market feeds.
        </AlertDescription>
      </Alert>
    </div>
  );
}