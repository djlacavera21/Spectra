import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Wallet, 
  Send, 
  Download, 
  Copy, 
  Eye, 
  EyeOff,
  ArrowUpDown,
  Zap,
  Shield
} from "lucide-react";

export default function CombinedSPECWallet({ user, specToUsdRate }) {
  const [showBalance, setShowBalance] = useState(true);
  const [activeWallet, setActiveWallet] = useState('primary');
  const [copied, setCopied] = useState(false);

  const primaryBalance = user?.spec_balance || 0;
  const secondaryBalance = user?.secondary_spec_balance || 0;
  const totalBalance = primaryBalance + secondaryBalance;
  const rate = specToUsdRate || 1.0;

  const copyAddress = (address) => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const formatAddress = (address) => {
    if (!address) return "Not Generated";
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-full blur-3xl -translate-y-4 translate-x-4"></div>
      
      <div className="relative z-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-lg flex items-center justify-center">
              <Wallet className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-semibold text-neutral-100">SPEC Wallets</h3>
              <p className="text-xs text-neutral-400">Hyperledger Fabric</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-green-500/20 text-green-400">Active</Badge>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowBalance(!showBalance)}
              className="text-neutral-400 hover:text-neutral-100 hover:bg-white/10"
            >
              {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-xs text-neutral-400 mb-2">Total Balance</p>
          <div className="text-3xl font-bold text-neutral-100 mb-2">
            {showBalance ? `${totalBalance.toLocaleString()} SPEC` : '••••••••'}
          </div>
          <div className="text-sm text-neutral-400">
            ≈ ${showBalance ? (totalBalance * rate).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : '••••'}
          </div>
        </div>

        <Tabs value={activeWallet} onValueChange={setActiveWallet} className="w-full mb-6">
          <TabsList className="grid w-full grid-cols-2 glass-effect">
            <TabsTrigger value="primary" className="text-neutral-400 data-[state=active]:bg-white/20 data-[state=active]:text-neutral-100">
              Primary
            </TabsTrigger>
            <TabsTrigger value="secondary" className="text-neutral-400 data-[state=active]:bg-white/20 data-[state=active]:text-neutral-100">
              Secondary
            </TabsTrigger>
          </TabsList>

          <TabsContent value="primary" className="space-y-3 mt-4">
            <div className="glass-effect rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-neutral-300">Primary Wallet</span>
                <Badge className="bg-blue-500/20 text-blue-400 text-xs">Original Mint</Badge>
              </div>
              <div className="text-lg font-bold text-neutral-100 mb-1">
                {showBalance ? `${primaryBalance.toLocaleString()} SPEC` : '••••••••'}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-neutral-400 font-mono flex-1">
                  {formatAddress(user?.wallet_address)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => copyAddress(user?.wallet_address)}
                  className="text-neutral-400 hover:text-neutral-100 hover:bg-white/10 h-6 w-6"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="secondary" className="space-y-3 mt-4">
            <div className="glass-effect rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-neutral-300">Secondary Wallet</span>
                <Badge className="bg-purple-500/20 text-purple-400 text-xs">2nd Mint Ready</Badge>
              </div>
              <div className="text-lg font-bold text-neutral-100 mb-1">
                {showBalance ? `${secondaryBalance.toLocaleString()} SPEC` : '••••••••'}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-neutral-400 font-mono flex-1">
                  {formatAddress(user?.secondary_wallet_address)}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => copyAddress(user?.secondary_wallet_address)}
                  className="text-neutral-400 hover:text-neutral-100 hover:bg-white/10 h-6 w-6"
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {copied && (
          <p className="text-xs text-green-400 mb-3">Address copied to clipboard!</p>
        )}

        <div className="grid grid-cols-3 gap-2">
          <Button
            size="sm"
            className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs h-8"
            onClick={() => alert(`Send from ${activeWallet} wallet`)}
          >
            <Send className="w-3 h-3 mr-1" />
            Send
          </Button>
          <Button
            size="sm"
            className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs h-8"
            onClick={() => alert(`Receive to ${activeWallet} wallet`)}
          >
            <Download className="w-3 h-3 mr-1" />
            Receive
          </Button>
          <Button
            size="sm"
            className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs h-8"
            onClick={() => alert('Swap SPEC tokens')}
          >
            <ArrowUpDown className="w-3 h-3 mr-1" />
            Swap
          </Button>
        </div>
      </div>
    </div>
  );
}