
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowUpRight, ArrowDownLeft, Clock, CheckCircle, XCircle, Activity } from "lucide-react";
import { format } from "date-fns";

const StatusIcon = ({ status }) => {
  switch (status) {
    case "confirmed":
      return <CheckCircle className="w-4 h-4 text-green-400" />;
    case "pending":
      return <Clock className="w-4 h-4 text-yellow-400" />;
    case "failed":
      return <XCircle className="w-4 h-4 text-red-400" />;
    default:
      return <Clock className="w-4 h-4 text-gray-400" />;
  }
};

const TransactionRow = ({ transaction, currentUserAddress }) => {
  const isOutgoing = transaction.from_address === currentUserAddress;
  const TransactionIcon = isOutgoing ? ArrowUpRight : ArrowDownLeft;
  
  return (
    <div className="flex items-center justify-between p-4 glass-effect rounded-lg hover:bg-white/10 transition-colors">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
          isOutgoing ? 'bg-red-500/20' : 'bg-green-500/20'
        }`}>
          <TransactionIcon className={`w-5 h-5 ${
            isOutgoing ? 'text-red-400' : 'text-green-400'
          }`} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-neutral-200">
              {isOutgoing ? 'Sent' : 'Received'}
            </span>
            <StatusIcon status={transaction.status} />
          </div>
          <div className="text-xs text-neutral-400">
            {format(new Date(transaction.created_date), 'MMM d, HH:mm')}
          </div>
        </div>
      </div>
      <div className="text-right">
        <div className={`font-semibold ${
          isOutgoing ? 'text-red-400' : 'text-green-400'
        }`}>
          {isOutgoing ? '-' : '+'}{transaction.amount.toLocaleString()} SPEC
        </div>
        <div className="text-xs text-neutral-400">
          {transaction.transaction_type.replace('_', ' ')}
        </div>
      </div>
    </div>
  );
};

export default function RecentTransactions({ transactions, currentUserAddress, onViewAll }) {
  return (
    <div className="glass-card rounded-xl p-6 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-neutral-100">Recent Transactions</h3>
        <Button
          variant="ghost"
          size="sm"
          onClick={onViewAll}
          className="text-neutral-400 hover:text-neutral-100 hover:bg-white/10"
        >
          View All
        </Button>
      </div>
      
      <div className="space-y-3 flex-1">
        {transactions.length > 0 ? (
          transactions.slice(0, 5).map((transaction) => (
            <TransactionRow
              key={transaction.id}
              transaction={transaction}
              currentUserAddress={currentUserAddress}
            />
          ))
        ) : (
          <div className="text-center py-8 text-neutral-400 flex flex-col items-center justify-center h-full">
            <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>No transactions yet</p>
            <p className="text-sm">Your transaction history will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}
