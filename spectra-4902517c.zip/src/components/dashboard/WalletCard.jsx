import React from "react";
import { Wallet, Eye, EyeOff, Copy, Send, Download, ArrowUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import WalletActionModal from "../wallet/WalletActionModal";

export default function WalletCard({ title = "SPEC Wallet", description = "Hyperledger Fabric Balance", balance, address, user, walletType = "SPEC" }) {
  const [showBalance, setShowBalance] = React.useState(true);
  const [copied, setCopied] = React.useState(false);
  const [actionModal, setActionModal] = React.useState({ isOpen: false, action: null });

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col">
        {/* Enhanced background decoration */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-r from-blue-400/20 to-purple-500/20 rounded-full blur-3xl -translate-y-8 translate-x-8"></div>
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-gradient-to-r from-cyan-400/15 to-blue-500/15 rounded-full blur-2xl translate-y-4 -translate-x-4"></div>
        
        <div className="relative z-10 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl flex items-center justify-center crypto-glow">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">{title}</h3>
                <p className="text-sm text-neutral-400">{description}</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setShowBalance(!showBalance)}>
              {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>

          {/* Enhanced Balance Display */}
          <div className="mb-6">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-bold text-neutral-100">
                {showBalance ? balance?.toLocaleString() : "••••••"}
              </span>
              <span className="text-lg text-neutral-400">SPEC</span>
            </div>
            <div className="flex items-center gap-4">
              <p className="text-sm text-neutral-400">
                ≈ ${showBalance ? (balance * 1.00).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "••••"} USD
              </p>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-400">Live</span>
              </div>
            </div>
          </div>

          {/* SPEC Wallet Address Only */}
          <div className="mb-6 space-y-3 flex-grow">
            <div>
              <p className="text-xs text-neutral-400 mb-2">Wallet Address (Hyperledger Fabric)</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-3">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">
                  {address}
                </span>
                <Button variant="ghost" size="icon" onClick={copyAddress} className="h-7 w-7">
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            {copied && (
              <p className="text-xs text-green-400 mt-1">Address copied!</p>
            )}
          </div>

          {/* Enhanced Action Buttons */}
          <div className="grid grid-cols-3 gap-3">
            <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white" onClick={() => handleAction('send')}>
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
              <Download className="w-4 h-4 mr-1" />
              Receive
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Swap
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType={walletType}
        walletAddress={address}
        balance={balance}
        user={user}
      />
    </>
  );
}