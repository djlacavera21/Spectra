import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Wallet, 
  ArrowRight, 
  Shield, 
  AlertTriangle,
  Copy,
  ExternalLink 
} from 'lucide-react';
import { useSignature } from './SignatureContext';

export default function SignatureModal() {
  const { isOpen, transactionDetails, handleConfirm, handleReject } = useSignature();

  if (!isOpen || !transactionDetails) {
    return null;
  }

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <Dialog open={isOpen} onOpenChange={() => handleReject()}>
      <DialogContent className="bg-black border border-neutral-700 text-neutral-200 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl text-neutral-200">
            <Shield className="w-6 h-6 text-yellow-400" />
            Transaction Signature Required
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <Card className="bg-neutral-900 border-neutral-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-neutral-400">From</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-neutral-200">
                    {transactionDetails.from?.substring(0, 6)}...{transactionDetails.from?.substring(-4)}
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(transactionDetails.from)}
                    className="h-6 w-6 p-0 bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center justify-center py-2">
                <ArrowRight className="w-5 h-5 text-neutral-400" />
              </div>
              
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm text-neutral-400">To</span>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-xs text-neutral-200">
                    {transactionDetails.to?.substring(0, 6)}...{transactionDetails.to?.substring(-4)}
                  </span>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(transactionDetails.to)}
                    className="h-6 w-6 p-0 bg-neutral-800 hover:bg-neutral-700 text-neutral-300"
                  >
                    <Copy className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-neutral-400">Amount</span>
              <span className="font-bold text-neutral-200">{transactionDetails.amount} SPEC</span>
            </div>
            
            {transactionDetails.fee && (
              <div className="flex justify-between items-center">
                <span className="text-neutral-400">Platform Fee</span>
                <span className="text-neutral-200">{transactionDetails.fee} SPEC</span>
              </div>
            )}
            
            <div className="flex justify-between items-center pt-2 border-t border-neutral-700">
              <span className="text-neutral-400">Total Cost</span>
              <span className="font-bold text-yellow-400">{transactionDetails.total} SPEC</span>
            </div>
          </div>

          {transactionDetails.metadata && (
            <Card className="bg-neutral-900 border-neutral-700">
              <CardContent className="p-3">
                <div className="text-xs text-neutral-400 mb-2">Transaction Details</div>
                <div className="space-y-1 text-xs">
                  {transactionDetails.metadata.asset_name && (
                    <div>Asset: <span className="text-neutral-200">{transactionDetails.metadata.asset_name}</span></div>
                  )}
                  {transactionDetails.metadata.action && (
                    <div>Action: <span className="text-neutral-200">{transactionDetails.metadata.action}</span></div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="flex items-center gap-2 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-yellow-400 flex-shrink-0" />
            <div className="text-xs text-yellow-300">
              Please review all transaction details carefully before confirming.
            </div>
          </div>
        </div>

        <div className="flex gap-3 pt-4">
          <Button 
            variant="outline" 
            className="flex-1 border-neutral-700 hover:bg-neutral-800 text-neutral-200 bg-neutral-900"
            onClick={handleReject}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 bg-gradient-to-r from-green-600 to-green-800 text-neutral-200 hover:from-green-700 hover:to-green-900 border-none"
            onClick={handleConfirm}
          >
            <Wallet className="w-4 h-4 mr-2" />
            Confirm Transaction
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}