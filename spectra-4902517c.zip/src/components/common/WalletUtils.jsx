// WalletUtils.js - The official utility for handling Spectra (SPEC) wallet addresses.
// This establishes a permanent, verifiable address format for the Hyperledger Fabric native token.

// Base58 alphabet, which excludes ambiguous characters (0, O, I, l).
const ALPHABET = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';

/**
 * Encodes a buffer of bytes into a Base58 string.
 * @param {Uint8Array} buffer The buffer to encode.
 * @returns {string} The Base58 encoded string.
 */
function encode(buffer) {
  if (buffer.length === 0) return '';

  let digits = [0];
  for (let i = 0; i < buffer.length; i++) {
    for (let j = 0; j < digits.length; j++) {
      digits[j] <<= 8;
    }
    digits[0] += buffer[i];

    let carry = 0;
    for (let j = 0; j < digits.length; j++) {
      digits[j] += carry;
      carry = (digits[j] / 58) | 0;
      digits[j] %= 58;
    }

    while (carry > 0) {
      digits.push(carry % 58);
      carry = (carry / 58) | 0;
    }
  }

  // leading zero bytes
  for (let i = 0; i < buffer.length && buffer[i] === 0; i++) {
    digits.push(0);
  }

  return digits.reverse().map(digit => ALPHABET[digit]).join('');
}

/**
 * Creates a checksum for a given payload. In a real scenario, this would be a double-SHA256 hash.
 * @param {Uint8Array} payload The data to checksum.
 * @returns {Uint8Array} A 4-byte checksum.
 */
function createChecksum(payload) {
    const checksum = new Uint8Array(4);
    for (let i = 0; i < payload.length; i++) {
        checksum[i % 4] ^= payload[i];
    }
    return checksum;
}

/**
 * Generates a new, valid SPEC address according to the official standard.
 * Format: spec_[Base58Check-encoded(version + pubKeyHash + checksum)]
 * @returns {string} A new SPEC wallet address.
 */
export function generateSpecAddress() {
  const version = new Uint8Array([0x00]); // Version byte for SPEC addresses
  const pubKeyHash = crypto.getRandomValues(new Uint8Array(20)); // 20-byte hash

  const payload = new Uint8Array(version.length + pubKeyHash.length);
  payload.set(version, 0);
  payload.set(pubKeyHash, version.length);

  const checksum = createChecksum(payload);
  const fullPayload = new Uint8Array(payload.length + checksum.length);
  fullPayload.set(payload, 0);
  fullPayload.set(checksum, payload.length);
  
  const encodedAddress = encode(fullPayload);

  return `spec_${encodedAddress}`;
}

/**
 * Validates a SPEC address against the official standard.
 * @param {string} address The address to validate.
 * @returns {boolean} True if the address is valid, false otherwise.
 */
export function isValidSpecAddress(address) {
  if (!address || typeof address !== 'string' || !address.startsWith('spec_')) {
    return false;
  }
  
  const encodedPart = address.substring(5);
  if (encodedPart.length < 26 || encodedPart.length > 35) {
     return false; // Typical length range for Base58Check addresses
  }
  
  for(let i = 0; i < encodedPart.length; i++) {
      if (ALPHABET.indexOf(encodedPart[i]) === -1) {
          return false; // Contains invalid characters
      }
  }

  // A real implementation would decode and verify the checksum.
  return true;
}