import React, { createContext, useContext, useState, useCallback } from 'react';

const SignatureContext = createContext(null);

export function useSignature() {
  return useContext(SignatureContext);
}

export function SignatureProvider({ children }) {
  const [isOpen, setIsOpen] = useState(false);
  const [transactionDetails, setTransactionDetails] = useState(null);
  const [callbacks, setCallbacks] = useState({ onConfirm: null, onReject: null });

  const requestSignature = useCallback((details, onConfirm, onReject) => {
    setTransactionDetails(details);
    setCallbacks({ onConfirm, onReject });
    setIsOpen(true);
  }, []);

  const handleConfirm = useCallback(async () => {
    if (callbacks.onConfirm) {
      await callbacks.onConfirm();
    }
    setIsOpen(false);
    setTransactionDetails(null);
    setCallbacks({ onConfirm: null, onReject: null });
  }, [callbacks]);

  const handleReject = useCallback(() => {
    if (callbacks.onReject) {
      callbacks.onReject();
    }
    setIsOpen(false);
    setTransactionDetails(null);
    setCallbacks({ onConfirm: null, onReject: null });
  }, [callbacks]);
  
  const value = {
    isOpen,
    transactionDetails,
    requestSignature,
    handleConfirm,
    handleReject,
  };

  return (
    <SignatureContext.Provider value={value}>
      {children}
    </SignatureContext.Provider>
  );
}