import React, { createContext, useState, useEffect, useContext, useCallback } from 'react';
import { User, NotificationEvent } from '@/api/entities';

const NotificationContext = createContext(null);

export const NotificationProvider = ({ children }) => {
  const [notifications, setNotifications] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);

  const fetchUser = useCallback(async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);
    } catch (e) {
      setCurrentUser(null);
    }
  }, []);
  
  const fetchNotifications = useCallback(async () => {
    if (!currentUser) return;
    setIsLoading(true);
    try {
      const userNotifications = await NotificationEvent.filter(
        { user_wallet: currentUser.wallet_address },
        '-created_date',
        100
      );
      setNotifications(userNotifications);
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      setNotifications([]);
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  useEffect(() => {
    if (currentUser) {
      fetchNotifications();
      const interval = setInterval(fetchNotifications, 60000); // Poll every 60 seconds
      return () => clearInterval(interval);
    }
  }, [currentUser, fetchNotifications]);

  const markAsRead = async (notificationId) => {
    try {
      await NotificationEvent.update(notificationId, { status: 'read', read_at: new Date().toISOString() });
      setNotifications(prev =>
        prev.map(n => (n.id === notificationId ? { ...n, status: 'read' } : n))
      );
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    if (!currentUser) return;
    try {
      const unread = notifications.filter(n => n.status !== 'read');
      // This should be a single backend call, but we simulate it with multiple updates
      await Promise.all(
        unread.map(n => NotificationEvent.update(n.id, { status: 'read', read_at: new Date().toISOString() }))
      );
      fetchNotifications();
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
    }
  };

  const value = {
    notifications,
    isLoading,
    unreadCount: notifications.filter(n => n.status !== 'read').length,
    markAsRead,
    markAllAsRead,
    fetchNotifications,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};