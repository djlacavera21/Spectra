import React, { useState } from 'react';
import { useNotifications } from './NotificationService';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bell, 
  CheckCheck, 
  Mail, 
  Trash2, 
  Loader2,
  LogIn,
  LogOut,
  ShieldCheck,
  TrendingUp,
  ArrowDownLeft,
  Settings,
  AlertTriangle
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const NOTIFICATION_ICONS = {
  login_success: <LogIn className="w-5 h-5 text-green-400" />,
  security_alert: <AlertTriangle className="w-5 h-5 text-red-400" />,
  trade_executed: <TrendingUp className="w-5 h-5 text-blue-400" />,
  deposit_received: <ArrowDownLeft className="w-5 h-5 text-green-400" />,
  password_changed: <ShieldCheck className="w-5 h-5 text-yellow-400" />,
  default: <Mail className="w-5 h-5 text-neutral-400" />,
};

const NotificationItem = ({ notification, onMarkRead }) => {
  const isRead = notification.status === 'read';
  const Icon = NOTIFICATION_ICONS[notification.event_type] || NOTIFICATION_ICONS.default;

  return (
    <div className={`flex items-start gap-4 p-4 glass-effect rounded-lg transition-colors ${isRead ? 'opacity-60' : 'hover:bg-neutral-800'}`}>
      <div className="mt-1">{Icon}</div>
      <div className="flex-1">
        <div className="flex items-center justify-between">
          <p className={`font-semibold ${isRead ? 'text-neutral-400' : 'text-neutral-100'}`}>{notification.title}</p>
          <span className="text-xs text-neutral-500">{formatDistanceToNow(new Date(notification.created_date), { addSuffix: true })}</span>
        </div>
        <p className="text-sm text-neutral-400 mt-1">{notification.message}</p>
        {notification.metadata?.ip_address && (
          <p className="text-xs text-neutral-500 mt-2 font-mono">
            IP: {notification.metadata.ip_address}
          </p>
        )}
      </div>
      {!isRead && (
        <Button size="icon" variant="ghost" onClick={() => onMarkRead(notification.id)} className="w-8 h-8">
          <CheckCheck className="w-4 h-4 text-blue-400" />
        </Button>
      )}
    </div>
  );
};

export default function NotificationCenter() {
  const { notifications, isLoading, markAsRead, markAllAsRead, fetchNotifications } = useNotifications();
  const [activeTab, setActiveTab] = useState('all');

  const filteredNotifications = notifications.filter(n => {
    if (activeTab === 'all') return true;
    if (activeTab === 'unread') return n.status !== 'read';
    return false;
  });

  if (isLoading && notifications.length === 0) {
    return (
      <div className="flex justify-center items-center h-96">
        <Loader2 className="w-8 h-8 animate-spin text-neutral-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="glass-card">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-yellow-400" />
            <div>
              <CardTitle className="text-2xl text-neutral-100">Notification Center</CardTitle>
              <p className="text-neutral-400">All alerts and account updates.</p>
            </div>
          </div>
          <Button onClick={markAllAsRead}>
            <CheckCheck className="w-4 h-4 mr-2"/>
            Mark All as Read
          </Button>
        </CardHeader>
      </Card>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 glass-effect">
          <TabsTrigger value="all">All Notifications</TabsTrigger>
          <TabsTrigger value="unread">Unread</TabsTrigger>
        </TabsList>
        <TabsContent value={activeTab} className="mt-6">
          <div className="space-y-4">
            {filteredNotifications.length > 0 ? (
              filteredNotifications.map(n => (
                <NotificationItem key={n.id} notification={n} onMarkRead={markAsRead} />
              ))
            ) : (
              <div className="text-center py-16 text-neutral-500">
                <Bell className="w-12 h-12 mx-auto mb-4" />
                <p>No {activeTab === 'unread' ? 'unread' : ''} notifications.</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}