
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, Eye, Zap, Layers, ExternalLink } from "lucide-react";

export default function AssetCard({ asset, onBuy, onLike, onView }) {
  const [isLiked, setIsLiked] = React.useState(false);
  const [imageLoaded, setImageLoaded] = React.useState(false);
  const [imageError, setImageError] = React.useState(false);

  const handleLike = () => {
    setIsLiked(!isLiked);
    onLike?.(asset.id);
  };

  const handleView = () => {
    onView?.(asset.id);
  };

  const handleImageLoad = () => {
    setImageLoaded(true);
  };

  const handleImageError = () => {
    setImageError(true);
    setImageLoaded(true);
  };

  return (
    <div className="glass-card rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 flex flex-col group">
      {/* Asset Image */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-gray-800 to-gray-900">
        {!imageLoaded && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-400"></div>
          </div>
        )}
        
        {!imageError ? (
          <img
            src={asset.image_url || `https://picsum.photos/400/400?random=${asset.id}`}
            alt={asset.asset_name}
            className={`w-full h-full object-cover transition-opacity duration-300 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-700 to-gray-800">
            <div className="text-center">
              <Layers className="w-12 h-12 text-gray-500 mx-auto mb-2" />
              <p className="text-xs text-gray-500">Image unavailable</p>
            </div>
          </div>
        )}

        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <Button
            onClick={handleView}
            size="sm"
            className="bg-neutral-200/90 text-black hover:bg-neutral-200 backdrop-blur-sm border-none"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            View Details
          </Button>
        </div>

        {/* Top badges */}
        <div className="absolute top-3 right-3 flex gap-2">
          <Badge className="bg-black/50 text-neutral-200 border-none capitalize backdrop-blur-sm">
            {asset.asset_type}
          </Badge>
          {asset.token_id && (
            <Badge className="bg-green-500/20 text-green-400 border-green-500/30 backdrop-blur-sm">
              Minted
            </Badge>
          )}
        </div>

        {/* Bottom interaction buttons */}
        <div className="absolute bottom-3 left-3 flex gap-2">
          <div className="glass-effect rounded-full px-3 py-1 flex items-center gap-1 backdrop-blur-sm">
            <Eye className="w-3 h-3 text-neutral-200" />
            <span className="text-xs text-neutral-200">{asset.views || 0}</span>
          </div>
          <button
            onClick={handleLike}
            className="glass-effect rounded-full p-2 hover:bg-white/20 transition-colors backdrop-blur-sm"
          >
            <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : 'text-neutral-200'}`} />
          </button>
        </div>
      </div>

      {/* Asset Details */}
      <div className="p-4 flex flex-col flex-grow">
        {asset.collection_name && (
          <div className="flex items-center gap-2 mb-2 text-xs text-gray-400">
            <Layers className="w-3 h-3" />
            <span className="truncate">{asset.collection_name}</span>
          </div>
        )}
        
        <h3 className="font-semibold text-neutral-100 mb-2 truncate flex-grow line-clamp-2">
          {asset.asset_name}
        </h3>

        {asset.description && (
          <p className="text-xs text-neutral-400 mb-3 line-clamp-2">
            {asset.description}
          </p>
        )}
        
        {/* Price and Action */}
        <div className="flex items-center justify-between mt-auto pt-3 border-t border-white/10">
          <div>
            <div className="flex items-center gap-1 mb-1">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="font-bold text-neutral-100">
                {asset.price_spec.toLocaleString()} SPEC
              </span>
            </div>
            <p className="text-xs text-neutral-500">
              ≈ ${(asset.price_spec * 1.00).toLocaleString()} USD
            </p>
          </div>
          <Button
            onClick={() => onBuy(asset)}
            size="sm"
            className="bg-gradient-to-r from-gray-500 to-gray-700 hover:from-gray-600 hover:to-gray-800 text-white border-none"
          >
            Buy Now
          </Button>
        </div>

        {/* Asset metadata */}
        {asset.token_id && (
          <div className="mt-2 pt-2 border-t border-white/10">
            <p className="text-xs text-neutral-500 font-mono truncate">
              ID: {asset.token_id.substring(0, 16)}...
            </p>
          </div>
        )}
      </div>

      {/* Seller info */}
      <div className="px-4 pb-4">
        <div className="flex items-center justify-between text-xs text-neutral-500">
          <span>Seller:</span>
          <span className="font-mono truncate ml-2">
            {asset.seller_address.substring(0, 6)}...{asset.seller_address.substring(asset.seller_address.length - 4)}
          </span>
        </div>
      </div>
    </div>
  );
}
