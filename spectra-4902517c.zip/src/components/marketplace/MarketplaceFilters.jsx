import React from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Filter, TrendingUp, Clock, Grid, List, SlidersHorizontal } from "lucide-react";

export default function MarketplaceFilters({ 
  onFilterChange, 
  onSearchChange, 
  onSortChange,
  assetCounts = {},
  activeFilter = "all",
  viewMode = "grid",
  onViewModeChange 
}) {
  const [searchValue, setSearchValue] = React.useState("");
  const [priceRange, setPriceRange] = React.useState("all");
  const [sortBy, setSortBy] = React.useState("newest");

  const assetTypes = [
    { value: "all", label: "All Types" },
    { value: "nft", label: "NFT" },
    { value: "digital_art", label: "Digital Art" },
    { value: "music", label: "Music" },
    { value: "video", label: "Video" },
    { value: "domain", label: "Domain" },
    { value: "other", label: "Other" }
  ];

  const priceRanges = [
    { value: "all", label: "All Prices" },
    { value: "0-10", label: "0 - 10 SPEC" },
    { value: "10-100", label: "10 - 100 SPEC" },
    { value: "100-1000", label: "100 - 1K SPEC" },
    { value: "1000-10000", label: "1K - 10K SPEC" },
    { value: "10000+", label: "10K+ SPEC" }
  ];

  const sortOptions = [
    { value: "newest", label: "Recently Listed", icon: Clock },
    { value: "price_low", label: "Price: Low to High", icon: TrendingUp },
    { value: "price_high", label: "Price: High to Low", icon: TrendingUp },
    { value: "popular", label: "Most Popular", icon: TrendingUp },
    { value: "ending_soon", label: "Ending Soon", icon: Clock }
  ];

  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchValue(value);
    onSearchChange(value);
  };

  const handleSortChange = (value) => {
    setSortBy(value);
    onSortChange(value);
  };

  const handlePriceRangeChange = (value) => {
    setPriceRange(value);
  };

  const clearFilters = () => {
    setSearchValue("");
    setPriceRange("all");
    setSortBy("newest");
    onSearchChange("");
    onFilterChange("all");
    onSortChange("newest");
  };

  // Force remove white overlay styles
  const buttonStyle = {
    backgroundColor: 'rgba(64, 64, 64, 0.8)',
    color: '#e5e5e5',
    border: '1px solid rgba(255, 255, 255, 0.2)'
  };

  const activeButtonStyle = {
    background: 'linear-gradient(135deg, #6b7280 0%, #374151 100%)',
    color: '#ffffff',
    border: 'none'
  };

  const hoverStyle = {
    backgroundColor: 'rgba(75, 85, 99, 0.8)',
    color: '#f3f4f6'
  };

  return (
    <div className="glass-card rounded-xl p-6 space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
        <Input
          placeholder="Search assets, collections, or creators..."
          className="pl-10 bg-white/10 border-white/20 text-neutral-200 placeholder:text-neutral-500 h-12"
          value={searchValue}
          onChange={handleSearchChange}
        />
        {searchValue && (
          <button
            onClick={() => handleSearchChange({ target: { value: "" } })}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 px-2 py-1 rounded text-neutral-400"
            style={buttonStyle}
            onMouseEnter={(e) => Object.assign(e.target.style, hoverStyle)}
            onMouseLeave={(e) => Object.assign(e.target.style, buttonStyle)}
          >
            ×
          </button>
        )}
      </div>

      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        {/* Filter Buttons */}
        <div className="flex flex-wrap gap-2">
          {assetTypes.map(type => (
            <button
              key={type.value}
              onClick={() => onFilterChange(type.value)}
              className="px-3 py-2 rounded-md text-sm transition-all flex items-center gap-2"
              style={activeFilter === type.value ? activeButtonStyle : buttonStyle}
              onMouseEnter={(e) => {
                if (activeFilter !== type.value) {
                  Object.assign(e.target.style, hoverStyle);
                }
              }}
              onMouseLeave={(e) => {
                if (activeFilter !== type.value) {
                  Object.assign(e.target.style, buttonStyle);
                }
              }}
            >
              {type.label}
              {assetCounts[type.value] > 0 && (
                <span className="ml-2 px-2 py-0.5 bg-white/20 text-neutral-200 rounded text-xs">
                  {assetCounts[type.value]}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Advanced Filters & Controls */}
        <div className="flex flex-wrap gap-3 items-center">
          {/* Price Range */}
          <Select value={priceRange} onValueChange={handlePriceRangeChange}>
            <SelectTrigger 
              className="w-40 text-neutral-200"
              style={buttonStyle}
            >
              <SelectValue placeholder="Price Range" />
            </SelectTrigger>
            <SelectContent>
              {priceRanges.map(range => (
                <SelectItem key={range.value} value={range.value}>
                  {range.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* Sort */}
          <Select value={sortBy} onValueChange={handleSortChange}>
            <SelectTrigger 
              className="w-48 text-neutral-200"
              style={buttonStyle}
            >
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              {sortOptions.map(option => (
                <SelectItem key={option.value} value={option.value}>
                  <div className="flex items-center gap-2">
                    <option.icon className="w-4 h-4" />
                    {option.label}
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {/* View Mode Toggle */}
          {onViewModeChange && (
            <div className="flex rounded-lg overflow-hidden">
              <button
                onClick={() => onViewModeChange("grid")}
                className="p-2 border-r border-white/20"
                style={viewMode === "grid" ? activeButtonStyle : buttonStyle}
                onMouseEnter={(e) => {
                  if (viewMode !== "grid") {
                    Object.assign(e.target.style, hoverStyle);
                  }
                }}
                onMouseLeave={(e) => {
                  if (viewMode !== "grid") {
                    Object.assign(e.target.style, buttonStyle);
                  }
                }}
              >
                <Grid className="w-4 h-4" />
              </button>
              <button
                onClick={() => onViewModeChange("list")}
                className="p-2"
                style={viewMode === "list" ? activeButtonStyle : buttonStyle}
                onMouseEnter={(e) => {
                  if (viewMode !== "list") {
                    Object.assign(e.target.style, hoverStyle);
                  }
                }}
                onMouseLeave={(e) => {
                  if (viewMode !== "list") {
                    Object.assign(e.target.style, buttonStyle);
                  }
                }}
              >
                <List className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Clear Filters */}
          <button
            onClick={clearFilters}
            className="px-3 py-2 rounded-md text-sm flex items-center gap-2"
            style={buttonStyle}
            onMouseEnter={(e) => Object.assign(e.target.style, hoverStyle)}
            onMouseLeave={(e) => Object.assign(e.target.style, buttonStyle)}
          >
            <SlidersHorizontal className="w-4 h-4" />
            Clear
          </button>
        </div>
      </div>

      {/* Active Filters Display */}
      {(activeFilter !== "all" || priceRange !== "all" || searchValue) && (
        <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
          <span className="text-sm text-neutral-400">Active filters:</span>
          {activeFilter !== "all" && (
            <Badge variant="secondary" className="bg-gray-500/20 text-gray-400">
              Type: {assetTypes.find(t => t.value === activeFilter)?.label}
            </Badge>
          )}
          {priceRange !== "all" && (
            <Badge variant="secondary" className="bg-gray-500/20 text-gray-400">
              Price: {priceRanges.find(p => p.value === priceRange)?.label}
            </Badge>
          )}
          {searchValue && (
            <Badge variant="secondary" className="bg-gray-500/20 text-gray-400">
              Search: "{searchValue}"
            </Badge>
          )}
        </div>
      )}
    </div>
  );
}