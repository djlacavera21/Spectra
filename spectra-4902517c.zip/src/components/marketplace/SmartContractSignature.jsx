import React from 'react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { FileText, Edit, ShieldCheck, Loader2, CheckCircle } from 'lucide-react';

export default function SmartContractSignature({ 
  assetDetails, 
  onSign, 
  onCancel, 
  isSigning, 
  uploadProgress = 0 
}) {
  const contractText = `
    NFT MINTING AGREEMENT (Spectra v1.2)

    This agreement, entered into on ${new Date().toLocaleDateString()}, governs the minting of a new Non-Fungible Token ("NFT") on the Spectra Hyperledger Fabric network.

    1.  **NFT Details**:
        -   **Name**: ${assetDetails.asset_name}
        -   **Collection**: ${assetDetails.collection_name || 'Uncategorized'}
        -   **Price**: ${assetDetails.price_spec} SPEC
        -   **Description**: ${assetDetails.description ? assetDetails.description.substring(0, 100) + '...' : 'No description provided'}

    2.  **Creator's Warranties**: The Creator warrants they hold all necessary intellectual property rights to the associated media and that it does not infringe on any third-party rights.

    3.  **Blockchain Transaction**: The Creator authorizes the deployment of a smart contract to mint the NFT. This action is irreversible and will be permanently recorded on the blockchain. A network fee of 0.5 SPEC will be deducted from your account.

    4.  **Terms of Sale**: The NFT will be listed for sale on the Spectra Marketplace at the price specified above immediately upon successful minting.

    5.  **Platform Fees**: A 2.5% platform fee will be applied to any future sales of this NFT.

    By signing this transaction, you acknowledge you have read, understood, and agree to be bound by the terms of this agreement. Your digital signature confirms your intent and constitutes a legally binding commitment.
  `;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <FileText className="w-8 h-8 text-yellow-400" />
        <div>
          <h3 className="text-xl font-bold text-neutral-100">Smart Contract Signature</h3>
          <p className="text-neutral-400">Review and confirm the minting of your NFT on-chain</p>
        </div>
      </div>

      {/* Contract Text */}
      <div className="glass-effect rounded-lg p-4 h-64 overflow-y-auto custom-scrollbar">
        <pre className="text-xs text-neutral-300 whitespace-pre-wrap font-mono leading-relaxed">
          {contractText}
        </pre>
      </div>

      {/* Asset Summary */}
      <div className="glass-effect rounded-lg p-4">
        <h4 className="text-sm font-semibold text-neutral-200 mb-3">Transaction Summary</h4>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <span className="text-neutral-400">Asset Name:</span>
            <p className="text-neutral-100 font-medium">{assetDetails.asset_name}</p>
          </div>
          <div>
            <span className="text-neutral-400">Listing Price:</span>
            <p className="text-neutral-100 font-medium">{assetDetails.price_spec} SPEC</p>
          </div>
          <div>
            <span className="text-neutral-400">Minting Fee:</span>
            <p className="text-neutral-100 font-medium">0.5 SPEC</p>
          </div>
          <div>
            <span className="text-neutral-400">Network:</span>
            <p className="text-neutral-100 font-medium">Hyperledger Fabric</p>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      {isSigning && uploadProgress > 0 && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-neutral-400">Processing...</span>
            <span className="text-neutral-300">{uploadProgress}%</span>
          </div>
          <Progress value={uploadProgress} className="h-2" />
          <div className="text-xs text-neutral-500 text-center">
            {uploadProgress < 30 && "Uploading image to IPFS..."}
            {uploadProgress >= 30 && uploadProgress < 60 && "Generating smart contract..."}
            {uploadProgress >= 60 && uploadProgress < 90 && "Broadcasting to blockchain..."}
            {uploadProgress >= 90 && uploadProgress < 100 && "Finalizing transaction..."}
            {uploadProgress === 100 && "Complete!"}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3 pt-4 border-t border-white/10">
        <Button 
          variant="outline" 
          onClick={onCancel} 
          disabled={isSigning}
          className="flex-1 border-white/20 text-neutral-200 hover:bg-white/10"
        >
          <Edit className="w-4 h-4 mr-2" />
          Back to Edit
        </Button>
        <Button 
          onClick={onSign} 
          disabled={isSigning} 
          className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white"
        >
          {isSigning ? (
            <>
              <Loader2 className="animate-spin rounded-full h-4 w-4 mr-2" />
              Processing On-Chain...
            </>
          ) : uploadProgress === 100 ? (
            <>
              <CheckCircle className="w-4 h-4 mr-2" />
              Minting Complete!
            </>
          ) : (
            <>
              <ShieldCheck className="w-4 h-4 mr-2" />
              Sign & Mint NFT
            </>
          )}
        </Button>
      </div>

      {/* Legal Disclaimer */}
      <div className="text-xs text-neutral-500 bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
        <p className="flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-yellow-400 flex-shrink-0 mt-0.5" />
          <span>
            This transaction will be recorded on the blockchain and cannot be reversed. 
            Ensure all details are correct before proceeding.
          </span>
        </p>
      </div>
    </div>
  );
}