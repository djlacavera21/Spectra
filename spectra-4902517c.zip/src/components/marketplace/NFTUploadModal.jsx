
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { 
  Upload, 
  Image as ImageIcon, 
  X, 
  Palette, 
  Coins, 
  ShieldCheck,
  AlertCircle,
  CheckCircle,
  FileText,
  Loader2
} from 'lucide-react';
import SmartContractSignature from './SmartContractSignature';

export default function NFTUploadModal({ isOpen, onClose, onUpload, isProcessing }) {
  const [step, setStep] = useState(1);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [assetData, setAssetData] = useState({
    asset_name: '',
    collection_name: '',
    description: '',
    price_spec: ''
  });
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  const [errors, setErrors] = useState({});

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setAssetData(prev => ({ ...prev, [name]: value }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!assetData.asset_name.trim()) {
      newErrors.asset_name = 'Asset name is required';
    }
    
    if (!assetData.price_spec || parseFloat(assetData.price_spec) <= 0) {
      newErrors.price_spec = 'Valid price is required';
    }
    
    if (!imageFile) {
      newErrors.image = 'Image is required';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        setErrors(prev => ({ ...prev, image: 'Please select an image file' }));
        return;
      }
      
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        setErrors(prev => ({ ...prev, image: 'Image must be less than 10MB' }));
        return;
      }
      
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      
      // Clear image error
      if (errors.image) {
        setErrors(prev => ({ ...prev, image: '' }));
      }
      
      // Simulate upload progress
      simulateUploadProgress();
    }
  };

  const simulateUploadProgress = () => {
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 100);
  };

  const handleNextStep = () => {
    if (!validateForm()) {
      return;
    }
    setStep(2);
  };

  const handleCreateAsset = async () => {
    setUploadProgress(0);
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 90) {
          clearInterval(progressInterval);
          return 90;
        }
        return prev + 10;
      });
    }, 200);

    try {
      await onUpload(assetData, imageFile);
      setUploadProgress(100);
      clearInterval(progressInterval);
    } catch (error) {
      clearInterval(progressInterval);
      setUploadProgress(0);
    }
  };
  
  const resetAndClose = () => {
    setAssetData({ asset_name: '', collection_name: '', description: '', price_spec: '' });
    setImageFile(null);
    setImagePreview('');
    setUploadProgress(0);
    setErrors({});
    setStep(1);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="glass-card rounded-xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto relative">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={resetAndClose} 
          className="absolute top-4 right-4 text-neutral-400 hover:text-neutral-200"
        >
          <X className="w-5 h-5" />
        </Button>
        
        {/* Progress Indicator */}
        <div className="flex items-center justify-center mb-6">
          <div className="flex items-center gap-4">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step >= 1 ? 'bg-gradient-to-r from-gray-500 to-gray-700 text-white' : 'bg-gray-700 text-gray-400'
            }`}>
              {step > 1 ? <CheckCircle className="w-5 h-5" /> : '1'}
            </div>
            <div className={`w-16 h-1 ${step > 1 ? 'bg-gradient-to-r from-gray-500 to-gray-700' : 'bg-gray-700'}`}></div>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
              step >= 2 ? 'bg-gradient-to-r from-gray-500 to-gray-700 text-white' : 'bg-gray-700 text-gray-400'
            }`}>
              {step > 2 ? <CheckCircle className="w-5 h-5" /> : '2'}
            </div>
          </div>
        </div>
        
        {step === 1 && (
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <Palette className="w-8 h-8 text-purple-400" />
              <div>
                <h2 className="text-2xl font-bold text-neutral-100">Create New NFT</h2>
                <p className="text-neutral-400">Upload your artwork and provide details to mint it.</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Input 
                    name="asset_name" 
                    placeholder="Asset Name *" 
                    value={assetData.asset_name} 
                    onChange={handleInputChange} 
                    className={`bg-white/5 border-white/20 text-neutral-100 ${errors.asset_name ? 'border-red-500' : ''}`}
                  />
                  {errors.asset_name && (
                    <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" />
                      {errors.asset_name}
                    </p>
                  )}
                </div>

                <Input 
                  name="collection_name" 
                  placeholder="Collection Name (Optional)" 
                  value={assetData.collection_name} 
                  onChange={handleInputChange} 
                  className="bg-white/5 border-white/20 text-neutral-100" 
                />

                <Textarea 
                  name="description" 
                  placeholder="Description" 
                  value={assetData.description} 
                  onChange={handleInputChange} 
                  className="bg-white/5 border-white/20 text-neutral-100 h-28" 
                />

                <div>
                  <div className="relative">
                    <Coins className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 w-4 h-4" />
                    <Input 
                      name="price_spec" 
                      type="number" 
                      step="0.01"
                      placeholder="Price in SPEC *" 
                      value={assetData.price_spec} 
                      onChange={handleInputChange} 
                      className={`bg-white/5 border-white/20 text-neutral-100 pl-10 ${errors.price_spec ? 'border-red-500' : ''}`}
                    />
                  </div>
                  {errors.price_spec && (
                    <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                      <AlertCircle className="w-4 h-4" />
                      {errors.price_spec}
                    </p>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm text-neutral-400 mb-2">Artwork Image *</label>
                <div className="w-full h-56 border-2 border-dashed border-white/20 rounded-lg flex items-center justify-center text-neutral-400 relative overflow-hidden">
                  {imagePreview ? (
                    <div className="relative w-full h-full">
                      <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                        <Button
                          size="sm"
                          className="bg-neutral-200 text-black hover:bg-neutral-300"
                        >
                          Change Image
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center">
                      <Upload className="w-8 h-8 mx-auto mb-2" />
                      <p>Click to upload or drag & drop</p>
                      <p className="text-xs text-neutral-500 mt-1">PNG, JPG, GIF (Max 10MB)</p>
                    </div>
                  )}
                  <input 
                    type="file" 
                    accept="image/*" 
                    onChange={handleFileChange} 
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  />
                </div>
                {errors.image && (
                  <p className="text-red-400 text-sm mt-1 flex items-center gap-1">
                    <AlertCircle className="w-4 h-4" />
                    {errors.image}
                  </p>
                )}
                
                {uploadProgress > 0 && uploadProgress < 100 && (
                  <div className="mt-2">
                    <Progress value={uploadProgress} className="h-2" />
                    <p className="text-xs text-neutral-400 mt-1">Uploading... {uploadProgress}%</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-between items-center pt-4 border-t border-white/10">
              <div className="text-sm text-neutral-400">
                <p>Minting fee: <span className="text-neutral-200 font-semibold">0.5 SPEC</span></p>
              </div>
              <Button 
                onClick={handleNextStep} 
                disabled={isProcessing} 
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white hover:from-purple-600 hover:to-pink-600"
              >
                Continue to Signing
              </Button>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <SmartContractSignature 
              assetDetails={assetData} 
              onSign={handleCreateAsset}
              onCancel={() => setStep(1)}
              isSigning={isProcessing}
              uploadProgress={uploadProgress}
            />
          </div>
        )}
      </div>
    </div>
  );
}
