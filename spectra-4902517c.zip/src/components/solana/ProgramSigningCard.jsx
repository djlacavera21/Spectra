import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  FileCode2, 
  Coins, 
  Clock, 
  Zap, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Copy,
  ExternalLink,
  Calculator,
  Layers
} from 'lucide-react';

export default function ProgramSigningCard({ program, onSign, onCancel, isVisible }) {
  const [feeSettings, setFeeSettings] = useState({
    computeUnits: 200000,
    priorityFee: 0.00001, // SOL
    rent: 0.002, // SOL for rent exemption
  });
  const [selectedSpeed, setSelectedSpeed] = useState('standard');
  const [estimatedTime, setEstimatedTime] = useState('~30 sec');
  const [totalCost, setTotalCost] = useState(0);
  const [activeTab, setActiveTab] = useState('details');

  const speedPresets = {
    slow: { priorityFee: 0.000005, time: '~2 min', color: 'bg-blue-500/20 text-blue-400' },
    standard: { priorityFee: 0.00001, time: '~30 sec', color: 'bg-green-500/20 text-green-400' },
    fast: { priorityFee: 0.00005, time: '~15 sec', color: 'bg-orange-500/20 text-orange-400' },
    priority: { priorityFee: 0.0001, time: '~5 sec', color: 'bg-red-500/20 text-red-400' }
  };

  useEffect(() => {
    if (program) {
      // Estimate compute units based on program complexity
      const codeLength = program.code?.length || 1000;
      const estimatedComputeUnits = Math.min(1400000, Math.max(100000, Math.floor(codeLength / 5)));
      
      setFeeSettings(prev => ({ ...prev, computeUnits: estimatedComputeUnits }));
    }
  }, [program]);

  useEffect(() => {
    // Calculate total cost in SOL
    const cost = feeSettings.priorityFee + feeSettings.rent + (feeSettings.computeUnits * 0.000000001);
    setTotalCost(cost);
    
    const preset = speedPresets[selectedSpeed];
    if (preset) {
      setEstimatedTime(preset.time);
    }
  }, [feeSettings, selectedSpeed]);

  const handleSpeedChange = (speed) => {
    setSelectedSpeed(speed);
    const preset = speedPresets[speed];
    setFeeSettings(prev => ({
      ...prev,
      priorityFee: preset.priorityFee
    }));
  };

  const handleCustomFeeChange = (field, value) => {
    setFeeSettings(prev => ({ ...prev, [field]: parseFloat(value) || 0 }));
    setSelectedSpeed('custom');
  };

  const handleSign = () => {
    const signedProgram = {
      ...program,
      feeSettings,
      totalCost,
      estimatedTime,
      signedAt: new Date().toISOString()
    };
    onSign(signedProgram);
  };

  const copyProgramAddress = () => {
    if (program?.estimatedAddress) {
      navigator.clipboard.writeText(program.estimatedAddress);
    }
  };

  if (!isVisible || !program) {
    return null;
  }

  return (
    <Card className="glass-card shadow-lg" style={{ border: '1px solid #00FFA350' }}>
      <CardHeader className="border-b border-white/10">
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <FileCode2 className="w-6 h-6" style={{ color: '#00FFA3' }} />
          <span>Program Signature Required</span>
          <Badge style={{ backgroundColor: '#00FFA320', color: '#00FFA3' }}>
            <AlertTriangle className="w-3 h-3 mr-1" />
            Pending Signature
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="p-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 glass-effect mb-4">
            <TabsTrigger value="details">Program Details</TabsTrigger>
            <TabsTrigger value="fees">Fee Settings</TabsTrigger>
            <TabsTrigger value="review">Review & Sign</TabsTrigger>
          </TabsList>

          <TabsContent value="details" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-neutral-300 text-sm">Program Name</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100 font-medium">{program.name}</p>
                </div>
              </div>
              <div>
                <Label className="text-neutral-300 text-sm">Program Type</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100">{program.programType || 'SPL Token'}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="text-neutral-300 text-sm">Token Symbol</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100 font-medium">{program.tokenSymbol}</p>
                </div>
              </div>
              <div>
                <Label className="text-neutral-300 text-sm">Total Supply</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100">{program.totalSupply?.toLocaleString()}</p>
                </div>
              </div>
              <div>
                <Label className="text-neutral-300 text-sm">Decimals</Label>
                <div className="glass-effect rounded-lg p-3 mt-1">
                  <p className="text-neutral-100">{program.decimals}</p>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-neutral-300 text-sm">Estimated Program Address</Label>
              <div className="glass-effect rounded-lg p-3 mt-1 flex items-center justify-between">
                <p className="text-neutral-100 font-mono text-sm flex-1">
                  {program.estimatedAddress}
                </p>
                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={copyProgramAddress}>
                    <Copy className="w-3 h-3" />
                  </Button>
                  <Button size="sm" variant="ghost">
                    <ExternalLink className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </div>

            <div>
              <Label className="text-neutral-300 text-sm">Program Features</Label>
              <div className="glass-effect rounded-lg p-3 mt-1">
                <div className="flex flex-wrap gap-2">
                  {program.features?.mintable && <Badge className="bg-green-500/20 text-green-400">Mintable</Badge>}
                  {program.features?.burnable && <Badge className="bg-red-500/20 text-red-400">Burnable</Badge>}
                  {program.features?.freezable && <Badge className="bg-blue-500/20 text-blue-400">Freezable</Badge>}
                  {program.features?.transferFeeConfig && <Badge className="bg-purple-500/20 text-purple-400">Transfer Fees</Badge>}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="fees" className="space-y-4">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {Object.entries(speedPresets).map(([speed, preset]) => (
                <button
                  key={speed}
                  onClick={() => handleSpeedChange(speed)}
                  className={`p-3 rounded-lg border transition-all ${
                    selectedSpeed === speed 
                      ? 'border-purple-500/50 bg-purple-500/10' 
                      : 'border-white/20 hover:border-white/30 bg-white/5'
                  }`}
                >
                  <div className="text-center">
                    <div className="flex items-center justify-center mb-2">
                      {speed === 'slow' && <Clock className="w-4 h-4 text-blue-400" />}
                      {speed === 'standard' && <CheckCircle className="w-4 h-4 text-green-400" />}
                      {speed === 'fast' && <Zap className="w-4 h-4 text-orange-400" />}
                      {speed === 'priority' && <TrendingUp className="w-4 h-4 text-red-400" />}
                    </div>
                    <p className="text-xs font-medium text-neutral-200 capitalize mb-1">{speed}</p>
                    <p className="text-xs text-neutral-400">{preset.time}</p>
                    <p className="text-xs text-neutral-300 mt-1">{preset.priorityFee} SOL</p>
                  </div>
                </button>
              ))}
            </div>

            <div className="border-t border-white/10 pt-4">
              <h4 className="text-sm font-medium text-neutral-200 mb-3 flex items-center gap-2">
                <Calculator className="w-4 h-4" />
                Custom Fee Settings
              </h4>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <Label className="text-neutral-300 text-sm">Compute Units</Label>
                  <Input
                    type="number"
                    value={feeSettings.computeUnits}
                    onChange={(e) => handleCustomFeeChange('computeUnits', e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                  />
                  <p className="text-xs text-neutral-500 mt-1">Maximum compute units for this transaction</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-neutral-300 text-sm">Priority Fee (SOL)</Label>
                    <Input
                      type="number"
                      step="0.000001"
                      value={feeSettings.priorityFee}
                      onChange={(e) => handleCustomFeeChange('priorityFee', e.target.value)}
                      className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                    />
                  </div>
                  <div>
                    <Label className="text-neutral-300 text-sm">Rent (SOL)</Label>
                    <Input
                      type="number"
                      step="0.000001"
                      value={feeSettings.rent}
                      onChange={(e) => handleCustomFeeChange('rent', e.target.value)}
                      className="bg-white/5 border-white/20 text-neutral-100 mt-1"
                    />
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="review" className="space-y-4">
            <Alert className="bg-purple-500/10 border-purple-500/30">
              <CheckCircle className="w-4 h-4 text-purple-400" />
              <AlertDescription className="text-purple-300">
                Review all details carefully before signing the transaction.
              </AlertDescription>
            </Alert>

            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Program Name:</span>
                <span className="text-neutral-100 font-medium">{program.name}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Compute Units:</span>
                <span className="text-neutral-100">{feeSettings.computeUnits.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Priority Fee:</span>
                <span className="text-neutral-100">{feeSettings.priorityFee} SOL</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Rent Exemption:</span>
                <span className="text-neutral-100">{feeSettings.rent} SOL</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg">
                <span className="text-neutral-300">Estimated Time:</span>
                <span className="text-neutral-100">{estimatedTime}</span>
              </div>
              <div className="flex justify-between items-center p-3 glass-effect rounded-lg border" style={{ borderColor: '#00FFA350' }}>
                <span className="text-neutral-300">Total Cost:</span>
                <span className="font-bold" style={{ color: '#00FFA3' }}>{totalCost.toFixed(6)} SOL</span>
              </div>
            </div>

            <Alert style={{ backgroundColor: '#ff930320', borderColor: '#ff930350' }}>
              <AlertTriangle className="w-4 h-4" style={{ color: '#ff9303' }} />
              <AlertDescription style={{ color: '#ff9303aa' }} className="text-sm">
                This transaction will deploy a Rust program to the Solana blockchain. 
                Transaction fees are non-refundable even if the deployment fails.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>

        <div className="flex gap-3 mt-6 pt-4 border-t border-white/10">
          <Button 
            variant="outline" 
            className="flex-1 border-white/20 hover:bg-white/10"
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button 
            className="flex-1 text-white hover:opacity-90"
            style={{ background: 'linear-gradient(to right, #8b5cf6, #00FFA3)' }}
            onClick={handleSign}
          >
            <Coins className="w-4 h-4 mr-2" />
            Sign & Deploy Program
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}