import React from 'react';
import { Activity, Zap, Clock, ShieldCheck } from 'lucide-react';

export default function NetworkStats() {
  const stats = {
    tps: { current: 3450, max: 65000 },
    blockTime: 0.45,
    epoch: 567,
    slot: 245890123,
    health: "Healthy"
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">Solana Network Statistics</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard icon={Zap} label="Transactions per Second" value={stats.tps.current.toLocaleString()} subtitle={`Max: ${stats.tps.max.toLocaleString()}`} />
        <StatCard icon={Clock} label="Block Time" value={`${stats.blockTime}s`} subtitle="Confirmation Speed" />
        <StatCard icon={ShieldCheck} label="Network Health" value={stats.health} subtitle="Current Status" highlight="text-green-400" />
      </div>
      <div className="mt-6 pt-6 border-t border-white/10">
        <h4 className="text-lg font-semibold text-neutral-200 mb-4">Epoch Information</h4>
        <div className="flex justify-between items-center glass-effect p-4 rounded-lg">
          <div>
            <p className="text-sm text-neutral-400">Current Epoch</p>
            <p className="text-2xl font-bold text-neutral-100">{stats.epoch}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-400">Current Slot</p>
            <p className="text-2xl font-bold text-neutral-100">{stats.slot.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-neutral-400">Epoch Progress</p>
            <div className="w-40 bg-neutral-700 rounded-full h-2.5 mt-2">
              <div className="bg-gradient-to-r from-green-400 to-purple-500 h-2.5 rounded-full" style={{ width: `75%` }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const StatCard = ({ icon: Icon, label, value, subtitle, highlight = 'text-neutral-100' }) => (
  <div className="glass-effect rounded-lg p-4">
    <div className="flex items-center gap-3 mb-2">
      <Icon className="w-5 h-5 text-neutral-400" />
      <p className="text-sm text-neutral-400">{label}</p>
    </div>
    <p className={`text-3xl font-bold ${highlight}`}>{value}</p>
    <p className="text-xs text-neutral-500 mt-1">{subtitle}</p>
  </div>
);