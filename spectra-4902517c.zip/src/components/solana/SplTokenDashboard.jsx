import React from 'react';
import { Droplets, Users, BarChart, ExternalLink } from 'lucide-react';

export default function SplTokenDashboard() {
  const tokenInfo = {
    name: "Spectra Coin (SPL)",
    address: "SPECxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
    totalSupply: 500000000,
    holders: 12530,
    marketCap: 500000000,
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">SPEC SPL Token Dashboard</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <StatCard icon={Droplets} label="Total Supply" value={tokenInfo.totalSupply.toLocaleString()} />
        <StatCard icon={Users} label="Unique Holders" value={tokenInfo.holders.toLocaleString()} />
        <StatCard icon={BarChart} label="Market Cap" value={`$${tokenInfo.marketCap.toLocaleString()}`} />
      </div>
      <div className="glass-effect rounded-lg p-4 flex items-center justify-between">
        <div>
          <p className="text-sm text-neutral-400">Token Address</p>
          <p className="text-base font-mono text-neutral-200">{tokenInfo.address}</p>
        </div>
        <button className="p-2 rounded-md hover:bg-neutral-600 transition-colors">
          <ExternalLink className="w-5 h-5 text-neutral-400" />
        </button>
      </div>
    </div>
  );
}

const StatCard = ({ icon: Icon, label, value }) => (
  <div className="glass-effect rounded-lg p-4">
    <div className="flex items-center gap-3 mb-2">
      <Icon className="w-5 h-5 text-neutral-400" />
      <p className="text-sm text-neutral-400">{label}</p>
    </div>
    <p className="text-2xl font-bold text-neutral-100">{value}</p>
  </div>
);