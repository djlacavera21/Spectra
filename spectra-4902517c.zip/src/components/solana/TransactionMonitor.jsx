import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function TransactionMonitor() {
    const transactions = [
        { sig: '3j...', type: 'Transfer', from: 'UserA', to: 'UserB', amount: '1,000 SPEC' },
        { sig: '5r...', type: 'SPL Mint', from: 'Bridge', to: 'UserC', amount: '500 SPEC' },
        { sig: '2e...', type: 'Swap', from: 'Raydium', to: 'UserD', amount: '2.5 SOL' },
        { sig: '4t...', type: 'Transfer', from: 'UserE', to: 'UserF', amount: '10,000 SPEC' },
    ];

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-xl font-bold text-neutral-100 mb-6">Live Solana Transactions</h3>
      <div className="font-mono text-sm text-neutral-300 bg-black/30 p-4 rounded-lg h-64 overflow-y-auto custom-scrollbar">
        {transactions.map((tx, index) => (
          <div key={index} className="flex items-center gap-4 mb-2">
            <span className="text-neutral-500">[{tx.sig}]</span>
            <span className="text-purple-400">{tx.type.padEnd(10)}</span>
            <span className="text-blue-400">{tx.from}</span>
            <ArrowRight className="w-4 h-4 text-neutral-500" />
            <span className="text-green-400">{tx.to}</span>
            <span className="text-yellow-400 ml-auto">{tx.amount}</span>
          </div>
        ))}
      </div>
    </div>
  );
}