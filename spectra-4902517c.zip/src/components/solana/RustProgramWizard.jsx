import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Wand2, Copy, Zap, AlertCircle } from 'lucide-react';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

export default function RustProgramWizard({ onDeploy }) {
  const [config, setConfig] = useState({
    programName: 'MyToken',
    tokenName: 'My Awesome Token',
    tokenSymbol: 'MAT',
    totalSupply: 1000000,
    decimals: 9,
    programType: 'spl_token',
    features: {
      mintable: true,
      burnable: true,
      freezable: false,
      transferFeeConfig: false,
    },
  });
  const [generatedCode, setGeneratedCode] = useState('');
  const [copied, setCopied] = useState(false);

  const handleConfigChange = (e) => {
    const { name, value, type } = e.target;
    setConfig(prev => ({ ...prev, [name]: type === 'number' ? parseFloat(value) || 0 : value }));
  };

  const handleFeatureChange = (feature, value) => {
    setConfig(prev => ({
      ...prev,
      features: { ...prev.features, [feature]: value }
    }));
  };

  useEffect(() => {
    const generateCode = () => {
      const { programName, tokenName, tokenSymbol, totalSupply, decimals, features } = config;
      
      let dependencies = `[dependencies]
anchor-lang = "0.29.0"
anchor-spl = "0.29.0"
spl-token = "4.0.0"`;

      if (features.transferFeeConfig) {
        dependencies += `\nspl-token-2022 = "1.0.0"`;
      }

      const code = `use anchor_lang::prelude::*;
use anchor_spl::{
    associated_token::AssociatedToken,
    token::{self, Mint, Token, TokenAccount, Transfer, MintTo, Burn},
};

declare_id!("${generateProgramId()}");

#[program]
pub mod ${programName.toLowerCase().replace(/[^a-z0-9]/g, '_')} {
    use super::*;

    pub fn initialize_mint(
        ctx: Context<InitializeMint>,
        decimals: u8,
        mint_authority: Pubkey,
        freeze_authority: Option<Pubkey>,
    ) -> Result<()> {
        msg!("Initializing mint for ${tokenName}");
        msg!("Token Symbol: ${tokenSymbol}");
        msg!("Total Supply: ${totalSupply}");
        msg!("Decimals: {}", decimals);
        Ok(())
    }

    ${features.mintable ? `
    pub fn mint_tokens(
        ctx: Context<MintTokens>,
        amount: u64,
    ) -> Result<()> {
        let cpi_accounts = MintTo {
            mint: ctx.accounts.mint.to_account_info(),
            to: ctx.accounts.token_account.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::mint_to(cpi_ctx, amount)?;
        msg!("Minted {} tokens to {}", amount, ctx.accounts.token_account.key());
        Ok(())
    }` : ''}

    ${features.burnable ? `
    pub fn burn_tokens(
        ctx: Context<BurnTokens>,
        amount: u64,
    ) -> Result<()> {
        let cpi_accounts = Burn {
            mint: ctx.accounts.mint.to_account_info(),
            from: ctx.accounts.token_account.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::burn(cpi_ctx, amount)?;
        msg!("Burned {} tokens from {}", amount, ctx.accounts.token_account.key());
        Ok(())
    }` : ''}

    pub fn transfer_tokens(
        ctx: Context<TransferTokens>,
        amount: u64,
    ) -> Result<()> {
        let cpi_accounts = Transfer {
            from: ctx.accounts.from.to_account_info(),
            to: ctx.accounts.to.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        
        token::transfer(cpi_ctx, amount)?;
        msg!("Transferred {} tokens", amount);
        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializeMint<'info> {
    #[account(
        init,
        payer = payer,
        mint::decimals = ${decimals},
        mint::authority = payer,
        ${features.freezable ? 'mint::freeze_authority = payer,' : ''}
    )]
    pub mint: Account<'info, Mint>,
    #[account(mut)]
    pub payer: Signer<'info>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub rent: Sysvar<'info, Rent>,
}

${features.mintable ? `
#[derive(Accounts)]
pub struct MintTokens<'info> {
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    #[account(mut)]
    pub token_account: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}` : ''}

${features.burnable ? `
#[derive(Accounts)]
pub struct BurnTokens<'info> {
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    #[account(mut)]
    pub token_account: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}` : ''}

#[derive(Accounts)]
pub struct TransferTokens<'info> {
    #[account(mut)]
    pub from: Account<'info, TokenAccount>,
    #[account(mut)]
    pub to: Account<'info, TokenAccount>,
    pub authority: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

// Program Errors
#[error_code]
pub enum ${programName}Error {
    #[msg("Insufficient funds")]
    InsufficientFunds,
    #[msg("Unauthorized")]
    Unauthorized,
    #[msg("Invalid amount")]
    InvalidAmount,
}`;

      setGeneratedCode(code);
    };

    generateCode();
  }, [config]);

  const generateProgramId = () => {
    const chars = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
    let result = '';
    for (let i = 0; i < 44; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  };
  
  const copyCode = () => {
    navigator.clipboard.writeText(generatedCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDeployClick = () => {
    const estimatedAddress = generateProgramId();
    
    onDeploy({
      name: config.programName,
      code: generatedCode,
      estimatedAddress,
      tokenName: config.tokenName,
      tokenSymbol: config.tokenSymbol,
      totalSupply: config.totalSupply,
      decimals: config.decimals,
      features: config.features,
      programType: config.programType
    });
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left side: Configuration */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-neutral-100">
            <Wand2 className="w-6 h-6" style={{ color: '#00FFA3' }} />
            Solana Program Wizard
          </CardTitle>
          <CardDescription className="text-neutral-400">
            Define your SPL token's properties, and a deployable Rust program will be generated.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="programName">Program Name</Label>
            <Input id="programName" name="programName" value={config.programName} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="programType">Program Type</Label>
            <Select value={config.programType} onValueChange={(value) => setConfig(prev => ({ ...prev, programType: value }))}>
              <SelectTrigger className="bg-white/5 border-white/20">
                <SelectValue placeholder="Select program type" />
              </SelectTrigger>
              <SelectContent className="glass-card border-white/20 text-neutral-200">
                <SelectItem value="spl_token">SPL Token</SelectItem>
                <SelectItem value="nft_collection">NFT Collection</SelectItem>
                <SelectItem value="defi_protocol">DeFi Protocol</SelectItem>
                <SelectItem value="custom">Custom Program</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="tokenName">Token Name</Label>
              <Input id="tokenName" name="tokenName" value={config.tokenName} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="tokenSymbol">Token Symbol</Label>
              <Input id="tokenSymbol" name="tokenSymbol" value={config.tokenSymbol} onChange={handleConfigChange} className="bg-white/5 border-white/20" maxLength="10" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="totalSupply">Total Supply</Label>
              <Input id="totalSupply" name="totalSupply" type="number" value={config.totalSupply} onChange={handleConfigChange} className="bg-white/5 border-white/20" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="decimals">Decimals</Label>
              <Input id="decimals" name="decimals" type="number" value={config.decimals} onChange={handleConfigChange} className="bg-white/5 border-white/20" min="0" max="18" />
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-white/10">
            <h4 className="font-medium text-neutral-200">Program Features</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Switch id="mintable" checked={config.features.mintable} onCheckedChange={(v) => handleFeatureChange('mintable', v)} />
                <Label htmlFor="mintable">Mintable</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="burnable" checked={config.features.burnable} onCheckedChange={(v) => handleFeatureChange('burnable', v)} />
                <Label htmlFor="burnable">Burnable</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="freezable" checked={config.features.freezable} onCheckedChange={(v) => handleFeatureChange('freezable', v)} />
                <Label htmlFor="freezable">Freezable</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="transferFeeConfig" checked={config.features.transferFeeConfig} onCheckedChange={(v) => handleFeatureChange('transferFeeConfig', v)} />
                <Label htmlFor="transferFeeConfig">Transfer Fees</Label>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Right side: Generated Code */}
      <Card className="glass-card flex flex-col">
        <CardHeader>
          <CardTitle className="text-neutral-100">Generated Rust Code</CardTitle>
          <CardDescription className="text-neutral-400">
            This Anchor program is generated based on your configuration.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-grow flex flex-col">
          <div className="relative flex-grow">
            <Textarea
              readOnly
              value={generatedCode}
              className="w-full h-full font-mono text-xs bg-black/50 border-white/20 custom-scrollbar resize-none"
            />
            <Button size="sm" variant="ghost" className="absolute top-2 right-2 h-7" onClick={copyCode}>
              <Copy className="w-3 h-3 mr-1" />
              {copied ? 'Copied!' : 'Copy'}
            </Button>
          </div>
          <Alert className="mt-4" style={{ backgroundColor: '#00FFA320', borderColor: '#00FFA350' }}>
            <AlertCircle className="w-4 h-4" style={{ color: '#00FFA3' }} />
            <AlertTitle style={{ color: '#00FFA3' }}>Anchor Framework</AlertTitle>
            <AlertDescription style={{ color: '#00FFA380' }}>
              This program uses Anchor, the leading framework for Solana development with automatic security checks.
            </AlertDescription>
          </Alert>
          <Button className="w-full mt-4 text-white" style={{ background: 'linear-gradient(to right, #8b5cf6, #00FFA3)' }} onClick={handleDeployClick}>
            <Zap className="w-4 h-4 mr-2" />
            Deploy this Program
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}