import React from 'react';
import { Link as LinkIcon, CheckCircle, AlertTriangle, RefreshCw } from 'lucide-react';

export default function RpcEndpointManager() {
  const endpoints = [
    { name: 'Mainnet-Beta (Public)', url: 'api.mainnet-beta.solana.com', status: 'online', ping: 45 },
    { name: 'Triton RPC Pool', url: 'solana-mainnet.rpc.triton.one', status: 'online', ping: 32 },
    { name: 'Helius RPC', url: 'mainnet.helius-rpc.com', status: 'online', ping: 25 },
    { name: 'Testnet RPC', url: 'api.testnet.solana.com', status: 'degraded', ping: 120, message: 'High Latency' },
  ];

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-neutral-100">RPC Endpoint Manager</h3>
        <button className="flex items-center gap-2 text-sm px-3 py-1.5 rounded-md border border-white/20 text-neutral-300 hover:bg-white/10 transition-colors">
          <RefreshCw className="w-4 h-4" />
          Test All
        </button>
      </div>
      <div className="space-y-4">
        {endpoints.map((ep, index) => (
          <div key={index} className="glass-effect rounded-lg p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <LinkIcon className="w-5 h-5 text-neutral-400" />
              <div>
                <p className="font-semibold text-neutral-200">{ep.name}</p>
                <p className="text-xs text-neutral-500 font-mono">{ep.url}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm font-mono text-neutral-300">{ep.ping}ms</span>
              <div className={`flex items-center gap-2 px-2 py-1 rounded-full text-xs ${
                ep.status === 'online' ? 'bg-green-500/20 text-green-400' : 'bg-yellow-500/20 text-yellow-400'
              }`}>
                {ep.status === 'online' ? <CheckCircle className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                <span className="capitalize">{ep.status}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}