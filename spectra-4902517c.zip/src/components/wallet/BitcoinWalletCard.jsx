
import React, { useState, useEffect } from "react";
import { Copy, Send, Download, ArrowUpDown, Wallet, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities";
import WalletActionModal from "./WalletActionModal";

const BitcoinLogo = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="12" cy="12" r="12" fill="#F7931A"/>
    <path d="M15.68 10.79c.18-1.2-.73-1.85-1.98-2.28l.4-1.63-1-.25-.4 1.59c-.26-.07-.53-.13-.8-.19l.4-1.6-1-.25-.4 1.63c-.22-.05-.43-.1-.64-.15l0 0-1.38-.34-.27 1.06s.74.17.72.18c.41.1.48.37.47.58l-.47 1.88c.03.01.07.02.11.04-.04-.01-.08-.02-.11-.03l-.66 2.63c-.05.12-.18.31-.47.24.01.01-.72-.18-.72-.18l-.49 1.14 1.3.32c.24.06.48.13.71.19l-.4 1.64 1 .25.4-1.62c.27.07.53.14.79.2l-.4 1.61 1 .25.4-1.64c1.67.32 2.93.19 3.46-1.33.43-1.22-.02-1.93-.9-2.39.64-.15 1.12-.57 1.25-1.44zm-2.24 3.14c-.3 1.22-2.36.56-3.02.4l.54-2.16c.66.17 2.81.49 2.48 1.76zm.31-3.15c-.28 1.11-1.99.55-2.55.41l.49-1.96c.56.14 2.35.4 2.06 1.55z" fill="white"/>
  </svg>
);

export default function BitcoinWalletCard({ address, balance = 0 }) {
  const [copied, setCopied] = useState(false);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  if (!address) {
    return (
      <div className="glass-card rounded-2xl p-6 h-full flex flex-col justify-center">
        <div className="text-center py-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-orange-500 rounded-xl flex items-center justify-center">
            <BitcoinLogo />
          </div>
          <h3 className="text-lg font-semibold text-neutral-100 mb-2">Bitcoin Wallet</h3>
          <p className="text-neutral-400 mb-6">Create or import your Bitcoin wallet to get started.</p>
          
          <div className="space-y-3">
            <Button
              className="w-full bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white"
              onClick={() => alert('Bitcoin wallet creation - use Create Additional Wallets section')}
            >
              <Wallet className="w-4 h-4 mr-2" />
              Create Bitcoin Wallet
            </Button>

            <Button
              variant="outline"
              className="w-full border-white/20 hover:bg-white/10"
              onClick={() => alert('Import wallet functionality - use External Wallet Import from main wallet page')}
            >
              Import Existing Wallet
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-r from-orange-400/10 to-yellow-500/10 rounded-full blur-3xl -translate-y-8 translate-x-8"></div>
        
        <div className="relative z-10 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-orange-500 rounded-xl flex items-center justify-center crypto-glow">
                <BitcoinLogo />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">Bitcoin Wallet</h3>
                <p className="text-sm text-neutral-400">Imported Wallet</p>
              </div>
            </div>
          </div>

          {/* Balance Display */}
          <div className="mb-6">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-bold text-neutral-100">
                {balance.toFixed(8)}
              </span>
              <span className="text-lg text-neutral-400">BTC</span>
            </div>
          </div>

          {/* Address Details */}
          <div className="mb-6 space-y-3 flex-grow">
            <div>
              <p className="text-xs text-neutral-400 mb-2">Bitcoin Address</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-3">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">
                  {address}
                </span>
                <Button variant="ghost" size="icon" onClick={copyAddress} className="h-7 w-7">
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
              {copied && <p className="text-xs text-green-400 mt-1">Address copied!</p>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Button className="bg-gradient-to-r from-orange-500 to-yellow-500 hover:from-orange-600 hover:to-yellow-600 text-white" onClick={() => handleAction('send')}>
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
              <Download className="w-4 h-4 mr-1" />
              Receive
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Swap
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType="BTC"
        walletAddress={address}
        balance={balance}
        user={user}
      />
    </>
  );
}
