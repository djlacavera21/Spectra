
import React from "react";
import { DollarSign, Eye, EyeOff, Copy, Send, Download, ArrowUpDown, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import WalletActionModal from "./WalletActionModal";
import { User } from "@/api/entities";

export default function StablecoinWalletCard({ title, tokenSymbol, balance, address, iconBgClass }) {
  const [showBalance, setShowBalance] = React.useState(true);
  const [copied, setCopied] = React.useState(false);
  const [actionModal, setActionModal] = React.useState({ isOpen: false, action: null });
  const [user, setUser] = React.useState(null);

  React.useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!address) {
    return (
      <div className="glass-card rounded-2xl p-6 h-full flex flex-col justify-center">
        <div className="text-center py-8">
          <div className={`w-16 h-16 mx-auto mb-4 ${iconBgClass} rounded-xl flex items-center justify-center`}>
            <DollarSign className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-lg font-semibold text-neutral-100 mb-2">{title}</h3>
          <p className="text-neutral-400 mb-6">Create your {tokenSymbol} wallet to get started.</p>
          
          <div className="space-y-3">
            <Button 
              onClick={() => alert(`Create ${tokenSymbol} wallet functionality - use Create Additional Wallets section`)}
              className={`w-full ${iconBgClass} hover:opacity-90 text-white`}
            >
              <Wallet className="w-4 h-4 mr-2" />
              Create {tokenSymbol} Wallet
            </Button>
            
            <p className="text-xs text-neutral-500">
              ERC-20 token on Ethereum network
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col">
        <div className={`absolute top-0 right-0 w-40 h-40 ${iconBgClass}/20 rounded-full blur-3xl -translate-y-8 translate-x-8`}></div>
        <div className={`absolute bottom-0 left-0 w-32 h-32 ${iconBgClass}/15 rounded-full blur-2xl translate-y-4 -translate-x-4`}></div>
        
        <div className="relative z-10 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 ${iconBgClass} rounded-xl flex items-center justify-center crypto-glow`}>
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">{title}</h3>
                <div className="flex items-center gap-2">
                  <p className="text-sm text-neutral-400">ERC-20 Stablecoin</p>
                  <Badge className="bg-green-500/20 text-green-400 text-xs">Active</Badge>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => setShowBalance(!showBalance)}>
              {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          </div>

          <div className="mb-6">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-bold text-neutral-100">
                {showBalance ? balance?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "••••••"}
              </span>
              <span className="text-lg text-neutral-400">{tokenSymbol}</span>
            </div>
            <div className="text-sm text-neutral-400">
              ≈ ${showBalance ? balance?.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2}) : "••••"} USD
            </div>
          </div>

          <div className="mb-6 space-y-3 flex-grow">
            <div>
              <p className="text-xs text-neutral-400 mb-2">Wallet Address (ERC-20)</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-3">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">
                  {address}
                </span>
                <Button variant="ghost" size="icon" onClick={copyAddress} className="h-7 w-7">
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            </div>
            
            {copied && (
              <p className="text-xs text-green-400 mt-1">Address copied!</p>
            )}
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Button className={`bg-gradient-to-r ${iconBgClass === 'bg-gray-500' ? 'from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700' : 'from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600'} text-white`} onClick={() => handleAction('send')}>
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
              <Download className="w-4 h-4 mr-1" />
              Receive
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Swap
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType={tokenSymbol}
        walletAddress={address}
        balance={balance}
        user={user}
      />
    </>
  );
}
