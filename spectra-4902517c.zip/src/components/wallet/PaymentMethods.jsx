import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Banknote, CreditCard, MoreHorizontal, Trash2 } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import AddPaymentMethodModal from './AddPaymentMethodModal';

const paymentMethodsData = [
  {
    id: 1,
    type: 'credit_card',
    brand: 'Visa',
    last4: '4242',
    expiry: '12/26',
    icon: CreditCard
  },
  {
    id: 2,
    type: 'bank_account',
    name: 'Chase Bank',
    last4: '9876',
    icon: Banknote
  },
];

const PaymentMethodCard = ({ method, onRemove }) => {
  return (
    <div className="flex items-center justify-between p-4 glass-effect rounded-lg">
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
          <method.icon className="w-6 h-6 text-cyan-400" />
        </div>
        <div>
          <h4 className="font-semibold text-neutral-100">
            {method.type === 'credit_card' ? `${method.brand} **** ${method.last4}` : method.name}
          </h4>
          <p className="text-sm text-neutral-400">
            {method.type === 'credit_card' ? `Expires ${method.expiry}` : `Account ending in ${method.last4}`}
          </p>
        </div>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon" className="h-8 w-8">
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="glass-effect border-white/10">
          <DropdownMenuItem onClick={() => onRemove(method.id)} className="text-red-400 focus:text-red-400 focus:bg-red-500/10">
            <Trash2 className="w-4 h-4 mr-2" />
            Remove
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default function PaymentMethods({ user, onRefresh }) {
  const [methods, setMethods] = useState(paymentMethodsData);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const addPaymentMethod = () => {
    setIsModalOpen(true);
  };
  
  const handleMethodAdded = (newMethod) => {
    setMethods(prevMethods => [...prevMethods, newMethod]);
    setIsModalOpen(false);
  };

  const removePaymentMethod = (id) => {
    if(window.confirm("Are you sure you want to remove this payment method?")) {
      setMethods(methods.filter(m => m.id !== id));
    }
  };

  return (
    <>
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-neutral-100">
              <CreditCard className="w-6 h-6 text-green-400" />
              Payment Methods
            </CardTitle>
            <Button onClick={addPaymentMethod} className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
              <Plus className="w-4 h-4 mr-2" />
              Add Method
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {methods.length > 0 ? (
            <div className="space-y-4">
              {methods.map(method => (
                <PaymentMethodCard key={method.id} method={method} onRemove={removePaymentMethod} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Banknote className="w-16 h-16 text-neutral-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-neutral-300 mb-2">No Payment Methods</h3>
              <p className="text-neutral-400 mb-6">Add a bank account or credit card to buy crypto.</p>
              <Button onClick={addPaymentMethod}>
                Add Payment Method
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      <AddPaymentMethodModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onMethodAdded={handleMethodAdded}
      />
    </>
  );
}