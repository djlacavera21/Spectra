import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ExternalWallet } from '@/api/entities';
import { Loader2, AlertTriangle, Key, Book } from 'lucide-react';

export default function ExternalWalletImport({ isOpen, onClose, onImportComplete }) {
  const [walletName, setWalletName] = useState('');
  const [network, setNetwork] = useState('ethereum');
  const [importMethod, setImportMethod] = useState('private_key');
  const [privateKey, setPrivateKey] = useState('');
  const [seedPhrase, setSeedPhrase] = useState('');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // In a real implementation, you would use a robust cryptographic library like ethers.js or web3.js
  const deriveAddressFromPrivateKey = (pk) => `0x...${pk.slice(-4)}`;
  const deriveAddressFromSeed = (seed) => `0x...${seed.split(' ')[0].slice(-4)}`;

  const handleImport = async () => {
    setError('');
    if (!walletName || !network) {
      setError('Please provide a wallet name and select a network.');
      return;
    }

    let address = '';
    let encryptedKey = '';
    let encryptedSeed = '';

    if (importMethod === 'private_key') {
      if (!privateKey) {
        setError('Please provide a private key.');
        return;
      }
      address = deriveAddressFromPrivateKey(privateKey);
      encryptedKey = `encrypted_${privateKey}`; // Placeholder for real encryption
    } else {
      if (!seedPhrase) {
        setError('Please provide a seed phrase.');
        return;
      }
      address = deriveAddressFromSeed(seedPhrase);
      encryptedSeed = `encrypted_${seedPhrase}`; // Placeholder for real encryption
    }

    setIsProcessing(true);
    try {
      await ExternalWallet.create({
        wallet_name: walletName,
        address: address,
        network: network,
        import_method: importMethod,
        private_key_encrypted: encryptedKey,
        seed_phrase_encrypted: encryptedSeed,
        is_validated: true, // Assuming validation happens here
      });

      alert('Wallet imported successfully!');
      onImportComplete();
      
    } catch (e) {
      setError('Failed to import wallet. Please try again.');
      console.error(e);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle>Import External Wallet</DialogTitle>
          <DialogDescription>
            Import an existing wallet using a private key or seed phrase.
            Keys will be stored encrypted.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Never share your private keys or seed phrase. Importing exposes your keys to this application. Proceed with caution.
            </AlertDescription>
          </Alert>

          <div>
            <Label htmlFor="wallet-name">Wallet Name</Label>
            <Input id="wallet-name" value={walletName} onChange={(e) => setWalletName(e.target.value)} placeholder="e.g., My MetaMask" />
          </div>

          <div>
            <Label htmlFor="network">Network</Label>
            <Select value={network} onValueChange={setNetwork}>
              <SelectTrigger>
                <SelectValue placeholder="Select a network" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ethereum">Ethereum</SelectItem>
                <SelectItem value="bitcoin">Bitcoin</SelectItem>
                <SelectItem value="solana">Solana</SelectItem>
                <SelectItem value="polygon">Polygon</SelectItem>
                <SelectItem value="bsc">BNB Smart Chain</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex gap-2">
            <Button onClick={() => setImportMethod('private_key')} variant={importMethod === 'private_key' ? 'default' : 'outline'} className="flex-1">
              <Key className="w-4 h-4 mr-2" /> Private Key
            </Button>
            <Button onClick={() => setImportMethod('seed_phrase')} variant={importMethod === 'seed_phrase' ? 'default' : 'outline'} className="flex-1">
              <Book className="w-4 h-4 mr-2" /> Seed Phrase
            </Button>
          </div>

          {importMethod === 'private_key' ? (
            <div>
              <Label htmlFor="private-key">Private Key</Label>
              <Input id="private-key" type="password" value={privateKey} onChange={(e) => setPrivateKey(e.target.value)} />
            </div>
          ) : (
            <div>
              <Label htmlFor="seed-phrase">Seed Phrase (12 or 24 words)</Label>
              <Textarea id="seed-phrase" value={seedPhrase} onChange={(e) => setSeedPhrase(e.target.value)} />
            </div>
          )}

          {error && <p className="text-sm text-red-400">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isProcessing}>Cancel</Button>
          <Button onClick={handleImport} disabled={isProcessing}>
            {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Import Wallet
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}