import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle, 
  XCircle, 
  Activity,
  ExternalLink
} from "lucide-react";
import { format } from "date-fns";

const TransactionRow = ({ transaction, currentUserAddress }) => {
  const isOutgoing = transaction.from_address === currentUserAddress;
  const TransactionIcon = isOutgoing ? ArrowUpRight : ArrowDownLeft;

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed': return 'bg-green-500/20 text-green-400';
      case 'pending': return 'bg-yellow-500/20 text-yellow-400';
      case 'failed': return 'bg-red-500/20 text-red-400';
      default: return 'bg-neutral-500/20 text-neutral-400';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'confirmed': return <CheckCircle className="w-3 h-3" />;
      case 'pending': return <Clock className="w-3 h-3" />;
      case 'failed': return <XCircle className="w-3 h-3" />;
      default: return <Activity className="w-3 h-3" />;
    }
  };

  return (
    <div className="flex items-center justify-between p-4 glass-effect rounded-lg hover:bg-neutral-900 transition-colors">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
          isOutgoing ? 'bg-red-500/20' : 'bg-green-500/20'
        }`}>
          <TransactionIcon className={`w-5 h-5 ${
            isOutgoing ? 'text-red-400' : 'text-green-400'
          }`} />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-neutral-200 capitalize">
              {transaction.transaction_type.replace('_', ' ')}
            </span>
            <Badge className={`text-xs ${getStatusColor(transaction.status)}`}>
              <div className="flex items-center gap-1">
                {getStatusIcon(transaction.status)}
                {transaction.status}
              </div>
            </Badge>
          </div>
          <div className="text-xs text-neutral-400">
            {format(new Date(transaction.created_date), 'MMM d, HH:mm')}
          </div>
        </div>
      </div>
      <div className="text-right">
        <div className={`font-semibold ${
          isOutgoing ? 'text-red-400' : 'text-green-400'
        }`}>
          {isOutgoing ? '-' : '+'}{transaction.amount.toLocaleString()} {transaction.metadata?.from_token || 'SPEC'}
        </div>
        <div className="text-xs text-neutral-400 font-mono">
          {transaction.transaction_hash ? `...${transaction.transaction_hash.slice(-8)}` : 'N/A'}
        </div>
      </div>
    </div>
  );
};

export default function TransactionHistory({ transactions = [], currentUserAddress }) {
  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-neutral-100">Recent Transactions</CardTitle>
          <Button variant="outline" size="sm" className="text-neutral-200 border-white/20 hover:bg-white/10">
            <ExternalLink className="w-4 h-4 mr-2" />
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions && transactions.length > 0 ? (
            transactions.map((transaction) => (
              <TransactionRow
                key={transaction.id}
                transaction={transaction}
                currentUserAddress={currentUserAddress}
              />
            ))
          ) : (
            <div className="text-center py-8 text-neutral-400 flex flex-col items-center justify-center h-full">
              <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>No transactions yet</p>
              <p className="text-sm text-neutral-500 mt-1">Your transaction history will appear here</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}