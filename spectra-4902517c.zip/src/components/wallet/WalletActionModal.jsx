import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Transaction } from '@/api/entities';
import { useSignature } from '../common/SignatureContext';
import { AlertTriangle, Copy, Loader2, QrCode } from 'lucide-react';

export default function WalletActionModal({ isOpen, onClose, action, asset, user, onTransactionComplete }) {
  const [amount, setAmount] = useState('');
  const [toAddress, setToAddress] = useState('');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { requestSignature } = useSignature();

  const handleSend = () => {
    if (!amount || !toAddress) {
      setError('Please fill in all fields.');
      return;
    }

    const sendAmount = parseFloat(amount);
    if (isNaN(sendAmount) || sendAmount <= 0) {
      setError('Invalid amount.');
      return;
    }
    
    // This is a simplified check. A real implementation would check the correct asset balance.
    if (sendAmount > user.spec_balance) {
        setError('Insufficient balance.');
        return;
    }

    const transactionDetails = {
      from: user.wallet_address,
      to: toAddress,
      amount: sendAmount,
      asset: asset,
      fee: 0.001, // Example fee
      action: 'Asset Transfer'
    };

    requestSignature(
      transactionDetails,
      async () => { // onConfirm
        setIsProcessing(true);
        setError('');
        try {
          await Transaction.create({
            from_address: user.wallet_address,
            to_address: toAddress,
            amount: sendAmount,
            transaction_type: 'transfer',
            status: 'pending',
            metadata: { asset: asset }
          });
          
          // In a real system, the balance update would happen after blockchain confirmation.
          // Here, we simulate it for UI feedback.
          
          alert('Transaction sent for processing!');
          onTransactionComplete();
        } catch (e) {
          setError('Failed to create transaction. Please try again.');
          console.error(e);
        } finally {
          setIsProcessing(false);
        }
      },
      () => { // onReject
        setError('Transaction rejected.');
      }
    );
  };
  
  const copyAddress = () => {
    navigator.clipboard.writeText(user.wallet_address);
    alert('Address copied to clipboard!');
  }

  const renderContent = () => {
    if (action === 'send') {
      return (
        <div className="space-y-4">
          <div>
            <Label htmlFor="toAddress">Recipient Address</Label>
            <Input 
              id="toAddress" 
              value={toAddress} 
              onChange={(e) => setToAddress(e.target.value)}
              placeholder="0x..."
            />
          </div>
          <div>
            <Label htmlFor="amount">Amount ({asset})</Label>
            <Input 
              id="amount" 
              type="number" 
              value={amount} 
              onChange={(e) => setAmount(e.target.value)}
              placeholder="0.00"
            />
          </div>
        </div>
      );
    }

    if (action === 'receive') {
      return (
        <div className="space-y-4 text-center">
          <p className="text-sm text-neutral-400">
            Share this address to receive {asset}.
          </p>
          <div className="p-4 bg-black/20 rounded-lg">
            {/* In a real app, we'd generate a real QR code */}
            <QrCode className="w-32 h-32 mx-auto text-neutral-200" />
          </div>
          <div className="font-mono p-3 bg-black/20 rounded-lg break-all">
            {user?.wallet_address}
          </div>
          <Button onClick={copyAddress} className="w-full">
            <Copy className="w-4 h-4 mr-2" />
            Copy Address
          </Button>
        </div>
      );
    }

    return null;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card">
        <DialogHeader>
          <DialogTitle className="capitalize">{action} {asset}</DialogTitle>
          <DialogDescription>
            {action === 'send' 
              ? `Enter the details to send ${asset}.` 
              : `Your address to receive ${asset}.`}
          </DialogDescription>
        </DialogHeader>
        
        {error && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {renderContent()}
        
        {action === 'send' && (
          <DialogFooter>
            <Button variant="outline" onClick={onClose} disabled={isProcessing}>Cancel</Button>
            <Button onClick={handleSend} disabled={isProcessing}>
              {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Continue
            </Button>
          </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}