
import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Wallet, 
  ArrowRight, 
  Shield, 
  AlertTriangle,
  Copy,
  ExternalLink,
  Zap,
  Clock,
  CheckCircle,
  Key,
  Loader2,
  XCircle,
  Send
} from 'lucide-react';
import { User, Transaction } from '@/api/entities';
import { useSignature } from '../common/SignatureContext';
import { isValidSpecAddress } from '@/components/common/WalletUtils'; // Corrected import path

// This is a simplified Base58 decoder for demonstration.
const base58 = {
  alphabet: '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz',
  decode: (encoded) => {
    // A real implementation would convert the Base58 string back to a byte buffer.
    // This is just for validation logic.
    return encoded.split('').map(char => base58.alphabet.indexOf(char));
  }
};


const TransactionSigningModal = ({ isOpen, onClose, asset, userAddress, userBalance }) => {
  const [recipientAddress, setRecipientAddress] = useState('');
  const [amount, setAmount] = useState('');
  const [feeRate, setFeeRate] = useState('medium');
  const [customFee, setCustomFee] = useState('');
  const [transactionData, setTransactionData] = useState(null);
  const [networkFees, setNetworkFees] = useState({
    slow: { rate: 1, fee: 0.00001, time: '60+ min' },
    medium: { rate: 10, fee: 0.0001, time: '10-20 min' },
    fast: { rate: 20, fee: 0.0002, time: '1-3 min' }
  });
  const [isCalculating, setIsCalculating] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [addressValid, setAddressValid] = useState(null); // null, true, false
  const { requestSignature } = useSignature();

  useEffect(() => {
    if (isOpen && asset) {
      loadNetworkFees();
    }
  }, [isOpen, asset]);

  useEffect(() => {
    setAddressValid(null);
    if (recipientAddress) {
      validateAddress(recipientAddress);
    }
  }, [recipientAddress, asset]);

  useEffect(() => {
    if (recipientAddress && amount && addressValid) {
      calculateTransaction();
    } else {
      setTransactionData(null);
    }
  }, [recipientAddress, amount, feeRate, customFee, addressValid]);

  const loadNetworkFees = async () => {
    try {
      if (asset === 'BTC') {
        const response = await fetch('https://mempool.space/api/v1/fees/recommended');
        const fees = await response.json();
        const txSize = 250; // Average tx size in bytes
        setNetworkFees({
          slow: { rate: fees.economyFee, fee: fees.economyFee * txSize * 1e-8, time: '60+ min' },
          medium: { rate: fees.halfHourFee, fee: fees.halfHourFee * txSize * 1e-8, time: '10-30 min' },
          fast: { rate: fees.fastestFee, fee: fees.fastestFee * txSize * 1e-8, time: '1-10 min' }
        });
      }
    } catch (error) {
      console.error('Failed to load network fees:', error);
    }
  };

  const validateAddress = (address) => {
    let isValid = false;
    switch (asset) {
      case 'SPEC':
        // Real, robust address validation for SPEC tokens using the utility function
        isValid = isValidSpecAddress(address);
        break;
      case 'BTC':
        const btcRegex = /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,39}$/;
        isValid = btcRegex.test(address);
        break;
      case 'ETH':
      case 'USDC':
      case 'USDT':
        const ethRegex = /^0x[a-fA-F0-9]{40}$/;
        isValid = ethRegex.test(address);
        break;
      case 'SOL':
        const solRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
        isValid = solRegex.test(address);
        break;
      default:
        isValid = false;
    }
    setAddressValid(isValid);
  };

  const calculateTransaction = async () => {
    if (!amount || !recipientAddress || !addressValid) return;
    
    setIsCalculating(true);
    try {
      const amountFloat = parseFloat(amount);
      if (isNaN(amountFloat) || amountFloat <= 0) {
        setTransactionData(null);
        return;
      }

      // Simulate UTXO selection and transaction construction
      await new Promise(res => setTimeout(res, 300)); // Simulate network latency

      const selectedFee = feeRate === 'custom' ? (parseFloat(customFee) || 0) : networkFees[feeRate].fee;
      const totalCost = amountFloat + selectedFee;

      setTransactionData({
        from: userAddress,
        to: recipientAddress,
        sendAmount: amountFloat,
        fee: selectedFee,
        total: totalCost,
        hasSufficientFunds: userBalance >= totalCost,
      });

    } catch (error) {
      console.error('Error calculating transaction:', error);
    } finally {
      setIsCalculating(false);
    }
  };

  const handleSignAndSend = () => {
    if (!transactionData || !transactionData.hasSufficientFunds) return;
    
    const signatureDetails = {
      from: transactionData.from,
      to: transactionData.to,
      amount: transactionData.sendAmount,
      fee: transactionData.fee.toFixed(8),
      total: transactionData.total.toFixed(8),
      asset: asset,
      metadata: { action: `${asset} Transfer` },
      data: `0x... (Real signed transaction data for ${asset})`
    };

    requestSignature(signatureDetails, onConfirmSend, onRejectSend);
  };

  const onConfirmSend = async () => {
    setIsProcessing(true);
    try {
      // Real transaction broadcasting would happen here
      await new Promise(res => setTimeout(res, 1500)); 

      const txHash = '0x' + Array.from(crypto.getRandomValues(new Uint8Array(32))).map(b => b.toString(16).padStart(2, '0')).join('');

      await Transaction.create({
        from_address: transactionData.from,
        to_address: transactionData.to,
        amount: transactionData.sendAmount,
        gas_fee: transactionData.fee,
        transaction_type: 'transfer',
        status: 'pending',
        transaction_hash: txHash,
        metadata: { asset: asset }
      });
      
      alert(`Transaction for ${transactionData.sendAmount} ${asset} has been signed and broadcast!`);
      onClose();

    } catch (error) {
      console.error('Transaction failed:', error);
      alert("An error occurred during the transaction. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const onRejectSend = () => {
    alert("Transaction rejected by user.");
  };
  
  const getAddressInputStyle = () => {
    if (recipientAddress === '') return {};
    if (addressValid) return { borderColor: 'hsl(var(--primary))' };
    return { borderColor: 'hsl(var(--destructive))' };
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="glass-card max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-neutral-100">
            <Send className="w-5 h-5" />
            Send {asset}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <label className="text-sm text-neutral-400">Recipient Address</label>
            <div className="relative">
              <Input
                placeholder={`Enter ${asset} address`}
                value={recipientAddress}
                onChange={(e) => setRecipientAddress(e.target.value)}
                style={getAddressInputStyle()}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2">
                {addressValid === true && <CheckCircle className="w-4 h-4 text-green-400" />}
                {addressValid === false && recipientAddress !== '' && <XCircle className="w-4 h-4 text-red-400" />}
              </div>
            </div>
            {addressValid === false && recipientAddress !== '' && (
              <p className="text-xs text-red-400 mt-1">Invalid {asset} address format.</p>
            )}
          </div>

          <div>
            <label className="text-sm text-neutral-400">Amount</label>
            <div className="relative">
              <Input
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
              <Button variant="ghost" size="sm" className="absolute right-1 top-1/2 -translate-y-1/2" onClick={() => setAmount(userBalance.toString())}>
                Max
              </Button>
            </div>
            <p className="text-xs text-neutral-500 mt-1">Balance: {userBalance} {asset}</p>
          </div>

          <div>
            <label className="text-sm text-neutral-400 mb-2 block">Network Fee</label>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(networkFees).map(([speed, {fee, time}]) => (
                <Button 
                  key={speed} 
                  variant={feeRate === speed ? 'default' : 'outline'}
                  onClick={() => setFeeRate(speed)}
                  className="flex flex-col h-auto items-start p-2"
                >
                  <span className="capitalize font-bold">{speed}</span>
                  <span className="text-xs">{fee.toFixed(6)} {asset}</span>
                  <span className="text-xs text-neutral-400">{time}</span>
                </Button>
              ))}
            </div>
          </div>

          {transactionData && (
            <Card className="glass-effect p-4">
              <CardContent className="p-0 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Sending</span>
                  <span>{transactionData.sendAmount} {asset}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Network Fee</span>
                  <span>{transactionData.fee.toFixed(8)} {asset}</span>
                </div>
                <hr className="border-white/10" />
                <div className="flex justify-between font-bold">
                  <span className="text-neutral-300">Total</span>
                  <span>{transactionData.total.toFixed(8)} {asset}</span>
                </div>
                {!transactionData.hasSufficientFunds && (
                  <Alert variant="destructive" className="mt-2">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>Insufficient funds.</AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )}

          <Button 
            className="w-full"
            disabled={!transactionData || !transactionData.hasSufficientFunds || isProcessing}
            onClick={handleSignAndSend}
          >
            {isProcessing ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Shield className="w-4 h-4 mr-2" />
            )}
            Sign & Send
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default TransactionSigningModal;
