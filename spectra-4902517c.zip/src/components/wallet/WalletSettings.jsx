import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Settings, Bell, Clock, Eye, Palette } from "lucide-react";

const SettingRow = ({ icon, title, description, children }) => (
  <div className="flex items-start justify-between p-4 glass-effect rounded-lg">
    <div className="flex items-start gap-4">
      <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
        {icon}
      </div>
      <div>
        <h4 className="font-semibold text-neutral-100">{title}</h4>
        <p className="text-sm text-neutral-400">{description}</p>
      </div>
    </div>
    <div className="flex items-center">{children}</div>
  </div>
);

export default function WalletSettings({ user, onRefresh }) {
  const [settings, setSettings] = useState({
    session_timeout: 30,
    primary_currency: 'USD',
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (user) {
      setSettings({
        session_timeout: user.session_timeout || 30,
        primary_currency: 'USD', // Placeholder as not in schema
      });
    }
  }, [user]);

  const handleSettingChange = async (key, value) => {
    setIsLoading(true);
    try {
      const newSettings = { ...settings, [key]: value };
      
      // Only update fields that exist in the User schema
      const updateData = {};
      if (key in user) {
        updateData[key] = value;
      }
      
      if(Object.keys(updateData).length > 0) {
        await User.updateMyUserData(updateData);
      }
      
      setSettings(newSettings);
      onRefresh();
      alert("Settings updated successfully.");
    } catch (error) {
      console.error("Failed to update setting:", error);
      alert("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <Settings className="w-6 h-6 text-gray-400" />
          Wallet Settings
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <SettingRow
          icon={<Palette className="w-5 h-5 text-blue-400" />}
          title="Primary Currency"
          description="Display values in your preferred currency."
        >
          <Select 
            value={settings.primary_currency}
            onValueChange={(val) => handleSettingChange('primary_currency', val)}
            disabled={isLoading}
          >
            <SelectTrigger className="w-[120px] bg-white/5 border-white/20">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="glass-effect">
              <SelectItem value="USD">USD</SelectItem>
              <SelectItem value="EUR">EUR</SelectItem>
              <SelectItem value="GBP">GBP</SelectItem>
              <SelectItem value="BTC">BTC</SelectItem>
            </SelectContent>
          </Select>
        </SettingRow>

        <SettingRow
          icon={<Clock className="w-5 h-5 text-orange-400" />}
          title="Session Timeout"
          description="Automatically log out after a period of inactivity."
        >
          <div className="flex items-center gap-2">
            <Input
              type="number"
              value={settings.session_timeout}
              onChange={(e) => setSettings({...settings, session_timeout: e.target.value})}
              className="w-20"
              disabled={isLoading}
            />
            <span className="text-sm text-neutral-400">minutes</span>
          </div>
        </SettingRow>
        <div className="flex justify-end">
            <Button onClick={() => handleSettingChange('session_timeout', settings.session_timeout)} disabled={isLoading}>
                {isLoading ? 'Saving...' : 'Save All Settings'}
            </Button>
        </div>
      </CardContent>
    </Card>
  );
}