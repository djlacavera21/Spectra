
import React, { useState, useEffect } from "react";
import { Copy, Send, Download, ArrowUpDown, ExternalLink, Loader2, Wallet } from "lucide-react";
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities";
import WalletActionModal from "./WalletActionModal";

const EthereumLogo = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M12 2.25L11.56 2.96L5.63 11.58L12 15.42L18.37 11.58L12.44 2.96L12 2.25Z" fill="#C0C0C0"/>
    <path d="M12 16.59L5.63 12.75L12 21.75L18.37 12.75L12 16.59Z" fill="#A9A9A9"/>
    <path d="M12 15.42L18.37 11.58L12 2.25V15.42Z" fill="#DCDCDC"/>
    <path d="M12 2.25L5.63 11.58L12 15.42V2.25Z" fill="#F0F0F0"/>
    <path d="M12 16.59L12 21.75L18.37 12.75L12 16.59Z" fill="#E0E0E0"/>
    <path d="M12 21.75L12 16.59L5.63 12.75L12 21.75Z" fill="#C8C8C8"/>
  </svg>
);

export default function EthWalletCard({ address }) {
  const [isConnecting, setIsConnecting] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const connectMetaMask = async () => {
    setIsConnecting(true);
    try {
      if (window.ethereum) {
        const accounts = await window.ethereum.request({
          method: 'eth_requestAccounts'
        });
        
        if (accounts.length > 0) {
          await User.updateMyUserData({
            eth_wallet_address: accounts[0],
            eth_balance: 0
          });
          
          window.location.reload();
        }
      } else {
        window.open('https://metamask.io/', '_blank');
        alert('MetaMask not detected. Please install MetaMask extension.');
      }
    } catch (error) {
      console.error('Failed to connect MetaMask:', error);
      alert('Failed to connect MetaMask. Please try again.');
    } finally {
      setIsConnecting(false);
    }
  };

  if (!address) {
    return (
      <div className="glass-card rounded-2xl p-6 h-full flex flex-col justify-center">
        <div className="text-center py-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-600 rounded-xl flex items-center justify-center">
            <EthereumLogo />
          </div>
          <h3 className="text-lg font-semibold text-neutral-100 mb-2">Ethereum Wallet</h3>
          <p className="text-neutral-400 mb-6">Connect your Ethereum wallet to get started.</p>
          
          <div className="space-y-3">
            <Button
              onClick={connectMetaMask}
              disabled={isConnecting}
              className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white"
            >
              {isConnecting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Wallet className="w-4 h-4 mr-2" />
                  Connect MetaMask
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              className="w-full border-white/20 hover:bg-white/10"
              onClick={() => alert('Import wallet functionality - use External Wallet Import from main wallet page')}
            >
              Import Existing Wallet
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // If address exists, show the full wallet card with real-time data
  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-r from-gray-400/10 to-gray-500/10 rounded-full blur-3xl -translate-y-8 translate-x-8"></div>
      
        <div className="relative z-10 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-neutral-700 rounded-xl flex items-center justify-center crypto-glow">
                <EthereumLogo />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">Ethereum Wallet</h3>
                <p className="text-sm text-neutral-400">Connected via MetaMask</p>
              </div>
            </div>
          </div>

          {/* Address Details */}
          <div className="mb-6 space-y-3 flex-grow">
            <div>
              <p className="text-xs text-neutral-400 mb-2">Wallet Address</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-3">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">
                  {address}
                </span>
                <div className="flex">
                  <Button variant="ghost" size="icon" onClick={copyAddress} className="h-7 w-7">
                    <Copy className="w-3 h-3" />
                  </Button>
                  <a href={`https://etherscan.io/address/${address}`} target="_blank" rel="noopener noreferrer">
                    <Button variant="ghost" size="icon" className="h-7 w-7">
                      <ExternalLink className="w-3 h-3" />
                    </Button>
                  </a>
                </div>
              </div>
              {copied && <p className="text-xs text-green-400 mt-1">Address copied!</p>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white" onClick={() => handleAction('send')}>
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
              <Download className="w-4 h-4 mr-1" />
              Receive
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Swap
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType="ETH"
        walletAddress={address}
        balance={user?.eth_balance || 0}
        user={user}
      />
    </>
  );
}
