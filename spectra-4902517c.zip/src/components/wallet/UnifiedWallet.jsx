import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Server, 
  Snowflake, 
  Thermometer, 
  Zap,
  Shield,
  Key,
  Lock,
  AlertTriangle,
  CheckCircle,
  ArrowUpDown,
  Eye,
  EyeOff
} from 'lucide-react';
import { VaultMovement, User } from '@/api/entities';

const UnifiedWallet = ({ user, vaultMovements, onRefresh }) => {
  const [walletTiers, setWalletTiers] = useState({
    cold: {
      name: 'Cold Storage',
      balance: 0,
      percentage: 0,
      status: 'secured',
      description: 'Offline, HSM-signed transactions',
      icon: Snowflake,
      color: 'text-blue-400',
      bgColor: 'bg-blue-500/20'
    },
    warm: {
      name: 'Warm Storage', 
      balance: 0,
      percentage: 0,
      status: 'active',
      description: 'Withdrawal delay buffer',
      icon: Thermometer,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/20'
    },
    hot: {
      name: 'Hot Wallet',
      balance: 0,
      percentage: 0,
      status: 'active',
      description: 'Limited balance auto-disbursal',
      icon: Zap,
      color: 'text-red-400',
      bgColor: 'bg-red-500/20'
    }
  });

  const [showBalances, setShowBalances] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    calculateWalletDistribution();
  }, [user, vaultMovements]);

  const calculateWalletDistribution = () => {
    const totalBalance = (user?.spec_balance || 0) + (user?.vault_balance || 0);
    const vaultBalance = user?.vault_balance || 0;
    const hotBalance = user?.spec_balance || 0;
    
    // Simulated distribution based on typical exchange security practices
    const coldBalance = vaultBalance * 0.80; // 80% in cold storage
    const warmBalance = vaultBalance * 0.15; // 15% in warm storage
    const actualHotBalance = hotBalance + (vaultBalance * 0.05); // 5% + user balance in hot

    setWalletTiers(prev => ({
      cold: {
        ...prev.cold,
        balance: coldBalance,
        percentage: totalBalance > 0 ? (coldBalance / totalBalance) * 100 : 0
      },
      warm: {
        ...prev.warm,
        balance: warmBalance,
        percentage: totalBalance > 0 ? (warmBalance / totalBalance) * 100 : 0
      },
      hot: {
        ...prev.hot,
        balance: actualHotBalance,
        percentage: totalBalance > 0 ? (actualHotBalance / totalBalance) * 100 : 0
      }
    }));
  };

  const initiateTierMovement = async (fromTier, toTier, amount) => {
    if (!amount || amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    setIsProcessing(true);
    try {
      await VaultMovement.create({
        movement_type: `${fromTier}_to_${toTier}`,
        asset: 'SPEC',
        amount: amount,
        initiated_by: user.wallet_address,
        status: 'pending_approval',
        notes: `Multi-tier wallet movement: ${amount} SPEC from ${fromTier} to ${toTier}`
      });

      alert(`Movement initiated: ${amount} SPEC from ${fromTier} to ${toTier} storage`);
      onRefresh();
    } catch (error) {
      console.error('Movement failed:', error);
      alert('Movement failed: ' + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const WalletTierCard = ({ tierKey, tier }) => {
    const IconComponent = tier.icon;
    
    return (
      <Card className="glass-card hover:border-blue-500/50 transition-all">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 ${tier.bgColor} rounded-xl flex items-center justify-center`}>
                <IconComponent className={`w-6 h-6 ${tier.color}`} />
              </div>
              <div>
                <CardTitle className="text-lg">{tier.name}</CardTitle>
                <p className="text-sm text-neutral-400">{tier.description}</p>
              </div>
            </div>
            <Badge className={`${tier.bgColor} ${tier.color}`}>
              {tier.status.toUpperCase()}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-neutral-400">Balance</span>
              <span className="font-bold text-neutral-100">
                {showBalances ? `${tier.balance.toLocaleString()} SPEC` : '••••••••'}
              </span>
            </div>
            <Progress value={tier.percentage} className="w-full h-2" />
            <div className="flex justify-between items-center text-xs text-neutral-500">
              <span>Allocation</span>
              <span>{tier.percentage.toFixed(1)}%</span>
            </div>
          </div>

          {tierKey === 'cold' && (
            <div className="space-y-2 pt-2 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <Shield className="w-3 h-3" />
                <span>HSM Protected</span>
              </div>
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <Key className="w-3 h-3" />
                <span>Multi-sig Required</span>
              </div>
            </div>
          )}

          {tierKey === 'warm' && (
            <div className="space-y-2 pt-2 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <Lock className="w-3 h-3" />
                <span>24h Withdrawal Delay</span>
              </div>
            </div>
          )}

          {tierKey === 'hot' && (
            <div className="space-y-2 pt-2 border-t border-white/10">
              <div className="flex items-center gap-2 text-xs text-neutral-400">
                <Zap className="w-3 h-3" />
                <span>Instant Transactions</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-neutral-100">Multi-Tier Wallet System</h2>
          <p className="text-neutral-400">Kraken-level security architecture with Cold/Warm/Hot storage</p>
        </div>
        <Button
          variant="outline"
          onClick={() => setShowBalances(!showBalances)}
          className="border-white/20 text-neutral-200 hover:bg-white/10"
        >
          {showBalances ? <EyeOff className="w-4 h-4 mr-2" /> : <Eye className="w-4 h-4 mr-2" />}
          {showBalances ? 'Hide' : 'Show'} Balances
        </Button>
      </div>

      {/* Security Notice */}
      <Alert className="bg-blue-500/20 border-blue-500/30">
        <Shield className="w-4 h-4 text-blue-400" />
        <AlertDescription className="text-blue-400">
          <strong>Multi-Tier Security:</strong> Your assets are distributed across three security tiers. 
          Cold storage provides maximum security, while hot wallets enable instant transactions.
        </AlertDescription>
      </Alert>

      {/* Wallet Tiers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {Object.entries(walletTiers).map(([key, tier]) => (
          <WalletTierCard key={key} tierKey={key} tier={tier} />
        ))}
      </div>

      {/* Movement Controls */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ArrowUpDown className="w-5 h-5" />
            Inter-Tier Movement Controls
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              onClick={() => initiateTierMovement('cold', 'warm', 1000)}
              disabled={isProcessing}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Cold → Warm
            </Button>
            <Button 
              onClick={() => initiateTierMovement('warm', 'hot', 500)}
              disabled={isProcessing}
              className="bg-yellow-600 hover:bg-yellow-700"
            >
              Warm → Hot
            </Button>
            <Button 
              onClick={() => initiateTierMovement('hot', 'warm', 100)}
              disabled={isProcessing}
              className="bg-red-600 hover:bg-red-700"
            >
              Hot → Warm
            </Button>
          </div>
          
          <Alert className="bg-yellow-500/20 border-yellow-500/30">
            <AlertTriangle className="w-4 h-4 text-yellow-400" />
            <AlertDescription className="text-yellow-400">
              <strong>Security Notice:</strong> All tier movements require multi-signature approval and may have delay periods for security.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Recent Movements */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle>Recent Tier Movements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {vaultMovements.slice(0, 5).map((movement) => (
              <div key={movement.id} className="glass-effect rounded-lg p-3">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-medium text-neutral-200">
                      {movement.movement_type.replace('_to_', ' → ').toUpperCase()}
                    </p>
                    <p className="text-sm text-neutral-400">
                      {movement.amount.toLocaleString()} {movement.asset}
                    </p>
                    <p className="text-xs text-neutral-500">
                      {new Date(movement.created_date).toLocaleString()}
                    </p>
                  </div>
                  <Badge className={
                    movement.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                    movement.status === 'processing' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-neutral-500/20 text-neutral-400'
                  }>
                    {movement.status.replace('_', ' ').toUpperCase()}
                  </Badge>
                </div>
              </div>
            ))}
            
            {vaultMovements.length === 0 && (
              <div className="text-center py-8 text-neutral-400">
                <Server className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No tier movements yet</p>
                <p className="text-sm">Fund movements between tiers will appear here</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default UnifiedWallet;