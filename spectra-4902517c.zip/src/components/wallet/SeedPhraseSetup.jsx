import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Shield, 
  Eye, 
  EyeOff, 
  Copy, 
  RefreshCw,
  CheckCircle,
  AlertTriangle,
  Lock,
  Download
} from "lucide-react";

const WORD_LIST = [
  "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
  "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
  "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
  "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "against", "age",
  "agent", "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol",
  "alert", "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also",
  "alter", "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient",
  "anger", "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna",
  "antique", "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch",
  "arctic", "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange",
  "arrest", "arrive", "arrow", "art", "artefact", "artist", "artwork", "ask", "aspect", "assault",
  "asset", "assist", "assume", "asthma", "athlete", "atom", "attack", "attend", "attitude", "attract",
  "auction", "audit", "august", "aunt", "author", "auto", "autumn", "average", "avocado", "avoid"
];

export default function SeedPhraseSetup({ onComplete, user }) {
  const [step, setStep] = useState(1);
  const [seedPhrase, setSeedPhrase] = useState([]);
  const [showPhrase, setShowPhrase] = useState(false);
  const [confirmationWords, setConfirmationWords] = useState({});
  const [confirmationIndexes] = useState([3, 7, 11]); // Random positions to verify
  const [hasConfirmedSecurity, setHasConfirmedSecurity] = useState(false);
  const [hasDownloaded, setHasDownloaded] = useState(false);

  const generateSeedPhrase = () => {
    const phrase = [];
    for (let i = 0; i < 12; i++) {
      const randomIndex = Math.floor(Math.random() * WORD_LIST.length);
      phrase.push(WORD_LIST[randomIndex]);
    }
    setSeedPhrase(phrase);
  };

  React.useEffect(() => {
    if (step === 1 && seedPhrase.length === 0) {
      generateSeedPhrase();
    }
  }, [step, seedPhrase.length]);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(seedPhrase.join(' '));
    alert('Seed phrase copied to clipboard!');
  };

  const downloadSeedPhrase = () => {
    const element = document.createElement("a");
    const file = new Blob([`SPECTRA WALLET SEED PHRASE\n\nWallet Address: ${user?.wallet_address}\nGenerated: ${new Date().toISOString()}\n\nSeed Phrase:\n${seedPhrase.join(' ')}\n\nIMPORTANT SECURITY NOTICE:\n- Never share this seed phrase with anyone\n- Store it in a secure location\n- This is the only way to recover your wallet\n- Spectra cannot help you recover a lost seed phrase`], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = `spectra-wallet-${user?.wallet_address?.slice(0, 8)}-seedphrase.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    setHasDownloaded(true);
  };

  const handleConfirmationChange = (index, value) => {
    setConfirmationWords(prev => ({
      ...prev,
      [index]: value.toLowerCase()
    }));
  };

  const isConfirmationComplete = () => {
    return confirmationIndexes.every(index => 
      confirmationWords[index] === seedPhrase[index]
    );
  };

  const handleComplete = () => {
    if (isConfirmationComplete() && hasConfirmedSecurity) {
      onComplete(seedPhrase.join(' '));
    }
  };

  if (step === 1) {
    return (
      <div className="glass-card rounded-xl p-6 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-8 h-8 text-yellow-400" />
          <div>
            <h2 className="text-2xl font-bold text-neutral-100">Secure Your Wallet</h2>
            <p className="text-neutral-400">Your seed phrase is the key to your Spectra wallet</p>
          </div>
        </div>

        <Alert className="mb-6 bg-yellow-500/20 border-yellow-500/30">
          <AlertTriangle className="w-4 h-4 text-yellow-400" />
          <AlertDescription className="text-yellow-400">
            <strong>Critical Security Information:</strong> Write down your seed phrase and store it safely. 
            This is the only way to recover your wallet if you lose access.
          </AlertDescription>
        </Alert>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-neutral-100">Your Seed Phrase</h3>
            <div className="flex gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowPhrase(!showPhrase)}
                className="text-neutral-400 hover:text-neutral-100"
              >
                {showPhrase ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={copyToClipboard}
                className="text-neutral-400 hover:text-neutral-100"
              >
                <Copy className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={generateSeedPhrase}
                className="text-neutral-400 hover:text-neutral-100"
              >
                <RefreshCw className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 p-4 glass-effect rounded-lg">
            {seedPhrase.map((word, index) => (
              <div key={index} className="flex items-center gap-2 p-2 bg-white/5 rounded">
                <span className="text-xs text-neutral-500 w-6">{index + 1}.</span>
                <span className="text-neutral-200 font-mono">
                  {showPhrase ? word : '••••••'}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4 mb-6">
          <Button
            onClick={downloadSeedPhrase}
            variant="outline"
            className="w-full border-white/20 text-neutral-200 hover:bg-white/10"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Seed Phrase (Recommended)
          </Button>
          
          <div className="flex items-start space-x-2">
            <Checkbox 
              id="security-confirmation"
              checked={hasConfirmedSecurity}
              onCheckedChange={setHasConfirmedSecurity}
            />
            <label htmlFor="security-confirmation" className="text-sm text-neutral-300 leading-relaxed">
              I understand that I am responsible for keeping my seed phrase safe and that Spectra cannot recover it if lost. 
              I have written it down and stored it securely.
            </label>
          </div>
        </div>

        <Button
          onClick={() => setStep(2)}
          disabled={!hasConfirmedSecurity}
          className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-white"
        >
          Continue to Verification
        </Button>
      </div>
    );
  }

  if (step === 2) {
    return (
      <div className="glass-card rounded-xl p-6 max-w-2xl mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <CheckCircle className="w-8 h-8 text-green-400" />
          <div>
            <h2 className="text-2xl font-bold text-neutral-100">Verify Your Seed Phrase</h2>
            <p className="text-neutral-400">Enter the requested words to confirm you've saved your seed phrase</p>
          </div>
        </div>

        <div className="space-y-4 mb-6">
          {confirmationIndexes.map(index => (
            <div key={index}>
              <label className="block text-sm text-neutral-400 mb-2">
                Word #{index + 1}
              </label>
              <Input
                value={confirmationWords[index] || ''}
                onChange={(e) => handleConfirmationChange(index, e.target.value)}
                placeholder={`Enter word #${index + 1}`}
                className="bg-white/5 border-white/20 text-neutral-100"
              />
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => setStep(1)}
            className="flex-1 border-white/20 text-neutral-200 hover:bg-white/10"
          >
            Back
          </Button>
          <Button
            onClick={handleComplete}
            disabled={!isConfirmationComplete()}
            className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
          >
            Complete Setup
          </Button>
        </div>
      </div>
    );
  }

  return null;
}