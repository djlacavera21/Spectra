import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Copy,
  QrCode,
  ExternalLink
} from 'lucide-react';

const ReceiveModal = ({ isOpen, onClose, asset, address }) => {
  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert('Address copied to clipboard!');
  };

  const openBlockExplorer = () => {
    let explorerUrl = '';
    
    switch (asset) {
      case 'BTC':
        explorerUrl = `https://mempool.space/address/${address}`;
        break;
      case 'ETH':
      case 'USDC':
      case 'USDT':
        explorerUrl = `https://etherscan.io/address/${address}`;
        break;
      case 'SOL':
        explorerUrl = `https://explorer.solana.com/address/${address}`;
        break;
      default:
        explorerUrl = `https://hyperledger-explorer.spectra.io/address/${address}`;
    }
    
    window.open(explorerUrl, '_blank');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-black border border-neutral-700 text-neutral-200 max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl text-neutral-200">
            <QrCode className="w-6 h-6 text-green-400" />
            Receive {asset}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* QR Code Placeholder */}
          <Card className="bg-neutral-900 border-neutral-700">
            <CardContent className="p-6 flex items-center justify-center">
              <div className="w-48 h-48 bg-white rounded-lg flex items-center justify-center">
                <div className="text-center text-black">
                  <QrCode className="w-16 h-16 mx-auto mb-2" />
                  <p className="text-sm">QR Code for</p>
                  <p className="text-xs font-mono break-all">{address}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Address */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-neutral-200">Wallet Address</label>
            <div className="flex gap-2">
              <div className="flex-1 p-3 bg-neutral-900 border border-neutral-700 rounded-md font-mono text-sm break-all">
                {address}
              </div>
              <Button
                onClick={() => copyToClipboard(address)}
                size="icon"
                className="bg-neutral-700 hover:bg-neutral-600"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Warning */}
          <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
            <p className="text-yellow-300 text-sm">
              <strong>Important:</strong> Only send {asset} to this address. 
              Sending other cryptocurrencies may result in permanent loss.
            </p>
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={openBlockExplorer}
              className="flex-1 border-neutral-700 text-neutral-200 hover:bg-neutral-800"
            >
              <ExternalLink className="w-4 h-4 mr-2" />
              View on Explorer
            </Button>
            <Button
              onClick={onClose}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-800 text-white hover:from-green-700 hover:to-green-900 border-none"
            >
              Done
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ReceiveModal;