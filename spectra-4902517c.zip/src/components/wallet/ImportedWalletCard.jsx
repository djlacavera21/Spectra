
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Copy, Send, Download, ArrowUpDown, MoreVertical, Trash2 } from "lucide-react";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import WalletActionModal from "./WalletActionModal";
import { User } from "@/api/entities";
import { ExternalWallet } from "@/api/entities";

const networkIcons = {
  ethereum: { icon: '⟠', name: 'Ethereum' },
  bitcoin: { icon: '₿', name: 'Bitcoin' },
  solana: { icon: '◎', name: 'Solana' },
  polygon: { icon: '⬢', name: 'Polygon' },
  bsc: { icon: '🔶', name: 'BSC' },
};

export default function ImportedWalletCard({ wallet, onWalletDelete }) {
  const [copied, setCopied] = useState(false);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(wallet.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete the wallet "${wallet.wallet_name}"? This action cannot be undone.`)) {
        try {
            await ExternalWallet.delete(wallet.id);
            if(onWalletDelete) {
                onWalletDelete(wallet.id);
            }
            alert("Wallet deleted successfully.");
        } catch (error) {
            console.error("Failed to delete wallet:", error);
            alert("Failed to delete wallet. Please try again.");
        }
    }
  };

  const { icon, name } = networkIcons[wallet.network] || { icon: '?', name: 'Unknown' };

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-neutral-700 rounded-xl flex items-center justify-center crypto-glow">
                <span className="text-2xl">{icon}</span>
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">{wallet.wallet_name}</h3>
                <p className="text-sm text-neutral-400">{name}</p>
              </div>
            </div>
             <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-neutral-100">
                        <MoreVertical className="w-4 h-4" />
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="glass-effect border-white/10 text-neutral-200">
                    <DropdownMenuItem onSelect={handleDelete} className="text-red-400 focus:bg-red-500/20 focus:text-red-300 cursor-pointer">
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete Wallet
                    </DropdownMenuItem>
                </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="space-y-3">
            <div>
              <p className="text-xs text-neutral-400 mb-1">Wallet Address</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-2">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">{wallet.address}</span>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={copyAddress}>
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
              {copied && <p className="text-xs text-green-400 mt-1">Address copied!</p>}
            </div>
            <p className="text-xs text-neutral-500">Balance for imported wallets is fetched live when sending.</p>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 mt-6">
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('send')}>
            <Send className="w-4 h-4 mr-1" />
            Send
          </Button>
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
            <Download className="w-4 h-4 mr-1" />
            Receive
          </Button>
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
            <ArrowUpDown className="w-4 h-4 mr-1" />
            Swap
          </Button>
        </div>
      </div>

      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType={wallet.network.toUpperCase()}
        walletAddress={wallet.address}
        balance={0} // Balance fetched live in modal for imported wallets
        user={user}
        isImported={true}
      />
    </>
  );
}
