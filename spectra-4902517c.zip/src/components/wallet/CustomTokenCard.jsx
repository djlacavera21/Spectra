
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Send, Download, ArrowUpDown, ExternalLink, Info } from "lucide-react";
import { format } from "date-fns";
import WalletActionModal from "./WalletActionModal";
import { User } from "@/api/entities";

export default function CustomTokenCard({ token }) {
  const [copied, setCopied] = useState(false);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [user, setUser] = useState(null); // Added user state

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []); // Added useEffect to load user

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(token.wallet_address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col justify-between">
        {/* Custom coin header */}
        <div>
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center crypto-glow">
                <span className="text-white font-bold text-sm">{token.symbol}</span>
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">{token.name}</h3>
                <div className="flex items-center gap-2">
                  <p className="text-sm text-neutral-400">Custom Network</p>
                  <Badge className="bg-purple-500/20 text-purple-400 text-xs">Genesis Created</Badge>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-neutral-400 hover:text-neutral-100" title="Token Info">
              <Info className="w-4 h-4" />
            </Button>
          </div>

          {/* Token Balance */}
          <div className="mb-4">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-3xl font-bold text-neutral-100">
                {(token.balance || 0).toLocaleString(undefined, { minimumFractionDigits: 4, maximumFractionDigits: 8 })}
              </span>
              <span className="text-lg text-neutral-400">{token.symbol}</span>
            </div>
            <div className="flex items-center gap-4">
              <p className="text-sm text-neutral-400">
                Genesis Block: {token.genesis_block?.substring(0, 8)}...
              </p>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                <span className="text-xs text-purple-400">Custom</span>
              </div>
            </div>
          </div>

          {/* Token Details */}
          <div className="space-y-3 mb-6">
            <div>
              <p className="text-xs text-neutral-400 mb-1">Wallet Address</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-2">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">{token.wallet_address}</span>
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={copyAddress}>
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
              {copied && <p className="text-xs text-green-400 mt-1">Address copied!</p>}
            </div>
            
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="glass-effect rounded-lg p-2">
                <p className="text-neutral-400">Total Supply</p>
                <p className="text-neutral-200 font-medium">{(token.total_supply || 0).toLocaleString()}</p>
              </div>
              <div className="glass-effect rounded-lg p-2">
                <p className="text-neutral-400">Created</p>
                <p className="text-neutral-200 font-medium">
                  {token.created_date ? format(new Date(token.created_date), 'MMM d, yyyy') : 'Unknown'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-3 gap-3">
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('send')}>
            <Send className="w-4 h-4 mr-1" />
            Send
          </Button>
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
            <Download className="w-4 h-4 mr-1" />
            Receive
          </Button>
          <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => alert('Explorer coming soon!')}>
            <ExternalLink className="w-4 h-4 mr-1" />
            Explorer
          </Button>
        </div>
      </div>

      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType={token.symbol}
        walletAddress={token.wallet_address}
        balance={token.balance}
        user={user}
        isCustomToken={true}
      />
    </>
  );
}
