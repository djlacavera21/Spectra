import React, { useState, useEffect } from "react";
import { SecurityEvent } from "@/api/entities";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";
import {
  ShieldCheck,
  ShieldAlert,
  Key,
  LogIn,
  Smartphone,
  Globe,
  Lock,
} from "lucide-react";

const eventIcons = {
  login_success: <LogIn className="w-4 h-4 text-green-400" />,
  login_failed: <ShieldAlert className="w-4 h-4 text-red-400" />,
  password_change: <Key className="w-4 h-4 text-yellow-400" />,
  "2fa_enabled": <Smartphone className="w-4 h-4 text-green-400" />,
  "2fa_disabled": <Smartphone className="w-4 h-4 text-yellow-400" />,
  ip_whitelist_updated: <Globe className="w-4 h-4 text-blue-400" />,
  account_locked_by_user: <Lock className="w-4 h-4 text-red-400" />,
  account_locked_by_admin: <Lock className="w-4 h-4 text-red-400" />,
  account_unlocked_by_admin: <ShieldCheck className="w-4 h-4 text-green-400" />,
  security_settings_changed: <ShieldCheck className="w-4 h-4 text-blue-400" />,
  default: <ShieldCheck className="w-4 h-4 text-neutral-400" />,
};

const eventText = {
  login_success: "Successful login",
  login_failed: "Failed login attempt",
  password_change: "Password changed",
  "2fa_enabled": "Two-factor authentication enabled",
  "2fa_disabled": "Two-factor authentication disabled",
  ip_whitelist_updated: "IP whitelist updated",
  account_locked_by_user: "Account locked by user",
  account_locked_by_admin: "Account locked by admin",
  account_unlocked_by_admin: "Account unlocked by admin",
  security_settings_changed: "Security settings updated",
  default: "Security event",
};

export default function SecurityHistory({ user }) {
  const [events, setEvents] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (user?.wallet_address) {
      loadSecurityEvents();
    }
  }, [user]);

  const loadSecurityEvents = async () => {
    setIsLoading(true);
    try {
      const eventList = await SecurityEvent.filter(
        { user_wallet: user.wallet_address },
        "-created_date",
        50
      );
      setEvents(eventList);
    } catch (error) {
      console.error("Failed to load security events:", error);
      // If no records are found, or another error occurs, ensure the list is empty.
      setEvents([]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <h3 className="text-lg font-bold text-neutral-100 mb-4">Security History</h3>
      {isLoading ? (
        <div className="text-center py-8 text-neutral-400">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-white mx-auto mb-3"></div>
          Loading security history...
        </div>
      ) : events.length === 0 ? (
        <div className="text-center py-8 text-neutral-400">
          <ShieldCheck className="w-12 h-12 mx-auto mb-3 opacity-50" />
          <p>No security events recorded yet.</p>
          <p className="text-sm">Your security activity will appear here as you use the platform.</p>
        </div>
      ) : (
        <div className="space-y-4 max-h-96 overflow-y-auto custom-scrollbar pr-2">
          {events.map((event) => (
            <div key={event.id} className="flex items-start gap-4 p-3 glass-effect rounded-lg">
              <div className="mt-1">
                {eventIcons[event.event_type] || eventIcons.default}
              </div>
              <div className="flex-1">
                <p className="text-sm text-neutral-200">
                  {eventText[event.event_type] || eventText.default}
                </p>
                <p className="text-xs text-neutral-400">
                  {formatDistanceToNow(new Date(event.created_date), { addSuffix: true })}
                </p>
                {event.details && Object.keys(event.details).length > 0 && (
                  <p className="text-xs text-neutral-500 mt-1">
                    {event.details.setting && `Setting: ${event.details.setting}`}
                    {event.details.added && `Added: ${event.details.added}`}
                    {event.details.removed && `Removed: ${event.details.removed}`}
                    {event.details.reason && `Reason: ${event.details.reason}`}
                  </p>
                )}
              </div>
              <Badge variant="outline" className="border-white/20 text-neutral-300 text-xs">
                {event.ip_address}
              </Badge>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}