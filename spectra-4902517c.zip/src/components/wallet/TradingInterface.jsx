import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowRightLeft, TrendingUp, Loader2 } from 'lucide-react';
import { useSignature } from '../common/SignatureContext';

export default function TradingInterface({ user, portfolioData, onRefresh }) {
  const [fromAsset, setFromAsset] = useState('SPEC');
  const [toAsset, setToAsset] = useState('ETH');
  const [fromAmount, setFromAmount] = useState('');
  const [toAmount, setToAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { requestSignature } = useSignature();

  const assets = portfolioData?.assets || [];
  const fromAssetData = assets.find(a => a.symbol === fromAsset);
  const fromAssetBalance = fromAssetData?.balance || 0;

  const prices = {
    SPEC: 1.00,
    ETH: 2340.50,
    BTC: 43250.75,
    SOL: 95.30,
    USDC: 1.00,
    USDT: 1.00
  };

  useEffect(() => {
    if (fromAmount && prices[fromAsset] && prices[toAsset]) {
      const fromValue = parseFloat(fromAmount) * prices[fromAsset];
      const convertedToAmount = fromValue / prices[toAsset];
      setToAmount(convertedToAmount.toFixed(8));
    } else {
      setToAmount('');
    }
  }, [fromAmount, fromAsset, toAsset]);

  const handleSwap = () => {
    const numericFromAmount = parseFloat(fromAmount);
    if (!numericFromAmount || numericFromAmount <= 0) {
      alert("Please enter a valid amount.");
      return;
    }

    if (numericFromAmount > fromAssetBalance) {
      alert(`Insufficient balance. You have ${fromAssetBalance} ${fromAsset}.`);
      return;
    }

    const transactionDetails = {
      from: user.wallet_address,
      to: "SpectraSwapContract",
      amount: numericFromAmount,
      fee: (numericFromAmount * 0.003).toFixed(6), // 0.3% swap fee
      total: (numericFromAmount * 1.003).toFixed(6),
      metadata: {
        action: "Asset Swap",
        from: `${numericFromAmount} ${fromAsset}`,
        to: `${toAmount} ${toAsset}`
      },
      data: `0x... (swap data)`
    };

    requestSignature(
      transactionDetails,
      // onConfirm
      async () => {
        setIsProcessing(true);
        // Simulate backend processing
        await new Promise(resolve => setTimeout(resolve, 2000));
        alert(`Successfully swapped ${fromAmount} ${fromAsset} for ${toAmount} ${toAsset}!`);
        onRefresh(); // Refresh parent data
        setFromAmount('');
        setIsProcessing(false);
      },
      // onReject
      () => {
        alert("Swap cancelled.");
      }
    );
  };

  const setMaxAmount = () => {
    setFromAmount(fromAssetBalance.toString());
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-3 text-neutral-100">
          <TrendingUp className="w-6 h-6 text-purple-400" />
          Quick Trade
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <label className="text-sm text-neutral-400">You Sell</label>
            <span className="text-sm text-neutral-400">
              Balance: {fromAssetBalance.toFixed(4)}
            </span>
          </div>
          <div className="flex gap-2">
            <Select value={fromAsset} onValueChange={setFromAsset}>
              <SelectTrigger className="w-[120px] bg-white/5 border-white/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-effect">
                {assets.map(asset => (
                  <SelectItem key={asset.symbol} value={asset.symbol}>{asset.symbol}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="relative flex-grow">
              <Input
                type="number"
                placeholder="0.0"
                value={fromAmount}
                onChange={(e) => setFromAmount(e.target.value)}
                className="pr-12"
              />
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7"
                onClick={setMaxAmount}
              >
                Max
              </Button>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
            <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full" onClick={() => {
                const tempAsset = fromAsset;
                setFromAsset(toAsset);
                setToAsset(tempAsset);
            }}>
                <ArrowRightLeft className="w-4 h-4" />
            </Button>
        </div>

        <div className="space-y-2">
          <label className="text-sm text-neutral-400">You Buy</label>
          <div className="flex gap-2">
            <Select value={toAsset} onValueChange={setToAsset}>
              <SelectTrigger className="w-[120px] bg-white/5 border-white/20">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="glass-effect">
                {Object.keys(prices).map(symbol => (
                  <SelectItem key={symbol} value={symbol}>{symbol}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="number"
              placeholder="0.0"
              value={toAmount}
              readOnly
              className="bg-white/5"
            />
          </div>
        </div>

        <Button onClick={handleSwap} disabled={isProcessing} className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white">
          {isProcessing ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <ArrowRightLeft className="w-4 h-4 mr-2" />}
          {isProcessing ? 'Processing...' : 'Swap Assets'}
        </Button>
      </CardContent>
    </Card>
  );
}