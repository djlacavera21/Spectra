import React, { useState, useEffect } from "react";
import { User, SecurityEvent } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  ShieldCheck,
  Smartphone,
  Fingerprint,
  Mail,
  MessageSquare,
  Network,
  Lock,
  Loader2,
  History
} from "lucide-react";
import SecurityHistory from "./SecurityHistory";

const SecurityFeature = ({ icon, title, description, children }) => (
  <div className="flex items-start justify-between p-4 glass-effect rounded-lg">
    <div className="flex items-start gap-4">
      <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
        {icon}
      </div>
      <div>
        <h4 className="font-semibold text-neutral-100">{title}</h4>
        <p className="text-sm text-neutral-400">{description}</p>
      </div>
    </div>
    <div className="flex items-center">{children}</div>
  </div>
);

export default function SecurityCenter({ user, onRefresh }) {
  const [securitySettings, setSecuritySettings] = useState({
    two_factor_enabled: false,
    biometric_enabled: false,
    email_notifications: true,
    sms_notifications: false,
    ip_whitelisting: false,
    hardware_wallet_required: false,
  });
  const [securityScore, setSecurityScore] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [securityHistory, setSecurityHistory] = useState([]);

  useEffect(() => {
    if (user) {
      const settings = {
        two_factor_enabled: user.two_factor_enabled || false,
        biometric_enabled: user.biometric_enabled || false,
        email_notifications: user.email_notifications || true,
        sms_notifications: user.sms_notifications || false,
        ip_whitelisting: user.ip_whitelisting || false,
        hardware_wallet_required: user.hardware_wallet_required || false,
      };
      setSecuritySettings(settings);
      calculateSecurityScore(settings);
      loadSecurityHistory();
    }
  }, [user]);

  const loadSecurityHistory = async () => {
    if (user?.wallet_address) {
      const events = await SecurityEvent.filter({ user_wallet: user.wallet_address }, '-created_date', 10);
      setSecurityHistory(events);
    }
  };

  const calculateSecurityScore = (settings) => {
    let score = 20; // Base score
    if (settings.two_factor_enabled) score += 30;
    if (settings.biometric_enabled) score += 20;
    if (settings.ip_whitelisting) score += 15;
    if (settings.hardware_wallet_required) score += 15;
    setSecurityScore(score);
  };

  const handleSettingChange = async (key, value) => {
    setIsLoading(true);
    try {
      const newSettings = { ...securitySettings, [key]: value };
      await User.updateMyUserData({ [key]: value });
      
      // Log security event
      await SecurityEvent.create({
        user_wallet: user.wallet_address,
        event_type: "security_settings_changed",
        ip_address: user.last_login_ip || 'N/A',
        details: {
          setting: key,
          value: value
        }
      });
      
      setSecuritySettings(newSettings);
      calculateSecurityScore(newSettings);
      onRefresh(); // Refresh parent user data
      loadSecurityHistory();
    } catch (error) {
      console.error("Failed to update security setting:", error);
      alert("An error occurred. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const getScoreColor = (score) => {
    if (score > 80) return "bg-green-500";
    if (score > 50) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  const getScoreText = (score) => {
    if (score > 80) return "Excellent";
    if (score > 50) return "Good";
    return "Basic";
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main Security Settings */}
      <div className="lg:col-span-2 space-y-6">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-neutral-100">
              <ShieldCheck className="w-6 h-6 text-blue-400" />
              Security Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <SecurityFeature
              icon={<Smartphone className="w-5 h-5 text-purple-400" />}
              title="Two-Factor Authentication (2FA)"
              description="Secure your account with an authenticator app."
            >
              <Switch
                checked={securitySettings.two_factor_enabled}
                onCheckedChange={(val) => handleSettingChange('two_factor_enabled', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
            <SecurityFeature
              icon={<Fingerprint className="w-5 h-5 text-green-400" />}
              title="Biometric Login"
              description="Use Face ID or fingerprint for quick, secure access."
            >
              <Switch
                checked={securitySettings.biometric_enabled}
                onCheckedChange={(val) => handleSettingChange('biometric_enabled', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
            <SecurityFeature
              icon={<Network className="w-5 h-5 text-cyan-400" />}
              title="IP Address Whitelisting"
              description="Restrict account access to specific IP addresses."
            >
              <Switch
                checked={securitySettings.ip_whitelisting}
                onCheckedChange={(val) => handleSettingChange('ip_whitelisting', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
            <SecurityFeature
              icon={<Lock className="w-5 h-5 text-red-400" />}
              title="Hardware Wallet Requirement"
              description="Require a hardware wallet for all transactions."
            >
              <Switch
                checked={securitySettings.hardware_wallet_required}
                onCheckedChange={(val) => handleSettingChange('hardware_wallet_required', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
          </CardContent>
        </Card>
        
        <SecurityHistory history={securityHistory} />
      </div>

      {/* Security Score & Notifications */}
      <div className="space-y-6">
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-neutral-100">Security Score</CardTitle>
          </CardHeader>
          <CardContent className="text-center">
            <div className="relative w-32 h-32 mx-auto mb-4">
              <svg className="w-full h-full" viewBox="0 0 36 36">
                <path
                  className="text-white/10"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  strokeWidth="3"
                />
                <path
                  className={`transition-all duration-500 ${getScoreColor(securityScore).replace('bg-', 'text-')}`}
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  strokeWidth="3"
                  strokeDasharray={`${securityScore}, 100`}
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold text-neutral-100">{securityScore}</span>
                <span className="text-sm text-neutral-400">/ 100</span>
              </div>
            </div>
            <Badge className={`${getScoreColor(securityScore)} text-white`}>
              {getScoreText(securityScore)}
            </Badge>
            <p className="text-sm text-neutral-400 mt-4">
              Enable more features to increase your account's security score.
            </p>
          </CardContent>
        </Card>

        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="text-neutral-100">Notifications</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <SecurityFeature
              icon={<Mail className="w-5 h-5 text-blue-400" />}
              title="Email Alerts"
              description="Receive email alerts for logins and transactions."
            >
              <Switch
                checked={securitySettings.email_notifications}
                onCheckedChange={(val) => handleSettingChange('email_notifications', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
            <SecurityFeature
              icon={<MessageSquare className="w-5 h-5 text-yellow-400" />}
              title="SMS Alerts"
              description="Receive SMS alerts for critical security events."
            >
              <Switch
                checked={securitySettings.sms_notifications}
                onCheckedChange={(val) => handleSettingChange('sms_notifications', val)}
                disabled={isLoading}
              />
            </SecurityFeature>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}