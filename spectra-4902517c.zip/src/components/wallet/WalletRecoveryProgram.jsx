import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Key, 
  Eye, 
  EyeOff, 
  Copy,
  AlertTriangle,
  Lock,
  X
} from "lucide-react";

const WORD_LIST = [
  "abandon", "ability", "able", "about", "above", "absent", "absorb", "abstract", "absurd", "abuse",
  "access", "accident", "account", "accuse", "achieve", "acid", "acoustic", "acquire", "across", "act",
  "action", "actor", "actress", "actual", "adapt", "add", "addict", "address", "adjust", "admit",
  "adult", "advance", "advice", "aerobic", "affair", "afford", "afraid", "again", "against", "age",
  "agent", "agree", "ahead", "aim", "air", "airport", "aisle", "alarm", "album", "alcohol",
  "alert", "alien", "all", "alley", "allow", "almost", "alone", "alpha", "already", "also",
  "alter", "always", "amateur", "amazing", "among", "amount", "amused", "analyst", "anchor", "ancient",
  "anger", "angle", "angry", "animal", "ankle", "announce", "annual", "another", "answer", "antenna",
  "antique", "anxiety", "any", "apart", "apology", "appear", "apple", "approve", "april", "arch",
  "arctic", "area", "arena", "argue", "arm", "armed", "armor", "army", "around", "arrange",
  "arrest", "arrive", "arrow", "art", "artefact", "artist", "artwork", "ask", "aspect", "assault",
  "asset", "assist", "assume", "asthma", "athlete", "atom", "attack", "attend", "attitude", "attract",
  "auction", "audit", "august", "aunt", "author", "auto", "autumn", "average", "avocado", "avoid"
];

const InfoRow = ({ label, value, isSensitive = false, isMono = false }) => {
  const [show, setShow] = useState(!isSensitive);
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="glass-effect rounded-lg p-3">
      <div className="flex items-center justify-between">
        <p className="text-sm text-neutral-400">{label}</p>
        <div className="flex items-center gap-2">
          {isSensitive && (
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => setShow(!show)}>
              {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </Button>
          )}
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={copyToClipboard}>
            <Copy className="w-4 h-4" />
          </Button>
        </div>
      </div>
      <p className={`text-sm text-neutral-100 mt-1 break-all ${isMono ? 'font-mono' : ''}`}>
        {show ? value : '••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••••'}
      </p>
      {copied && <p className="text-xs text-green-400 mt-1">Copied!</p>}
    </div>
  );
};

export default function WalletRecoveryProgram({ user, onClose }) {
  const [step, setStep] = useState(1);
  const [agreed, setAgreed] = useState(false);
  const [walletData, setWalletData] = useState(null);

  useEffect(() => {
    // Simulate generating/retrieving wallet data once
    const generateWalletData = () => {
      // Regenerate seed phrase for demonstration
      const phrase = [];
      for (let i = 0; i < 12; i++) {
        const randomIndex = Math.floor(Math.random() * WORD_LIST.length);
        phrase.push(WORD_LIST[randomIndex]);
      }
      
      // Simulate derived keys
      const privateKey = '0x' + [...Array(64)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');
      const publicKey = '0x04' + [...Array(128)].map(() => Math.floor(Math.random() * 16).toString(16)).join('');

      setWalletData({
        seedPhrase: phrase.join(' '),
        derivationPath: "m/44'/60'/0'/0/0",
        privateKey,
        publicKey,
        address: user.eth_wallet_address,
      });
    };
    
    generateWalletData();
  }, [user.eth_wallet_address]);

  if (step === 1) {
    return (
      <div className="border border-red-500/30 bg-red-500/10 rounded-lg p-6 text-center">
        <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-red-400" />
        <h3 className="text-xl font-bold text-red-300 mb-2">EXTREME SECURITY WARNING</h3>
        <p className="text-red-400 mb-6">
          You are about to view your wallet's secret recovery phrase and private keys.
          Exposing this information can result in the PERMANENT LOSS of all your assets.
        </p>
        <div className="flex items-start space-x-3 mb-6 p-4 bg-black/20 rounded-lg">
          <Checkbox 
            id="security-agreement"
            checked={agreed}
            onCheckedChange={setAgreed}
            className="border-red-400 mt-1"
          />
          <label htmlFor="security-agreement" className="text-sm text-neutral-300 text-left">
            I understand that my seed phrase and private keys are my responsibility. I will not share them with anyone. I acknowledge the risk of total asset loss if this information is compromised.
          </label>
        </div>
        <div className="flex gap-4">
          <Button
            onClick={onClose}
            variant="outline"
            className="flex-1 border-white/20 text-neutral-200"
          >
            Cancel
          </Button>
          <Button
            onClick={() => setStep(2)}
            disabled={!agreed}
            className="flex-1 bg-gradient-to-r from-red-600 to-orange-700 text-white"
          >
            <Lock className="w-4 h-4 mr-2" />
            Proceed with Caution
          </Button>
        </div>
      </div>
    );
  }

  if (step === 2 && walletData) {
    return (
      <div>
        <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-neutral-100">Wallet Recovery Program</h3>
            <Button onClick={onClose} variant="ghost" size="icon" className="text-neutral-400">
                <X className="w-5 h-5" />
            </Button>
        </div>
        <div className="space-y-4">
          <InfoRow 
            label="Secret Recovery Phrase (Mnemonic)"
            value={walletData.seedPhrase}
            isSensitive
            isMono
          />
          <InfoRow 
            label="Derivation Path"
            value={walletData.derivationPath}
            isMono
          />
          <InfoRow 
            label="Private Key"
            value={walletData.privateKey}
            isSensitive
            isMono
          />
          <InfoRow 
            label="Public Key"
            value={walletData.publicKey}
            isMono
          />
          <InfoRow 
            label="Ethereum Address"
            value={walletData.address}
            isMono
          />
        </div>
      </div>
    );
  }

  return null;
}