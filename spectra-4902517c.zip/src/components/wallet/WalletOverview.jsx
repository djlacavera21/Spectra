
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Copy,
  Send,
  Download,
  Plus,
  Eye,
  EyeOff,
  ExternalLink,
  RefreshCw,
  Wallet,
  CheckCircle,
  Loader2
} from 'lucide-react';
import { User } from '@/api/entities';
import TransactionSigningModal from './TransactionSigningModal';
import ReceiveModal from './ReceiveModal';

// This is a simplified Base58 encoder for demonstration.
// A real implementation would use a robust library.
const base58 = {
  alphabet: '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz',
  encode: (buffer) => {
    let num = BigInt('0x' + buffer.map(b => b.toString(16).padStart(2, '0')).join(''));
    let encoded = '';
    while (num > 0) {
      const remainder = num % 58n;
      num = num / 58n;
      encoded = base58.alphabet[Number(remainder)] + encoded;
    }
    return encoded;
  }
};


const WalletOverview = ({ user, onWalletUpdate }) => {
  const [showBalances, setShowBalances] = useState(true);
  const [isGenerating, setIsGenerating] = useState({});
  const [copied, setCopied] = useState('');
  const [activeModal, setActiveModal] = useState(null);

  const getCryptoIcon = (symbol) => {
    const icons = {
      'SPEC': 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/644056fd9_6046321b2_logo.png',
      'BTC': 'https://assets.coingecko.com/coins/images/1/small/bitcoin.png',
      'ETH': 'https://assets.coingecko.com/coins/images/279/small/ethereum.png',
      'SOL': 'https://assets.coingecko.com/coins/images/4128/small/solana.png',
      'USDC': 'https://assets.coingecko.com/coins/images/6319/small/USD_Coin_icon.png',
      'USDT': 'https://assets.coingecko.com/coins/images/325/small/Tether.png'
    };
    return icons[symbol] || '/api/placeholder/32/32';
  };

  const copyToClipboard = (text, label) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(''), 2000);
  };

  const generateWalletAddress = async (network) => {
    setIsGenerating(prev => ({ ...prev, [network]: true }));

    try {
      let newAddress = '';

      switch (network) {
        case 'hyperledger':
          // Real SPEC address generation with checksum and prefix
          const payload = crypto.getRandomValues(new Uint8Array(20)); // Represents public key hash
          // A real checksum would be more complex (e.g., double-SHA256)
          const checksum = crypto.getRandomValues(new Uint8Array(4));
          const fullPayload = new Uint8Array([...payload, ...checksum]);
          newAddress = `spec_${base58.encode(fullPayload)}`;
          break;

        case 'ethereum':
          const ethAddressBytes = crypto.getRandomValues(new Uint8Array(20));
          newAddress = '0x' + Array.from(ethAddressBytes).map(b => b.toString(16).padStart(2, '0')).join('');
          break;

        case 'bitcoin':
          const btcKeyHash = crypto.getRandomValues(new Uint8Array(20));
          newAddress = '1' + base58.encode(btcKeyHash).padStart(33, '1');
          break;

        case 'solana':
          const solPubKey = crypto.getRandomValues(new Uint8Array(32));
          newAddress = base58.encode(solPubKey);
          break;

        case 'usdc':
        case 'usdt':
          const tokenAddressBytes = crypto.getRandomValues(new Uint8Array(20));
          newAddress = '0x' + Array.from(tokenAddressBytes).map(b => b.toString(16).padStart(2, '0')).join('');
          break;
        default:
          newAddress = '';
          break;
      }

      const updateData = {};
      const addressField = network === 'hyperledger' ? 'wallet_address' : `${network}_wallet_address`;
      updateData[addressField] = newAddress;

      await User.updateMyUserData(updateData);

      if (onWalletUpdate) {
        onWalletUpdate();
      }

    } catch (error) {
      console.error(`Failed to generate ${network} wallet:`, error);
      alert(`Failed to generate ${network} wallet address`);
    } finally {
      setIsGenerating(prev => ({ ...prev, [network]: false }));
    }
  };

  const handleSend = (asset) => {
    setActiveModal({ type: 'send', asset });
  };

  const handleReceive = (asset, address) => {
    if (!address) {
      alert('Please generate a wallet address first');
      return;
    }
    setActiveModal({ type: 'receive', asset, address });
  };

  const wallets = [
    {
      symbol: 'SPEC',
      name: 'Spectra',
      balance: user?.spec_balance || 0,
      address: user?.wallet_address,
      network: 'hyperledger',
      canGenerate: !user?.wallet_address,
      price: 1.00
    },
    {
      symbol: 'BTC',
      name: 'Bitcoin',
      balance: user?.btc_balance || 0,
      address: user?.btc_wallet_address,
      network: 'bitcoin',
      canGenerate: !user?.btc_wallet_address,
      price: 65000.00
    },
    {
      symbol: 'ETH',
      name: 'Ethereum',
      balance: user?.eth_balance || 0,
      address: user?.eth_wallet_address,
      network: 'ethereum',
      canGenerate: !user?.eth_wallet_address,
      price: 3500.00
    },
    {
      symbol: 'SOL',
      name: 'Solana',
      balance: user?.sol_balance || 0,
      address: user?.sol_wallet_address,
      network: 'solana',
      canGenerate: !user?.sol_wallet_address,
      price: 150.00
    },
    {
      symbol: 'USDC',
      name: 'USD Coin',
      balance: user?.usdc_balance || 0,
      address: user?.usdc_wallet_address,
      network: 'usdc',
      canGenerate: !user?.usdc_wallet_address,
      price: 1.00
    },
    {
      symbol: 'USDT',
      name: 'Tether',
      balance: user?.usdt_balance || 0,
      address: user?.usdt_wallet_address,
      network: 'usdt',
      canGenerate: !user?.usdt_wallet_address,
      price: 1.00
    },
  ];
  
  const formatAddress = (address) => {
    if (!address) return "Not Generated";
    return `${address.slice(0, 10)}...${address.slice(-6)}`;
  };

  return (
    <Card className="glass-card h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-3 text-neutral-100">
            <Wallet className="w-6 h-6 text-purple-400" />
            My Wallets
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-neutral-400 hover:text-white"
              onClick={() => setShowBalances(prev => !prev)}
            >
              {showBalances ? <Eye className="w-5 h-5" /> : <EyeOff className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {wallets.map((wallet) => (
            <div key={wallet.symbol} className="glass-effect p-4 rounded-lg">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <img src={getCryptoIcon(wallet.symbol)} alt={wallet.name} className="w-8 h-8 rounded-full" />
                  <div>
                    <p className="font-semibold text-neutral-100">{wallet.name}</p>
                    <p className="text-xs text-neutral-400">{wallet.symbol}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-neutral-100">
                    {showBalances ? `${wallet.balance.toLocaleString()} ${wallet.symbol}` : '••••••'}
                  </p>
                  <p className="text-xs text-neutral-400">
                    {showBalances ? `≈ $${(wallet.balance * wallet.price).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '••••••'}
                  </p>
                </div>
              </div>

              {wallet.address ? (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-mono text-xs text-neutral-400 flex-1 truncate">{wallet.address}</span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-6 w-6 text-neutral-400 hover:text-white"
                      onClick={() => copyToClipboard(wallet.address, wallet.symbol)}
                    >
                      {copied === wallet.symbol ? <CheckCircle className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button size="sm" variant="outline" className="text-xs" onClick={() => handleSend(wallet.symbol)}>
                      <Send className="w-3 h-3 mr-1" />
                      Send
                    </Button>
                    <Button size="sm" variant="outline" className="text-xs" onClick={() => handleReceive(wallet.symbol, wallet.address)}>
                      <Download className="w-3 h-3 mr-1" />
                      Receive
                    </Button>
                  </div>
                </div>
              ) : (
                <Button 
                  className="w-full"
                  onClick={() => generateWalletAddress(wallet.network)}
                  disabled={isGenerating[wallet.network]}
                >
                  {isGenerating[wallet.network] ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Plus className="w-4 h-4 mr-2" />
                  )}
                  Generate {wallet.symbol} Address
                </Button>
              )}
            </div>
          ))}
        </div>

        {activeModal?.type === 'send' && (
          <TransactionSigningModal
            isOpen={true}
            onClose={() => setActiveModal(null)}
            asset={activeModal.asset}
            userAddress={wallets.find(w => w.symbol === activeModal.asset)?.address}
            userBalance={wallets.find(w => w.symbol === activeModal.asset)?.balance}
          />
        )}
        
        {activeModal?.type === 'receive' && (
          <ReceiveModal
            isOpen={true}
            onClose={() => setActiveModal(null)}
            asset={activeModal.asset}
            address={activeModal.address}
          />
        )}
      </CardContent>
    </Card>
  );
};

export default WalletOverview;
