
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Copy, Send, Download, ArrowUpDown, Wallet, Loader2 } from "lucide-react";
import { User } from "@/api/entities";
import WalletActionModal from "./WalletActionModal";

const SolanaLogo = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="solanaGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#00FFA3"/>
        <stop offset="100%" stopColor="#DC1FFF"/>
      </linearGradient>
    </defs>
    <path d="M4.5 17.25C4.08579 17.25 3.75 17.5858 3.75 18C3.75 18.4142 4.08579 18.75 4.5 18.75H19.5C19.9142 18.75 20.25 18.4142 20.25 18C20.25 17.5858 19.9142 17.25 19.5 17.25H4.5Z" fill="url(#solanaGradient)"/>
    <path d="M4.5 12C4.08579 12 3.75 12.3358 3.75 12.75C3.75 13.1642 4.08579 13.5 4.5 13.5H19.5C19.9142 13.5 20.25 13.1642 20.25 12.75C20.25 12.3358 19.9142 12 19.5 12H4.5Z" fill="url(#solanaGradient)"/>
    <path d="M4.5 6.75C4.08579 6.75 3.75 7.08579 3.75 7.5C3.75 7.91421 4.08579 8.25 4.5 8.25H19.5C19.9142 8.25 20.25 7.91421 20.25 7.5C20.25 7.08579 19.9142 6.75 19.5 6.75H4.5Z" fill="url(#solanaGradient)"/>
  </svg>
);

export default function SolanaWalletCard({ address, balance = 0, phantomConnected = false, onPhantomConnect }) {
  const [isConnectingPhantom, setIsConnectingPhantom] = useState(false);
  const [copied, setCopied] = useState(false);
  const [actionModal, setActionModal] = useState({ isOpen: false, action: null });
  const [user, setUser] = useState(null);

  useEffect(() => {
    const loadUser = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);
      } catch (error) {
        console.error("Error loading user:", error);
      }
    };
    loadUser();
  }, []);

  const handleAction = (action) => {
    setActionModal({ isOpen: true, action });
  };

  const closeActionModal = () => {
    setActionModal({ isOpen: false, action: null });
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  const connectPhantomWallet = async () => {
    setIsConnectingPhantom(true);
    try {
      if (window.solana && window.solana.isPhantom) {
        const response = await window.solana.connect();
        const publicKey = response.publicKey.toString();
        
        await User.updateMyUserData({
          phantom_connected: true,
          phantom_public_key: publicKey,
          sol_wallet_address: publicKey,
          sol_balance: 0
        });

        if (onPhantomConnect) {
          onPhantomConnect(publicKey);
        }

        window.location.reload();
      } else {
        window.open('https://phantom.app/', '_blank');
        alert('Phantom wallet not detected. Please install Phantom wallet extension and refresh the page.');
      }
    } catch (error) {
      console.error("Failed to connect Phantom wallet:", error);
      alert('Failed to connect Phantom wallet. Please try again.');
    } finally {
      setIsConnectingPhantom(false);
    }
  };

  if (!address && !phantomConnected) {
    return (
      <div className="glass-card rounded-2xl p-6 h-full flex flex-col justify-center">
        <div className="text-center py-8">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-green-400 to-purple-500 rounded-xl flex items-center justify-center">
            <SolanaLogo />
          </div>
          <h3 className="text-lg font-semibold text-neutral-100 mb-2">Solana Wallet</h3>
          <p className="text-neutral-400 mb-6">Connect your Phantom wallet or import existing wallet.</p>
          
          <div className="space-y-3">
            <Button 
              onClick={connectPhantomWallet}
              disabled={isConnectingPhantom}
              className="w-full bg-gradient-to-r from-green-400 to-purple-500 hover:from-green-500 hover:to-purple-600 text-white"
            >
              {isConnectingPhantom ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <Wallet className="w-4 h-4 mr-2" />
                  Connect Phantom
                </>
              )}
            </Button>
            
            <Button 
              variant="outline" 
              className="w-full border-white/20 hover:bg-white/10"
              onClick={() => alert('Import wallet functionality - use External Wallet Import from main wallet page')}
            >
              Import Existing Wallet
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="glass-card rounded-2xl p-6 relative overflow-hidden h-full flex flex-col">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-r from-green-400/10 to-purple-500/10 rounded-full blur-3xl -translate-y-8 translate-x-8"></div>
        
        <div className="relative z-10 flex-grow flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-r from-green-400 to-purple-500 rounded-xl flex items-center justify-center crypto-glow">
                <SolanaLogo />
              </div>
              <div>
                <h3 className="font-semibold text-neutral-100">Solana Wallet</h3>
                <div className="flex items-center gap-2">
                  <p className="text-sm text-neutral-400">Solana Network</p>
                  {phantomConnected && (
                    <Badge className="bg-green-500/20 text-green-400 text-xs">
                      Phantom Connected
                    </Badge>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Balance Display */}
          <div className="mb-6">
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-4xl font-bold text-neutral-100">
                {balance.toFixed(6)}
              </span>
              <span className="text-lg text-neutral-400">SOL</span>
            </div>
          </div>

          {/* Address Details */}
          <div className="mb-6 space-y-3 flex-grow">
            <div>
              <p className="text-xs text-neutral-400 mb-2">Solana Address</p>
              <div className="flex items-center gap-2 glass-effect rounded-lg p-3">
                <span className="text-sm text-neutral-300 font-mono flex-1 truncate">
                  {address}
                </span>
                <Button variant="ghost" size="icon" onClick={copyAddress} className="h-7 w-7">
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
              {copied && <p className="text-xs text-green-400 mt-1">Address copied!</p>}
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <Button className="bg-gradient-to-r from-green-500 to-purple-500 hover:from-green-600 hover:to-purple-600 text-white" onClick={() => handleAction('send')}>
              <Send className="w-4 h-4 mr-1" />
              Send
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('receive')}>
              <Download className="w-4 h-4 mr-1" />
              Receive
            </Button>
            <Button variant="outline" className="border-white/20 hover:bg-white/10" onClick={() => handleAction('swap')}>
              <ArrowUpDown className="w-4 h-4 mr-1" />
              Swap
            </Button>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      <WalletActionModal
        isOpen={actionModal.isOpen}
        onClose={closeActionModal}
        action={actionModal.action}
        walletType="SOL"
        walletAddress={address}
        balance={balance}
        user={user}
      />
    </>
  );
}
