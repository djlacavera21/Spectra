import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Banknote, CreditCard, ChevronLeft, Loader2, Search } from 'lucide-react';

const popularBanks = [
  { name: 'Chase', logo: '🏦' },
  { name: 'Bank of America', logo: '🏛️' },
  { name: 'Wells Fargo', logo: '🏪' },
  { name: 'Citi', logo: '🏢' },
  { name: 'U.S. Bank', logo: '🏦' },
  { name: 'PNC Bank', logo: '🏛️' },
  { name: 'Capital One', logo: '🏪' },
  { name: 'TD Bank', logo: '🏢' },
  { name: 'Truist', logo: '🏦' },
  { name: 'Fifth Third Bank', logo: '🏛️' }
];

export default function AddPaymentMethodModal({ isOpen, onClose, onMethodAdded }) {
  const [step, setStep] = useState('selection'); // 'selection', 'bank', 'card'
  const [isProcessing, setIsProcessing] = useState(false);
  const [bankSearch, setBankSearch] = useState('');
  const [cardDetails, setCardDetails] = useState({
    number: '',
    expiry: '',
    cvc: '',
    name: ''
  });

  const handleClose = () => {
    if (isProcessing) return;
    setStep('selection');
    setBankSearch('');
    onClose();
  };
  
  const handleBack = () => {
    setStep('selection');
  };

  const handleBankSelect = async (bankName) => {
    setIsProcessing(true);
    
    try {
      // Simulate the bank connection process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Create new payment method
      const newMethod = {
        id: Date.now(),
        type: 'bank_account',
        name: bankName,
        last4: Math.floor(1000 + Math.random() * 9000).toString(),
        icon: Banknote,
        routing_number: '0110*****',
        account_type: 'Checking'
      };

      onMethodAdded(newMethod);
      handleClose();
      
    } catch (error) {
      console.error('Error linking bank account:', error);
      alert('Failed to link bank account. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCardSubmit = async (e) => {
    e.preventDefault();
    setIsProcessing(true);
    
    try {
      // Simulate card tokenization
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const newMethod = {
        id: Date.now(),
        type: 'credit_card',
        brand: detectCardBrand(cardDetails.number),
        last4: cardDetails.number.slice(-4),
        expiry: cardDetails.expiry,
        icon: CreditCard,
      };
      
      onMethodAdded(newMethod);
      handleClose();
      
    } catch (error) {
      console.error('Error adding card:', error);
      alert('Failed to add card. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const detectCardBrand = (number) => {
    const firstDigit = number.charAt(0);
    if (firstDigit === '4') return 'Visa';
    if (firstDigit === '5') return 'Mastercard';
    if (firstDigit === '3') return 'American Express';
    return 'Card';
  };

  const filteredBanks = popularBanks.filter(bank =>
    bank.name.toLowerCase().includes(bankSearch.toLowerCase())
  );

  const renderSelection = () => (
    <div className="space-y-4 pt-4">
      <Button 
        variant="outline"
        className="w-full text-left p-6 h-auto glass-effect rounded-lg flex items-center gap-4 hover:bg-white/10 transition-colors"
        onClick={() => setStep('bank')}
        disabled={isProcessing}
      >
        <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
          <Banknote className="w-6 h-6 text-blue-400" />
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-neutral-100">Bank Account</h4>
          <p className="text-sm text-neutral-400">Connect your bank account securely.</p>
        </div>
      </Button>
      
      <Button 
        variant="outline"
        className="w-full text-left p-6 h-auto glass-effect rounded-lg flex items-center gap-4 hover:bg-white/10 transition-colors"
        onClick={() => setStep('card')}
        disabled={isProcessing}
      >
        <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
          <CreditCard className="w-6 h-6 text-green-400" />
        </div>
        <div className="flex-1">
          <h4 className="font-semibold text-neutral-100">Credit/Debit Card</h4>
          <p className="text-sm text-neutral-400">Add a card for instant purchases.</p>
        </div>
      </Button>
    </div>
  );

  const renderBankSelection = () => (
    <div className="pt-4 space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
        <Input
          placeholder="Search for your bank..."
          value={bankSearch}
          onChange={(e) => setBankSearch(e.target.value)}
          className="pl-10 bg-white/5 border-white/20 text-neutral-100"
        />
      </div>
      
      <div className="max-h-80 overflow-y-auto space-y-2">
        {filteredBanks.map((bank) => (
          <button
            key={bank.name}
            onClick={() => handleBankSelect(bank.name)}
            disabled={isProcessing}
            className="w-full p-4 glass-effect rounded-lg flex items-center gap-3 hover:bg-white/10 transition-colors text-left"
          >
            <span className="text-2xl">{bank.logo}</span>
            <span className="text-neutral-100 font-medium">{bank.name}</span>
            {isProcessing && (
              <Loader2 className="w-4 h-4 animate-spin ml-auto" />
            )}
          </button>
        ))}
      </div>
      
      {filteredBanks.length === 0 && (
        <div className="text-center py-8">
          <p className="text-neutral-400">No banks found matching "{bankSearch}"</p>
          <p className="text-sm text-neutral-500 mt-2">Try searching for a different bank name</p>
        </div>
      )}
    </div>
  );

  const renderCardForm = () => (
    <div className="pt-4">
      <form onSubmit={handleCardSubmit} className="space-y-4">
        <div>
          <Label htmlFor="cardName" className="text-neutral-300">Name on Card</Label>
          <Input 
            id="cardName" 
            placeholder="John Doe" 
            className="bg-white/5 border-white/20 text-neutral-100" 
            value={cardDetails.name}
            onChange={(e) => setCardDetails({...cardDetails, name: e.target.value})}
            required
          />
        </div>
        <div>
          <Label htmlFor="cardNumber" className="text-neutral-300">Card Number</Label>
          <Input 
            id="cardNumber" 
            placeholder="1234 5678 9012 3456" 
            className="bg-white/5 border-white/20 text-neutral-100" 
            value={cardDetails.number}
            onChange={(e) => setCardDetails({...cardDetails, number: e.target.value.replace(/\s/g, '')})}
            maxLength={16}
            required
          />
        </div>
        <div className="flex gap-4">
          <div className="flex-1">
            <Label htmlFor="cardExpiry" className="text-neutral-300">Expiry (MM/YY)</Label>
            <Input 
              id="cardExpiry" 
              placeholder="12/25" 
              className="bg-white/5 border-white/20 text-neutral-100" 
              value={cardDetails.expiry}
              onChange={(e) => setCardDetails({...cardDetails, expiry: e.target.value})}
              maxLength={5}
              required
            />
          </div>
          <div className="flex-1">
            <Label htmlFor="cardCvc" className="text-neutral-300">CVC</Label>
            <Input 
              id="cardCvc" 
              placeholder="123" 
              className="bg-white/5 border-white/20 text-neutral-100" 
              value={cardDetails.cvc}
              onChange={(e) => setCardDetails({...cardDetails, cvc: e.target.value})}
              maxLength={4}
              required
            />
          </div>
        </div>
        <Button 
          type="submit" 
          disabled={isProcessing} 
          className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
        >
          {isProcessing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            'Add Card'
          )}
        </Button>
      </form>
    </div>
  );

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="glass-card text-neutral-100 max-w-md">
        <DialogHeader>
          {step !== 'selection' && (
            <Button variant="ghost" size="icon" onClick={handleBack} className="absolute top-3 left-3 h-8 w-8">
              <ChevronLeft className="w-4 h-4" />
            </Button>
          )}
          <DialogTitle className="text-center pt-2">
            {step === 'selection' ? 'Add a Payment Method' : 
             step === 'bank' ? 'Connect Bank Account' : 
             'Add Credit Card'}
          </DialogTitle>
          <DialogDescription className="text-center">
            {step === 'selection' ? "Choose a method to add funds to your account." : 
             step === 'bank' ? "Select your bank to connect your account." :
             "Enter your card details securely."}
          </DialogDescription>
        </DialogHeader>
        
        {step === 'selection' && renderSelection()}
        {step === 'bank' && renderBankSelection()}
        {step === 'card' && renderCardForm()}
      </DialogContent>
    </Dialog>
  );
}