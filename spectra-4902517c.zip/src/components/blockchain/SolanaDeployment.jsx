import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Activity,
  Zap,
  Code,
  Server,
  Database,
  TrendingUp,
  Clock,
  Shield
} from 'lucide-react';

export default function SolanaDeployment({ networkStatus }) {
  const [programId, setProgramId] = useState('');
  const [deploymentCost, setDeploymentCost] = useState('');

  const deployProgram = () => {
    alert('Solana program deployment interface would connect to Solana RPC here.');
  };

  const estimateDeployment = () => {
    setDeploymentCost((Math.random() * 2 + 0.5).toFixed(4));
  };

  return (
    <div className="space-y-6">
      {/* Solana Network Status */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Activity className="w-5 h-5 text-green-400" />
            Solana Network Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-green-400" />
                <span className="text-sm text-neutral-400">Current Slot</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.slot?.toLocaleString()}</p>
              <p className="text-xs text-green-400">Active</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-neutral-400">TPS</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.tps?.toLocaleString()}</p>
              <p className="text-xs text-yellow-400">Real-time</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-400">Epoch</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.epoch}</p>
              <p className="text-xs text-blue-400">Current</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-neutral-400">Block Time</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">0.4s</p>
              <p className="text-xs text-purple-400">Average</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Program Deployment */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Code className="w-5 h-5 text-purple-400" />
            Solana Program Deployment
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-green-500/20 border-green-500/30">
            <Shield className="w-4 h-4 text-green-400" />
            <AlertDescription className="text-green-400">
              Deploy Rust-based programs to the Solana blockchain with built-in security auditing.
            </AlertDescription>
          </Alert>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button className="bg-purple-600 hover:bg-purple-700 h-20 flex flex-col items-center justify-center">
              <Code className="w-6 h-6 mb-2" />
              Deploy SPL Token
            </Button>
            <Button className="bg-green-600 hover:bg-green-700 h-20 flex flex-col items-center justify-center">
              <Database className="w-6 h-6 mb-2" />
              Deploy NFT Program
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 h-20 flex flex-col items-center justify-center">
              <Zap className="w-6 h-6 mb-2" />
              Deploy DeFi Program
            </Button>
            <Button onClick={deployProgram} className="bg-orange-600 hover:bg-orange-700 h-20 flex flex-col items-center justify-center">
              <Server className="w-6 h-6 mb-2" />
              Custom Program
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Deployment Cost Estimation */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
            Deployment Cost Estimation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Enter program size (bytes) or upload .so file..."
              className="bg-white/5 border-white/20 text-neutral-100"
            />
            <Button onClick={estimateDeployment} className="bg-yellow-600 hover:bg-yellow-700">
              Estimate Cost
            </Button>
          </div>
          {deploymentCost && (
            <Alert className="bg-green-500/20 border-green-500/30">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <AlertDescription className="text-green-400">
                <strong>Estimated Deployment Cost:</strong> {deploymentCost} SOL (~${(parseFloat(deploymentCost) * 65).toFixed(2)} USD)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* RPC Endpoint Management */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Server className="w-5 h-5 text-red-400" />
            RPC Endpoint Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="glass-effect rounded-lg p-4">
                <Badge className="bg-green-500/20 text-green-400 mb-2">Mainnet-Beta</Badge>
                <p className="text-sm text-neutral-200">https://api.mainnet-beta.solana.com</p>
                <p className="text-xs text-green-400 mt-1">Connected • 12ms latency</p>
              </div>
              <div className="glass-effect rounded-lg p-4">
                <Badge className="bg-yellow-500/20 text-yellow-400 mb-2">Devnet</Badge>
                <p className="text-sm text-neutral-200">https://api.devnet.solana.com</p>
                <p className="text-xs text-yellow-400 mt-1">Connected • 8ms latency</p>
              </div>
              <div className="glass-effect rounded-lg p-4">
                <Badge className="bg-blue-500/20 text-blue-400 mb-2">Testnet</Badge>
                <p className="text-sm text-neutral-200">https://api.testnet.solana.com</p>
                <p className="text-xs text-blue-400 mt-1">Connected • 15ms latency</p>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10">
                Add Custom RPC
              </Button>
              <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10">
                Test Connections
              </Button>
              <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10">
                Benchmark Performance
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}