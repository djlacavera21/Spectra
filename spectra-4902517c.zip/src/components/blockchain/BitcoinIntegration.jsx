import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Database,
  Send,
  Activity,
  RefreshCw,
  AlertCircle,
  Clock,
  CheckCircle,
  TrendingUp
} from 'lucide-react';

export default function BitcoinIntegration({ networkStatus }) {
  const [mempoolTxs, setMempoolTxs] = useState([]);
  const [addressBalance, setAddressBalance] = useState('');
  const [queryAddress, setQueryAddress] = useState('');
  const [feeEstimates, setFeeEstimates] = useState({
    fast: 25,
    medium: 15,
    slow: 8
  });

  useEffect(() => {
    // Simulate mempool monitoring
    const generateMempoolTx = () => ({
      txid: Math.random().toString(16).substr(2, 64),
      fee: Math.random() * 0.001,
      size: Math.floor(Math.random() * 1000) + 200,
      timestamp: Date.now()
    });

    const interval = setInterval(() => {
      if (Math.random() > 0.6) {
        setMempoolTxs(prev => [generateMempoolTx(), ...prev.slice(0, 9)]);
      }
    }, 2000);

    // Update fee estimates
    const feeInterval = setInterval(() => {
      setFeeEstimates(prev => ({
        fast: Math.max(5, prev.fast + Math.floor((Math.random() - 0.5) * 10)),
        medium: Math.max(3, prev.medium + Math.floor((Math.random() - 0.5) * 5)),
        slow: Math.max(1, prev.slow + Math.floor((Math.random() - 0.5) * 3))
      }));
    }, 10000);

    return () => {
      clearInterval(interval);
      clearInterval(feeInterval);
    };
  }, []);

  const queryBalance = async () => {
    if (queryAddress.trim()) {
      // Simulate balance query
      setAddressBalance((Math.random() * 10).toFixed(8));
    }
  };

  const broadcastTransaction = () => {
    alert('Transaction broadcast functionality would connect to Bitcoin Core RPC here.');
  };

  return (
    <div className="space-y-6">
      {/* Bitcoin Network Status */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Database className="w-5 h-5 text-orange-400" />
            Bitcoin Core Integration Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-orange-400" />
                <span className="text-sm text-neutral-400">Block Height</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.blockHeight?.toLocaleString()}</p>
              <p className="text-xs text-green-400">Synced</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Clock className="w-4 h-4 text-yellow-400" />
                <span className="text-sm text-neutral-400">Mempool Size</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.mempool?.toLocaleString()}</p>
              <p className="text-xs text-yellow-400">Transactions</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <RefreshCw className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-400">Connected Peers</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.peers}</p>
              <p className="text-xs text-blue-400">Active</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Fee Estimation */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <TrendingUp className="w-5 h-5 text-green-400" />
            Transaction Fee Estimates (sat/vB)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-effect rounded-lg p-4 text-center">
              <Badge className="bg-red-500/20 text-red-400 mb-2">Fast (1-2 blocks)</Badge>
              <p className="text-3xl font-bold text-neutral-100">{feeEstimates.fast}</p>
              <p className="text-sm text-neutral-400">~10-20 mins</p>
            </div>
            <div className="glass-effect rounded-lg p-4 text-center">
              <Badge className="bg-yellow-500/20 text-yellow-400 mb-2">Medium (3-6 blocks)</Badge>
              <p className="text-3xl font-bold text-neutral-100">{feeEstimates.medium}</p>
              <p className="text-sm text-neutral-400">~30-60 mins</p>
            </div>
            <div className="glass-effect rounded-lg p-4 text-center">
              <Badge className="bg-green-500/20 text-green-400 mb-2">Slow (6+ blocks)</Badge>
              <p className="text-3xl font-bold text-neutral-100">{feeEstimates.slow}</p>
              <p className="text-sm text-neutral-400">~60+ mins</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Address Balance Query */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Send className="w-5 h-5 text-purple-400" />
            Address Balance Query
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Enter Bitcoin address..."
              value={queryAddress}
              onChange={(e) => setQueryAddress(e.target.value)}
              className="bg-white/5 border-white/20 text-neutral-100 font-mono"
            />
            <Button onClick={queryBalance} className="bg-purple-600 hover:bg-purple-700">
              Query Balance
            </Button>
          </div>
          {addressBalance && (
            <Alert className="bg-green-500/20 border-green-500/30">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <AlertDescription className="text-green-400">
                <strong>Balance:</strong> {addressBalance} BTC
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Live Mempool Monitor */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Activity className="w-5 h-5 text-blue-400" />
            Live Mempool Monitor
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-80 overflow-y-auto custom-scrollbar">
            {mempoolTxs.map((tx, index) => (
              <div key={index} className="flex items-center justify-between p-3 glass-effect rounded-lg">
                <div>
                  <p className="text-sm font-mono text-neutral-200">
                    {tx.txid.slice(0, 16)}...{tx.txid.slice(-8)}
                  </p>
                  <p className="text-xs text-neutral-400">
                    {tx.size} bytes
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-orange-400">
                    {(tx.fee * 100000000 / tx.size).toFixed(1)} sat/vB
                  </p>
                  <p className="text-xs text-neutral-400">
                    {new Date(tx.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Transaction Broadcasting */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Send className="w-5 h-5 text-orange-400" />
            Transaction Broadcasting
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-blue-500/20 border-blue-500/30">
            <AlertCircle className="w-4 h-4 text-blue-400" />
            <AlertDescription className="text-blue-400">
              This interface connects directly to Bitcoin Core RPC for transaction broadcasting and network operations.
            </AlertDescription>
          </Alert>
          <Button onClick={broadcastTransaction} className="w-full bg-orange-600 hover:bg-orange-700">
            Open Transaction Broadcasting Interface
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}