import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Zap, 
  CheckCircle, 
  AlertTriangle,
  ExternalLink,
  Copy,
  Loader2,
  Activity
} from 'lucide-react';
import { Transaction } from '@/api/entities';

const BitcoinBroadcaster = () => {
  const [transactionHash, setTransactionHash] = useState('85acca71e2da630fa7dbdd9eb35a11c8bb65125fe9833f1a093ce3eee0caba7c');
  const [rawTransaction, setRawTransaction] = useState('');
  const [broadcastStatus, setBroadcastStatus] = useState(null);
  const [isBroadcasting, setIsBroadcasting] = useState(false);
  const [verificationResult, setVerificationResult] = useState(null);

  const broadcastTransaction = async () => {
    if (!rawTransaction.trim()) {
      alert('Please enter the raw transaction hex');
      return;
    }

    setIsBroadcasting(true);
    setBroadcastStatus(null);

    try {
      // Real Bitcoin Core RPC call to broadcast transaction
      const response = await fetch('/api/bitcoin/broadcast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          rawTransaction: rawTransaction.trim()
        })
      });

      if (!response.ok) {
        throw new Error(`Broadcast failed: ${response.status} ${response.statusText}`);
      }

      const result = await response.json();
      
      if (result.success) {
        setBroadcastStatus({
          status: 'success',
          txid: result.txid,
          message: 'Transaction successfully broadcast to Bitcoin network'
        });

        // Update transaction record in database
        await Transaction.create({
          from_address: 'Bitcoin Wallet',
          to_address: 'External Wallet',
          amount: 0, // Would need to parse from raw tx
          transaction_type: 'transfer',
          status: 'pending',
          transaction_hash: result.txid,
          metadata: {
            broadcast_method: 'bitcoin_rpc',
            raw_transaction: rawTransaction
          }
        });

      } else {
        setBroadcastStatus({
          status: 'error',
          message: result.error || 'Unknown broadcast error'
        });
      }

    } catch (error) {
      console.error('Broadcast error:', error);
      setBroadcastStatus({
        status: 'error',
        message: error.message
      });
    } finally {
      setIsBroadcasting(false);
    }
  };

  const verifyTransactionOnChain = async () => {
    if (!transactionHash.trim()) {
      alert('Please enter a transaction hash');
      return;
    }

    try {
      // Real Bitcoin blockchain verification using mempool.space API
      const response = await fetch(`https://mempool.space/api/tx/${transactionHash.trim()}`);
      
      if (!response.ok) {
        if (response.status === 404) {
          setVerificationResult({
            status: 'not_found',
            message: 'Transaction not found on Bitcoin blockchain'
          });
          return;
        }
        throw new Error(`Verification failed: ${response.status}`);
      }

      const txData = await response.json();
      
      setVerificationResult({
        status: 'found',
        data: {
          txid: txData.txid,
          block_height: txData.status?.block_height,
          confirmed: txData.status?.confirmed,
          confirmations: txData.status?.confirmed ? 1 : 0,
          fee: txData.fee,
          size: txData.size,
          vsize: txData.vsize
        },
        message: 'Transaction found on Bitcoin blockchain'
      });

    } catch (error) {
      console.error('Verification error:', error);
      setVerificationResult({
        status: 'error',
        message: error.message
      });
    }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-6">
      {/* Transaction Verification */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Activity className="w-5 h-5 text-blue-400" />
            Bitcoin Transaction Verification
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-neutral-400 mb-2 block">Transaction Hash</label>
            <div className="flex gap-2">
              <Input
                value={transactionHash}
                onChange={(e) => setTransactionHash(e.target.value)}
                placeholder="Enter Bitcoin transaction hash"
                className="bg-white/5 border-white/20 text-neutral-100"
              />
              <Button onClick={verifyTransactionOnChain} variant="outline" className="border-white/20">
                Verify
              </Button>
            </div>
          </div>

          {verificationResult && (
            <Alert className={`${
              verificationResult.status === 'found' ? 'bg-green-500/10 border-green-500/30' :
              verificationResult.status === 'not_found' ? 'bg-yellow-500/10 border-yellow-500/30' :
              'bg-red-500/10 border-red-500/30'
            }`}>
              <div className="flex items-center gap-2">
                {verificationResult.status === 'found' ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-yellow-400" />
                )}
                <AlertDescription className={
                  verificationResult.status === 'found' ? 'text-green-300' :
                  verificationResult.status === 'not_found' ? 'text-yellow-300' :
                  'text-red-300'
                }>
                  <strong>{verificationResult.message}</strong>
                  {verificationResult.data && (
                    <div className="mt-2 space-y-1 text-xs">
                      <div>Block Height: {verificationResult.data.block_height || 'Unconfirmed'}</div>
                      <div>Confirmed: {verificationResult.data.confirmed ? 'Yes' : 'No'}</div>
                      <div>Fee: {verificationResult.data.fee} sats</div>
                      <div>Size: {verificationResult.data.size} bytes</div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => window.open(`https://mempool.space/tx/${transactionHash}`, '_blank')}
                        className="mt-2 h-6 px-2 text-xs"
                      >
                        <ExternalLink className="w-3 h-3 mr-1" />
                        View on Explorer
                      </Button>
                    </div>
                  )}
                </AlertDescription>
              </div>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Transaction Broadcasting */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Zap className="w-5 h-5 text-orange-400" />
            Bitcoin Transaction Broadcasting
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm text-neutral-400 mb-2 block">Raw Transaction (Hex)</label>
            <Textarea
              value={rawTransaction}
              onChange={(e) => setRawTransaction(e.target.value)}
              placeholder="Enter raw transaction hex data to broadcast to Bitcoin network"
              className="bg-white/5 border-white/20 text-neutral-100 h-32 font-mono text-xs"
            />
          </div>

          <Button 
            onClick={broadcastTransaction}
            disabled={isBroadcasting || !rawTransaction.trim()}
            className="w-full bg-gradient-to-r from-orange-600 to-red-600 text-white"
          >
            {isBroadcasting ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Broadcasting to Bitcoin Network...
              </>
            ) : (
              <>
                <Zap className="w-4 h-4 mr-2" />
                Broadcast Transaction
              </>
            )}
          </Button>

          {broadcastStatus && (
            <Alert className={`${
              broadcastStatus.status === 'success' ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'
            }`}>
              <div className="flex items-center gap-2">
                {broadcastStatus.status === 'success' ? (
                  <CheckCircle className="w-4 h-4 text-green-400" />
                ) : (
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                )}
                <AlertDescription className={
                  broadcastStatus.status === 'success' ? 'text-green-300' : 'text-red-300'
                }>
                  <strong>{broadcastStatus.message}</strong>
                  {broadcastStatus.txid && (
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-xs font-mono">{broadcastStatus.txid}</span>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => copyToClipboard(broadcastStatus.txid)}
                        className="h-6 w-6 p-0"
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  )}
                </AlertDescription>
              </div>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Network Status */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-neutral-100">Bitcoin Network Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-100">820,456</div>
              <div className="text-sm text-neutral-400">Current Block</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-100">12,456</div>
              <div className="text-sm text-neutral-400">Mempool Size</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-neutral-100">25 sat/vB</div>
              <div className="text-sm text-neutral-400">Recommended Fee</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BitcoinBroadcaster;