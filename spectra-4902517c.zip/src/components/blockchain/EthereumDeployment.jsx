import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Zap,
  Code,
  Settings,
  Activity,
  TrendingUp,
  Server,
  Database,
  Shield
} from 'lucide-react';

export default function EthereumDeployment({ networkStatus }) {
  const [contractAddress, setContractAddress] = useState('');
  const [gasPrice, setGasPrice] = useState('');

  const deployContract = () => {
    alert('Smart contract deployment interface would connect to Ethereum node here.');
  };

  const estimateGas = () => {
    setGasPrice((Math.random() * 50 + 10).toFixed(2));
  };

  return (
    <div className="space-y-6">
      {/* Ethereum Node Status */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Zap className="w-5 h-5 text-blue-400" />
            Ethereum Node Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Database className="w-4 h-4 text-blue-400" />
                <span className="text-sm text-neutral-400">Block Height</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.blockHeight?.toLocaleString()}</p>
              <p className="text-xs text-green-400">Synced</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="w-4 h-4 text-green-400" />
                <span className="text-sm text-neutral-400">Gas Price</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.gasPrice}</p>
              <p className="text-xs text-green-400">Gwei</p>
            </div>

            <div className="glass-effect rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Activity className="w-4 h-4 text-purple-400" />
                <span className="text-sm text-neutral-400">Peers</span>
              </div>
              <p className="text-2xl font-bold text-neutral-100">{networkStatus?.peers}</p>
              <p className="text-xs text-purple-400">Connected</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Smart Contract Deployment */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Code className="w-5 h-5 text-green-400" />
            Smart Contract Deployment
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert className="bg-blue-500/20 border-blue-500/30">
            <Shield className="w-4 h-4 text-blue-400" />
            <AlertDescription className="text-blue-400">
              Deploy and manage smart contracts directly on the Ethereum mainnet and testnets.
            </AlertDescription>
          </Alert>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button className="bg-green-600 hover:bg-green-700 h-20 flex flex-col items-center justify-center">
              <Code className="w-6 h-6 mb-2" />
              Deploy ERC-20 Token
            </Button>
            <Button className="bg-purple-600 hover:bg-purple-700 h-20 flex flex-col items-center justify-center">
              <Database className="w-6 h-6 mb-2" />
              Deploy NFT Contract
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 h-20 flex flex-col items-center justify-center">
              <Shield className="w-6 h-6 mb-2" />
              Deploy Bridge Contract
            </Button>
            <Button onClick={deployContract} className="bg-orange-600 hover:bg-orange-700 h-20 flex flex-col items-center justify-center">
              <Settings className="w-6 h-6 mb-2" />
              Custom Contract
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Gas Estimation */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <TrendingUp className="w-5 h-5 text-yellow-400" />
            Gas Price Estimation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-3">
            <Input
              placeholder="Enter contract bytecode or function call..."
              className="bg-white/5 border-white/20 text-neutral-100"
            />
            <Button onClick={estimateGas} className="bg-yellow-600 hover:bg-yellow-700">
              Estimate Gas
            </Button>
          </div>
          {gasPrice && (
            <Alert className="bg-green-500/20 border-green-500/30">
              <TrendingUp className="w-4 h-4 text-green-400" />
              <AlertDescription className="text-green-400">
                <strong>Estimated Gas Cost:</strong> {gasPrice} Gwei (~${(parseFloat(gasPrice) * 0.001).toFixed(4)} USD)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Node Management */}
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-neutral-100">
            <Server className="w-5 h-5 text-red-400" />
            Node Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10 h-16 flex flex-col items-center justify-center">
              <Activity className="w-5 h-5 mb-1" />
              Node Metrics
            </Button>
            <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10 h-16 flex flex-col items-center justify-center">
              <Settings className="w-5 h-5 mb-1" />
              Configuration
            </Button>
            <Button variant="outline" className="border-white/20 text-neutral-200 hover:bg-white/10 h-16 flex flex-col items-center justify-center">
              <Database className="w-5 h-5 mb-1" />
              Sync Status
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}