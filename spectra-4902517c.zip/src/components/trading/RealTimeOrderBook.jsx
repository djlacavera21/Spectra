import React, { useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const OrderBookRow = ({ price, quantity, total, type, maxTotal }) => {
  const percentage = (total / maxTotal) * 100;
  const rowRef = useRef(null);

  useEffect(() => {
    // Flash animation on update
    if (rowRef.current) {
      rowRef.current.classList.add('flash');
      const timer = setTimeout(() => {
        rowRef.current?.classList.remove('flash');
      }, 300);
      return () => clearTimeout(timer);
    }
  }, [quantity]);

  return (
    <div ref={rowRef} className="relative flex justify-between text-xs font-mono p-1 transition-colors duration-300">
      <div 
        className={`absolute top-0 bottom-0 ${type === 'bid' ? 'right-0 bg-green-500/10' : 'left-0 bg-red-500/10'}`}
        style={{ width: `${percentage}%` }}
      ></div>
      <span className="z-10 text-green-400">{type === 'bid' ? price : ''}</span>
      <span className="z-10 text-neutral-200">{quantity}</span>
      <span className="z-10 text-neutral-400">{total}</span>
      <span className="z-10 text-red-400">{type === 'ask' ? price : ''}</span>
    </div>
  );
};

export default function RealTimeOrderBook({ orderBook }) {
  const maxTotal = Math.max(
    ...orderBook.bids.map(b => b.total),
    ...orderBook.asks.map(a => a.total),
    1 // ensure not zero
  );

  return (
    <Card className="glass-card h-[600px] flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Order Book</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow overflow-hidden">
        <style>{`
          .flash {
            animation: flash-animation 0.3s ease-out;
          }
          @keyframes flash-animation {
            0% { background-color: rgba(255, 255, 100, 0.2); }
            100% { background-color: transparent; }
          }
        `}</style>
        <div className="flex justify-between text-xs text-neutral-500 font-sans p-1 border-b border-neutral-700">
          <span>Price (USDT)</span>
          <span>Amount (SPEC)</span>
          <span>Total (USDT)</span>
        </div>
        <div className="h-[calc(100%-2rem)] overflow-y-auto">
          {/* Asks */}
          <div className="h-1/2 flex flex-col-reverse">
            {orderBook.asks.slice(0, 25).map((order, i) => (
              <OrderBookRow key={i} {...order} type="ask" maxTotal={maxTotal} />
            ))}
          </div>
          
          {/* Current Price Spread */}
          <div className="py-2 my-1 border-y border-neutral-600 text-center">
             <span className="text-lg font-bold text-green-400">{orderBook.bids[0]?.price}</span>
          </div>

          {/* Bids */}
          <div className="h-1/2 flex flex-col">
            {orderBook.bids.slice(0, 25).map((order, i) => (
              <OrderBookRow key={i} {...order} type="bid" maxTotal={maxTotal} />
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}