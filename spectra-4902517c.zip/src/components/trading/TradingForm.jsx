import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';

export default function TradingForm({ user, pair, currentPrice, onOrderPlaced }) {
  const [orderType, setOrderType] = useState('limit');
  const [side, setSide] = useState('buy');
  const [price, setPrice] = useState(currentPrice);
  const [amount, setAmount] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  // Handle both string and object pair formats
  const pairSymbol = typeof pair === 'string' ? pair : (pair?.symbol || 'SPEC/USDT');
  const [baseCurrency, quoteCurrency] = pairSymbol.split('/');
  const baseBalance = user?.spec_balance || 0;
  const quoteBalance = user?.usdt_balance || 0;

  const total = parseFloat(amount) * parseFloat(price) || 0;
  const tradingFee = total * 0.001; // 0.1% fee

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!amount || parseFloat(amount) <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    if (orderType === 'limit' && (!price || parseFloat(price) <= 0)) {
      alert('Please enter a valid price');
      return;
    }

    // Check balance
    if (side === 'buy' && quoteBalance < total + tradingFee) {
      alert(`Insufficient ${quoteCurrency} balance`);
      return;
    }

    if (side === 'sell' && baseBalance < parseFloat(amount)) {
      alert(`Insufficient ${baseCurrency} balance`);
      return;
    }

    setIsProcessing(true);
    
    try {
      const orderData = {
        side,
        type: orderType,
        amount: parseFloat(amount),
        price: orderType === 'market' ? currentPrice : parseFloat(price),
        total: orderType === 'market' ? parseFloat(amount) * currentPrice : total,
        fee: tradingFee
      };

      await onOrderPlaced(orderData);
      
      // Reset form
      setAmount('');
      if (orderType === 'limit') {
        setPrice(currentPrice);
      }
      
      alert('Order placed successfully!');
      
    } catch (error) {
      console.error('Order placement failed:', error);
      alert('Failed to place order: ' + error.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const getMaxAmount = () => {
    if (side === 'buy') {
      const effectivePrice = orderType === 'market' ? currentPrice : parseFloat(price) || currentPrice;
      return ((quoteBalance - tradingFee) / effectivePrice).toFixed(2);
    } else {
      return baseBalance.toFixed(2);
    }
  };

  const setMaxAmount = () => {
    setAmount(getMaxAmount());
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-neutral-100">
          <TrendingUp className="w-5 h-5" />
          Place Order - {pairSymbol}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Order Side */}
          <Tabs value={side} onValueChange={setSide} className="w-full">
            <TabsList className="grid w-full grid-cols-2 glass-effect">
              <TabsTrigger value="buy" className="text-neutral-400 data-[state=active]:bg-green-600 data-[state=active]:text-white">
                <TrendingUp className="w-4 h-4 mr-2" />
                BUY
              </TabsTrigger>
              <TabsTrigger value="sell" className="text-neutral-400 data-[state=active]:bg-red-600 data-[state=active]:text-white">
                <TrendingDown className="w-4 h-4 mr-2" />
                SELL
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Order Type */}
          <Tabs value={orderType} onValueChange={setOrderType} className="w-full">
            <TabsList className="grid w-full grid-cols-2 glass-effect">
              <TabsTrigger value="limit" className="text-neutral-400 data-[state=active]:bg-white/20 data-[state=active]:text-neutral-100">
                Limit
              </TabsTrigger>
              <TabsTrigger value="market" className="text-neutral-400 data-[state=active]:bg-white/20 data-[state=active]:text-neutral-100">
                Market
              </TabsTrigger>
            </TabsList>
          </Tabs>

          {/* Price Input (only for limit orders) */}
          {orderType === 'limit' && (
            <div>
              <label className="block text-sm text-neutral-400 mb-2">
                Price ({quoteCurrency})
              </label>
              <Input
                type="number"
                step="0.000001"
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                placeholder={`Enter price in ${quoteCurrency}`}
                className="bg-white/5 border-white/20 text-neutral-100"
              />
            </div>
          )}

          {/* Amount Input */}
          <div>
            <label className="block text-sm text-neutral-400 mb-2">
              Amount ({baseCurrency})
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={setMaxAmount}
                className="ml-2 text-xs text-blue-400 hover:text-blue-300 h-auto p-0"
              >
                Max: {getMaxAmount()}
              </Button>
            </label>
            <Input
              type="number"
              step="0.01"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={`Enter amount in ${baseCurrency}`}
              className="bg-white/5 border-white/20 text-neutral-100"
            />
          </div>

          {/* Order Summary */}
          <div className="glass-effect rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-neutral-400">Total:</span>
              <span className="text-neutral-100">
                {total.toFixed(6)} {quoteCurrency}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-neutral-400">Fee (0.1%):</span>
              <span className="text-neutral-100">
                {tradingFee.toFixed(6)} {quoteCurrency}
              </span>
            </div>
            <div className="flex justify-between text-sm font-medium border-t border-white/10 pt-2">
              <span className="text-neutral-400">Total with Fee:</span>
              <span className="text-neutral-100">
                {(total + tradingFee).toFixed(6)} {quoteCurrency}
              </span>
            </div>
          </div>

          {/* Account Balance */}
          <div className="glass-effect rounded-lg p-3">
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="w-4 h-4 text-neutral-400" />
              <span className="text-sm text-neutral-400">Available Balance</span>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-neutral-400">{baseCurrency}:</span>
                <span className="ml-2 text-neutral-100">{baseBalance.toFixed(2)}</span>
              </div>
              <div>
                <span className="text-neutral-400">{quoteCurrency}:</span>
                <span className="ml-2 text-neutral-100">{quoteBalance.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isProcessing || !amount}
            className={`w-full font-semibold ${
              side === 'buy' 
                ? 'bg-green-600 hover:bg-green-700 text-white' 
                : 'bg-red-600 hover:bg-red-700 text-white'
            }`}
          >
            {isProcessing ? 'Placing Order...' : `${side.toUpperCase()} ${baseCurrency}`}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}