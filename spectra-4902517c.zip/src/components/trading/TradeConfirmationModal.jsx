import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertTriangle, CheckCircle, Loader2 } from "lucide-react";

export default function TradeConfirmationModal({ isOpen, onClose, onConfirm, order, isLoading }) {
  if (!order) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-effect border-white/20 text-neutral-100">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            Confirm Trade
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Trading Pair:</span>
            <Badge className="bg-blue-500/20 text-blue-400">{order.pair}</Badge>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Side:</span>
            <Badge className={order.side === 'buy' ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}>
              {order.side.toUpperCase()}
            </Badge>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Type:</span>
            <span className="text-neutral-100 capitalize">{order.type}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Price:</span>
            <span className="text-neutral-100">{order.price?.toFixed(8)} {order.pair?.split('/')[1]}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Amount:</span>
            <span className="text-neutral-100">{order.amount?.toFixed(4)} {order.pair?.split('/')[0]}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Total:</span>
            <span className="text-neutral-100 font-bold">{order.total?.toFixed(4)} {order.pair?.split('/')[1]}</span>
          </div>
          
          <div className="flex justify-between items-center">
            <span className="text-neutral-400">Fee (0.1%):</span>
            <span className="text-neutral-100">≈ {(order.total * 0.001)?.toFixed(6)} {order.pair?.split('/')[1]}</span>
          </div>
        </div>
        
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={onClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button 
            onClick={onConfirm} 
            disabled={isLoading}
            className={order.side === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Confirm {order.side === 'buy' ? 'Buy' : 'Sell'}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}