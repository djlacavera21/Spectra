import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Clock, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { Order, User } from '@/api/entities';

export default function OrderHistory({ pairSymbol }) {
  const [orders, setOrders] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const loadOrders = useCallback(async () => {
    if (!pairSymbol) return;
    setIsLoading(true);
    try {
      const currentUser = await User.me();
      const userOrders = await Order.filter(
        { 
          user_wallet: currentUser.wallet_address,
          pair: pairSymbol
        },
        '-created_date',
        50 // Limit to 50 recent orders for this pair
      );
      setOrders(userOrders);
    } catch (error) {
      console.error("Error loading order history:", error);
      // In case of an error, set orders to an empty array
      setOrders([]);
    } finally {
      setIsLoading(false);
    }
  }, [pairSymbol]);

  useEffect(() => {
    loadOrders();
    // Refresh every 30 seconds
    const interval = setInterval(loadOrders, 30000);
    return () => clearInterval(interval);
  }, [loadOrders]);

  const getStatusInfo = (status) => {
    const statusMap = {
      open: { color: 'bg-blue-500/20 text-blue-400', icon: <Clock className="w-3 h-3" /> },
      filled: { color: 'bg-green-500/20 text-green-400', icon: <CheckCircle className="w-3 h-3" /> },
      partially_filled: { color: 'bg-yellow-500/20 text-yellow-400', icon: <Clock className="w-3 h-3" /> },
      cancelled: { color: 'bg-red-500/20 text-red-400', icon: <XCircle className="w-3 h-3" /> }
    };
    return statusMap[status] || statusMap.open;
  };

  const getSideColor = (side) => {
    return side === 'buy' ? 'text-green-400' : 'text-red-400';
  };
  
  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="text-neutral-100">Order History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-neutral-400">
            <Loader2 className="w-6 h-6 mx-auto mb-3 animate-spin" />
            <p>Loading order history...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="glass-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-neutral-100">Order History</CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={loadOrders}
            className="text-neutral-400 hover:text-neutral-100"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {orders && orders.length > 0 ? (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {orders.map((order) => {
              const statusInfo = getStatusInfo(order.status);
              const orderAmount = order.amount || 0;
              const filledAmount = order.filled_amount || 0;
              const orderPrice = order.price || 0;
              const filledPercentage = orderAmount > 0 ? (filledAmount / orderAmount) * 100 : 0;
              
              return (
                <div key={order.id} className="glass-effect rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Badge className={`${getSideColor(order.side)} bg-transparent border text-xs uppercase font-bold`}>
                        {order.side}
                      </Badge>
                      <span className="text-neutral-200 font-medium text-sm">{order.pair}</span>
                      <Badge className={`${statusInfo.color} text-xs`}>
                        <div className="flex items-center gap-1">
                          {statusInfo.icon}
                          {(order.status || 'open').replace('_', ' ')}
                        </div>
                      </Badge>
                    </div>
                    <span className="text-xs text-neutral-400">
                      {format(new Date(order.created_date), 'MMM dd, HH:mm')}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs">
                    <div>
                      <span className="text-neutral-400">Type:</span>
                      <span className="ml-1 text-neutral-200 capitalize">{order.type || 'limit'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-400">Price:</span>
                      <span className="ml-1 text-neutral-200">{orderPrice > 0 ? orderPrice.toFixed(4) : 'Market'}</span>
                    </div>
                    <div>
                      <span className="text-neutral-400">Amount:</span>
                      <span className="ml-1 text-neutral-200">{orderAmount.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-neutral-400">Filled:</span>
                      <span className="ml-1 text-neutral-200">
                        {filledAmount.toFixed(2)}
                      </span>
                    </div>
                  </div>
                  
                  {order.status !== 'filled' && order.status !== 'cancelled' && (
                    <div className="mt-2">
                      <div className="w-full bg-neutral-700 rounded-full h-1">
                        <div 
                          className="bg-blue-400 h-1 rounded-full transition-all duration-300"
                          style={{ width: `${filledPercentage}%` }}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8 text-neutral-400">
            <Clock className="w-10 h-10 mx-auto mb-3 opacity-50" />
            <p>No order history for this pair</p>
            <p className="text-sm">Your trades will appear here</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}