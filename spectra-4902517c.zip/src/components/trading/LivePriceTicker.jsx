import React, { useState, useEffect } from 'react';
import { TradingPair } from '@/api/entities';
import { TrendingUp, TrendingDown } from 'lucide-react';

const TickerItem = ({ pair }) => {
  const [price, setPrice] = useState(pair.last_price);
  const [change, setChange] = useState(pair.price_change_24h_percent);
  const [direction, setDirection] = useState('up');

  useEffect(() => {
    const interval = setInterval(() => {
      setPrice(prevPrice => {
        const newPrice = prevPrice * (1 + (Math.random() - 0.5) * 0.001);
        setDirection(newPrice >= prevPrice ? 'up' : 'down');
        return newPrice;
      });
      setChange(prevChange => prevChange + (Math.random() - 0.5) * 0.05);
    }, 1000 + Math.random() * 500);
    return () => clearInterval(interval);
  }, []);

  const isUp = change >= 0;

  return (
    <div className="flex-shrink-0 flex items-center gap-3 px-4 py-2 border-r border-neutral-700">
      <span className="font-semibold text-sm text-neutral-200">{pair.symbol}</span>
      <div className="flex items-center gap-1">
        <span className={`font-mono text-sm ${direction === 'up' ? 'text-green-400' : 'text-red-400'}`}>
          {price.toFixed(4)}
        </span>
        {isUp ? <TrendingUp className="w-3 h-3 text-green-400" /> : <TrendingDown className="w-3 h-3 text-red-400" />}
      </div>
      <span className={`text-xs font-medium ${isUp ? 'text-green-500' : 'text-red-500'}`}>
        {isUp ? '+' : ''}{change.toFixed(2)}%
      </span>
    </div>
  );
};

export default function LivePriceTicker() {
  const [pairs, setPairs] = useState([]);

  useEffect(() => {
    const fetchPairs = async () => {
      const activePairs = await TradingPair.filter({ is_active: true });
      // Fetch more pairs for a realistic ticker
      const allPairs = await TradingPair.list();
      setPairs(allPairs.length > activePairs.length ? allPairs : activePairs);
    };
    fetchPairs();
  }, []);

  if (pairs.length === 0) return null;

  return (
    <div className="glass-card w-full overflow-hidden">
      <div className="animate-marquee-infinite whitespace-nowrap flex">
        {pairs.map(pair => <TickerItem key={pair.id} pair={pair} />)}
        {/* Duplicate for seamless scroll */}
        {pairs.map(pair => <TickerItem key={`${pair.id}-clone`} pair={pair} />)}
      </div>
    </div>
  );
}