
import React, { useState } from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Brush
} from 'recharts';
import { format } from 'date-fns';

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="glass-card rounded-lg p-3 text-sm">
        <p className="label text-neutral-400">{`${format(new Date(data.time * 1000), 'MMM d, HH:mm')}`}</p>
        <p className="intro text-neutral-200">{`Open: ${data.open.toFixed(2)}`}</p>
        <p className="intro text-neutral-200">{`High: ${data.high.toFixed(2)}`}</p>
        <p className="intro text-neutral-200">{`Low: ${data.low.toFixed(2)}`}</p>
        <p className="intro text-neutral-200">{`Close: ${data.close.toFixed(2)}`}</p>
        <p className="intro text-neutral-200">{`Volume: ${data.volume.toFixed(2)}`}</p>
      </div>
    );
  }
  return null;
};

// A custom shape for the candlestick body
const CandlestickShape = (props) => {
  const { x, y, width, height, low, high, open, close } = props;
  const isUp = close >= open;
  const fill = isUp ? '#22c55e' : '#ef4444'; // green-500 or red-500
  const wickX = x + width / 2;

  return (
    <g stroke={fill} fill={fill} strokeWidth="1">
      {/* Wick */}
      <line x1={wickX} y1={y} x2={wickX} y2={height > 0 ? y + height : y} />
      <line x1={wickX} y1={y} x2={wickX} y2={y - (high - Math.max(open, close))} />
      <line x1={wickX} y1={y + (Math.min(open, close) - low)} x2={wickX} y2={y} />
      
      {/* Body */}
      <rect x={x} y={y} width={width} height={height || 0.1} fill={fill} />
    </g>
  );
};


export default function TradingChart({ data }) {
    const [timeframe, setTimeframe] = useState('1H');

    if (!data || data.length === 0) {
        return (
            <div className="glass-card rounded-xl p-6 h-96 flex items-center justify-center">
                <p className="text-neutral-400">Loading chart data...</p>
            </div>
        );
    }

    const chartData = data.map(d => ({
        ...d,
        // For candlestick, y is top of body, height is body height
        body: [d.open, d.close],
        candleY: Math.min(d.open, d.close),
        candleHeight: Math.abs(d.open - d.close),
    }));

    const yDomain = [
        Math.min(...data.map(d => d.low)) * 0.99,
        Math.max(...data.map(d => d.high)) * 1.01
    ];
    
    const volumeDomain = [0, Math.max(...data.map(d => d.volume)) * 2];

    return (
        <div className="glass-card rounded-xl p-6 h-[500px]">
            <div className="flex justify-between items-center mb-4">
                <div className="flex gap-2">
                    {['15M', '1H', '4H', '1D'].map(tf => (
                        <button
                            key={tf}
                            onClick={() => setTimeframe(tf)}
                            className={`px-3 py-1 rounded-md text-xs font-medium ${
                                timeframe === tf ? 'bg-white/20 text-neutral-100' : 'text-neutral-400 hover:bg-white/10'
                            }`}
                        >
                            {tf}
                        </button>
                    ))}
                </div>
            </div>
            <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
                    
                    <XAxis 
                        dataKey="time" 
                        tickFormatter={(time) => format(new Date(time * 1000), 'HH:mm')}
                        stroke="#9ca3af" 
                        tick={{ fontSize: 12 }}
                    />
                    
                    <YAxis 
                        yAxisId="left" 
                        orientation="left" 
                        domain={yDomain} 
                        tickFormatter={(price) => price.toFixed(2)}
                        stroke="#9ca3af" 
                        tick={{ fontSize: 12 }}
                    />
                    
                    <YAxis 
                        yAxisId="right" 
                        orientation="right" 
                        domain={volumeDomain}
                        tickFormatter={(vol) => `${(vol / 1000).toFixed(1)}k`}
                        stroke="#9ca3af" 
                        tick={{ fontSize: 12 }}
                    />

                    <Tooltip content={<CustomTooltip />} />
                    
                    <Bar yAxisId="right" dataKey="volume" barSize={20} fill="rgba(139, 92, 246, 0.4)" />
                    
                    {/* This is a trick to render candlesticks */}
                    <Bar 
                        yAxisId="left" 
                        dataKey="body" 
                        shape={<CandlestickShape />}
                    />
                    
                    <Brush dataKey="time" height={30} stroke="#8884d8"
                        startIndex={Math.max(0, chartData.length - 50)}
                        tickFormatter={(time) => format(new Date(time * 1000), 'MMM d')}
                    />
                </ComposedChart>
            </ResponsiveContainer>
        </div>
    );
}
