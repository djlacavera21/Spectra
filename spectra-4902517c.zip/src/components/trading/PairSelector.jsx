import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, TrendingUp, TrendingDown } from 'lucide-react';

export default function PairSelector({ pairs, selectedPair, onSelectPair }) {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredPairs = pairs.filter(pair =>
    pair.symbol.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const formatPrice = (price, decimals = 4) => {
    return price?.toFixed(decimals) || '0.0000';
  };

  const formatChange = (change) => {
    if (!change) return '0.00%';
    const sign = change >= 0 ? '+' : '';
    return `${sign}${change.toFixed(2)}%`;
  };

  return (
    <Card className="glass-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg text-neutral-200">Markets</CardTitle>
          <div className="relative w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 w-4 h-4" />
            <Input
              placeholder="Search pairs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-black border-neutral-700 text-neutral-200"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex gap-3 overflow-x-auto pb-2">
          {filteredPairs.map((pair) => (
            <div
              key={pair.symbol}
              onClick={() => onSelectPair(pair)}
              className={`flex-shrink-0 p-4 rounded-lg cursor-pointer transition-all hover:bg-neutral-800 min-w-[200px] ${
                selectedPair?.symbol === pair.symbol ? 'bg-blue-500/20 border border-blue-500/30' : 'bg-neutral-900 border border-neutral-700'
              }`}
            >
              <div className="flex justify-between items-center">
                <div>
                  <div className="font-semibold text-neutral-100">{pair.symbol}</div>
                  <div className="text-sm text-neutral-400">{formatPrice(pair.last_price)}</div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium flex items-center gap-1 ${
                    (pair.price_change_24h_percent || 0) >= 0 ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {(pair.price_change_24h_percent || 0) >= 0 ? 
                      <TrendingUp className="w-3 h-3" /> : 
                      <TrendingDown className="w-3 h-3" />
                    }
                    {formatChange(pair.price_change_24h_percent)}
                  </div>
                  <div className="text-xs text-neutral-500">
                    Vol: {((pair.volume_24h || 0) / 1000).toFixed(1)}K
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}