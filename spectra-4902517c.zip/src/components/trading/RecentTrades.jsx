import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function RecentTrades({ trades }) {
  return (
    <Card className="glass-card h-[300px] flex flex-col">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">Recent Trades</CardTitle>
      </CardHeader>
      <CardContent className="flex-grow overflow-y-auto">
        <div className="flex justify-between text-xs text-neutral-500 font-sans p-1 border-b border-neutral-700">
          <span>Price (USDT)</span>
          <span>Amount (SPEC)</span>
          <span>Time</span>
        </div>
        <div className="space-y-1 mt-1">
          {trades.map((trade, i) => (
            <div key={i} className="flex justify-between text-xs font-mono">
              <span className={trade.side === 'buy' ? 'text-green-400' : 'text-red-400'}>{trade.price}</span>
              <span className="text-neutral-200">{trade.quantity}</span>
              <span className="text-neutral-400">{trade.time}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}