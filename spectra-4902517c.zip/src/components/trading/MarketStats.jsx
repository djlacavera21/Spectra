import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Activity, BarChart3 } from 'lucide-react';

export default function MarketStats({ pair }) {
  if (!pair || Object.keys(pair).length === 0) {
    return (
      <Card className="glass-card">
        <CardContent className="p-6">
          <div className="text-center text-neutral-400">
            <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>Loading market data...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Safely access properties with defaults
  const lastPrice = pair.last_price || 0;
  const priceChange24h = pair.price_change_24h_percent || 0;
  const high24h = pair.high_24h || lastPrice;
  const low24h = pair.low_24h || lastPrice;
  const volume24h = pair.volume_24h || 0;
  const spread = pair.spread || Math.abs(high24h - low24h);

  const isPositive = priceChange24h >= 0;

  return (
    <Card className="glass-card">
      <CardContent className="p-6">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-6">
          <div className="text-center">
            <div className="text-2xl font-bold text-neutral-100 mb-1">
              {lastPrice.toFixed(6)}
            </div>
            <div className="text-xs text-neutral-400">Last Price</div>
          </div>
          
          <div className="text-center">
            <div className={`text-2xl font-bold mb-1 flex items-center justify-center gap-1 ${
              isPositive ? 'text-green-400' : 'text-red-400'
            }`}>
              {isPositive ? <TrendingUp className="w-5 h-5" /> : <TrendingDown className="w-5 h-5" />}
              {isPositive ? '+' : ''}{priceChange24h.toFixed(2)}%
            </div>
            <div className="text-xs text-neutral-400">24h Change</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-neutral-100 mb-1">
              {high24h.toFixed(6)}
            </div>
            <div className="text-xs text-neutral-400">24h High</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-neutral-100 mb-1">
              {low24h.toFixed(6)}
            </div>
            <div className="text-xs text-neutral-400">24h Low</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-neutral-100 mb-1">
              {volume24h.toLocaleString()}
            </div>
            <div className="text-xs text-neutral-400">24h Volume</div>
          </div>
          
          <div className="text-center">
            <div className="text-2xl font-bold text-neutral-100 mb-1">
              {spread.toFixed(6)}
            </div>
            <div className="text-xs text-neutral-400">Spread</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}