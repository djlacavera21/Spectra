import React, { useState, useEffect, createContext, useContext } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Zap,
  Globe,
  RefreshCw,
  AlertTriangle,
  CheckCircle
} from 'lucide-react';

// Create Market Data Context
const MarketDataContext = createContext();

export const useMarketData = () => {
  const context = useContext(MarketDataContext);
  if (!context) {
    throw new Error('useMarketData must be used within MarketDataProvider');
  }
  return context;
};

export const MarketDataProvider = ({ children, pairSymbol }) => {
  const [marketData, setMarketData] = useState({
    stats: null,
    ohlcv: [],
    orderBook: { bids: [], asks: [] },
    recentTrades: []
  });
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (pairSymbol) {
      loadMarketData(pairSymbol);
    }
  }, [pairSymbol]);

  const loadMarketData = async (symbol) => {
    setIsLoading(true);
    try {
      // Generate realistic market data for the trading pair
      const basePrice = symbol === 'SPEC/USDT' ? 1.0 : Math.random() * 100 + 50;
      const priceVariation = 0.02;
      
      // Generate OHLCV data for chart
      const ohlcvData = [];
      let currentPrice = basePrice;
      const now = Date.now();
      
      for (let i = 99; i >= 0; i--) {
        const timestamp = Math.floor((now - i * 300000) / 1000); // 5-minute intervals
        const open = currentPrice;
        const variation = (Math.random() - 0.5) * priceVariation;
        const close = open * (1 + variation);
        const high = Math.max(open, close) * (1 + Math.random() * 0.01);
        const low = Math.min(open, close) * (1 - Math.random() * 0.01);
        const volume = Math.random() * 1000 + 500;
        
        ohlcvData.push({
          time: timestamp,
          open: open,
          high: high,
          low: low,
          close: close,
          volume: volume
        });
        
        currentPrice = close;
      }

      // Generate order book
      const midPrice = currentPrice;
      const bids = [];
      const asks = [];
      
      for (let i = 0; i < 20; i++) {
        const bidPrice = midPrice * (1 - (i + 1) * 0.001);
        const askPrice = midPrice * (1 + (i + 1) * 0.001);
        const quantity = Math.random() * 100 + 10;
        
        bids.push({
          price: bidPrice.toFixed(6),
          quantity: quantity.toFixed(2),
          total: (bidPrice * quantity).toFixed(2)
        });
        
        asks.push({
          price: askPrice.toFixed(6),
          quantity: quantity.toFixed(2),
          total: (askPrice * quantity).toFixed(2)
        });
      }

      // Generate recent trades
      const recentTrades = [];
      for (let i = 0; i < 15; i++) {
        const price = (midPrice * (1 + (Math.random() - 0.5) * 0.002)).toFixed(6);
        const quantity = (Math.random() * 50 + 5).toFixed(2);
        const side = Math.random() > 0.5 ? 'buy' : 'sell';
        const time = new Date(now - i * 60000).toLocaleTimeString();
        
        recentTrades.push({ price, quantity, side, time });
      }

      // Market stats
      const stats = {
        symbol: symbol,
        last_price: currentPrice,
        price_change_24h_percent: (Math.random() - 0.5) * 10,
        high_24h: currentPrice * 1.05,
        low_24h: currentPrice * 0.95,
        volume_24h: Math.random() * 10000 + 5000,
        spread: Math.abs(asks[0]?.price - bids[0]?.price) || 0.001
      };

      setMarketData({
        stats,
        ohlcv: ohlcvData,
        orderBook: { bids, asks },
        recentTrades
      });

    } catch (error) {
      console.error('Failed to load market data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const value = {
    marketData,
    isLoading,
    refreshData: () => loadMarketData(pairSymbol)
  };

  return (
    <MarketDataContext.Provider value={value}>
      {children}
    </MarketDataContext.Provider>
  );
};

const MarketDataFeed = ({ onPriceUpdate }) => {
  const [marketData, setMarketData] = useState({
    bitcoin: { symbol: 'BTC', price: 0, change24h: 0, volume: 0, lastUpdate: null },
    ethereum: { symbol: 'ETH', price: 0, change24h: 0, volume: 0, lastUpdate: null },
    solana: { symbol: 'SOL', price: 0, change24h: 0, volume: 0, lastUpdate: null },
    spectra: { symbol: 'SPEC', price: 1.00, change24h: 0, volume: 0, lastUpdate: null }
  });

  const [feedStatus, setFeedStatus] = useState({
    status: 'connecting',
    lastUpdate: null,
    errorCount: 0,
    sources: ['CoinGecko', 'CoinMarketCap', 'Binance'],
    activeSource: 'CoinGecko'
  });

  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    // Initialize real market data connection
    fetchRealMarketData();
    
    // Set up real-time updates every 30 seconds
    const interval = setInterval(() => {
      fetchRealMarketData();
    }, 30000);

    return () => clearInterval(interval);
  }, []);

  const fetchRealMarketData = async () => {
    try {
      setFeedStatus(prev => ({ ...prev, status: 'updating' }));
      
      // Real API call to CoinGecko (free tier)
      const response = await fetch(
        'https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana&vs_currencies=usd&include_24hr_change=true&include_24hr_vol=true',
        {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          }
        }
      );

      if (!response.ok) {
        throw new Error(`API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const timestamp = new Date().toISOString();

      const newMarketData = {
        bitcoin: {
          symbol: 'BTC',
          price: data.bitcoin?.usd || 0,
          change24h: data.bitcoin?.usd_24h_change || 0,
          volume: data.bitcoin?.usd_24h_vol || 0,
          lastUpdate: timestamp
        },
        ethereum: {
          symbol: 'ETH',
          price: data.ethereum?.usd || 0,
          change24h: data.ethereum?.usd_24h_change || 0,
          volume: data.ethereum?.usd_24h_vol || 0,
          lastUpdate: timestamp
        },
        solana: {
          symbol: 'SOL',
          price: data.solana?.usd || 0,
          change24h: data.solana?.usd_24h_change || 0,
          volume: data.solana?.usd_24h_vol || 0,
          lastUpdate: timestamp
        },
        spectra: {
          symbol: 'SPEC',
          price: 1.00, // SPEC is pegged to USD
          change24h: 0,
          volume: 0,
          lastUpdate: timestamp
        }
      };

      setMarketData(newMarketData);
      setFeedStatus({
        status: 'connected',
        lastUpdate: timestamp,
        errorCount: 0,
        sources: ['CoinGecko', 'CoinMarketCap', 'Binance'],
        activeSource: 'CoinGecko'
      });

      // Notify parent component of price updates
      if (onPriceUpdate) {
        onPriceUpdate(newMarketData);
      }

    } catch (error) {
      console.error('Market data fetch error:', error);
      setFeedStatus(prev => ({
        ...prev,
        status: 'error',
        errorCount: prev.errorCount + 1
      }));
    }
  };

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await fetchRealMarketData();
    setTimeout(() => setIsRefreshing(false), 1000);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'connected': return 'text-green-400';
      case 'updating': return 'text-blue-400';
      case 'error': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'connected': return <CheckCircle className="w-4 h-4" />;
      case 'updating': return <Activity className="w-4 h-4 animate-pulse" />;
      case 'error': return <AlertTriangle className="w-4 h-4" />;
      default: return <Globe className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Market Data Feed Status */}
      <Card className="glass-card">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3 text-neutral-100">
              <TrendingUp className="w-6 h-6 text-green-400" />
              Real Market Data Feed
            </CardTitle>
            <div className="flex items-center gap-3">
              <Badge className={`${getStatusColor(feedStatus.status)} bg-transparent border-current`}>
                <div className="flex items-center gap-1">
                  {getStatusIcon(feedStatus.status)}
                  {feedStatus.status.toUpperCase()}
                </div>
              </Badge>
              <Button
                onClick={handleManualRefresh}
                disabled={isRefreshing}
                variant="outline"
                size="sm"
                className="border-white/20"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 text-sm text-neutral-400">
            <span>Source: {feedStatus.activeSource}</span>
            <span>•</span>
            <span>Last Update: {feedStatus.lastUpdate ? new Date(feedStatus.lastUpdate).toLocaleTimeString() : 'Never'}</span>
            <span>•</span>
            <span>Errors: {feedStatus.errorCount}</span>
          </div>
        </CardContent>
      </Card>

      {/* Live Price Data */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(marketData).map(([key, asset]) => (
          <Card key={key} className="glass-effect">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-xs font-bold">{asset.symbol}</span>
                  </div>
                  <span className="font-medium text-neutral-200">{asset.symbol}</span>
                </div>
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              
              <div className="space-y-2">
                <div className="text-2xl font-bold text-neutral-100">
                  ${asset.price.toLocaleString('en-US', { 
                    minimumFractionDigits: asset.symbol === 'BTC' ? 0 : 2,
                    maximumFractionDigits: asset.symbol === 'BTC' ? 0 : 4 
                  })}
                </div>
                
                <div className={`flex items-center gap-1 text-sm ${
                  asset.change24h >= 0 ? 'text-green-400' : 'text-red-400'
                }`}>
                  {asset.change24h >= 0 ? (
                    <TrendingUp className="w-4 h-4" />
                  ) : (
                    <TrendingDown className="w-4 h-4" />
                  )}
                  {Math.abs(asset.change24h).toFixed(2)}% (24h)
                </div>
                
                {asset.volume > 0 && (
                  <div className="text-xs text-neutral-400">
                    Vol: ${(asset.volume / 1e9).toFixed(2)}B
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Data Source Information */}
      <Alert className="bg-blue-500/10 border-blue-500/30">
        <Globe className="w-4 h-4 text-blue-400" />
        <AlertDescription className="text-blue-300">
          <strong>Live Market Data:</strong> Real-time cryptocurrency prices are fetched from {feedStatus.activeSource} API every 30 seconds. 
          This data feeds directly into portfolio calculations and trading operations.
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default MarketDataFeed;