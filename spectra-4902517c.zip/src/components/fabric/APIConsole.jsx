
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Zap, 
  Play, 
  Code, 
  Download,
  Upload,
  Settings,
  CheckCircle,
  AlertTriangle
} from "lucide-react";

export default function APIConsole() {
  const [selectedAPI, setSelectedAPI] = useState('fabric-ops');
  const [method, setMethod] = useState('GET');
  const [endpoint, setEndpoint] = useState('/api/v1/components');
  const [requestBody, setRequestBody] = useState('');
  const [response, setResponse] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedSDK, setSelectedSDK] = useState('nodejs'); // New state for SDK selection

  const apiEndpoints = {
    'fabric-ops': [
      { method: 'GET', path: '/api/v1/components', description: 'List all components' },
      { method: 'POST', path: '/api/v1/components/fabric-peer', description: 'Create a peer' },
      { method: 'GET', path: '/api/v1/components/{id}', description: 'Get component details' },
      { method: 'DELETE', path: '/api/v1/components/{id}', description: 'Delete a component' },
      { method: 'POST', path: '/api/v1/kubernetes/components/fabric-peer', description: 'Deploy peer to Kubernetes' },
      { method: 'GET', path: '/api/v1/logs', description: 'Get component logs' },
    ],
    'fabric-ca': [
      { method: 'POST', path: '/api/v1/register', description: 'Register user with CA' },
      { method: 'POST', path: '/api/v1/enroll', description: 'Enroll user certificate' },
      { method: 'GET', path: '/api/v1/identities', description: 'List identities' },
      { method: 'DELETE', path: '/api/v1/identities/{id}', description: 'Remove identity' },
    ],
    'fabric-gateway': [
      { method: 'POST', path: '/api/v1/networks/{network}/contracts/{contract}/transactions/{function}', description: 'Submit transaction' },
      { method: 'GET', path: '/api/v1/networks/{network}/contracts/{contract}/transactions/{function}', description: 'Evaluate transaction' },
      { method: 'GET', path: '/api/v1/networks/{network}/blocks/{blockNumber}', description: 'Get block' },
      { method: 'GET', path: '/api/v1/networks/{network}/transactions/{txId}', description: 'Get transaction' },
    ]
  };

  const sampleRequests = {
    'fabric-ops': {
      'POST': JSON.stringify({
        "display_name": "Peer Org1",
        "grpcwp_url": "https://peer0-org1.example.com:443",
        "api_url": "https://peer0-org1.example.com:443",
        "type": "fabric-peer",
        "msp_id": "Org1MSP",
        "location": "kubernetes"
      }, null, 2),
      'GET': ''
    },
    'fabric-ca': {
      'POST': JSON.stringify({
        "id": "user1",
        "secret": "user1pw",
        "type": "client",
        "affiliation": "org1.department1",
        "attrs": [
          {
            "name": "role",
            "value": "member",
            "ecert": true
          }
        ]
      }, null, 2)
    },
    'fabric-gateway': {
      'POST': JSON.stringify({
        "args": ["user123", "1000"],
        "transient": {},
        "endorsing_orgs": ["Org1MSP"]
      }, null, 2)
    }
  };

  const handleExecuteAPI = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockResponse = {
      status: 200,
      data: {
        message: "API call executed successfully",
        timestamp: new Date().toISOString(),
        endpoint: endpoint,
        method: method
      }
    };
    
    setResponse(JSON.stringify(mockResponse, null, 2));
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* API Console Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Zap className="w-6 h-6 text-yellow-400" />
          <h3 className="text-xl font-bold text-neutral-100">Fabric Operations Console APIs</h3>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-sm text-neutral-200">Operations Console</span>
            </div>
            <p className="text-xs text-green-400">API Ready</p>
            <p className="text-xs text-neutral-500">REST v2.5.3</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-neutral-200">Fabric CA API</span>
            </div>
            <p className="text-xs text-blue-400">Available</p>
            <p className="text-xs text-neutral-500">v1.5.2</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-purple-400" />
              <span className="text-sm text-neutral-200">Gateway API</span>
            </div>
            <p className="text-xs text-purple-400">Connected</p>
            <p className="text-xs text-neutral-500">gRPC + REST</p>
          </div>
        </div>
      </div>

      {/* API Testing Interface */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">API Testing Interface</h4>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Request Configuration */}
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-300 mb-2 block">API Service</label>
              <Select value={selectedAPI} onValueChange={setSelectedAPI}>
                <SelectTrigger className="bg-white/5 border-white/20 text-neutral-100">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="glass-card">
                  <SelectItem value="fabric-ops">Fabric Operations Console</SelectItem>
                  <SelectItem value="fabric-ca">Fabric Certificate Authority</SelectItem>
                  <SelectItem value="fabric-gateway">Fabric Gateway</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-sm text-neutral-300 mb-2 block">Method</label>
                <Select value={method} onValueChange={setMethod}>
                  <SelectTrigger className="bg-white/5 border-white/20 text-neutral-100">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-card">
                    <SelectItem value="GET">GET</SelectItem>
                    <SelectItem value="POST">POST</SelectItem>
                    <SelectItem value="PUT">PUT</SelectItem>
                    <SelectItem value="DELETE">DELETE</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2">
                <label className="text-sm text-neutral-300 mb-2 block">Endpoint</label>
                <Input
                  value={endpoint}
                  onChange={(e) => setEndpoint(e.target.value)}
                  className="bg-white/5 border-white/20 text-neutral-100"
                  placeholder="/api/v1/..."
                />
              </div>
            </div>

            {(method === 'POST' || method === 'PUT') && (
              <div>
                <label className="text-sm text-neutral-300 mb-2 block">Request Body</label>
                <Textarea
                  value={requestBody || sampleRequests[selectedAPI]?.[method] || ''}
                  onChange={(e) => setRequestBody(e.target.value)}
                  className="h-48 font-mono text-sm bg-black/50 border-white/20 text-neutral-100"
                  placeholder="Enter JSON request body..."
                />
              </div>
            )}

            <Button 
              onClick={handleExecuteAPI} 
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              ) : (
                <Play className="w-4 h-4 mr-2" />
              )}
              Execute API Call
            </Button>
          </div>

          {/* Response */}
          <div className="space-y-4">
            <div>
              <label className="text-sm text-neutral-300 mb-2 block">Response</label>
              <Textarea
                value={response}
                readOnly
                className="h-80 font-mono text-sm bg-black/50 border-white/20 text-neutral-100"
                placeholder="API response will appear here..."
              />
            </div>
          </div>
        </div>
      </div>

      {/* SDK Code Examples Section */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">SDK Code Examples</h4>
        <div className="flex items-center justify-between mb-4">
          <span className="text-neutral-300 text-sm">Select SDK:</span>
          <div className="flex gap-2">
            {['nodejs', 'go', 'java'].map(sdk => (
              <Button
                key={sdk}
                size="sm"
                onClick={() => setSelectedSDK(sdk)}
                className={selectedSDK === sdk ? 'bg-blue-600 text-white' : 'bg-white text-black hover:bg-neutral-200'}
              >
                {sdk.toUpperCase()}
              </Button>
            ))}
          </div>
        </div>

        <Tabs defaultValue="query" className="w-full">
          <TabsList className="grid w-full grid-cols-2 glass-effect mb-4">
            <TabsTrigger value="query" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Query Operations</TabsTrigger>
            <TabsTrigger value="transaction" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Transaction Operations</TabsTrigger>
          </TabsList>

          <TabsContent value="query">
            <div className="space-y-4">
              <Textarea
                readOnly
                className="h-60 font-mono text-sm bg-black/50 border-white/20 text-neutral-100"
                placeholder={`// ${selectedSDK} Query Operation Code Example`}
                value={`console.log("This is a placeholder for ${selectedSDK} Query code.");`}
              />
            </div>
          </TabsContent>

          <TabsContent value="transaction">
            <div className="space-y-4">
              <Textarea
                readOnly
                className="h-60 font-mono text-sm bg-black/50 border-white/20 text-neutral-100"
                placeholder={`// ${selectedSDK} Transaction Operation Code Example`}
                value={`console.log("This is a placeholder for ${selectedSDK} Transaction code.");`}
              />
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Available Endpoints */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">Available Endpoints</h4>
        <div className="space-y-3">
          {apiEndpoints[selectedAPI]?.map((ep, index) => (
            <div key={index} className="glass-effect rounded-lg p-3 flex items-center justify-between">
              <div>
                <div className="flex items-center gap-3">
                  <Badge className={`text-xs ${
                    ep.method === 'GET' ? 'bg-blue-500/20 text-blue-400' :
                    ep.method === 'POST' ? 'bg-green-500/20 text-green-400' :
                    ep.method === 'PUT' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {ep.method}
                  </Badge>
                  <span className="font-mono text-sm text-neutral-200">{ep.path}</span>
                </div>
                <p className="text-xs text-neutral-400 mt-1">{ep.description}</p>
              </div>
              <Button 
                size="sm" 
                onClick={() => {
                  setMethod(ep.method);
                  setEndpoint(ep.path);
                }}
                className="bg-white text-black hover:bg-neutral-200 text-xs"
              >
                Use
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
