import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Download, 
  Upload, 
  Code, 
  Network, 
  Database,
  Settings,
  CheckCircle,
  AlertCircle,
  Terminal,
  FileText,
  Package
} from "lucide-react";

export default function BlockchainResources() {
  const [deploymentStep, setDeploymentStep] = useState(0);
  const [isDeploying, setIsDeploying] = useState(false);

  const deploymentSteps = [
    "Download Hyperledger Fabric Network",
    "Configure Network Topology", 
    "Deploy SPEC Smart Contract",
    "Initialize Token Parameters",
    "Setup Cross-Chain Bridge",
    "Configure API Endpoints",
    "Test Network Connectivity",
    "Go Live"
  ];

  const handleDownloadResources = () => {
    // Create comprehensive deployment package
    const deploymentPackage = {
      "docker-compose.yml": generateDockerCompose(),
      "configtx.yaml": generateConfigTx(),
      "crypto-config.yaml": generateCryptoConfig(),
      "chaincode/spec-token.js": generateSPECChaincode(),
      "scripts/deploy.sh": generateDeployScript(),
      "api/fabric-gateway.js": generateFabricGateway(),
      "README.md": generateReadme()
    };

    // Create downloadable ZIP
    const element = document.createElement("a");
    const file = new Blob([JSON.stringify(deploymentPackage, null, 2)], {type: 'application/json'});
    element.href = URL.createObjectURL(file);
    element.download = `spectra-hyperledger-fabric-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const generateDockerCompose = () => {
    return `version: '3.7'

services:
  # Orderer Service
  orderer.spectra.com:
    image: hyperledger/fabric-orderer:2.4
    environment:
      - FABRIC_LOGGING_SPEC=INFO
      - ORDERER_GENERAL_LISTENADDRESS=0.0.0.0
      - ORDERER_GENERAL_BOOTSTRAPMETHOD=file
      - ORDERER_GENERAL_BOOTSTRAPFILE=/var/hyperledger/orderer/orderer.genesis.block
      - ORDERER_GENERAL_LOCALMSPID=OrdererMSP
      - ORDERER_GENERAL_LOCALMSPDIR=/var/hyperledger/orderer/msp
      - ORDERER_OPERATIONS_LISTENADDRESS=0.0.0.0:17050
    working_dir: /opt/gopath/src/github.com/hyperledger/fabric
    command: orderer
    volumes:
      - ./channel-artifacts/genesis.block:/var/hyperledger/orderer/orderer.genesis.block
      - ./crypto-config/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp:/var/hyperledger/orderer/msp
    ports:
      - 7050:7050
      - 17050:17050

  # Peer0 Org1
  peer0.org1.spectra.com:
    image: hyperledger/fabric-peer:2.4
    environment:
      - CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
      - CORE_VM_DOCKER_HOSTCONFIG_NETWORKMODE=fabric_test
      - FABRIC_LOGGING_SPEC=INFO
      - CORE_PEER_TLS_ENABLED=true
      - CORE_PEER_PROFILE_ENABLED=true
      - CORE_PEER_TLS_CERT_FILE=/etc/hyperledger/fabric/tls/server.crt
      - CORE_PEER_TLS_KEY_FILE=/etc/hyperledger/fabric/tls/server.key
      - CORE_PEER_TLS_ROOTCERT_FILE=/etc/hyperledger/fabric/tls/ca.crt
      - CORE_PEER_ID=peer0.org1.spectra.com
      - CORE_PEER_ADDRESS=peer0.org1.spectra.com:7051
      - CORE_PEER_LISTENADDRESS=0.0.0.0:7051
      - CORE_PEER_CHAINCODEADDRESS=peer0.org1.spectra.com:7052
      - CORE_PEER_CHAINCODELISTENADDRESS=0.0.0.0:7052
      - CORE_PEER_GOSSIP_BOOTSTRAP=peer0.org1.spectra.com:7051
      - CORE_PEER_GOSSIP_EXTERNALENDPOINT=peer0.org1.spectra.com:7051
      - CORE_PEER_LOCALMSPID=Org1MSP
      - CORE_OPERATIONS_LISTENADDRESS=0.0.0.0:17051
      - CORE_LEDGER_STATE_STATEDATABASE=CouchDB
      - CORE_LEDGER_STATE_COUCHDBCONFIG_COUCHDBADDRESS=couchdb0:5984
      - CORE_LEDGER_STATE_COUCHDBCONFIG_USERNAME=admin
      - CORE_LEDGER_STATE_COUCHDBCONFIG_PASSWORD=adminpw
    working_dir: /opt/gopath/src/github.com/hyperledger/fabric/peer
    command: peer node start
    volumes:
      - /var/run/:/host/var/run/
      - ./crypto-config/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/msp:/etc/hyperledger/fabric/msp
      - ./crypto-config/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls:/etc/hyperledger/fabric/tls
    ports:
      - 7051:7051
      - 17051:17051
    depends_on:
      - couchdb0

  # CouchDB for Peer0
  couchdb0:
    image: couchdb:3.1.1
    environment:
      - COUCHDB_USER=admin
      - COUCHDB_PASSWORD=adminpw
    ports:
      - 5984:5984

  # CLI
  cli:
    image: hyperledger/fabric-tools:2.4
    tty: true
    stdin_open: true
    environment:
      - GOPATH=/opt/gopath
      - CORE_VM_ENDPOINT=unix:///host/var/run/docker.sock
      - FABRIC_LOGGING_SPEC=INFO
      - CORE_PEER_ID=cli
      - CORE_PEER_ADDRESS=peer0.org1.spectra.com:7051
      - CORE_PEER_LOCALMSPID=Org1MSP
      - CORE_PEER_TLS_ENABLED=true
      - CORE_PEER_TLS_CERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls/server.crt
      - CORE_PEER_TLS_KEY_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls/server.key
      - CORE_PEER_TLS_ROOTCERT_FILE=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls/ca.crt
      - CORE_PEER_MSPCONFIGPATH=/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.spectra.com/users/Admin@org1.spectra.com/msp
    working_dir: /opt/gopath/src/github.com/hyperledger/fabric/peer
    command: /bin/bash
    volumes:
      - /var/run/:/host/var/run/
      - ./chaincode/:/opt/gopath/src/github.com/chaincode
      - ./crypto-config:/opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/
`;
  };

  const generateSPECChaincode = () => {
    return `'use strict';

const { Contract } = require('fabric-contract-api');

class SPECTokenContract extends Contract {

    async initLedger(ctx) {
        console.info('============= START : Initialize SPEC Token Ledger ===========');
        
        const tokenInfo = {
            name: 'Spectra Coin',
            symbol: 'SPEC',
            decimals: 18,
            totalSupply: '33333333333333000000000000000000', // 33.333 trillion with 18 decimals
            owner: 'SpectraFoundation',
            created: new Date().toISOString()
        };

        await ctx.stub.putState('TOKEN_INFO', Buffer.from(JSON.stringify(tokenInfo)));
        
        // Initialize admin balance
        const adminBalance = {
            balance: '33333333333333000000000000000000',
            frozen: false
        };
        
        await ctx.stub.putState('BALANCE_SpectraFoundation', Buffer.from(JSON.stringify(adminBalance)));
        
        console.info('============= END : Initialize SPEC Token Ledger ===========');
    }

    async getTokenInfo(ctx) {
        const tokenInfoAsBytes = await ctx.stub.getState('TOKEN_INFO');
        if (!tokenInfoAsBytes || tokenInfoAsBytes.length === 0) {
            throw new Error('Token info does not exist');
        }
        return tokenInfoAsBytes.toString();
    }

    async balanceOf(ctx, account) {
        const balanceAsBytes = await ctx.stub.getState(\`BALANCE_\${account}\`);
        if (!balanceAsBytes || balanceAsBytes.length === 0) {
            return '0';
        }
        const balance = JSON.parse(balanceAsBytes.toString());
        return balance.balance;
    }

    async transfer(ctx, to, amount) {
        const from = ctx.clientIdentity.getID();
        
        // Get sender balance
        const fromBalanceAsBytes = await ctx.stub.getState(\`BALANCE_\${from}\`);
        if (!fromBalanceAsBytes || fromBalanceAsBytes.length === 0) {
            throw new Error('Insufficient balance');
        }
        
        const fromBalance = JSON.parse(fromBalanceAsBytes.toString());
        const transferAmount = BigInt(amount);
        const currentBalance = BigInt(fromBalance.balance);
        
        if (currentBalance < transferAmount) {
            throw new Error('Insufficient balance');
        }
        
        // Update sender balance
        fromBalance.balance = (currentBalance - transferAmount).toString();
        await ctx.stub.putState(\`BALANCE_\${from}\`, Buffer.from(JSON.stringify(fromBalance)));
        
        // Get or create receiver balance
        let toBalanceAsBytes = await ctx.stub.getState(\`BALANCE_\${to}\`);
        let toBalance;
        
        if (!toBalanceAsBytes || toBalanceAsBytes.length === 0) {
            toBalance = { balance: '0', frozen: false };
        } else {
            toBalance = JSON.parse(toBalanceAsBytes.toString());
        }
        
        // Update receiver balance
        const receiverCurrentBalance = BigInt(toBalance.balance);
        toBalance.balance = (receiverCurrentBalance + transferAmount).toString();
        await ctx.stub.putState(\`BALANCE_\${to}\`, Buffer.from(JSON.stringify(toBalance)));
        
        // Emit transfer event
        const transferEvent = {
            from: from,
            to: to,
            amount: amount,
            timestamp: new Date().toISOString()
        };
        
        ctx.stub.setEvent('Transfer', Buffer.from(JSON.stringify(transferEvent)));
        
        return JSON.stringify({
            success: true,
            txId: ctx.stub.getTxID(),
            from: from,
            to: to,
            amount: amount
        });
    }

    async mint(ctx, to, amount) {
        // Only admin can mint
        const minter = ctx.clientIdentity.getID();
        if (!minter.includes('SpectraFoundation')) {
            throw new Error('Only admin can mint tokens');
        }
        
        // Get token info to update total supply
        const tokenInfoAsBytes = await ctx.stub.getState('TOKEN_INFO');
        const tokenInfo = JSON.parse(tokenInfoAsBytes.toString());
        
        const mintAmount = BigInt(amount);
        const currentSupply = BigInt(tokenInfo.totalSupply);
        tokenInfo.totalSupply = (currentSupply + mintAmount).toString();
        
        await ctx.stub.putState('TOKEN_INFO', Buffer.from(JSON.stringify(tokenInfo)));
        
        // Get or create recipient balance
        let toBalanceAsBytes = await ctx.stub.getState(\`BALANCE_\${to}\`);
        let toBalance;
        
        if (!toBalanceAsBytes || toBalanceAsBytes.length === 0) {
            toBalance = { balance: '0', frozen: false };
        } else {
            toBalance = JSON.parse(toBalanceAsBytes.toString());
        }
        
        // Update recipient balance
        const recipientCurrentBalance = BigInt(toBalance.balance);
        toBalance.balance = (recipientCurrentBalance + mintAmount).toString();
        await ctx.stub.putState(\`BALANCE_\${to}\`, Buffer.from(JSON.stringify(toBalance)));
        
        // Emit mint event
        const mintEvent = {
            to: to,
            amount: amount,
            timestamp: new Date().toISOString(),
            totalSupply: tokenInfo.totalSupply
        };
        
        ctx.stub.setEvent('Mint', Buffer.from(JSON.stringify(mintEvent)));
        
        return JSON.stringify({
            success: true,
            txId: ctx.stub.getTxID(),
            to: to,
            amount: amount,
            newTotalSupply: tokenInfo.totalSupply
        });
    }

    async burn(ctx, amount) {
        const burner = ctx.clientIdentity.getID();
        
        // Get burner balance
        const burnerBalanceAsBytes = await ctx.stub.getState(\`BALANCE_\${burner}\`);
        if (!burnerBalanceAsBytes || burnerBalanceAsBytes.length === 0) {
            throw new Error('Insufficient balance to burn');
        }
        
        const burnerBalance = JSON.parse(burnerBalanceAsBytes.toString());
        const burnAmount = BigInt(amount);
        const currentBalance = BigInt(burnerBalance.balance);
        
        if (currentBalance < burnAmount) {
            throw new Error('Insufficient balance to burn');
        }
        
        // Update burner balance
        burnerBalance.balance = (currentBalance - burnAmount).toString();
        await ctx.stub.putState(\`BALANCE_\${burner}\`, Buffer.from(JSON.stringify(burnerBalance)));
        
        // Update total supply
        const tokenInfoAsBytes = await ctx.stub.getState('TOKEN_INFO');
        const tokenInfo = JSON.parse(tokenInfoAsBytes.toString());
        const currentSupply = BigInt(tokenInfo.totalSupply);
        tokenInfo.totalSupply = (currentSupply - burnAmount).toString();
        
        await ctx.stub.putState('TOKEN_INFO', Buffer.from(JSON.stringify(tokenInfo)));
        
        // Emit burn event
        const burnEvent = {
            from: burner,
            amount: amount,
            timestamp: new Date().toISOString(),
            newTotalSupply: tokenInfo.totalSupply
        };
        
        ctx.stub.setEvent('Burn', Buffer.from(JSON.stringify(burnEvent)));
        
        return JSON.stringify({
            success: true,
            txId: ctx.stub.getTxID(),
            from: burner,
            amount: amount,
            newTotalSupply: tokenInfo.totalSupply
        });
    }

    async getAllTransactions(ctx) {
        const allResults = [];
        const iterator = await ctx.stub.getHistoryForKey('TOKEN_INFO');
        let result = await iterator.next();
        
        while (!result.done) {
            const strValue = Buffer.from(result.value.value.toString()).toString('utf8');
            const record = {
                txId: result.value.txId,
                timestamp: result.value.timestamp,
                isDelete: result.value.isDelete,
                value: strValue
            };
            allResults.push(record);
            result = await iterator.next();
        }
        await iterator.close();
        
        return JSON.stringify(allResults);
    }
}

module.exports = SPECTokenContract;`;
  };

  const generateDeployScript = () => {
    return `#!/bin/bash

echo "=========================================="
echo "SPECTRA HYPERLEDGER FABRIC DEPLOYMENT"
echo "=========================================="

# Set environment variables
export FABRIC_CFG_PATH=\${PWD}/config/
export CORE_PEER_TLS_ENABLED=true
export ORDERER_CA=\${PWD}/crypto-config/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp/tlscacerts/tlsca.spectra.com-cert.pem
export PEER0_ORG1_CA=\${PWD}/crypto-config/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls/ca.crt

# Step 1: Generate crypto material
echo "Step 1: Generating crypto material..."
cryptogen generate --config=./crypto-config.yaml

# Step 2: Generate genesis block
echo "Step 2: Generating genesis block..."
configtxgen -profile SpectraOrdererGenesis -channelID system-channel -outputBlock ./channel-artifacts/genesis.block

# Step 3: Generate channel configuration transaction
echo "Step 3: Generating channel configuration..."
configtxgen -profile SpectraChannel -outputCreateChannelTx ./channel-artifacts/channel.tx -channelID spectrachannel

# Step 4: Start the network
echo "Step 4: Starting Hyperledger Fabric network..."
docker-compose up -d

# Wait for containers to start
sleep 10

# Step 5: Create and join channel
echo "Step 5: Creating and joining channel..."
docker exec cli peer channel create -o orderer.spectra.com:7050 -c spectrachannel -f /opt/gopath/src/github.com/hyperledger/fabric/peer/channel-artifacts/channel.tx --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp/tlscacerts/tlsca.spectra.com-cert.pem

docker exec cli peer channel join -b spectrachannel.block

# Step 6: Package and install chaincode
echo "Step 6: Installing SPEC Token chaincode..."
docker exec cli peer lifecycle chaincode package spec-token.tar.gz --path /opt/gopath/src/github.com/chaincode/spec-token --lang node --label spec-token_1.0

docker exec cli peer lifecycle chaincode install spec-token.tar.gz

# Step 7: Approve and commit chaincode
echo "Step 7: Approving and committing chaincode..."
PACKAGE_ID=\$(docker exec cli peer lifecycle chaincode queryinstalled | grep "spec-token_1.0" | cut -d' ' -f3 | cut -d',' -f1)

docker exec cli peer lifecycle chaincode approveformyorg -o orderer.spectra.com:7050 --channelID spectrachannel --name spec-token --version 1.0 --package-id \$PACKAGE_ID --sequence 1 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp/tlscacerts/tlsca.spectra.com-cert.pem

docker exec cli peer lifecycle chaincode commit -o orderer.spectra.com:7050 --channelID spectrachannel --name spec-token --version 1.0 --sequence 1 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp/tlscacerts/tlsca.spectra.com-cert.pem

# Step 8: Initialize the ledger
echo "Step 8: Initializing SPEC Token ledger..."
docker exec cli peer chaincode invoke -o orderer.spectra.com:7050 --tls true --cafile /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/ordererOrganizations/spectra.com/orderers/orderer.spectra.com/msp/tlscacerts/tlsca.spectra.com-cert.pem -C spectrachannel -n spec-token --peerAddresses peer0.org1.spectra.com:7051 --tlsRootCertFiles /opt/gopath/src/github.com/hyperledger/fabric/peer/crypto/peerOrganizations/org1.spectra.com/peers/peer0.org1.spectra.com/tls/ca.crt -c '{"function":"initLedger","Args":[]}'

echo "=========================================="
echo "SPEC TOKEN SUCCESSFULLY DEPLOYED!"
echo "Network: Hyperledger Fabric"
echo "Channel: spectrachannel"
echo "Chaincode: spec-token"
echo "Total Supply: 33,333,333,333,333 SPEC"
echo "=========================================="

# Test the deployment
echo "Testing deployment..."
docker exec cli peer chaincode query -C spectrachannel -n spec-token -c '{"function":"getTokenInfo","Args":[]}'

echo "Deployment complete! SPEC token is now live on Hyperledger Fabric."`;
  };

  const generateFabricGateway = () => {
    return `const { Gateway, Wallets } = require('fabric-network');
const path = require('path');
const fs = require('fs');

class SPECFabricGateway {
    constructor() {
        this.channelName = 'spectrachannel';
        this.chaincodeName = 'spec-token';
        this.walletPath = path.join(process.cwd(), 'wallet');
        this.connectionProfile = path.resolve(__dirname, '..', 'connection-org1.json');
    }

    async connectToGateway() {
        try {
            // Create a new file system based wallet for managing identities
            const wallet = await Wallets.newFileSystemWallet(this.walletPath);
            
            // Check to see if we've already enrolled the user
            const identity = await wallet.get('appUser');
            if (!identity) {
                throw new Error('An identity for the user "appUser" does not exist in the wallet');
            }

            // Create a new gateway for connecting to our peer node
            const gateway = new Gateway();
            await gateway.connect(this.connectionProfile, {
                wallet,
                identity: 'appUser',
                discovery: { enabled: true, asLocalhost: true }
            });

            return gateway;
        } catch (error) {
            console.error(\`Failed to connect to gateway: \${error}\`);
            throw error;
        }
    }

    async getTokenInfo() {
        const gateway = await this.connectToGateway();
        try {
            const network = await gateway.getNetwork(this.channelName);
            const contract = network.getContract(this.chaincodeName);
            
            const result = await contract.evaluateTransaction('getTokenInfo');
            return JSON.parse(result.toString());
        } finally {
            gateway.disconnect();
        }
    }

    async getBalance(account) {
        const gateway = await this.connectToGateway();
        try {
            const network = await gateway.getNetwork(this.channelName);
            const contract = network.getContract(this.chaincodeName);
            
            const result = await contract.evaluateTransaction('balanceOf', account);
            return result.toString();
        } finally {
            gateway.disconnect();
        }
    }

    async transfer(to, amount) {
        const gateway = await this.connectToGateway();
        try {
            const network = await gateway.getNetwork(this.channelName);
            const contract = network.getContract(this.chaincodeName);
            
            const result = await contract.submitTransaction('transfer', to, amount);
            return JSON.parse(result.toString());
        } finally {
            gateway.disconnect();
        }
    }

    async mint(to, amount) {
        const gateway = await this.connectToGateway();
        try {
            const network = await gateway.getNetwork(this.channelName);
            const contract = network.getContract(this.chaincodeName);
            
            const result = await contract.submitTransaction('mint', to, amount);
            return JSON.parse(result.toString());
        } finally {
            gateway.disconnect();
        }
    }

    async burn(amount) {
        const gateway = await this.connectToGateway();
        try {
            const network = await gateway.getNetwork(this.channelName);
            const contract = network.getContract(this.chaincodeName);
            
            const result = await contract.submitTransaction('burn', amount);
            return JSON.parse(result.toString());
        } finally {
            gateway.disconnect();
        }
    }
}

module.exports = SPECFabricGateway;`;
  };

  const generateReadme = () => {
    return `# SPECTRA HYPERLEDGER FABRIC DEPLOYMENT

## Overview
This package contains everything needed to deploy SPEC token on Hyperledger Fabric blockchain.

## Prerequisites
- Docker and Docker Compose
- Node.js 14+ and npm
- Hyperledger Fabric binaries (v2.4+)
- Git

## Quick Start

1. **Install Hyperledger Fabric**:
   \`\`\`bash
   curl -sSL https://bit.ly/2ysbOFE | bash -s -- 2.4.0 1.5.0
   \`\`\`

2. **Extract deployment files**:
   \`\`\`bash
   # Extract the JSON package contents to your project directory
   \`\`\`

3. **Make scripts executable**:
   \`\`\`bash
   chmod +x scripts/deploy.sh
   \`\`\`

4. **Deploy the network**:
   \`\`\`bash
   ./scripts/deploy.sh
   \`\`\`

## Network Architecture

- **Orderer**: Single orderer node (orderer.spectra.com:7050)
- **Peer**: Single peer node (peer0.org1.spectra.com:7051)
- **Database**: CouchDB for world state
- **Channel**: spectrachannel
- **Chaincode**: spec-token (Node.js)

## SPEC Token Details

- **Name**: Spectra Coin
- **Symbol**: SPEC  
- **Decimals**: 18
- **Total Supply**: 33,333,333,333,333 SPEC
- **Network**: Hyperledger Fabric

## Smart Contract Functions

- \`getTokenInfo()\` - Get token metadata
- \`balanceOf(account)\` - Get account balance
- \`transfer(to, amount)\` - Transfer tokens
- \`mint(to, amount)\` - Mint new tokens (admin only)
- \`burn(amount)\` - Burn tokens

## API Integration

Use the provided \`fabric-gateway.js\` to integrate with your application:

\`\`\`javascript
const SPECGateway = require('./api/fabric-gateway');
const gateway = new SPECGateway();

// Get token info
const tokenInfo = await gateway.getTokenInfo();

// Check balance
const balance = await gateway.getBalance('user123');

// Transfer tokens
const result = await gateway.transfer('recipient123', '1000000000000000000'); // 1 SPEC
\`\`\`

## Network Status

Check network status:
\`\`\`bash
docker ps
docker logs peer0.org1.spectra.com
\`\`\`

## Troubleshooting

1. **Port conflicts**: Ensure ports 7050, 7051, 5984 are available
2. **Permission issues**: Run with sudo if needed
3. **Container issues**: Run \`docker-compose down -v\` to reset

## Production Deployment

For production:
1. Use multiple orderers and peers
2. Enable TLS everywhere
3. Implement proper CA infrastructure
4. Set up monitoring and logging
5. Configure backup strategies

## Support

For technical support, contact the Spectra development team.

---

**IMPORTANT**: This creates a real blockchain network. Ensure you understand the implications before deploying to production.`;
  };

  const generateConfigTx = () => {
    return `Organizations:
    - &OrdererOrg
        Name: OrdererOrg
        ID: OrdererMSP
        MSPDir: crypto-config/ordererOrganizations/spectra.com/msp
        Policies:
            Readers:
                Type: Signature
                Rule: "OR('OrdererMSP.member')"
            Writers:
                Type: Signature
                Rule: "OR('OrdererMSP.member')"
            Admins:
                Type: Signature
                Rule: "OR('OrdererMSP.admin')"

    - &Org1
        Name: Org1MSP
        ID: Org1MSP
        MSPDir: crypto-config/peerOrganizations/org1.spectra.com/msp
        Policies:
            Readers:
                Type: Signature
                Rule: "OR('Org1MSP.admin', 'Org1MSP.peer', 'Org1MSP.client')"
            Writers:
                Type: Signature
                Rule: "OR('Org1MSP.admin', 'Org1MSP.client')"
            Admins:
                Type: Signature
                Rule: "OR('Org1MSP.admin')"
        AnchorPeers:
            - Host: peer0.org1.spectra.com
              Port: 7051

Capabilities:
    Channel: &ChannelCapabilities
        V2_0: true
    Orderer: &OrdererCapabilities
        V2_0: true
    Application: &ApplicationCapabilities
        V2_0: true

Application: &ApplicationDefaults
    Organizations:
    Policies:
        Readers:
            Type: ImplicitMeta
            Rule: "ANY Readers"
        Writers:
            Type: ImplicitMeta
            Rule: "ANY Writers"
        Admins:
            Type: ImplicitMeta
            Rule: "MAJORITY Admins"
    Capabilities:
        <<: *ApplicationCapabilities

Orderer: &OrdererDefaults
    OrdererType: solo
    Addresses:
        - orderer.spectra.com:7050
    BatchTimeout: 2s
    BatchSize:
        MaxMessageCount: 10
        AbsoluteMaxBytes: 99 MB
        PreferredMaxBytes: 512 KB
    Organizations:
    Policies:
        Readers:
            Type: ImplicitMeta
            Rule: "ANY Readers"
        Writers:
            Type: ImplicitMeta
            Rule: "ANY Writers"
        Admins:
            Type: ImplicitMeta
            Rule: "MAJORITY Admins"
        BlockValidation:
            Type: ImplicitMeta
            Rule: "ANY Writers"

Channel: &ChannelDefaults
    Policies:
        Readers:
            Type: ImplicitMeta
            Rule: "ANY Readers"
        Writers:
            Type: ImplicitMeta
            Rule: "ANY Writers"
        Admins:
            Type: ImplicitMeta
            Rule: "MAJORITY Admins"
    Capabilities:
        <<: *ChannelCapabilities

Profiles:
    SpectraOrdererGenesis:
        <<: *ChannelDefaults
        Orderer:
            <<: *OrdererDefaults
            Organizations:
                - *OrdererOrg
            Capabilities:
                <<: *OrdererCapabilities
        Consortiums:
            SpectraConsortium:
                Organizations:
                    - *Org1

    SpectraChannel:
        Consortium: SpectraConsortium
        <<: *ChannelDefaults
        Application:
            <<: *ApplicationDefaults
            Organizations:
                - *Org1
            Capabilities:
                <<: *ApplicationCapabilities`;
  };

  const generateCryptoConfig = () => {
    return `OrdererOrgs:
  - Name: Orderer
    Domain: spectra.com
    Specs:
      - Hostname: orderer

PeerOrgs:
  - Name: Org1
    Domain: org1.spectra.com
    EnableNodeOUs: true
    Template:
      Count: 1
    Users:
      Count: 1`;
  };

  const startDeployment = async () => {
    setIsDeploying(true);
    
    for (let i = 0; i < deploymentSteps.length; i++) {
      setDeploymentStep(i);
      await new Promise(resolve => setTimeout(resolve, 2000)); // Simulate deployment time
    }
    
    setIsDeploying(false);
    alert('SPEC Token successfully deployed to Hyperledger Fabric!');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Package className="w-8 h-8 text-blue-400" />
          <div>
            <h3 className="text-xl font-bold text-neutral-100">Blockchain Deployment Resources</h3>
            <p className="text-neutral-400">Deploy SPEC token to live Hyperledger Fabric network</p>
          </div>
        </div>
        
        <Alert className="bg-blue-500/20 border-blue-500/30">
          <AlertCircle className="w-4 h-4 text-blue-400" />
          <AlertDescription className="text-blue-400">
            <strong>Production Ready:</strong> This deployment package creates a real blockchain network with actual SPEC tokens.
            Ensure you understand the implications before deploying to production.
          </AlertDescription>
        </Alert>
      </div>

      {/* Deployment Package */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">Complete Deployment Package</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Code className="w-5 h-5 text-green-400" />
              <span className="font-medium text-neutral-200">Smart Contract</span>
            </div>
            <p className="text-sm text-neutral-400">SPEC token chaincode (Node.js)</p>
          </div>
          
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Network className="w-5 h-5 text-blue-400" />
              <span className="font-medium text-neutral-200">Network Config</span>
            </div>
            <p className="text-sm text-neutral-400">Docker Compose & Fabric configs</p>
          </div>
          
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Terminal className="w-5 h-5 text-purple-400" />
              <span className="font-medium text-neutral-200">Deploy Scripts</span>
            </div>
            <p className="text-sm text-neutral-400">Automated deployment scripts</p>
          </div>
          
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Database className="w-5 h-5 text-yellow-400" />
              <span className="font-medium text-neutral-200">API Gateway</span>
            </div>
            <p className="text-sm text-neutral-400">Node.js integration layer</p>
          </div>
        </div>

        <div className="flex gap-4">
          <Button
            onClick={handleDownloadResources}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white"
          >
            <Download className="w-4 h-4 mr-2" />
            Download Complete Package
          </Button>
          
          <Button
            onClick={startDeployment}
            disabled={isDeploying}
            variant="outline"
            className="border-white/20 text-neutral-200 hover:bg-white/10"
          >
            <Upload className="w-4 h-4 mr-2" />
            {isDeploying ? 'Deploying...' : 'Start Deployment'}
          </Button>
        </div>
      </div>

      {/* Deployment Progress */}
      {isDeploying && (
        <div className="glass-card rounded-xl p-6">
          <h4 className="text-lg font-bold text-neutral-100 mb-4">Deployment Progress</h4>
          
          <div className="space-y-3">
            {deploymentSteps.map((step, index) => (
              <div key={index} className="flex items-center gap-3">
                {index < deploymentStep ? (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                ) : index === deploymentStep ? (
                  <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <div className="w-5 h-5 border-2 border-neutral-600 rounded-full"></div>
                )}
                <span className={`${
                  index <= deploymentStep ? 'text-neutral-200' : 'text-neutral-500'
                }`}>
                  {step}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Network Specifications */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">Network Specifications</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-neutral-200 mb-3">Token Details</h5>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-400">Name:</span>
                <span className="text-neutral-200">Spectra Coin</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Symbol:</span>
                <span className="text-neutral-200">SPEC</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Decimals:</span>
                <span className="text-neutral-200">18</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Total Supply:</span>
                <span className="text-neutral-200">33.333 Trillion</span>
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-neutral-200 mb-3">Network Config</h5>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-400">Platform:</span>
                <span className="text-neutral-200">Hyperledger Fabric 2.4</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Channel:</span>
                <span className="text-neutral-200">spectrachannel</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Chaincode:</span>
                <span className="text-neutral-200">spec-token</span>
              </div>
              <div className="flex justify-between">
                <span className="text-neutral-400">Database:</span>
                <span className="text-neutral-200">CouchDB</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}