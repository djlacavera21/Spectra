import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUpRight, ArrowDownLeft, Zap, Activity } from "lucide-react";
import { format } from "date-fns";

export default function RealTimeTransactions() {
  const [realtimeTransactions, setRealtimeTransactions] = useState([]);
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    // Simulate real-time transaction events from Hyperledger Fabric
    const simulateTransactionEvents = () => {
      const transactionTypes = ['transfer', 'mint', 'marketplace_buy', 'marketplace_sell'];
      const addresses = [
        '0x742d35Cc6634C0532925a3b8D2B9f2C6C7b3c2e1',
        '0x8f3e2a9b1c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f',
        '0x1a2b3c4d5e6f7890abcdef1234567890abcdef12',
        '0x9e8d7c6b5a4938271605f4e3d2c1b0a9f8e7d6c5'
      ];

      const newTransaction = {
        id: Date.now(),
        hash: `0x${Math.random().toString(16).substr(2, 64)}`,
        type: transactionTypes[Math.floor(Math.random() * transactionTypes.length)],
        from: addresses[Math.floor(Math.random() * addresses.length)],
        to: addresses[Math.floor(Math.random() * addresses.length)],
        amount: Math.floor(Math.random() * 5000) + 100,
        timestamp: new Date().toISOString(),
        blockNumber: Math.floor(Math.random() * 1000) + 500000,
        status: Math.random() > 0.1 ? 'confirmed' : 'pending'
      };

      setRealtimeTransactions(prev => [newTransaction, ...prev.slice(0, 9)]);
    };

    if (isListening) {
      const interval = setInterval(simulateTransactionEvents, 3000);
      return () => clearInterval(interval);
    }
  }, [isListening]);

  useEffect(() => {
    // Auto-start listening when component mounts
    setIsListening(true);
  }, []);

  const getTransactionIcon = (type) => {
    switch (type) {
      case 'transfer':
        return <ArrowUpRight className="w-4 h-4 text-blue-400" />;
      case 'mint':
        return <Zap className="w-4 h-4 text-yellow-400" />;
      case 'marketplace_buy':
      case 'marketplace_sell':
        return <ArrowDownLeft className="w-4 h-4 text-green-400" />;
      default:
        return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'confirmed':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'pending':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-blue-400" />
          <h3 className="text-xl font-bold text-white">Real-Time Transactions</h3>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          <span className="text-sm text-white/60">Live</span>
        </div>
      </div>

      <div className="space-y-3">
        {realtimeTransactions.length > 0 ? (
          realtimeTransactions.map((tx) => (
            <div
              key={tx.id}
              className="glass-effect rounded-lg p-4 hover:bg-white/5 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  {getTransactionIcon(tx.type)}
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-white">
                        {tx.type.replace('_', ' ').toUpperCase()}
                      </span>
                      <Badge className={getStatusColor(tx.status)}>
                        {tx.status}
                      </Badge>
                    </div>
                    <p className="text-xs text-white/60">
                      Block #{tx.blockNumber.toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-white">
                    {tx.amount.toLocaleString()} SPEC
                  </p>
                  <p className="text-xs text-white/60">
                    {format(new Date(tx.timestamp), 'HH:mm:ss')}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <p className="text-white/60">From</p>
                  <p className="font-mono text-white/80">
                    {tx.from.slice(0, 10)}...{tx.from.slice(-6)}
                  </p>
                </div>
                <div>
                  <p className="text-white/60">To</p>
                  <p className="font-mono text-white/80">
                    {tx.to.slice(0, 10)}...{tx.to.slice(-6)}
                  </p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-white/60">
            <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
            <p>Waiting for transactions...</p>
            <p className="text-sm">Live transactions will appear here</p>
          </div>
        )}
      </div>
    </div>
  );
}