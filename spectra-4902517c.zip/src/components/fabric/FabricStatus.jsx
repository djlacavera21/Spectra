import React, { useState, useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Server, Activity, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export default function FabricStatus() {
  const [networkStatus, setNetworkStatus] = useState({
    status: 'connecting',
    blockHeight: 0,
    peersConnected: 0,
    lastBlockTime: null,
    contractsDeployed: 0
  });

  useEffect(() => {
    // Simulate network status check
    const checkNetworkStatus = () => {
      // In a real implementation, this would call the backend
      setNetworkStatus({
        status: 'online',
        blockHeight: Math.floor(Math.random() * 1000) + 500000,
        peersConnected: 2,
        lastBlockTime: new Date().toISOString(),
        contractsDeployed: 2
      });
    };

    checkNetworkStatus();
    const interval = setInterval(checkNetworkStatus, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'offline':
        return <XCircle className="w-4 h-4 text-red-400" />;
      case 'connecting':
        return <Activity className="w-4 h-4 text-yellow-400 animate-pulse" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'online':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'offline':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      case 'connecting':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <Server className="w-6 h-6 text-purple-400" />
        <h3 className="text-xl font-bold text-white">Hyperledger Fabric Network</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="flex items-center gap-3">
          {getStatusIcon(networkStatus.status)}
          <div>
            <p className="text-sm text-white/60">Network Status</p>
            <Badge className={getStatusColor(networkStatus.status)}>
              {networkStatus.status}
            </Badge>
          </div>
        </div>
        
        <div>
          <p className="text-sm text-white/60">Block Height</p>
          <p className="text-lg font-bold text-white">
            {networkStatus.blockHeight.toLocaleString()}
          </p>
        </div>
        
        <div>
          <p className="text-sm text-white/60">Peers Connected</p>
          <p className="text-lg font-bold text-white">
            {networkStatus.peersConnected}/2
          </p>
        </div>
        
        <div>
          <p className="text-sm text-white/60">Smart Contracts</p>
          <p className="text-lg font-bold text-white">
            {networkStatus.contractsDeployed}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="glass-effect rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
            <span className="text-sm font-medium text-white">SPEC Token Contract</span>
          </div>
          <p className="text-xs text-white/60">spec-token v1.0</p>
          <p className="text-xs text-white/60">Channel: spectra-channel</p>
        </div>
        
        <div className="glass-effect rounded-lg p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-green-400 rounded-full"></div>
            <span className="text-sm font-medium text-white">Marketplace Contract</span>
          </div>
          <p className="text-xs text-white/60">spectra-marketplace v1.0</p>
          <p className="text-xs text-white/60">Channel: spectra-channel</p>
        </div>
      </div>

      {networkStatus.lastBlockTime && (
        <div className="mt-4 text-xs text-white/60">
          Last block: {new Date(networkStatus.lastBlockTime).toLocaleString()}
        </div>
      )}
    </div>
  );
}