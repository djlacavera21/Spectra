
import React, { useState, useEffect, useRef, useImperativeHandle, forwardRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Terminal, 
  Play, 
  Square,
  Maximize2,
  Minimize2,
  Copy,
  Download,
  Upload,
  Settings,
  Zap,
  GitBranch,
  Server,
  Database,
  Network,
  CheckCircle,
  AlertTriangle,
  Loader2,
  Archive // Added Archive icon
} from "lucide-react";
import { User } from '@/api/entities'; // Added User import for wallet integration

const DEPLOYMENT_COMMANDS = [
  {
    category: "Environment Setup",
    commands: [
      "curl -fsSL https://get.docker.com -o get-docker.sh && sh get-docker.sh",
      "sudo usermod -aG docker $USER",
      "docker --version",
      "docker-compose --version",
      "curl -sSL https://bit.ly/2ysbOFE | bash -s",
      "export PATH=$PATH:$HOME/fabric-samples/bin"
    ]
  },
  {
    category: "Hyperledger Fabric Network",
    commands: [
      "cd ~/fabric-samples/test-network",
      "./network.sh down",
      "./network.sh up createChannel -ca -c spectrachannel",
      "export CORE_PEER_TLS_ENABLED=true",
      "export CORE_PEER_LOCALMSPID='Org1MSP'",
      "export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt",
      "export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp",
      "export CORE_PEER_ADDRESS=localhost:7051"
    ]
  },
  {
    category: "Spectra Coin Smart Contract",
    commands: [
      "mkdir -p ~/spectra-chaincode/src",
      "cd ~/spectra-chaincode",
      "npm init -y",
      "npm install fabric-contract-api",
      "cat > src/spectra-coin.js << 'EOF'",
      `'use strict';

const { Contract } = require('fabric-contract-api');

class SpectraCoinContract extends Contract {
    
    async InitLedger(ctx) {
        const TOTAL_SUPPLY = 33333333333333;
        const TOKEN_NAME = 'Spectra Coin';
        const TOKEN_SYMBOL = 'SPEC';
        
        const owner = ctx.clientIdentity.getID();
        const balance = { balance: TOTAL_SUPPLY };
        
        await ctx.stub.putState(owner, Buffer.from(JSON.stringify(balance)));
        await ctx.stub.putState('initialized', Buffer.from('true'));
        await ctx.stub.putState('tokenName', Buffer.from(TOKEN_NAME));
        await ctx.stub.putState('tokenSymbol', Buffer.from(TOKEN_SYMBOL));
        await ctx.stub.putState('totalSupply', Buffer.from(TOTAL_SUPPLY.toString()));
        await ctx.stub.putState('owner', Buffer.from(owner));
        
        console.log('\\nSpectra Coin initialized with 33.333 Trillion SPEC tokens');
        return JSON.stringify({ success: true, totalSupply: TOTAL_SUPPLY });
    }
    
    async GetBalance(ctx, accountId) {
        const data = await ctx.stub.getState(accountId);
        if (!data || data.length === 0) {
            return '0';
        }
        const balance = JSON.parse(data.toString());
        return balance.balance.toString();
    }
    
    async Transfer(ctx, to, amountStr) {
        const from = ctx.clientIdentity.getID();
        const amount = parseInt(amountStr);
        
        const fromBalanceBytes = await ctx.stub.getState(from);
        if (!fromBalanceBytes || fromBalanceBytes.length === 0) {
            throw new Error('Sender has no balance');
        }
        
        const fromBalance = JSON.parse(fromBalanceBytes.toString());
        if (fromBalance.balance < amount) {
            throw new Error('Insufficient balance');
        }
        
        const toBalanceBytes = await ctx.stub.getState(to);
        const toBalance = toBalanceBytes && toBalanceBytes.length > 0
            ? JSON.parse(toBalanceBytes.toString())
            : { balance: 0 };
        
        fromBalance.balance -= amount;
        toBalance.balance += amount;
        
        await ctx.stub.putState(from, Buffer.from(JSON.stringify(fromBalance)));
        await ctx.stub.putState(to, Buffer.from(JSON.stringify(toBalance)));
        
        return JSON.stringify({ success: true, from, to, amount });
    }
    
    async TokenInfo(ctx) {
        const name = await ctx.stub.getState('tokenName');
        const symbol = await ctx.stub.getState('tokenSymbol');
        const totalSupply = await ctx.stub.getState('totalSupply');
        
        return JSON.stringify({
            name: name.toString(),
            symbol: symbol.toString(),
            totalSupply: totalSupply.toString()
        });
    }
}

module.exports = SpectraCoinContract;
EOF`,
      "cat > package.json << 'EOF'",
      `{
  "name": "spectra-coin-chaincode",
  "version": "1.0.0",
  "description": "Spectra Coin Smart Contract for Hyperledger Fabric",
  "main": "index.js",
  "engines": {
    "node": ">=14"
  },
  "scripts": {
    "start": "fabric-chaincode-node start"
  },
  "dependencies": {
    "fabric-contract-api": "^2.2.0",
    "fabric-shim": "^2.2.0"
  }
}
EOF`,
      "cat > index.js << 'EOF'",
      `'use strict';

const SpectraCoinContract = require('./src/spectra-coin');

module.exports.SpectraCoinContract = SpectraCoinContract;
module.exports.contracts = [SpectraCoinContract];
EOF`
    ]
  },
  {
    category: "Chaincode Deployment",
    commands: [
      "cd ~/fabric-samples/test-network",
      "peer lifecycle chaincode package spectra_coin.tar.gz --path ~/spectra-chaincode --lang node --label spectra_coin_1.0",
      "peer lifecycle chaincode install spectra_coin.tar.gz",
      "peer lifecycle chaincode queryinstalled",
      "export CC_PACKAGE_ID=$(peer lifecycle chaincode queryinstalled --output json | jq -r '.installed_chaincodes[0].package_id')",
      "peer lifecycle chaincode approveformyorg -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID spectrachannel --name spectraCoin --version 1.0 --package-id $CC_PACKAGE_ID --sequence 1 --init-required --tls --cafile ${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem",
      "peer lifecycle chaincode checkcommitreadiness --channelID spectrachannel --name spectraCoin --version 1.0 --sequence 1 --init-required --tls --cafile ${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem --output json",
      "peer lifecycle chaincode commit -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --channelID spectrachannel --name spectraCoin --version 1.0 --sequence 1 --init-required --tls --cafile ${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem --peerAddresses localhost:7051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt --peerAddresses localhost:9051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt"
    ]
  },
  {
    category: "Spectra Coin Initialization",
    commands: [
      "peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile ${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem -C spectrachannel -n spectraCoin --peerAddresses localhost:7051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt --peerAddresses localhost:9051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org2.example.com/peers/peer0.org2.example.com/tls/ca.crt --isInit -c '{\"function\":\"InitLedger\",\"Args\":[]}'",
      "echo '🎉 Spectra Coin initialized with 33.333 Trillion SPEC tokens!'",
      "peer chaincode query -C spectrachannel -n spectraCoin -c '{\"function\":\"TokenInfo\",\"Args\":[]}'",
      "echo '💰 Querying token information...'",
      "peer chaincode query -C spectrachannel -n spectraCoin -c '{\"function\":\"GetBalance\",\"Args\":[\"x509::/C=US/ST=North Carolina/O=Hyperledger/OU=Fabric/CN=appUser1::CN=ca.org1.example.com,O=org1.example.com,L=Durham,ST=North Carolina,C=US\"]}'",
      "echo '🚀 Spectra Coin deployment completed successfully!'"
    ]
  },
  {
    category: "Testing & Verification",
    commands: [
      "echo '🔍 Testing Spectra Coin functionality...'",
      "peer chaincode invoke -o localhost:7050 --ordererTLSHostnameOverride orderer.example.com --tls --cafile ${PWD}/organizations/ordererOrganizations/example.com/orderers/orderer.example.com/msp/tlscacerts/tlsca.example.com-cert.pem -C spectrachannel -n spectraCoin --peerAddresses localhost:7051 --tlsRootCertFiles ${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt -c '{\"function\":\"Transfer\",\"Args\":[\"testUser\",\"1000000\"]}'",
      "echo '💸 Transferred 1,000,000 SPEC tokens to testUser'",
      "peer chaincode query -C spectrachannel -n spectraCoin -c '{\"function\":\"GetBalance\",\"Args\":[\"testUser\"]}'",
      "echo '✅ Transfer verified successfully!'",
      "docker ps",
      "echo '🌐 Spectra Network Status:'",
      "docker logs peer0.org1.example.com | tail -10",
      "echo '📊 Network is running and processing transactions!'",
      "echo '🎯 Live Stream Demo Complete - Spectra Coin is now deployed on Hyperledger Fabric!'"
    ]
  }
];

const BITCOIN_ZIP_COMMANDS = [
  {
    category: "Archive Extraction",
    commands: [
      "echo 'Receiving bitcoin-master.zip...'",
      "unzip bitcoin-master.zip -d ./build",
      "cd ./build/bitcoin-master",
      "echo '📁 Extracted source files successfully'"
    ]
  },
  {
    category: "Configuration & Customization",
    commands: [
      "echo '🔧 Applying coin configuration...'",
      "sed -i 's/Bitcoin/{{COIN_NAME}}/g' *.cpp *.h",
      "sed -i 's/BTC/{{TICKER_SYMBOL}}/g' *.cpp *.h",
      "sed -i 's/bitcoin/{{COIN_NAME_LOWER}}/g' *.cpp *.h",
      "sed -i 's/0.21.1/{{VERSION}}/g' *.cpp *.h",
      "sed -i 's/MAX_MONEY = 21000000/MAX_MONEY = {{AMOUNT_TO_MINT}}/g' *.h", // Added line
      "echo '✅ Coin parameters updated: {{COIN_NAME}} ({{TICKER_SYMBOL}}) v{{VERSION}}'",
      "echo '✅ Total supply set to: {{AMOUNT_TO_MINT}}'", // Added line
      "echo '🏗️  Preparing build configuration...'"
    ]
  },
  {
    category: "Build Configuration",
    commands: [
      "./autogen.sh",
      "./configure --with-gui=no --enable-wallet",
      "echo '✅ Build configuration completed'"
    ]
  },
  {
    category: "Compilation",
    commands: [
      "make clean",
      "make -j$(nproc)",
      "make install",
      "echo '🚀 {{COIN_NAME}} daemon compiled successfully!'"
    ]
  },
  {
    category: "Genesis Block Creation",
    commands: [
      "echo '💎 Creating genesis block for {{COIN_NAME}}...'",
      "{{COIN_NAME_LOWER}}d -daemon -regtest",
      "sleep 3",
      "{{COIN_NAME_LOWER}}-cli -regtest generate 1",
      "{{COIN_NAME_LOWER}}-cli -regtest getblockchaininfo",
      "echo '✅ Genesis block created and blockchain initialized!'"
    ]
  },
  {
    category: "Wallet Creation & Setup",
    commands: [
      "echo '💳 Setting up {{COIN_NAME}} wallet...'",
      "{{COIN_NAME_LOWER}}-cli -regtest createwallet \"{{COIN_NAME_LOWER}}_wallet\"",
      "NEW_ADDRESS=$({{COIN_NAME_LOWER}}-cli -regtest getnewaddress)",
      "echo \"📍 New {{TICKER_SYMBOL}} wallet address: $NEW_ADDRESS\"",
      "{{COIN_NAME_LOWER}}-cli -regtest generatetoaddress 50 $NEW_ADDRESS",
      "BALANCE=$({{COIN_NAME_LOWER}}-cli -regtest getbalance)",
      "echo \"💰 Initial {{TICKER_SYMBOL}} balance: $BALANCE\"",
      "echo '✅ {{COIN_NAME}} wallet created and funded!'"
    ]
  },
  {
    category: "Desktop Wallet Packaging",
    commands: [
      "echo '📦 Packaging {{COIN_NAME}} desktop wallet...'",
      "mkdir -p ../../{{COIN_NAME_LOWER}}-wallet-v{{VERSION}}",
      "cp {{COIN_NAME_LOWER}}d {{COIN_NAME_LOWER}}-cli {{COIN_NAME_LOWER}}-tx ../../{{COIN_NAME_LOWER}}-wallet-v{{VERSION}}/",
      "cp README.txt license.txt ../../{{COIN_NAME_LOWER}}-wallet-v{{VERSION}}/",
      "cd ../../",
      "zip -r {{COIN_NAME_LOWER}}-wallet-v{{VERSION}}.zip {{COIN_NAME_LOWER}}-wallet-v{{VERSION}}/",
      "echo '✅ Desktop wallet package created: {{COIN_NAME_LOWER}}-wallet-v{{VERSION}}.zip'",
      "echo '📡 Registering new coin in Spectra ecosystem...'"
    ]
  }
];

const LinuxShellEmulator = forwardRef((props, ref) => {
  const [isShellActive, setIsShellActive] = useState(true); // Default to active
  const [currentCommand, setCurrentCommand] = useState('');
  const [commandHistory, setCommandHistory] = useState([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [output, setOutput] = useState([
    '🚀 Spectra Live Stream Deployment Console',
    '📡 Shell-in-a-Box Emulator Ready',
    '💎 Welcome to the Spectra Coin Deployment Demo!',
    '',
    'Type "help" for deployment commands or "deploy-spectra" for full auto-deployment.',
    'user@spectra-fabric:~$ '
  ]);
  const [isExecuting, setIsExecuting] = useState(false);
  const [deploymentStep, setDeploymentStep] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentCategory, setCurrentCategory] = useState('');
  const terminalRef = useRef(null);
  const inputRef = useRef(null);
  const [coinConfig, setCoinConfig] = useState({
    coinName: 'GenesisCoin',
    tickerSymbol: 'GEN',
    version: '0.1.0',
    amountToMint: 21000000 // Added
  });

  useImperativeHandle(ref, () => ({
    runCommand: (command) => {
      if (!isExecuting) {
        simulateCommandExecution(command.trim());
      }
    },
    setCoinConfig: (config) => {
      setCoinConfig(config);
    }
  }));

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [output]);

  useEffect(() => {
    if (inputRef.current && isShellActive) {
      inputRef.current.focus();
    }
  }, [isShellActive]);

  const generateMockAddress = (symbol) => {
    // Generate different address formats based on coin type
    const formats = {
      'BTC': () => `1${btoa(Math.random().toString()).substring(0, 27)}`,
      'ETH': () => `0x${Array.from(crypto.getRandomValues(new Uint8Array(20))).map(b => b.toString(16).padStart(2, '0')).join('')}`,
      'default': () => `${symbol}${Array.from(crypto.getRandomValues(new Uint8Array(16))).map(b => b.toString(16).padStart(2, '0')).join('')}`
    };
    
    return (formats[symbol] || formats['default'])();
  };

  const generateMockHash = () => {
    return Array.from(crypto.getRandomValues(new Uint8Array(32)))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
  };

  const simulateCommandExecution = async (command, delay = 1000) => {
    setIsExecuting(true);
    
    // Add command to output
    setOutput(prev => [...prev, `user@spectra-fabric:~$ ${command}`]);
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Simulate different command outputs
    let commandOutput = [];
    
    if (command.includes('docker --version')) {
      commandOutput = ['Docker version 24.0.7, build afdd53b'];
    } else if (command.includes('fabric-samples')) {
      commandOutput = ['===> Downloading Hyperledger Fabric samples', '===> Pulling fabric Images', '===> Fabric Images pulled successfully'];
    } else if (command.includes('./network.sh up')) {
      commandOutput = [
        '🚀 Starting Hyperledger Fabric Network...',
        'Creating channel "spectrachannel"',
        '✅ Channel created successfully',
        '🌐 Network is up and running!'
      ];
    } else if (command.includes('chaincode package')) {
      commandOutput = ['📦 Packaging Spectra Coin chaincode...', '✅ spectra_coin.tar.gz created successfully'];
    } else if (command.includes('chaincode install')) {
      commandOutput = ['📥 Installing chaincode on peers...', '✅ Chaincode installed successfully'];
    } else if (command.includes('InitLedger')) {
      commandOutput = [
        '🎉 Initializing Spectra Coin...',
        '💰 Creating 33,333,333,333,333 SPEC tokens',
        '📝 Setting token name: Spectra Coin',
        '🏷️  Setting token symbol: SPEC',
        '✅ Spectra Coin initialized successfully!'
      ];
    } else if (command.includes('TokenInfo')) {
      commandOutput = [
        '📊 Token Information:',
        '   Name: Spectra Coin',
        '   Symbol: SPEC',
        '   Total Supply: 33,333,333,333,333',
        '💎 Token deployment verified!'
      ];
    } else if (command.includes('Transfer')) {
      commandOutput = ['💸 Processing transfer...', '✅ Transfer completed successfully'];
    } else if (command.includes('GetBalance')) {
      commandOutput = ['💰 Balance: 33,332,999,333,333 SPEC'];
    } else if (command.includes('docker ps')) {
      commandOutput = [
        'CONTAINER ID   IMAGE                               COMMAND                  STATUS',
        '1a2b3c4d5e6f   hyperledger/fabric-peer:latest     "peer node start"        Up 5 minutes',
        '2b3c4d5e6f7g   hyperledger/fabric-orderer:latest  "orderer"                Up 5 minutes',
        '3c4d5e6f7g8h   hyperledger/fabric-ca:latest       "sh -c fabric-ca-server" Up 5 minutes'
      ];
    } else if (command === 'help') {
      commandOutput = [
        '🔧 Available Commands:',
        '   deploy-spectra      - Run full Spectra Coin (Hyperledger) deployment',
        '   deploy-bitcoin-zip  - Run deployment from uploaded bitcoin-master.zip',
        '   setup-fabric        - Setup Hyperledger Fabric environment',
        '   create-contract     - Create Spectra Coin smart contract',
        '   deploy-contract     - Deploy contract to network',
        '   test-contract       - Test contract functionality',
        '   network-status      - Check network status',
        '   clear               - Clear terminal',
        '',
        '💡 Tip: Use "deploy-spectra" for the complete Hyperledger demo or "deploy-bitcoin-zip" for custom coin creation.'
      ];
    } else if (command === 'deploy-spectra') {
      return await runFullDeployment(DEPLOYMENT_COMMANDS, 'Spectra Coin (Hyperledger Fabric)');
    } else if (command === 'deploy-bitcoin-zip') {
      return await runFullDeployment(BITCOIN_ZIP_COMMANDS, 'Custom Coin from Zip');
    } else if (command === 'clear') {
      setOutput([
        '🚀 Spectra Live Stream Deployment Console',
        'user@spectra-fabric:~$ '
      ]);
      setIsExecuting(false);
      return;
    } else if (command.includes('sed -i')) {
      commandOutput = [`🔧 Replacing Bitcoin references with ${coinConfig.coinName}...`, '✅ Configuration updated'];
    } else if (command.includes('createwallet')) {
      commandOutput = [`📝 Creating wallet for ${coinConfig.coinName}...`, `✅ Wallet "${coinConfig.coinName.toLowerCase()}_wallet" created`];
    } else if (command.includes('getnewaddress')) {
      const mockAddress = generateMockAddress(coinConfig.tickerSymbol);
      commandOutput = [`📍 New ${coinConfig.tickerSymbol} address: ${mockAddress}`];
    } else if (command.includes('generatetoaddress')) {
      commandOutput = [`⛏️  Mining 50 blocks to fund wallet...`, `✅ 50 blocks mined successfully`];
    } else if (command.includes('getbalance')) {
      commandOutput = [`💰 Current balance: 50.00000000 ${coinConfig.tickerSymbol}`];
    } else if (command.startsWith('unzip')) {
        commandOutput = ['Archive:  bitcoin-master.zip', '   creating: ./build/bitcoin-master/', '  inflating: ./build/bitcoin-master/main.cpp', '  inflating: ./build/bitcoin-master/src/wallet.cpp', '... (files extracted)', 'Done.'];
    } else if (command.startsWith('./autogen.sh')) {
        commandOutput = ['Generating build system...', 'libtoolize: putting files in AC_CONFIG_AUX_DIR, `aux`', 'libtoolize: copying file `aux/ltmain.sh`', '... (autogen output)', 'Done.'];
    } else if (command.startsWith('./configure')) {
        commandOutput = ['checking for a BSD-compatible install... /usr/bin/install -c', 'checking for g++... g++', 'checking whether the C++ compiler works... yes', 'checking for pkg-config... /usr/bin/pkg-config', '... (configure options)', 'Configuration complete.'];
    } else if (command.startsWith('make')) {
        commandOutput = ['Making all in src...', '  CXX      main.o', '  CXX      wallet.o', '  CXX      net.o', '  LINK     bitcoind', '  LINK     bitcoin-cli', '... (compilation output)', 'Build complete.'];
    } else if (command.includes('daemon')) {
        commandOutput = [`${coinConfig.coinName} server starting`, `${coinConfig.coinName} Core version v${coinConfig.version} (64-bit)`, 'Loading P2P addresses...', `Initialized RPC server at 127.0.0.1:8332`];
    } else if (command.includes('-cli') && (command.includes('getinfo') || command.includes('getblockchaininfo'))) {
        commandOutput = ['{', `  "chain": "regtest",`, `  "blocks": 1,`, `  "bestblockhash": "0x${generateMockHash()}",`, `  "difficulty": 4.656542373906925e-10,`, `  "mediantime": ${Math.floor(Date.now() / 1000)},`, `  "verificationprogress": 1,`, `  "initialblockdownload": false,`, `  "chainwork": "0x02",`, `  "size_on_disk": 293,`, `  "pruned": false`, '}'];
    } else if (command.startsWith('zip -r')) {
      commandOutput = [`  adding: ${coinConfig.coinName.toLowerCase()}-wallet-v${coinConfig.version}/ (stored 0%)`, `  adding: ${coinConfig.coinName.toLowerCase()}-wallet-v${coinConfig.version}/${coinConfig.coinName.toLowerCase()}d (deflated 65%)`, `  adding: ${coinConfig.coinName.toLowerCase()}-wallet-v${coinConfig.version}/${coinConfig.coinName.toLowerCase()}-cli (deflated 60%)`, 'Finished packaging wallet.'];
    } else {
      commandOutput = [`bash: ${command}: command not found`];
    }
    
    // Add output with typing effect
    for (const line of commandOutput) {
      await new Promise(resolve => setTimeout(resolve, 300));
      setOutput(prev => [...prev, line]);
    }
    
    await new Promise(resolve => setTimeout(resolve, delay));
    setOutput(prev => [...prev, '', 'user@spectra-fabric:~$ ']);
    setIsExecuting(false);
  };

  const runFullDeployment = async (commandSet, type) => {
    setOutput(prev => [...prev, `🎬 Starting Full ${type} Deployment...`, '']);
    
    for (let i = 0; i < commandSet.length; i++) {
      const category = commandSet[i];
      setCurrentCategory(category.category);
      setDeploymentStep(i + 1);
      
      setOutput(prev => [...prev, `📋 === ${category.category} ===`, '']);
      
      for (const rawCommand of category.commands) {
        // Replace placeholders with actual coin configuration
        const command = rawCommand
          .replace(/\{\{COIN_NAME\}\}/g, coinConfig.coinName)
          .replace(/\{\{TICKER_SYMBOL\}\}/g, coinConfig.tickerSymbol)
          .replace(/\{\{VERSION\}\}/g, coinConfig.version)
          .replace(/\{\{COIN_NAME_LOWER\}\}/g, coinConfig.coinName.toLowerCase())
          .replace(/\{\{AMOUNT_TO_MINT\}\}/g, coinConfig.amountToMint); // Added
        
        if (command.startsWith('cat >') || command === 'EOF') {
          // Handle file creation commands
          setOutput(prev => [...prev, `user@spectra-fabric:~$ ${command}`]);
          await new Promise(resolve => setTimeout(resolve, 500));
          if (command.includes('spectra-coin.js')) {
            setOutput(prev => [...prev, '📝 Creating Spectra Coin smart contract...', '✅ Smart contract created successfully!']);
          } else if (command.includes('package.json')) {
            setOutput(prev => [...prev, '📦 Creating package.json...', '✅ Package configuration created!']);
          } else if (command.includes('index.js')) {
            setOutput(prev => [...prev, '🔗 Creating contract index...', '✅ Contract entry point created!']);
          }
          await new Promise(resolve => setTimeout(resolve, 800));
        } else if (command.includes('echo') || command.includes('sleep')) { // Added sleep to echo-like handling
          await simulateCommandExecution(command, 500);
        } else {
          await simulateCommandExecution(command, 1200);
        }
      }
      
      setOutput(prev => [...prev, `✅ ${category.category} completed!`, '']);
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    // Register new coin in user's wallet after successful deployment
    if (type === 'Custom Coin from Zip') {
      await registerNewCoinInWallet();
    }

    setOutput(prev => [...prev, 
      `🎉 ${type} DEPLOYMENT COMPLETE! 🎉`,
      '',
      type === 'Custom Coin from Zip' ? `✅ ${coinConfig.coinName} (${coinConfig.tickerSymbol}) has been successfully created!` : `✅ ${type} process finished successfully!`,
      '',
      type === 'Spectra Coin (Hyperledger Fabric)' ? '✨ Spectra Coin has been successfully deployed to Hyperledger Fabric!' : '',
      type === 'Spectra Coin (Hyperledger Fabric)' ? '💎 33.333 Trillion SPEC tokens are now live on the blockchain' : '',
      type === 'Spectra Coin (Hyperledger Fabric)' ? '🚀 Network is running and ready for transactions' : '',
      type === 'Spectra Coin (Hyperledger Fabric)' ? '📊 Smart contract functions verified and operational' : '',
      type === 'Custom Coin from Zip' ? '🏦 New coin registered in your Spectra wallet' : '',
      type === 'Custom Coin from Zip' ? '💎 Genesis wallet created with initial balance' : '',
      type === 'Custom Coin from Zip' ? '📦 Desktop wallet package ready for download' : '',
      '',
      '👥 Thank you for watching the Spectra Live Stream!',
      'user@spectra-fabric:~$ '
    ]);
    
    setCurrentCategory('');
    setDeploymentStep(0);
    setIsExecuting(false);
  };

  const registerNewCoinInWallet = async () => {
    try {
      const currentUser = await User.me();
      
      // Generate wallet address for new coin
      const newWalletAddress = generateMockAddress(coinConfig.tickerSymbol);
      
      // Add new coin to user's custom tokens
      const customTokens = currentUser.custom_tokens || [];
      const newToken = {
        symbol: coinConfig.tickerSymbol,
        name: coinConfig.coinName,
        wallet_address: newWalletAddress,
        balance: 50.0, // Initial mining reward from generate 50
        network: 'custom',
        created_date: new Date().toISOString(),
        genesis_block: generateMockHash(),
        total_supply: parseInt(coinConfig.amountToMint, 10), // Updated
        decimals: 8
      };
      
      customTokens.push(newToken);
      
      await User.updateMyUserData({
        custom_tokens: customTokens,
        [`${coinConfig.tickerSymbol.toLowerCase()}_wallet_address`]: newWalletAddress,
        [`${coinConfig.tickerSymbol.toLowerCase()}_balance`]: 50.0
      });
      
      console.log(`✅ ${coinConfig.coinName} registered in wallet`);
    } catch (error) {
      console.error('Error registering new coin:', error);
    }
  };

  const handleCommandSubmit = (e) => {
    e.preventDefault();
    if (!currentCommand.trim() || isExecuting) return;
    
    setCommandHistory(prev => [...prev, currentCommand]);
    setHistoryIndex(-1);
    simulateCommandExecution(currentCommand.trim());
    setCurrentCommand('');
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (historyIndex < commandHistory.length - 1) {
        const newIndex = historyIndex + 1;
        setHistoryIndex(newIndex);
        setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        setHistoryIndex(newIndex);
        setCurrentCommand(commandHistory[commandHistory.length - 1 - newIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setCurrentCommand('');
      }
    }
  };

  const copyOutput = () => {
    const text = output.join('\n');
    navigator.clipboard.writeText(text);
    alert('Terminal output copied to clipboard!');
  };

  const getDeploymentCommands = () => {
    if (currentCategory.includes('Spectra')) {
        return DEPLOYMENT_COMMANDS;
    } else if (currentCategory.includes('Coin from Zip')) {
        return BITCOIN_ZIP_COMMANDS;
    }
    return DEPLOYMENT_COMMANDS; // Default if no specific deployment is active
};


  return (
    <div className={`space-y-6 ${isFullscreen ? 'fixed inset-0 z-50 bg-black p-4' : ''}`}>
      {/* Header */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-r from-green-600 to-blue-600 rounded-xl flex items-center justify-center">
              <Terminal className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-neutral-100">Linux Shell Emulator</h3>
              <p className="text-neutral-400">Shell-in-a-Box for Live Spectra Deployment Demo</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {deploymentStep > 0 && (
              <Badge className="bg-blue-500/20 text-blue-400">
                Step {deploymentStep}/{getDeploymentCommands().length} : {currentCategory}
              </Badge>
            )}
            <Button
              onClick={() => setIsFullscreen(!isFullscreen)}
              variant="outline"
              size="icon"
              className="border-white/20 text-neutral-300"
            >
              {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </Button>
          </div>
        </div>

        <Alert className="bg-green-500/20 border-green-500/30">
          <Terminal className="w-4 h-4 text-green-400" />
          <AlertDescription className="text-green-400">
            <strong>Live Stream Ready:</strong> This shell emulator will demonstrate the complete Spectra Coin deployment process 
            on Hyperledger Fabric and custom coin creation from a zip archive. Use "deploy-spectra" or "deploy-bitcoin-zip" command to run a full demo sequence.
          </AlertDescription>
        </Alert>
      </div>

      {/* Terminal Interface */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="bg-neutral-900 px-4 py-2 flex items-center justify-between border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="flex gap-2">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
            </div>
            <span className="text-neutral-400 text-sm ml-4">user@spectra-fabric:~</span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={copyOutput}
              variant="ghost"
              size="sm"
              className="text-neutral-400 hover:text-neutral-100"
            >
              <Copy className="w-3 h-3" />
            </Button>
            <Button
              onClick={() => setIsShellActive(!isShellActive)}
              variant="ghost"
              size="sm"
              className={isShellActive ? "text-red-400 hover:text-red-300" : "text-green-400 hover:text-green-300"}
            >
              {isShellActive ? <Square className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            </Button>
          </div>
        </div>

        <div 
          ref={terminalRef}
          className={`bg-black text-green-400 font-mono text-sm p-4 overflow-y-auto ${isFullscreen ? 'h-[calc(100vh-200px)]' : 'h-96'}`}
        >
          {output.map((line, index) => (
            <div key={index} className="whitespace-pre-wrap">
              {line}
            </div>
          ))}
          
          {isShellActive && !isExecuting && (
            <form onSubmit={handleCommandSubmit} className="flex items-center">
              <span className="text-green-400">user@spectra-fabric:~$ </span>
              <input
                ref={inputRef}
                type="text"
                value={currentCommand}
                onChange={(e) => setCurrentCommand(e.target.value)}
                onKeyDown={handleKeyDown}
                className="flex-1 bg-transparent border-none outline-none text-green-400 ml-1"
                autoComplete="off"
                disabled={isExecuting}
              />
              {isExecuting && <Loader2 className="w-4 h-4 animate-spin text-green-400 ml-2" />}
            </form>
          )}
        </div>
      </div>

      {/* Quick Commands for Live Demo */}
      <div className="glass-card rounded-xl p-6">
        <h4 className="text-lg font-bold text-neutral-100 mb-4">🎬 Incubator Quick Commands</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
           <Button
            onClick={() => simulateCommandExecution('deploy-bitcoin-zip')}
            disabled={isExecuting}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white h-12"
          >
            <Archive className="w-4 h-4 mr-2" />
            Deploy Custom Coin
          </Button>
          <Button
            onClick={() => simulateCommandExecution('deploy-spectra')}
            disabled={isExecuting}
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white h-12"
          >
            <Zap className="w-4 h-4 mr-2" />
            Full Demo Deploy (Hyperledger)
          </Button>
          <Button
            onClick={() => simulateCommandExecution('setup-fabric')}
            disabled={isExecuting}
            className="bg-blue-600 hover:bg-blue-700 text-white h-12"
          >
            <Server className="w-4 h-4 mr-2" />
            Setup Fabric
          </Button>
          <Button
            onClick={() => simulateCommandExecution('docker ps')}
            disabled={isExecuting}
            className="bg-green-600 hover:bg-green-700 text-white h-12"
          >
            <Database className="w-4 h-4 mr-2" />
            Network Status
          </Button>
          <Button
            onClick={() => simulateCommandExecution('peer chaincode query -C spectrachannel -n spectraCoin -c \'{"function":"TokenInfo","Args":[]}\'')}
            disabled={isExecuting}
            className="bg-yellow-600 hover:bg-yellow-700 text-white h-12"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Verify SPEC
          </Button>
          <Button
            onClick={() => simulateCommandExecution('help')}
            disabled={isExecuting}
            className="bg-purple-600 hover:bg-purple-700 text-white h-12"
          >
            <Terminal className="w-4 h-4 mr-2" />
            Help Commands
          </Button>
          <Button
            onClick={() => simulateCommandExecution('clear')}
            disabled={isExecuting}
            className="bg-neutral-600 hover:bg-neutral-700 text-white h-12"
          >
            Clear Terminal
          </Button>
        </div>
      </div>

      {/* Deployment Progress */}
      {deploymentStep > 0 && (
        <div className="glass-card rounded-xl p-6">
          <h4 className="text-lg font-bold text-neutral-100 mb-4">🚀 Live Deployment Progress</h4>
          <div className="space-y-3">
            {getDeploymentCommands().map((category, index) => (
              <div key={index} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  index + 1 < deploymentStep ? 'bg-green-500' :
                  index + 1 === deploymentStep ? 'bg-blue-500 animate-pulse' :
                  'bg-neutral-600'
                }`}>
                  {index + 1 < deploymentStep ? (
                    <CheckCircle className="w-4 h-4 text-white" />
                  ) : (
                    <span className="text-white text-sm">{index + 1}</span>
                  )}
                </div>
                <div className="flex-1">
                  <p className={`font-medium ${
                    index + 1 <= deploymentStep ? 'text-neutral-100' : 'text-neutral-400'
                  }`}>
                    {category.category}
                  </p>
                  <p className="text-xs text-neutral-500">{category.commands.length} commands</p>
                </div>
                {index + 1 === deploymentStep && (
                  <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
});

export default LinuxShellEmulator;
