
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Terminal,
  Play,
  Code,
  Database,
  Network,
  CheckCircle,
  AlertTriangle
} from "lucide-react";

export default function FabricSDKInterface() {
  const [selectedSDK, setSelectedSDK] = useState('nodejs');
  const [queryInput, setQueryInput] = useState('');
  const [transactionInput, setTransactionInput] = useState('');
  const [isExecuting, setIsExecuting] = useState(false);

  const sdkExamples = {
    nodejs: {
      query: `const { Gateway, Wallets } = require('fabric-network');

async function queryLedger() {
    const wallet = await Wallets.newFileSystemWallet('./wallet');
    const gateway = new Gateway();

    await gateway.connect(connectionProfile, {
        wallet,
        identity: 'appUser',
        discovery: { enabled: true, asLocalhost: true }
    });

    const network = await gateway.getNetwork('spectrachannel');
    const contract = network.getContract('spec-token');

    const result = await contract.evaluateTransaction('balanceOf', 'user123');
    console.log('Balance:', result.toString());

    gateway.disconnect();
}`,
      transaction: `async function transferTokens() {
    const gateway = new Gateway();
    await gateway.connect(connectionProfile, { wallet, identity: 'appUser' });

    const network = await gateway.getNetwork('spectrachannel');
    const contract = network.getContract('spec-token');

    await contract.submitTransaction('transfer', 'recipient', '1000');
    console.log('Transfer completed');

    gateway.disconnect();
}`
    },
    go: {
      query: `package main

import (
    "github.com/hyperledger/fabric-sdk-go/pkg/core/config"
    "github.com/hyperledger/fabric-sdk-go/pkg/gateway"
)

func queryLedger() error {
    wallet, err := gateway.NewFileSystemWallet("wallet")
    if err != nil {
        return err
    }

    gw, err := gateway.Connect(
        gateway.WithConfig(config.FromFile("connection.yaml")),
        gateway.WithIdentity(wallet, "appUser"),
    )
    if err != nil {
        return err
    }
    defer gw.Close()

    network, err := gw.GetNetwork("spectrachannel")
    if err != nil {
        return err
    }

    contract := network.GetContract("spec-token")
    result, err := contract.EvaluateTransaction("balanceOf", "user123")
    if err != nil {
        return err
    }

    fmt.Printf("Balance: %s", result)
    return nil
}`,
      transaction: `func transferTokens() error {
    // ... connection setup ...

    contract := network.GetContract("spec-token")
    _, err := contract.SubmitTransaction("transfer", "recipient", "1000")
    if err != nil {
        return err
    }

    fmt.Println("Transfer completed")
    return nil
}`
    },
    java: {
      query: `import org.hyperledger.fabric.gateway.*;

public class QueryLedger {
    public static void main(String[] args) throws Exception {
        Wallet wallet = Wallets.newFileSystemWallet(Paths.get("wallet"));

        Gateway.Builder builder = Gateway.createBuilder();
        builder.identity(wallet, "appUser").networkConfig(Paths.get("connection.yaml"));

        try (Gateway gateway = builder.connect()) {
            Network network = gateway.getNetwork("spectrachannel");
            Contract contract = network.getContract("spec-token");

            byte[] result = contract.evaluateTransaction("balanceOf", "user123");
            System.out.println("Balance: " + new String(result));
        }
    }
}`,
      transaction: `public void transferTokens() throws Exception {
    // ... connection setup ...

    Contract contract = network.getContract("spec-token");
    contract.submitTransaction("transfer", "recipient", "1000");
    System.out.println("Transfer completed");
}`
    }
  };

  const handleExecuteQuery = async () => {
    setIsExecuting(true);
    // Simulate query execution
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsExecuting(false);
    alert('Query executed successfully!');
  };

  const handleExecuteTransaction = async () => {
    setIsExecuting(true);
    // Simulate transaction execution
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsExecuting(false);
    alert('Transaction submitted successfully!');
  };

  return (
    <div className="space-y-6">
      {/* SDK Interface */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Terminal className="w-6 h-6 text-green-400" />
            <h3 className="text-xl font-bold text-neutral-100">Fabric SDK Interface</h3>
          </div>
          <div className="flex gap-2">
            {['nodejs', 'go', 'java'].map(sdk => (
              <Button
                key={sdk}
                variant={selectedSDK === sdk ? "default" : "secondary"}
                size="sm"
                onClick={() => setSelectedSDK(sdk)}
                className={selectedSDK === sdk ? 'bg-blue-600 text-white' : 'bg-white text-black hover:bg-neutral-200'}
              >
                {sdk.toUpperCase()}
              </Button>
            ))}
          </div>
        </div>

        <Tabs defaultValue="query" className="w-full">
          <TabsList className="grid w-full grid-cols-2 glass-effect mb-4">
            <TabsTrigger value="query" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Query Operations</TabsTrigger>
            <TabsTrigger value="transaction" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Transaction Operations</TabsTrigger>
          </TabsList>

          <TabsContent value="query">
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-neutral-200 mb-3">Sample Query Code ({selectedSDK.toUpperCase()})</h4>
                <Textarea
                  value={sdkExamples[selectedSDK].query}
                  readOnly
                  className="h-64 font-mono text-xs bg-black/50 border-white/20 text-neutral-100"
                />
              </div>
              <div>
                <h4 className="font-medium text-neutral-200 mb-2">Custom Query</h4>
                <Input
                  placeholder="Enter function name and parameters..."
                  value={queryInput}
                  onChange={(e) => setQueryInput(e.target.value)}
                  className="bg-white/5 border-white/20 text-neutral-100 mb-3"
                />
                <Button
                  onClick={handleExecuteQuery}
                  disabled={isExecuting}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  {isExecuting ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Play className="w-4 h-4 mr-2" />
                  )}
                  Execute Query
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="transaction">
            <div className="space-y-4">
              <div>
                <h4 className="font-medium text-neutral-200 mb-3">Sample Transaction Code ({selectedSDK.toUpperCase()})</h4>
                <Textarea
                  value={sdkExamples[selectedSDK].transaction}
                  readOnly
                  className="h-64 font-mono text-xs bg-black/50 border-white/20 text-neutral-100"
                />
              </div>
              <div>
                <h4 className="font-medium text-neutral-200 mb-2">Custom Transaction</h4>
                <Input
                  placeholder="Enter transaction function and parameters..."
                  value={transactionInput}
                  onChange={(e) => setTransactionInput(e.target.value)}
                  className="bg-white/5 border-white/20 text-neutral-100 mb-3"
                />
                <Button
                  onClick={handleExecuteTransaction}
                  disabled={isExecuting}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  {isExecuting ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  ) : (
                    <Play className="w-4 h-4 mr-2" />
                  )}
                  Submit Transaction
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Connection Status */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-xl font-bold text-neutral-100 mb-4">SDK Connection Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-sm text-neutral-200">Gateway Connection</span>
            </div>
            <p className="text-xs text-green-400">Connected</p>
            <p className="text-xs text-neutral-500">spectrachannel</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-sm text-neutral-200">Wallet Identity</span>
            </div>
            <p className="text-xs text-green-400">Authenticated</p>
            <p className="text-xs text-neutral-500">appUser</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="text-sm text-neutral-200">Smart Contracts</span>
            </div>
            <p className="text-xs text-green-400">Available</p>
            <p className="text-xs text-neutral-500">spec-token, marketplace</p>
          </div>
        </div>
      </div>
    </div>
  );
}
