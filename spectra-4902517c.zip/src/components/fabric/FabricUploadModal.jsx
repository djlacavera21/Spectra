import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Upload, X } from "lucide-react";

const ENTRY_TYPES = [
  { value: "trade", label: "Trade" },
  { value: "swap", label: "Swap" },
  { value: "marketplace", label: "Marketplace Transaction" },
  { value: "whale_transaction", label: "Whale Transaction" },
  { value: "product_purchase", label: "Product Purchase" },
  { value: "contract", label: "Signed Contract" },
  { value: "data", label: "General Data Upload" },
];

const MARKETPLACES = [
    "Spectra", "Binance", "Coinbase", "Kraken", "Uniswap", "1inch", "OpenSea", "Other"
];

export default function FabricUploadModal({ isOpen, onClose, onUpload, isProcessing }) {
  const [entryType, setEntryType] = useState("");
  const [marketplace, setMarketplace] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");
  const [transactionHash, setTransactionHash] = useState("");
  const [files, setFiles] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!entryType || !title || !description) {
      alert("Please fill in all required fields.");
      return;
    }
    const entryData = {
      entry_type: entryType,
      marketplace_name: marketplace,
      title,
      description,
      amount_spec: parseFloat(amount) || 0,
      transaction_hash: transactionHash,
    };
    onUpload(entryData, files);
  };

  const handleFileChange = (e) => {
    setFiles(Array.from(e.target.files));
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-neutral-100">Add to Your Personal Fabric</DialogTitle>
          <DialogDescription className="text-neutral-400">
            Contribute to the Master Fabric by providing transparent data. The more detail you provide, the greater the rewards.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="entryType" className="text-neutral-300">Entry Type *</Label>
              <Select onValueChange={setEntryType} required>
                <SelectTrigger id="entryType" className="bg-white/5 border-white/20 text-neutral-100">
                  <SelectValue placeholder="Select an entry type..." />
                </SelectTrigger>
                <SelectContent className="glass-card">
                  {ENTRY_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value} className="focus:bg-white/10">{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="marketplace" className="text-neutral-300">Marketplace</Label>
              <Select onValueChange={setMarketplace}>
                <SelectTrigger id="marketplace" className="bg-white/5 border-white/20 text-neutral-100">
                  <SelectValue placeholder="Select a marketplace..." />
                </SelectTrigger>
                <SelectContent className="glass-card">
                  {MARKETPLACES.map(mp => (
                    <SelectItem key={mp} value={mp} className="focus:bg-white/10">{mp}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label htmlFor="title" className="text-neutral-300">Title *</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} required className="bg-white/5 border-white/20 text-neutral-100" />
          </div>
          <div>
            <Label htmlFor="description" className="text-neutral-300">Description *</Label>
            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} required className="bg-white/5 border-white/20 text-neutral-100" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="amount" className="text-neutral-300">Amount (SPEC)</Label>
              <Input id="amount" type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="bg-white/5 border-white/20 text-neutral-100" />
            </div>
            <div>
              <Label htmlFor="txHash" className="text-neutral-300">Transaction Hash</Label>
              <Input id="txHash" value={transactionHash} onChange={(e) => setTransactionHash(e.target.value)} className="bg-white/5 border-white/20 text-neutral-100" />
            </div>
          </div>
          <div>
            <Label htmlFor="files" className="text-neutral-300">Upload Evidence (Optional)</Label>
            <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-white/20 border-dashed rounded-md">
              <div className="space-y-1 text-center">
                <Upload className="mx-auto h-12 w-12 text-neutral-400" />
                <div className="flex text-sm text-neutral-500">
                  <label htmlFor="files" className="relative cursor-pointer bg-neutral-900 rounded-md font-medium text-blue-400 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                    <span>Upload files</span>
                    <Input id="files" name="files" type="file" className="sr-only" multiple onChange={handleFileChange} />
                  </label>
                  <p className="pl-1">or drag and drop</p>
                </div>
                {files.length > 0 ? (
                  <p className="text-xs text-neutral-400">{files.length} file(s) selected</p>
                ) : (
                  <p className="text-xs text-neutral-500">PNG, JPG, PDF up to 10MB</p>
                )}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={onClose} className="text-neutral-300">Cancel</Button>
            <Button type="submit" disabled={isProcessing} className="bg-blue-600 hover:bg-blue-700 text-white">
              {isProcessing ? "Processing..." : "Add Entry"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}