import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { 
  Database, 
  Network, 
  Zap, 
  Settings, 
  AlertTriangle,
  CheckCircle
} from "lucide-react";

export default function HybridControls() {
  const [fabricMode, setFabricMode] = useState(false);
  const [simulationMode, setSimulationMode] = useState(true);
  const [isTransitioning, setIsTransitioning] = useState(false);

  const handleModeSwitch = async (mode) => {
    setIsTransitioning(true);
    
    // Simulate mode switching delay
    setTimeout(() => {
      if (mode === 'fabric') {
        setFabricMode(true);
        setSimulationMode(false);
      } else {
        setFabricMode(false);
        setSimulationMode(true);
      }
      setIsTransitioning(false);
    }, 2000);
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <Settings className="w-6 h-6 text-purple-400" />
        <h3 className="text-xl font-bold text-white">Hybrid Mode Controls</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        {/* Simulation Mode */}
        <div className="glass-effect rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Database className="w-5 h-5 text-blue-400" />
              <span className="font-medium text-white">Simulation Mode</span>
            </div>
            <Badge className={simulationMode ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
              {simulationMode ? 'Active' : 'Inactive'}
            </Badge>
          </div>
          <p className="text-sm text-white/60 mb-4">
            Fast prototyping with simulated blockchain operations
          </p>
          <div className="flex items-center gap-3">
            <Switch
              checked={simulationMode}
              onCheckedChange={() => !isTransitioning && handleModeSwitch('simulation')}
              disabled={isTransitioning}
            />
            <Label className="text-sm text-white/80">
              {simulationMode ? 'Enabled' : 'Disabled'}
            </Label>
          </div>
        </div>

        {/* Fabric Mode */}
        <div className="glass-effect rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Network className="w-5 h-5 text-green-400" />
              <span className="font-medium text-white">Fabric Integration</span>
            </div>
            <Badge className={fabricMode ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}>
              {fabricMode ? 'Active' : 'Inactive'}
            </Badge>
          </div>
          <p className="text-sm text-white/60 mb-4">
            Real blockchain operations with Hyperledger Fabric
          </p>
          <div className="flex items-center gap-3">
            <Switch
              checked={fabricMode}
              onCheckedChange={() => !isTransitioning && handleModeSwitch('fabric')}
              disabled={isTransitioning}
            />
            <Label className="text-sm text-white/80">
              {fabricMode ? 'Connected' : 'Disconnected'}
            </Label>
          </div>
        </div>
      </div>

      {/* Status and Actions */}
      <div className="space-y-4">
        {isTransitioning && (
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-3">
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span className="text-white">Switching modes...</span>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-green-400" />
              <span className="text-sm text-white">Data Persistence</span>
            </div>
            <p className="text-xs text-white/60">
              {fabricMode ? 'Blockchain ledger' : 'Local database'}
            </p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="w-4 h-4 text-yellow-400" />
              <span className="text-sm text-white">Transaction Speed</span>
            </div>
            <p className="text-xs text-white/60">
              {fabricMode ? '~3-5 seconds' : 'Instant'}
            </p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-orange-400" />
              <span className="text-sm text-white">Gas Fees</span>
            </div>
            <p className="text-xs text-white/60">
              {fabricMode ? 'Real network fees' : 'Simulated'}
            </p>
          </div>
        </div>

        {/* Migration Options */}
        <div className="glass-effect rounded-lg p-4">
          <h4 className="font-medium text-white mb-3">Migration Options</h4>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              className="border-white/20 text-white hover:bg-white/10"
              disabled={isTransitioning}
            >
              Export to Fabric
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-white/20 text-white hover:bg-white/10"
              disabled={isTransitioning}
            >
              Import from Fabric
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="border-white/20 text-white hover:bg-white/10"
              disabled={isTransitioning}
            >
              Sync States
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}