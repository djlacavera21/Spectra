
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label"; // Added Label import
import { 
  Package, 
  Download, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Terminal,
  Network,
  Database,
  Play,
  Settings
} from "lucide-react";
import { InvokeLLM } from "@/api/integrations";

const FABRIC_LIFECYCLE_STEPS = [
  { id: 'package', name: 'Package Chaincode', description: 'Create chaincode package' },
  { id: 'install', name: 'Install on Peers', description: 'Install chaincode on peer nodes' },
  { id: 'approve', name: 'Approve for Org', description: 'Approve chaincode definition' },
  { id: 'checkcommit', name: 'Check Commit Readiness', description: 'Verify approval status' },
  { id: 'commit', name: 'Commit to Channel', description: 'Commit chaincode definition' },
  { id: 'init', name: 'Initialize Chaincode', description: 'Initialize chaincode on channel' },
  { id: 'verify', name: 'Verify Deployment', description: 'Test chaincode functionality' }
];

export default function FabricDeploymentManager({ contractCode, contractName, onDeploymentComplete }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentLogs, setDeploymentLogs] = useState([]);
  const [deploymentConfig, setDeploymentConfig] = useState({
    chaincodeName: 'specToken', // Changed default
    chaincodeVersion: '1.0',
    channelName: 'spectrachannel',
    sequence: 1,
    endorsementPolicy: "OR('Org1MSP.peer')",
    collectionConfig: '',
    initRequired: true,
    initFunction: 'InitLedger', // Added initFunction
    initArgs: '[]' // Added initArgs
  });

  const addLog = (message, type = 'info') => {
    const timestamp = new Date().toLocaleTimeString();
    setDeploymentLogs(prev => [...prev, { timestamp, message, type }]);
  };

  const executeLifecycleStep = async (step) => {
    const { chaincodeName, chaincodeVersion, channelName, sequence, endorsementPolicy, initRequired, initFunction, initArgs } = deploymentConfig;
    
    switch (step.id) {
      case 'package':
        addLog(`📦 Packaging chaincode: ${chaincodeName}:${chaincodeVersion}`, 'info');
        addLog(`peer lifecycle chaincode package spectra_coin.tar.gz --path ./dist --lang node --label spectra_coin_1`, 'command');
        
        // Simulate packaging with AI
        const packageResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode packaging for contract "${chaincodeName}" version "${chaincodeVersion}". Generate realistic packaging output with file sizes and checksums.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              packageId: { type: "string" },
              packageSize: { type: "string" },
              checksum: { type: "string" },
              message: { type: "string" }
            }
          }
        });
        
        if (packageResult.success) {
          addLog(`✅ Package created successfully: ${packageResult.packageSize}`, 'success');
          addLog(`📋 Package ID: ${packageResult.packageId}`, 'info');
          addLog(`🔐 Checksum: ${packageResult.checksum}`, 'info');
        } else {
          throw new Error(packageResult.message);
        }
        break;

      case 'install':
        addLog(`🔧 Installing chaincode on peer nodes...`, 'info');
        addLog(`peer lifecycle chaincode install spectra_coin.tar.gz`, 'command');
        
        const installResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode installation on peer nodes. Generate realistic installation logs with peer responses and package IDs.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              installedPeers: { type: "array", items: { type: "string" } },
              packageId: { type: "string" },
              message: { type: "string" }
            }
          }
        });
        
        if (installResult.success) {
          installResult.installedPeers.forEach(peer => {
            addLog(`✅ Installed on ${peer}`, 'success');
          });
          addLog(`📋 Package ID: ${installResult.packageId}`, 'info');
        } else {
          throw new Error(installResult.message);
        }
        break;

      case 'approve':
        addLog(`👍 Approving chaincode for Org1...`, 'info'); // Updated log message
        addLog(`peer lifecycle chaincode approveformyorg --channelID ${channelName} --name ${chaincodeName} --version ${chaincodeVersion} --package-id $PACKAGE_ID --sequence ${sequence} --init-required`, 'command'); // Updated command
        
        const approveResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode approval process for organization. Generate realistic approval transaction details.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              txId: { type: "string" },
              blockNumber: { type: "number" },
              organization: { type: "string" },
              message: { type: "string" }
            }
          }
        });
        
        if (approveResult.success) {
          addLog(`✅ Approved by ${approveResult.organization}`, 'success');
          addLog(`📋 Transaction ID: ${approveResult.txId}`, 'info');
          addLog(`🏗️ Block Number: ${approveResult.blockNumber}`, 'info');
        } else {
          throw new Error(approveResult.message);
        }
        break;

      case 'checkcommit':
        addLog(`🔍 Checking commit readiness on channel '${channelName}'...`, 'info'); // Updated log message
        addLog(`peer lifecycle chaincode checkcommitreadiness --channelID ${channelName} --name ${chaincodeName} --version ${chaincodeVersion} --sequence ${sequence} --init-required`, 'command'); // Updated command
        
        const checkResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode commit readiness check. Show which organizations have approved.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              approvals: { type: "object" },
              readyToCommit: { type: "boolean" },
              message: { type: "string" }
            }
          }
        });
        
        if (checkResult.success && checkResult.readyToCommit) {
          addLog(`✅ Commit readiness check passed`, 'success');
          Object.entries(checkResult.approvals).forEach(([org, approved]) => {
            addLog(`${approved ? '✅' : '❌'} ${org}: ${approved ? 'Approved' : 'Not Approved'}`, approved ? 'success' : 'warning');
          });
        } else {
          throw new Error(checkResult.message || 'Not ready to commit');
        }
        break;

      case 'commit':
        addLog(`🚀 Committing chaincode to channel '${channelName}'...`, 'info'); // Updated log message
        addLog(`peer lifecycle chaincode commit -o orderer.example.com:7050 --channelID ${channelName} --name ${chaincodeName} --version ${chaincodeVersion} --sequence ${sequence} --init-required`, 'command'); // Updated command
        
        const commitResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode commit to channel. Generate realistic commit transaction details.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              txId: { type: "string" },
              blockNumber: { type: "number" },
              channelName: { type: "string" },
              message: { type: "string" }
            }
          }
        });
        
        if (commitResult.success) {
          addLog(`✅ Chaincode committed to channel: ${commitResult.channelName}`, 'success');
          addLog(`📋 Commit Transaction ID: ${commitResult.txId}`, 'info');
          addLog(`🏗️ Commit Block Number: ${commitResult.blockNumber}`, 'info');
        } else {
          throw new Error(commitResult.message);
        }
        break;

      case 'init':
        if (initRequired) {
          addLog(`🌱 Initializing chaincode...`, 'info'); // Updated log message
          addLog(`peer chaincode invoke -o orderer.example.com:7050 --isInit -C ${channelName} -n ${chaincodeName} -c '{"function":"${initFunction}","Args":${initArgs}}'`, 'command'); // Updated command
          
          const initResult = await InvokeLLM({
            prompt: `Simulate Hyperledger Fabric chaincode initialization. Generate realistic initialization response.`,
            response_json_schema: {
              type: "object",
              properties: {
                success: { type: "boolean" },
                txId: { type: "string" },
                result: { type: "string" },
                message: { type: "string" }
              }
            }
          });
          
          if (initResult.success) {
            addLog(`✅ Chaincode initialized successfully`, 'success');
            addLog(`📋 Init Transaction ID: ${initResult.txId}`, 'info');
            addLog(`📄 Result: ${initResult.result}`, 'info');
          } else {
            throw new Error(initResult.message);
          }
        } else {
          addLog(`ℹ️ Skipping initialization as 'init-required' is false.`, 'info'); // Updated log message
        }
        break;

      case 'verify':
        addLog(`✅ Verifying deployed chaincode...`, 'info'); // Updated log message
        addLog(`peer chaincode query -C ${channelName} -n ${chaincodeName} -c '{"function":"TokenInfo","Args":[]}'`, 'command'); // Updated command
        
        const verifyResult = await InvokeLLM({
          prompt: `Simulate Hyperledger Fabric chaincode verification query. Test basic functionality.`,
          response_json_schema: {
            type: "object",
            properties: {
              success: { type: "boolean" },
              queryResult: { type: "string" },
              responseTime: { type: "number" },
              message: { type: "string" }
            }
          }
        });
        
        if (verifyResult.success) {
          addLog(`✅ Verification successful (${verifyResult.responseTime}ms)`, 'success');
          addLog(`📄 Query Result: ${verifyResult.queryResult}`, 'info');
        } else {
          throw new Error(verifyResult.message);
        }
        break;

      default:
        throw new Error(`Unknown step: ${step.id}`); // Added default case
    }
  };

  const startDeployment = async () => {
    setIsDeploying(true);
    setCurrentStep(0);
    setDeploymentLogs([]);
    
    addLog(`🚀 Starting Hyperledger Fabric deployment lifecycle`, 'info');
    addLog(`📋 Contract: ${deploymentConfig.chaincodeName} v${deploymentConfig.chaincodeVersion}`, 'info');
    addLog(`🌐 Channel: ${deploymentConfig.channelName}`, 'info');

    try {
      for (let i = 0; i < FABRIC_LIFECYCLE_STEPS.length; i++) {
        setCurrentStep(i);
        const step = FABRIC_LIFECYCLE_STEPS[i];
        
        addLog(`\n--- ${step.name} ---`, 'step');
        await executeLifecycleStep(step);
        await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate processing time
      }
      
      addLog(`\n🎉 Deployment completed successfully!`, 'success');
      addLog(`✅ Chaincode ${deploymentConfig.chaincodeName} is now active on ${deploymentConfig.channelName}`, 'success');
      
      if (onDeploymentComplete) {
        onDeploymentComplete({
          chaincodeName: deploymentConfig.chaincodeName,
          version: deploymentConfig.chaincodeVersion,
          channel: deploymentConfig.channelName,
          status: 'active'
        });
      }
      
    } catch (error) {
      addLog(`❌ Deployment failed: ${error.message}`, 'error');
    } finally {
      setIsDeploying(false);
    }
  };

  useEffect(() => {
    if (isDeploying) {
      addLog(`Deployment started for ${deploymentConfig.chaincodeName} v${deploymentConfig.chaincodeVersion} on channel ${deploymentConfig.channelName}.`, 'info');
    }
  }, [isDeploying, deploymentConfig.chaincodeName, deploymentConfig.chaincodeVersion, deploymentConfig.channelName]); // Added useEffect

  const getLogColor = (type) => {
    switch (type) {
      case 'success': return 'text-green-400';
      case 'error': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'command': return 'text-blue-400';
      case 'step': return 'text-purple-400 font-bold';
      default: return 'text-neutral-300';
    }
  };

  return (
    <Card className="glass-card">
      <CardHeader>
        <CardTitle className="flex items-center text-neutral-100">
          <Network className="w-5 h-5 mr-2 text-green-400" />
          Fabric Deployment Manager
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Deployment Configuration */}
          <div className="space-y-4">
            <h4 className="font-medium text-neutral-200">Deployment Configuration</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs text-neutral-400">Chaincode Name</Label>
                <Input value={deploymentConfig.chaincodeName} onChange={e => setDeploymentConfig(p => ({...p, chaincodeName: e.target.value}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
              </div>
              <div>
                <Label className="text-xs text-neutral-400">Version</Label>
                <Input value={deploymentConfig.chaincodeVersion} onChange={e => setDeploymentConfig(p => ({...p, chaincodeVersion: e.target.value}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
              </div>
              <div>
                <Label className="text-xs text-neutral-400">Channel</Label>
                <Select 
                  value={deploymentConfig.channelName} 
                  onValueChange={(value) => setDeploymentConfig(prev => ({ ...prev, channelName: value }))}
                >
                  <SelectTrigger className="bg-white/5 border-white/20 text-neutral-100 h-8">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="glass-card">
                    <SelectItem value="spectrachannel">spectrachannel</SelectItem>
                    <SelectItem value="testchannel">testchannel</SelectItem>
                    <SelectItem value="devchannel">devchannel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-neutral-400">Sequence</Label>
                <Input type="number" value={deploymentConfig.sequence} onChange={e => setDeploymentConfig(p => ({...p, sequence: parseInt(e.target.value)}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
              </div>
            </div>
             <div>
                <Label className="text-xs text-neutral-400">Endorsement Policy</Label>
                <Input value={deploymentConfig.endorsementPolicy} onChange={e => setDeploymentConfig(p => ({...p, endorsementPolicy: e.target.value}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
              </div>
            <div className="flex items-center space-x-2">
               <input type="checkbox" id="initRequired" checked={deploymentConfig.initRequired} onChange={e => setDeploymentConfig(p => ({...p, initRequired: e.target.checked}))} />
               <Label htmlFor="initRequired" className="text-sm text-neutral-300">Initialization Required</Label>
            </div>
            {deploymentConfig.initRequired && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs text-neutral-400">Init Function</Label>
                  <Input value={deploymentConfig.initFunction} onChange={e => setDeploymentConfig(p => ({...p, initFunction: e.target.value}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
                </div>
                <div>
                  <Label className="text-xs text-neutral-400">Init Args</Label>
                  <Input value={deploymentConfig.initArgs} onChange={e => setDeploymentConfig(p => ({...p, initArgs: e.target.value}))} className="bg-white/5 border-white/20 text-neutral-100 h-8" />
                </div>
              </div>
            )}
             <Button onClick={startDeployment} disabled={isDeploying} className="w-full bg-green-600 hover:bg-green-700 text-white">
                {isDeploying ? (
                  <div className="flex items-center">
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Executing: {FABRIC_LIFECYCLE_STEPS[currentStep]?.name || '...'}
                  </div>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Start Deployment
                  </>
                )}
             </Button>
          </div>

          {/* Deployment Progress & Logs */}
          <div className="space-y-6">
            {/* Deployment Progress */}
            <div className="glass-card rounded-xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-bold text-neutral-100 flex items-center gap-2">
                  <Network className="w-5 h-5 text-green-400" />
                  Fabric Lifecycle Deployment
                </h3>
              </div>

              {/* Progress Steps */}
              <div className="space-y-3 mb-6">
                {FABRIC_LIFECYCLE_STEPS.map((step, index) => (
                  <div key={step.id} className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      index < currentStep ? 'bg-green-500' :
                      index === currentStep && isDeploying ? 'bg-blue-500' :
                      'bg-neutral-600'
                    }`}>
                      {index < currentStep ? (
                        <CheckCircle className="w-4 h-4 text-white" />
                      ) : index === currentStep && isDeploying ? (
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      ) : (
                        <span className="text-xs font-bold text-white">{index + 1}</span>
                      )}
                    </div>
                    <div>
                      <p className={`font-medium ${
                        index <= currentStep ? 'text-neutral-200' : 'text-neutral-500'
                      }`}>
                        {step.name}
                      </p>
                      <p className={`text-sm ${
                        index <= currentStep ? 'text-neutral-400' : 'text-neutral-600'
                      }`}>
                        {step.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Progress Bar */}
              {isDeploying && (
                <div className="mb-4">
                  <Progress 
                    value={(currentStep / FABRIC_LIFECYCLE_STEPS.length) * 100} 
                    className="w-full"
                  />
                  <p className="text-sm text-neutral-400 mt-2">
                    Step {currentStep + 1} of {FABRIC_LIFECYCLE_STEPS.length}: {FABRIC_LIFECYCLE_STEPS[currentStep]?.name}
                  </p>
                </div>
              )}
            </div>

            {/* Deployment Logs */}
            {deploymentLogs.length > 0 && (
              <div className="glass-card rounded-xl p-6">
                <h3 className="text-xl font-bold text-neutral-100 mb-4 flex items-center gap-2">
                  <Terminal className="w-5 h-5 text-green-400" />
                  Deployment Logs
                </h3>
                <div className="bg-black/50 rounded-lg p-4 h-96 overflow-y-auto font-mono text-sm">
                  {deploymentLogs.map((log, index) => (
                    <div key={index} className="mb-1">
                      <span className="text-neutral-500">[{log.timestamp}]</span>
                      <span className={`ml-2 ${getLogColor(log.type)}`}>
                        {log.message}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
