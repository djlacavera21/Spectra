
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Server, 
  Activity, 
  Settings,
  Play,
  StopCircle,
  RefreshCw,
  Monitor,
  HardDrive,
  Cpu
} from "lucide-react";

export default function KubernetesManager() {
  const [pods, setPods] = useState([
    { name: 'peer0-org1-deployment', status: 'Running', cpu: '250m', memory: '512Mi', restarts: 0 },
    { name: 'peer1-org1-deployment', status: 'Running', cpu: '200m', memory: '480Mi', restarts: 0 },
    { name: 'orderer-deployment', status: 'Running', cpu: '150m', memory: '256Mi', restarts: 0 },
    { name: 'couchdb0-deployment', status: 'Running', cpu: '100m', memory: '1Gi', restarts: 1 },
    { name: 'couchdb1-deployment', status: 'Running', cpu: '95m', memory: '1Gi', restarts: 0 }
  ]);

  const [services, setServices] = useState([
    { name: 'peer0-org1-service', type: 'NodePort', port: '7051:30051', status: 'Active' },
    { name: 'peer1-org1-service', type: 'NodePort', port: '8051:30052', status: 'Active' },
    { name: 'orderer-service', type: 'NodePort', port: '7050:30050', status: 'Active' },
    { name: 'couchdb0-service', type: 'ClusterIP', port: '5984', status: 'Active' },
    { name: 'couchdb1-service', type: 'ClusterIP', port: '5984', status: 'Active' }
  ]);

  const getStatusColor = (status) => {
    switch (status) {
      case 'Running':
      case 'Active':
        return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'Pending':
        return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'Failed':
        return 'bg-red-500/20 text-red-400 border-red-500/30';
      default:
        return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-6">
      {/* Cluster Overview */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Server className="w-6 h-6 text-blue-400" />
            <h3 className="text-xl font-bold text-neutral-100">Kubernetes Cluster Management</h3>
          </div>
          <div className="flex gap-3">
            <Button className="bg-white text-black hover:bg-neutral-200">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button className="bg-white text-black hover:bg-neutral-200">
              <Monitor className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </div>
        </div>

        {/* Cluster Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Server className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-neutral-400">Nodes</span>
            </div>
            <p className="text-2xl font-bold text-neutral-100">3</p>
            <p className="text-xs text-green-400">All Ready</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Activity className="w-5 h-5 text-green-400" />
              <span className="text-sm text-neutral-400">Pods</span>
            </div>
            <p className="text-2xl font-bold text-neutral-100">{pods.length}</p>
            <p className="text-xs text-green-400">Running</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="w-5 h-5 text-yellow-400" />
              <span className="text-sm text-neutral-400">CPU Usage</span>
            </div>
            <p className="text-2xl font-bold text-neutral-100">45%</p>
            <p className="text-xs text-yellow-400">Normal</p>
          </div>

          <div className="glass-effect rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <HardDrive className="w-5 h-5 text-purple-400" />
              <span className="text-sm text-neutral-400">Memory</span>
            </div>
            <p className="text-2xl font-bold text-neutral-100">3.2Gi</p>
            <p className="text-xs text-purple-400">Used</p>
          </div>
        </div>
      </div>

      {/* Kubernetes Resources */}
      <Tabs defaultValue="pods" className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass-effect">
          <TabsTrigger value="pods" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Pods</TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Services</TabsTrigger>
          <TabsTrigger value="deployments" className="data-[state=active]:bg-white data-[state=active]:text-black text-neutral-400">Deployments</TabsTrigger>
        </TabsList>

        <TabsContent value="pods" className="space-y-4">
          <div className="glass-card rounded-xl p-6">
            <h4 className="text-lg font-bold text-neutral-100 mb-4">Pod Status</h4>
            <div className="space-y-3">
              {pods.map((pod, index) => (
                <div key={index} className="glass-effect rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h5 className="font-medium text-neutral-200">{pod.name}</h5>
                      <div className="flex items-center gap-4 mt-1">
                        <span className="text-sm text-neutral-400">CPU: {pod.cpu}</span>
                        <span className="text-sm text-neutral-400">Memory: {pod.memory}</span>
                        <span className="text-sm text-neutral-400">Restarts: {pod.restarts}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className={getStatusColor(pod.status)}>
                        {pod.status}
                      </Badge>
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                          <Activity className="w-3 h-3 mr-1" />
                          Logs
                        </Button>
                        <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                          <Settings className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="services" className="space-y-4">
          <div className="glass-card rounded-xl p-6">
            <h4 className="text-lg font-bold text-neutral-100 mb-4">Services</h4>
            <div className="space-y-3">
              {services.map((service, index) => (
                <div key={index} className="glass-effect rounded-lg p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h5 className="font-medium text-neutral-200">{service.name}</h5>
                      <div className="flex items-center gap-4 mt-1">
                        <span className="text-sm text-neutral-400">Type: {service.type}</span>
                        <span className="text-sm text-neutral-400">Port: {service.port}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge className={getStatusColor(service.status)}>
                        {service.status}
                      </Badge>
                      <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                        <Settings className="w-3 h-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="deployments" className="space-y-4">
          <div className="glass-card rounded-xl p-6">
            <h4 className="text-lg font-bold text-neutral-100 mb-4">Deployments</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Button className="bg-green-600 hover:bg-green-700 text-white h-12">
                <Play className="w-4 h-4 mr-2" />
                Scale Up
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white h-12">
                <RefreshCw className="w-4 h-4 mr-2" />
                Rolling Update
              </Button>
              <Button className="bg-yellow-600 hover:bg-yellow-700 text-white h-12">
                <StopCircle className="w-4 h-4 mr-2" />
                Scale Down
              </Button>
              <Button className="bg-purple-600 hover:bg-purple-700 text-white h-12">
                <Settings className="w-4 h-4 mr-2" />
                Configure
              </Button>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
