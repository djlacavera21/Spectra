import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Search, 
  Filter, 
  ExternalLink, 
  FileText, 
  Clock, 
  CheckCircle, 
  XCircle,
  Eye,
  EyeOff,
  ArrowUpDown,
  TrendingUp,
  ShoppingCart,
  Coins,
  Globe,
  BarChart3
} from "lucide-react";
import { format } from "date-fns";

const getEntryIcon = (type) => {
  const icons = {
    'trade': ArrowUpDown,
    'swap': TrendingUp,
    'marketplace': ShoppingCart,
    'whale_transaction': Coins,
    'product_purchase': Globe,
    'contract': FileText,
    'data': BarChart3
  };
  return icons[type] || FileText;
};

const getStatusColor = (status) => {
  switch (status) {
    case 'verified': return 'bg-green-500/20 text-green-400';
    case 'pending': return 'bg-yellow-500/20 text-yellow-400';
    case 'rejected': return 'bg-red-500/20 text-red-400';
    default: return 'bg-gray-500/20 text-gray-400';
  }
};

const getVisibilityIcon = (visibility) => {
  switch (visibility) {
    case 'public': return <Eye className="w-3 h-3" />;
    case 'private': return <EyeOff className="w-3 h-3" />;
    default: return <Eye className="w-3 h-3" />;
  }
};

export default function FabricEntries({ entries, onRefresh }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const filteredEntries = entries.filter(entry => {
    const matchesSearch = entry.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         entry.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === 'all' || entry.entry_type === filterType;
    const matchesStatus = filterStatus === 'all' || entry.verification_status === filterStatus;
    
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="glass-card rounded-xl p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
            <Input
              placeholder="Search entries..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-white/5 border-white/20 text-neutral-100"
            />
          </div>
          
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="px-3 py-2 bg-white/5 border border-white/20 rounded-md text-neutral-100"
          >
            <option value="all">All Types</option>
            <option value="trade">Trading</option>
            <option value="swap">Swaps</option>
            <option value="marketplace">Marketplace</option>
            <option value="whale_transaction">Whale TX</option>
            <option value="product_purchase">Purchases</option>
            <option value="contract">Contracts</option>
            <option value="data">Data</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 bg-white/5 border border-white/20 rounded-md text-neutral-100"
          >
            <option value="all">All Status</option>
            <option value="verified">Verified</option>
            <option value="pending">Pending</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Entries List */}
      <div className="space-y-4">
        {filteredEntries.length > 0 ? (
          filteredEntries.map((entry) => {
            const EntryIcon = getEntryIcon(entry.entry_type);
            
            return (
              <div key={entry.id} className="glass-card rounded-xl p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-600 rounded-lg flex items-center justify-center">
                      <EntryIcon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-neutral-100">{entry.title}</h3>
                      <p className="text-sm text-neutral-400 capitalize">
                        {entry.entry_type.replace('_', ' ')}
                        {entry.marketplace_name && ` • ${entry.marketplace_name}`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(entry.verification_status)}>
                      {entry.verification_status === 'verified' && <CheckCircle className="w-3 h-3 mr-1" />}
                      {entry.verification_status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                      {entry.verification_status === 'rejected' && <XCircle className="w-3 h-3 mr-1" />}
                      {entry.verification_status}
                    </Badge>
                    
                    <Badge className="bg-purple-500/20 text-purple-400">
                      +{entry.reward_earned} SPEC
                    </Badge>
                    
                    <div className="flex items-center gap-1 text-neutral-400">
                      {getVisibilityIcon(entry.visibility)}
                      <span className="text-xs capitalize">{entry.visibility}</span>
                    </div>
                  </div>
                </div>

                <p className="text-neutral-300 mb-4">{entry.description}</p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4 text-sm text-neutral-500">
                    <span>{format(new Date(entry.created_date), 'MMM d, yyyy')}</span>
                    {entry.amount_spec && (
                      <span>{entry.amount_spec.toLocaleString()} SPEC involved</span>
                    )}
                    {entry.tags && entry.tags.length > 0 && (
                      <div className="flex gap-1">
                        {entry.tags.slice(0, 3).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    {entry.external_url && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => window.open(entry.external_url, '_blank')}
                        className="text-neutral-400 hover:text-neutral-100"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    )}
                    {entry.transaction_hash && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => navigator.clipboard.writeText(entry.transaction_hash)}
                        className="text-neutral-400 hover:text-neutral-100"
                      >
                        <FileText className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="glass-card rounded-xl p-12 text-center">
            <FileText className="w-12 h-12 mx-auto mb-4 text-neutral-500" />
            <h3 className="text-lg font-semibold text-neutral-300 mb-2">No entries found</h3>
            <p className="text-neutral-500">
              {searchTerm || filterType !== 'all' || filterStatus !== 'all' 
                ? 'Try adjusting your search or filters'
                : 'Start building your fabric by adding your first entry'
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}