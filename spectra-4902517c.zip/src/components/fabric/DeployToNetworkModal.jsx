
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Play, 
  Package, 
  Upload, 
  CheckCircle, 
  AlertTriangle,
  Network,
  Database,
  Settings
} from "lucide-react";

const AVAILABLE_CONTRACTS = [
  {
    id: 'spec-token-v1',
    name: 'SPEC Token Contract v1.0',
    language: 'nodejs',
    status: 'ready',
    size: '2.3 MB',
    functions: 8
  },
  {
    id: 'marketplace-v1',
    name: 'Digital Marketplace v1.0',
    language: 'nodejs',
    status: 'ready',
    size: '1.8 MB',
    functions: 12
  },
  {
    id: 'supply-chain-v1',
    name: 'Supply Chain Tracker v1.0',
    language: 'go',
    status: 'testing',
    size: '3.1 MB',
    functions: 6
  }
];

const AVAILABLE_CHANNELS = [
  {
    id: 'spectrachannel',
    name: 'spectrachannel',
    peers: 2,
    orderers: 1,
    status: 'active'
  },
  {
    id: 'testchannel',
    name: 'testchannel',
    peers: 1,
    orderers: 1,
    status: 'active'
  },
  {
    id: 'devchannel',
    name: 'devchannel',
    peers: 2,
    orderers: 1,
    status: 'maintenance'
  }
];

const DEPLOYMENT_STEPS = [
  'Package Chaincode',
  'Install on Peers',
  'Approve for Organization',
  'Commit to Channel',
  'Initialize Ledger',
  'Verify Deployment'
];

export default function DeployToNetworkModal({ isOpen, onClose, onSuccess }) {
  const [selectedContract, setSelectedContract] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('');
  const [contractVersion, setContractVersion] = useState('1.0');
  const [initArgs, setInitArgs] = useState('[]');
  const [isDeploying, setIsDeploying] = useState(false);
  const [deploymentStep, setDeploymentStep] = useState(0);

  const handleDeploy = async () => {
    if (!selectedContract || !selectedChannel) {
      alert('Please select a contract and channel');
      return;
    }

    setIsDeploying(true);
    setDeploymentStep(0);

    // Simulate deployment steps
    for (let i = 0; i < DEPLOYMENT_STEPS.length; i++) {
      setDeploymentStep(i);
      await new Promise(resolve => setTimeout(resolve, 1500));
    }

    alert('Smart contract deployed successfully to Hyperledger Fabric network!');
    setIsDeploying(false);
    onSuccess();
  };

  const getContractStatusColor = (status) => {
    switch (status) {
      case 'ready': return 'bg-green-500/20 text-green-400';
      case 'testing': return 'bg-yellow-500/20 text-yellow-400';
      case 'error': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getChannelStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-500/20 text-green-400';
      case 'maintenance': return 'bg-yellow-500/20 text-yellow-400';
      case 'offline': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-neutral-100 flex items-center gap-2">
            <Network className="w-5 h-5 text-green-400" />
            Deploy to Hyperledger Fabric Network
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Deploy your smart contract to a live Hyperledger Fabric network channel
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Contract Selection */}
          <div>
            <Label className="text-neutral-300 mb-3 block">Select Smart Contract</Label>
            <div className="space-y-3">
              {AVAILABLE_CONTRACTS.map(contract => (
                <div
                  key={contract.id}
                  onClick={() => setSelectedContract(contract.id)}
                  className={`glass-effect rounded-lg p-4 cursor-pointer transition-all ${
                    selectedContract === contract.id 
                      ? 'border-green-500 bg-green-500/10' 
                      : 'border-white/20 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-neutral-200">{contract.name}</h4>
                      <div className="flex items-center gap-4 mt-1 text-sm text-neutral-400">
                        <span>Language: {contract.language.toUpperCase()}</span>
                        <span>Size: {contract.size}</span>
                        <span>Functions: {contract.functions}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getContractStatusColor(contract.status)}>
                        {contract.status}
                      </Badge>
                      <Package className="w-4 h-4 text-neutral-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Channel Selection */}
          <div>
            <Label className="text-neutral-300 mb-3 block">Select Target Channel</Label>
            <div className="space-y-3">
              {AVAILABLE_CHANNELS.map(channel => (
                <div
                  key={channel.id}
                  onClick={() => channel.status === 'active' && setSelectedChannel(channel.id)}
                  className={`glass-effect rounded-lg p-4 transition-all ${
                    channel.status !== 'active' 
                      ? 'opacity-50 cursor-not-allowed' 
                      : selectedChannel === channel.id 
                        ? 'border-blue-500 bg-blue-500/10 cursor-pointer' 
                        : 'border-white/20 hover:border-white/30 cursor-pointer'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-neutral-200">{channel.name}</h4>
                      <div className="flex items-center gap-4 mt-1 text-sm text-neutral-400">
                        <span>Peers: {channel.peers}</span>
                        <span>Orderers: {channel.orderers}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getChannelStatusColor(channel.status)}>
                        {channel.status}
                      </Badge>
                      <Database className="w-4 h-4 text-neutral-400" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Deployment Configuration */}
          {selectedContract && selectedChannel && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="version" className="text-neutral-300">Contract Version</Label>
                  <Input
                    id="version"
                    value={contractVersion}
                    onChange={(e) => setContractVersion(e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100"
                    placeholder="1.0"
                  />
                </div>
                <div>
                  <Label htmlFor="initArgs" className="text-neutral-300">Initialization Arguments</Label>
                  <Input
                    id="initArgs"
                    value={initArgs}
                    onChange={(e) => setInitArgs(e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100"
                    placeholder='["arg1", "arg2"]'
                  />
                </div>
              </div>

              {/* Deployment Preview */}
              <div className="glass-effect rounded-lg p-4">
                <h4 className="font-medium text-neutral-200 mb-3 flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Deployment Summary
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Contract:</span>
                    <span className="text-neutral-200">
                      {AVAILABLE_CONTRACTS.find(c => c.id === selectedContract)?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Channel:</span>
                    <span className="text-neutral-200">{selectedChannel}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Version:</span>
                    <span className="text-neutral-200">{contractVersion}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Init Args:</span>
                    <span className="text-neutral-200 font-mono text-xs">{initArgs}</span>
                  </div>
                </div>
              </div>

              {/* Deployment Warning */}
              <Alert className="bg-yellow-500/20 border-yellow-500/30">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                <AlertDescription className="text-yellow-400">
                  <strong>Production Deployment:</strong> This will deploy the smart contract to a live blockchain network. 
                  Ensure all code has been thoroughly tested before proceeding.
                </AlertDescription>
              </Alert>
            </div>
          )}

          {/* Deployment Progress */}
          {isDeploying && (
            <div className="glass-effect rounded-lg p-4">
              <h4 className="font-medium text-neutral-200 mb-4">Deployment Progress</h4>
              <div className="space-y-3">
                {DEPLOYMENT_STEPS.map((step, index) => (
                  <div key={index} className="flex items-center gap-3">
                    {index < deploymentStep ? (
                      <CheckCircle className="w-5 h-5 text-green-400" />
                    ) : index === deploymentStep ? (
                      <div className="w-5 h-5 border-2 border-blue-400 border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <div className="w-5 h-5 border-2 border-neutral-600 rounded-full"></div>
                    )}
                    <span className={`${
                      index <= deploymentStep ? 'text-neutral-200' : 'text-neutral-500'
                    }`}>
                      {step}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button 
              variant="outline" 
              onClick={onClose}
              disabled={isDeploying}
              className="bg-white text-black hover:bg-neutral-200"
            >
              Cancel
            </Button>
            <Button
              onClick={handleDeploy}
              disabled={!selectedContract || !selectedChannel || isDeploying}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              {isDeploying ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Deploying to Network...
                </div>
              ) : (
                <>
                  <Play className="w-4 h-4 mr-2" />
                  Deploy to Network
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
