import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Eye, 
  CheckCircle, 
  FileText, 
  TrendingUp 
} from "lucide-react";

export default function TransparencyScore({ score, entriesCount, verifiedCount }) {
  const getScoreColor = (score) => {
    if (score > 75) return "from-green-400 to-emerald-500";
    if (score > 50) return "from-yellow-400 to-orange-500";
    return "from-red-400 to-pink-500";
  };

  const getScoreLabel = (score) => {
    if (score > 80) return "Diamond";
    if (score > 60) return "Gold";
    if (score > 40) return "Silver";
    return "Bronze";
  };

  const getScoreBadgeColor = (score) => {
    if (score > 75) return "bg-green-500/20 text-green-400";
    if (score > 50) return "bg-yellow-500/20 text-yellow-400";
    return "bg-red-500/20 text-red-400";
  };

  return (
    <div className="glass-card rounded-xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <Eye className="w-6 h-6 text-blue-400" />
        <h3 className="text-xl font-bold text-neutral-100">Transparency Score</h3>
        <Badge className={getScoreBadgeColor(score)}>
          {getScoreLabel(score)} Tier
        </Badge>
      </div>

      <div className="relative mb-6">
        <div className="w-full h-4 bg-neutral-700 rounded-full overflow-hidden">
          <div 
            className={`h-full bg-gradient-to-r ${getScoreColor(score)} transition-all duration-500 relative`}
            style={{ width: `${score}%` }}
          >
            <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
          </div>
        </div>
        <div className="flex justify-between mt-2 text-sm">
          <span className="text-neutral-500">0%</span>
          <span className={`font-bold ${score > 75 ? 'text-green-400' : score > 50 ? 'text-yellow-400' : 'text-red-400'}`}>
            {score}%
          </span>
          <span className="text-neutral-500">100%</span>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="glass-effect rounded-lg p-3 text-center">
          <FileText className="w-5 h-5 mx-auto mb-2 text-blue-400" />
          <p className="text-lg font-bold text-neutral-100">{entriesCount}</p>
          <p className="text-xs text-neutral-400">Entries</p>
        </div>

        <div className="glass-effect rounded-lg p-3 text-center">
          <CheckCircle className="w-5 h-5 mx-auto mb-2 text-green-400" />
          <p className="text-lg font-bold text-neutral-100">{verifiedCount}</p>
          <p className="text-xs text-neutral-400">Verified</p>
        </div>

        <div className="glass-effect rounded-lg p-3 text-center">
          <TrendingUp className="w-5 h-5 mx-auto mb-2 text-purple-400" />
          <p className="text-lg font-bold text-neutral-100">
            {entriesCount > 0 ? Math.round((verifiedCount / entriesCount) * 100) : 0}%
          </p>
          <p className="text-xs text-neutral-400">Quality</p>
        </div>
      </div>

      <div className="mt-4 space-y-2">
        <div className="flex justify-between text-sm">
          <span className="text-neutral-400">Next tier at:</span>
          <span className="text-neutral-200">
            {score > 80 ? 'Max tier reached!' : 
             score > 60 ? '81% (Diamond)' : 
             score > 40 ? '61% (Gold)' : '41% (Silver)'}
          </span>
        </div>
        {score <= 80 && (
          <div className="text-xs text-neutral-500">
            Add {score > 60 ? 'more verified entries' : score > 40 ? 'diverse content types' : 'quality entries'} to reach the next tier
          </div>
        )}
      </div>
    </div>
  );
}