import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, StopCircle, RefreshCw, Trash2, Terminal, Cpu, HardDrive, MemoryStick } from 'lucide-react';
import { Progress } from "@/components/ui/progress";

const initialNodes = [
  { id: 'peer0.org1.example.com', type: 'Peer', status: 'running', uptime: '12d 4h 15m', version: '2.5.1', cpu: 15, mem: 45, disk: 60 },
  { id: 'orderer.example.com', type: 'Orderer', status: 'running', uptime: '28d 1h 5m', version: '2.5.1', cpu: 25, mem: 60, disk: 45 },
  { id: 'ca.org1.example.com', type: 'Certificate Authority', status: 'running', uptime: '28d 1h 10m', version: '1.5.6', cpu: 5, mem: 25, disk: 20 },
  { id: 'peer1.org1.example.com', type: 'Peer', status: 'stopped', uptime: 'N/A', version: '2.5.1', cpu: 0, mem: 0, disk: 58 },
];

const generateLog = (nodeId) => {
    const levels = ['INFO', 'WARN', 'ERROR'];
    const components = ['gossip', 'msp', 'ledger', 'endorser', 'comm'];
    const level = levels[Math.floor(Math.random() * levels.length)];
    const component = components[Math.floor(Math.random() * components.length)];
    return `${new Date().toISOString()} [${component}] ${level} -> [${nodeId}] This is a sample log entry detailing an operation or status change. Random number: ${Math.random().toFixed(5)}`;
}

const NodeCard = ({ node, onAction, onSelectLogs }) => {
    const getStatusColor = (status) => {
        if (status === 'running') return 'text-green-400';
        if (status === 'stopped') return 'text-red-400';
        return 'text-yellow-400';
    }

    return (
        <Card className="glass-card hover:border-blue-500/50 transition-all">
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <CardTitle className="text-lg">{node.id}</CardTitle>
                        <p className="text-sm text-neutral-400">{node.type}</p>
                    </div>
                    <Badge className={`capitalize ${getStatusColor(node.status).replace('text-', 'bg-').replace('-400', '/20')} ${getStatusColor(node.status)}`}>
                        {node.status}
                    </Badge>
                </div>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="text-xs text-neutral-500">
                    <p>Uptime: {node.uptime}</p>
                    <p>Version: {node.version}</p>
                </div>
                <div className="space-y-2">
                    <div className="flex items-center gap-2">
                        <Cpu className="w-4 h-4 text-neutral-400" />
                        <Progress value={node.cpu} className="w-full h-2" />
                        <span className="text-xs w-8">{node.cpu}%</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <MemoryStick className="w-4 h-4 text-neutral-400" />
                        <Progress value={node.mem} className="w-full h-2" />
                         <span className="text-xs w-8">{node.mem}%</span>
                    </div>
                    <div className="flex items-center gap-2">
                        <HardDrive className="w-4 h-4 text-neutral-400" />
                        <Progress value={node.disk} className="w-full h-2" />
                         <span className="text-xs w-8">{node.disk}%</span>
                    </div>
                </div>
                <div className="flex justify-between items-center pt-2">
                    <div className="flex gap-1">
                        <Button size="icon" variant="ghost" onClick={() => onAction(node.id, 'start')} disabled={node.status === 'running'}>
                            <Play className="w-4 h-4 text-green-400" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => onAction(node.id, 'stop')} disabled={node.status !== 'running'}>
                            <StopCircle className="w-4 h-4 text-yellow-400" />
                        </Button>
                        <Button size="icon" variant="ghost" onClick={() => onAction(node.id, 'restart')}>
                            <RefreshCw className="w-4 h-4 text-blue-400" />
                        </Button>
                    </div>
                    <Button variant="outline" size="sm" onClick={() => onSelectLogs(node.id)}>
                        <Terminal className="w-4 h-4 mr-2" /> Logs
                    </Button>
                </div>
            </CardContent>
        </Card>
    )
}

export default function IBMFabricBackend() {
    const [nodes, setNodes] = useState(initialNodes);
    const [selectedLogNode, setSelectedLogNode] = useState(initialNodes[0].id);
    const [logs, setLogs] = useState([]);
    const logIntervalRef = useRef(null);

    useEffect(() => {
        // Simulate resource usage changes
        const resourceInterval = setInterval(() => {
            setNodes(prevNodes => prevNodes.map(n => {
                if (n.status === 'running') {
                    return {
                        ...n,
                        cpu: Math.max(5, Math.min(95, n.cpu + Math.floor(Math.random() * 7) - 3)),
                        mem: Math.max(20, Math.min(95, n.mem + Math.floor(Math.random() * 5) - 2)),
                    }
                }
                return n;
            }));
        }, 3000);

        return () => clearInterval(resourceInterval);
    }, []);

    useEffect(() => {
        if (logIntervalRef.current) {
            clearInterval(logIntervalRef.current);
        }

        if(selectedLogNode) {
            setLogs([generateLog(selectedLogNode)]); // Start with one log
            logIntervalRef.current = setInterval(() => {
                setLogs(prev => [generateLog(selectedLogNode), ...prev.slice(0, 100)]);
            }, 1500);
        }

        return () => clearInterval(logIntervalRef.current);

    }, [selectedLogNode]);


    const handleNodeAction = (nodeId, action) => {
        setNodes(prevNodes => prevNodes.map(n => {
            if (n.id === nodeId) {
                switch(action) {
                    case 'start': return {...n, status: 'running'};
                    case 'stop': return {...n, status: 'stopped', cpu: 0, mem: 0, uptime: 'N/A'};
                    case 'restart': 
                        // Quick restart simulation
                        setTimeout(() => setNodes(curr => curr.map(cn => cn.id === nodeId ? {...cn, status: 'running'} : cn)), 1000);
                        return {...n, status: 'restarting'};
                    default: return n;
                }
            }
            return n;
        }));
    };

    return (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-6">
                <Card className="glass-card">
                    <CardHeader>
                        <CardTitle>Fabric Backend Nodes</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-neutral-400 text-sm mb-4">
                            Real-time monitoring and lifecycle management of core Hyperledger Fabric services.
                        </p>
                    </CardContent>
                </Card>
                {nodes.map(node => (
                    <NodeCard key={node.id} node={node} onAction={handleNodeAction} onSelectLogs={setSelectedLogNode} />
                ))}
            </div>
            <div>
                 <Card className="glass-card h-full flex flex-col">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                           <Terminal className="w-5 h-5 text-purple-400" /> Live Logs: {selectedLogNode}
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="flex-grow overflow-hidden">
                        <div className="bg-black rounded-lg p-4 h-full overflow-y-auto font-mono text-xs text-neutral-300">
                            {logs.map((log, i) => (
                                <p key={i} className={`${log.includes('ERROR') ? 'text-red-400' : log.includes('WARN') ? 'text-yellow-400' : ''}`}>
                                    {log}
                                </p>
                            ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}