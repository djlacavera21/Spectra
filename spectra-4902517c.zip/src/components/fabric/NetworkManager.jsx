
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Server, 
  Database, 
  Network,
  Play,
  StopCircle, // Changed from Stop to StopCircle
  Settings,
  Activity,
  CheckCircle,
  AlertTriangle
} from "lucide-react";

export default function NetworkManager() {
  const [peers] = useState([
    { id: 'peer0.org1.spectra.com', status: 'running', port: 7051, ledgerHeight: 892 },
    { id: 'peer1.org1.spectra.com', status: 'running', port: 8051, ledgerHeight: 892 }
  ]);

  const [orderers] = useState([
    { id: 'orderer.spectra.com', status: 'running', port: 7050, type: 'solo' }
  ]);

  const [channels] = useState([
    { name: 'spectrachannel', peers: 2, chaincodes: 3, blocks: 892 },
    { name: 'testchannel', peers: 1, chaincodes: 1, blocks: 45 }
  ]);

  return (
    <div className="space-y-6">
      {/* Network Topology */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-xl font-bold text-neutral-100 mb-4">Network Topology</h3>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Peers */}
          <div>
            <h4 className="font-medium text-neutral-200 mb-3 flex items-center gap-2">
              <Server className="w-4 h-4 text-blue-400" />
              Peer Nodes
            </h4>
            <div className="space-y-3">
              {peers.map(peer => (
                <div key={peer.id} className="glass-effect rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-neutral-200">{peer.id}</span>
                    <Badge className="bg-green-500/20 text-green-400">{peer.status}</Badge>
                  </div>
                  <div className="text-xs text-neutral-400 space-y-1">
                    <p>Port: {peer.port}</p>
                    <p>Ledger Height: {peer.ledgerHeight}</p>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Activity className="w-3 h-3 mr-1" />
                      Logs
                    </Button>
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Orderers */}
          <div>
            <h4 className="font-medium text-neutral-200 mb-3 flex items-center gap-2">
              <Database className="w-4 h-4 text-green-400" />
              Orderer Nodes
            </h4>
            <div className="space-y-3">
              {orderers.map(orderer => (
                <div key={orderer.id} className="glass-effect rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-neutral-200">{orderer.id}</span>
                    <Badge className="bg-green-500/20 text-green-400">{orderer.status}</Badge>
                  </div>
                  <div className="text-xs text-neutral-400 space-y-1">
                    <p>Port: {orderer.port}</p>
                    <p>Type: {orderer.type}</p>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Activity className="w-3 h-3 mr-1" />
                      Logs
                    </Button>
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Settings className="w-3 h-3 mr-1" />
                      Config
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Channels */}
          <div>
            <h4 className="font-medium text-neutral-200 mb-3 flex items-center gap-2">
              <Network className="w-4 h-4 text-purple-400" />
              Channels
            </h4>
            <div className="space-y-3">
              {channels.map(channel => (
                <div key={channel.name} className="glass-effect rounded-lg p-3">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-neutral-200">{channel.name}</span>
                    <Badge className="bg-purple-500/20 text-purple-400">Active</Badge>
                  </div>
                  <div className="text-xs text-neutral-400 space-y-1">
                    <p>Peers: {channel.peers}</p>
                    <p>Chaincodes: {channel.chaincodes}</p>
                    <p>Blocks: {channel.blocks}</p>
                  </div>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Activity className="w-3 h-3 mr-1" />
                      Explorer
                    </Button>
                    <Button size="sm" className="bg-white/10 text-neutral-200 hover:bg-white/20 text-xs">
                      <Settings className="w-3 h-3 mr-1" />
                      Manage
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Network Controls */}
      <div className="glass-card rounded-xl p-6">
        <h3 className="text-xl font-bold text-neutral-100 mb-4">Network Controls</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Button className="bg-green-600 hover:bg-green-700 text-white h-12">
            <Play className="w-4 h-4 mr-2" />
            Start Network
          </Button>
          <Button className="bg-red-600 hover:bg-red-700 text-white h-12">
            <StopCircle className="w-4 h-4 mr-2" /> {/* Changed from Stop to StopCircle */}
            Stop Network
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white h-12">
            <Network className="w-4 h-4 mr-2" />
            Add Peer
          </Button>
          <Button className="bg-purple-600 hover:bg-purple-700 text-white h-12">
            <Database className="w-4 h-4 mr-2" />
            Create Channel
          </Button>
        </div>
      </div>
    </div>
  );
}
