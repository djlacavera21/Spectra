
import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Code, FileText, Download, CheckCircle } from "lucide-react";

const CONTRACT_TEMPLATES = {
  'spec-token': {
    name: 'SPEC Token Contract',
    description: 'ERC-20 like token contract for SPEC tokens',
    language: 'nodejs',
    functions: ['initLedger', 'mint', 'transfer', 'balanceOf', 'burn'],
    complexity: 'Advanced'
  },
  'marketplace': {
    name: 'Digital Marketplace',
    description: 'NFT and digital asset marketplace contract',
    language: 'nodejs',
    functions: ['createAsset', 'transferAsset', 'listForSale', 'purchase'],
    complexity: 'Intermediate'
  },
  'supply-chain': {
    name: 'Supply Chain Tracking',
    description: 'Track products through supply chain',
    language: 'go',
    functions: ['createProduct', 'updateLocation', 'transferOwnership', 'getHistory'],
    complexity: 'Intermediate'
  },
  'identity': {
    name: 'Identity Management',
    description: 'Decentralized identity verification',
    language: 'java',
    functions: ['createIdentity', 'verifyIdentity', 'updateCredentials', 'revokeAccess'],
    complexity: 'Advanced'
  },
  'voting': {
    name: 'Voting System',
    description: 'Secure and transparent voting mechanism',
    language: 'nodejs',
    functions: ['createElection', 'castVote', 'tallyVotes', 'getResults'],
    complexity: 'Basic'
  },
  'custom': {
    name: 'Custom Contract',
    description: 'Start with a blank template',
    language: 'nodejs',
    functions: [],
    complexity: 'Custom'
  }
};

export default function NewSmartContractModal({ isOpen, onClose, onSuccess }) {
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [contractName, setContractName] = useState('');
  const [contractDescription, setContractDescription] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('nodejs');
  const [isCreating, setIsCreating] = useState(false);

  const handleCreateContract = async () => {
    if (!selectedTemplate || !contractName) {
      alert('Please select a template and enter a contract name');
      return;
    }

    setIsCreating(true);

    // Simulate contract creation
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Generate contract code based on template
    const template = CONTRACT_TEMPLATES[selectedTemplate];
    
    alert(`Smart contract "${contractName}" created successfully!\nTemplate: ${template.name}\nLanguage: ${template.language}\nFunctions: ${template.functions.join(', ')}`);

    setIsCreating(false);
    onSuccess();
  };

  const handleTemplateSelect = (templateKey) => {
    setSelectedTemplate(templateKey);
    const template = CONTRACT_TEMPLATES[templateKey];
    setSelectedLanguage(template.language);
    setContractDescription(template.description);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="glass-card max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-neutral-100 flex items-center gap-2">
            <Code className="w-5 h-5 text-blue-400" />
            Create New Smart Contract
          </DialogTitle>
          <DialogDescription className="text-neutral-400">
            Choose a template to quickly start developing your Hyperledger Fabric smart contract
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Template Selection */}
          <div>
            <Label className="text-neutral-300 mb-3 block">Choose Contract Template</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(CONTRACT_TEMPLATES).map(([key, template]) => (
                <div
                  key={key}
                  onClick={() => handleTemplateSelect(key)}
                  className={`glass-effect rounded-lg p-4 cursor-pointer transition-all ${
                    selectedTemplate === key 
                      ? 'border-blue-500 bg-blue-500/10' 
                      : 'border-white/20 hover:border-white/30'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-medium text-neutral-200">{template.name}</h4>
                    <div className="flex gap-2">
                      <Badge className={`text-xs ${
                        template.complexity === 'Basic' ? 'bg-green-500/20 text-green-400' :
                        template.complexity === 'Intermediate' ? 'bg-yellow-500/20 text-yellow-400' :
                        template.complexity === 'Advanced' ? 'bg-red-500/20 text-red-400' :
                        'bg-purple-500/20 text-purple-400'
                      }`}>
                        {template.complexity}
                      </Badge>
                      <Badge className="bg-blue-500/20 text-blue-400 text-xs">
                        {template.language.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-neutral-400 mb-3">{template.description}</p>
                  {template.functions.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {template.functions.slice(0, 3).map(func => (
                        <Badge key={func} variant="outline" className="text-xs border-white/20 text-neutral-400">
                          {func}()
                        </Badge>
                      ))}
                      {template.functions.length > 3 && (
                        <Badge variant="outline" className="text-xs border-white/20 text-neutral-400">
                          +{template.functions.length - 3} more
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Contract Details */}
          {selectedTemplate && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="contractName" className="text-neutral-300">Contract Name *</Label>
                  <Input
                    id="contractName"
                    placeholder="e.g., my-token-contract"
                    value={contractName}
                    onChange={(e) => setContractName(e.target.value)}
                    className="bg-white/5 border-white/20 text-neutral-100"
                  />
                </div>
                <div>
                  <Label htmlFor="language" className="text-neutral-300">Programming Language</Label>
                  <Select value={selectedLanguage} onValueChange={setSelectedLanguage}>
                    <SelectTrigger className="bg-white/5 border-white/20 text-neutral-100">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="glass-card">
                      <SelectItem value="nodejs">Node.js</SelectItem>
                      <SelectItem value="go">Go</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="description" className="text-neutral-300">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what this smart contract does..."
                  value={contractDescription}
                  onChange={(e) => setContractDescription(e.target.value)}
                  className="bg-white/5 border-white/20 text-neutral-100 h-20"
                />
              </div>

              {/* Contract Preview */}
              <div className="glass-effect rounded-lg p-4">
                <h4 className="font-medium text-neutral-200 mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Contract Preview
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Template:</span>
                    <span className="text-neutral-200">{CONTRACT_TEMPLATES[selectedTemplate].name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Language:</span>
                    <span className="text-neutral-200">{selectedLanguage.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Functions:</span>
                    <span className="text-neutral-200">{CONTRACT_TEMPLATES[selectedTemplate].functions.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Complexity:</span>
                    <span className="text-neutral-200">{CONTRACT_TEMPLATES[selectedTemplate].complexity}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex justify-end gap-3 pt-4 border-t border-white/10">
            <Button 
              variant="outline" 
              onClick={onClose}
              className="bg-white text-black hover:bg-neutral-200"
            >
              Cancel
            </Button>
            <Button
              onClick={handleCreateContract}
              disabled={!selectedTemplate || !contractName || isCreating}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isCreating ? (
                <div className="flex items-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Creating Contract...
                </div>
              ) : (
                <>
                  <CheckCircle className="w-4 h-4 mr-2" />
                  Create Smart Contract
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
